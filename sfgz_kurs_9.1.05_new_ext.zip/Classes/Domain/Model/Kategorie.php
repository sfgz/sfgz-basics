<?php
namespace Sfgz\SfgzKurs\Domain\Model;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Kategorie
 */
class Kategorie extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * kategorieGruppe
     *
     * @var int
     */
    protected $kategorieGruppe = 0;

    /**
     * kategorieName
     *
     * @var string
     * @validate NotEmpty
     */
    protected $kategorieName = '';

    /**
     * reihenfolge
     *
     * @var int
     */
    protected $reihenfolge = 0;

    /**
     * Returns the kategorieGruppe
     *
     * @return int $kategorieGruppe
     */
    public function getKategorieGruppe()
    {
        return $this->kategorieGruppe;
    }

    /**
     * Sets the kategorieGruppe
     *
     * @param int $kategorieGruppe
     * @return void
     */
    public function setKategorieGruppe($kategorieGruppe)
    {
        $this->kategorieGruppe = $kategorieGruppe;
    }

    /**
     * Returns the kategorieName
     *
     * @return string $kategorieName
     */
    public function getKategorieName()
    {
        return $this->kategorieName;
    }

    /**
     * Sets the kategorieName
     *
     * @param string $kategorieName
     * @return void
     */
    public function setKategorieName($kategorieName)
    {
        $this->kategorieName = $kategorieName;
    }

    /**
     * Returns the reihenfolge
     *
     * @return int $reihenfolge
     */
    public function getReihenfolge()
    {
        return $this->reihenfolge;
    }

    /**
     * Sets the reihenfolge
     *
     * @param int $reihenfolge
     * @return void
     */
    public function setReihenfolge($reihenfolge)
    {
        $this->reihenfolge = $reihenfolge;
    }
}
