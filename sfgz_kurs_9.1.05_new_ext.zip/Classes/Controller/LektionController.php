<?php
namespace Sfgz\SfgzKurs\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * LektionController
 */
class LektionController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    
    /**
     * propertiesToSkip
     *
     * @var array
     */
    protected $propertiesToSkip = null;
    
    /**
     * durchfuehrungRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\DurchfuehrungRepository
     */
    protected $durchfuehrungRepository = null;
    
    /**
     * lektionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\LektionRepository
     * @inject
     */
    protected $lektionRepository = null;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 */
	protected $persistenceManager = NULL;

    /**
     * timeZoneString
     *
     * @var string
     */
    protected $timeZoneString = 'Europe/Zurich';

    /**
     * initialize
     *
     * @return void
     */
    public function initializeAction()
    {
		$this->timeZone = new \DateTimeZone( $this->timeZoneString );
		
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		$this->durchfuehrungRepository = $objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\DurchfuehrungRepository');
	    $this->durchfuehrungRepository->setDefaultQuerySettings($querySettings);
    }
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $lektions = $this->lektionRepository->findAll();
        $this->view->assign('lektions', $lektions);
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {
		if( $this->request->hasArgument('durchfuehrung') ) {
			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
			$this->view->assign('durchfuehrung', $this->request->getArgument('durchfuehrung') );
		}
    }

    /**
     * initializeCreate
     *
     * @return void
     */
    public function initializeCreateAction()
    {
		if ($this->request->hasArgument('newLektion')) {
			$trmArg = $this->request->getArgument('newLektion');
			$arg = $this->arguments->getArgument('newLektion')->getPropertyMappingConfiguration();
			if( empty($trmArg['lektionDatum']) ){
			    $arg->skipProperties('lektionDatum');
				$this->propertiesToSkip['lektionDatum'] = 1;
			}else{
			      $arg->forProperty('lektionDatum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
		}
    }

    /**
     * action create
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Lektion $newLektion
     * @return void
     */
    public function createAction(\Sfgz\SfgzKurs\Domain\Model\Lektion $newLektion)
    {
        if( $this->request->hasArgument('abort') ) $this->redirect('edit', 'Durchfuehrung', NULL, array('durchfuehrung' => $newLektion->getDurchfuehrung() ) );

        $newLektion = $this->sanitiezeDateAndLessons($newLektion);
        
        $this->addFlashMessage('Die Lektion wurde erstellt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        $this->lektionRepository->add($newLektion);
        $this->persistenceManager->persistAll();
       $this->redirect('edit', NULL, NULL, array('lektion' => $newLektion ) );
    }

    /**
     * action edit
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Lektion $lektion
     * @ignorevalidation $lektion
     * @return void
     */
    public function editAction(\Sfgz\SfgzKurs\Domain\Model\Lektion $lektion)
    {
        $durchfUid = $lektion->getDurchfuehrung();
        $objDurchfuehrung = $this->durchfuehrungRepository->findByUid( $durchfUid );
        $this->view->assign('durchfuehrung', $objDurchfuehrung );
        $this->view->assign('lektion', $lektion);
    }

    /**
     * initializeUpdate
     *
     * @return void
     */
    public function initializeUpdateAction()
    {
		if ($this->request->hasArgument('lektion')) {
			$trmArg = $this->request->getArgument('lektion');
			$arg = $this->arguments->getArgument('lektion')->getPropertyMappingConfiguration();
			if( empty($trmArg['lektionDatum']) ){
 					$arg->skipProperties('lektionDatum');
 					$this->propertiesToSkip['lektionDatum'] = 1;
			}else{
					$arg->forProperty('lektionDatum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
		}
    }

    /**
     * sanitiezeDateAndLessons
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Lektion $lektion
     * @return \Sfgz\SfgzKurs\Domain\Model\Lektion
     */
    public function sanitiezeDateAndLessons(\Sfgz\SfgzKurs\Domain\Model\Lektion $lektion)
    {
		$objDate = $lektion->getLektionDatum();
		$lektion->setLektionDatum( new \DateTime($objDate->format('Y-m-d 12:00'),$this->timeZone) );
		$this->importfunctionsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ImportfunctionsUtility');
		$options = $lektion->getZeitVon() . ',' . $lektion->getZeitBis();
		$lektionenzahl = $this->importfunctionsUtility->import_lessonsCount( $options  );
		$aktLekt = $lektion->getLektionenzahl();
		if( empty( $aktLekt) ) $lektion->setLektionenzahl( $lektionenzahl );
		return $lektion;
    }

    /**
     * action update
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Lektion $lektion
     * @return void
     */
    public function updateAction(\Sfgz\SfgzKurs\Domain\Model\Lektion $lektion)
    {
        if( $this->request->hasArgument('abort') ) $this->redirect('edit', 'Durchfuehrung', NULL, array('durchfuehrung' => $lektion->getDurchfuehrung() ) );

        $lektion = $this->sanitiezeDateAndLessons($lektion);
        $GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        $this->addFlashMessage('Die Lektion wurde gespeichert.' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        $this->lektionRepository->update($lektion);
       $this->redirect('edit', NULL, NULL, array('lektion' => $lektion ) );
    }

    /**
     * action delete
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Lektion $lektion
     * @return void
     */
    public function deleteAction(\Sfgz\SfgzKurs\Domain\Model\Lektion $lektion)
    {
        $durchfuehrung = $lektion->getDurchfuehrung();
        $this->addFlashMessage('Die Lektion wurde entfernt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->lektionRepository->remove($lektion);
        $this->redirect('edit', 'Durchfuehrung', NULL, array('durchfuehrung' => $durchfuehrung ) );
    }

}
