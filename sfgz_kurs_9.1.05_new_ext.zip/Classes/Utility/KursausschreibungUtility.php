<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class KursausschreibungUtility
 * 
 * 
 */
 
class KursausschreibungUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * Property settings
	 *
	 * @var array
	 */
	protected $settings = NULL;
	
	/**
	 * Property aObjTables
	 *
	 * @var array
	 */
	protected $aObjTables = NULL;
	
	/**
	 * Property aHtmlReplace
	 *
	 * @var array
	 */
	protected $aHtmlReplace = [
		'linebreak' => [ 
							'<b>'=> '', 
							'</b>'=> '', 
							'<li>'=> '- ', 
							'<LI>'=> '- ', 
							'</li>'=>    "</w:t><w:br/><w:t>" , 
							'</LI>'=>    "</w:t><w:br/><w:t>" , 
							'<br>'=>     "</w:t><w:br/><w:t>" , 
							'<BR>'=>     "</w:t><w:br/><w:t>" , 
							'<br />'=>   "</w:t><w:br/><w:t>" , 
							'<BR />'=>   "</w:t><w:br/><w:t>" , 
							'<p>'=>'' , 
							'<P>'=>'' , 
							'</p>'=>"</P>" , 
							'</P>'=>"</w:t></w:r></w:p><w:p><w:r><w:t>" , 
							'<ul>'=>'' , 
							'<UL>'=>'' , 
							'</ul>'=>"</UL>", 
							'</UL>'=>"</w:t></w:r></w:p><w:p><w:r><w:t>"
					],
		'search'=> [ 
							'&apos;' ,
							'&quot;' ,
							'&nbsp;' ,
							'&' ,
							'&amp;gt;' ,
							'&amp;lt;' 
					],
		'replace'=> [ 
							"'" ,
							'"' ,
							' ',
							'&amp;',
							'&gt;',
							'&lt;'
					]
	];

	/**
	 * Property placeholder
	 *
	 * @var array
	 */
	protected $placeholder = NULL;
	
	/**
	 * Property kurseingabeOrdner
	 *
	 * @var string
	 */
	Public $kurseingabeOrdner = NULL;
	
	/**
	 * Property kurseingabeDatei
	 *
	 * @var string
	 */
	Public $kurseingabeDatei = NULL;
	
	/**
	 * Property downloadFolder
	 *
	 * @var string
	 */
	protected $downloadFolder = NULL;

    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     */
    protected $kursRepository = null;

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_conf';

    /**
     * fileFieldname
     *
     * @var string
     */
    protected $fileFieldname = 'kursauschreibung';

    /**
     * flashMessages
     *
     * @var array
     */
    public $flashMessages = [];
	
	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);

		$this->kursRepository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\KursRepository');
	    $this->kursRepository->setDefaultQuerySettings($querySettings);

	    $this->tableMapperUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\TableMapperUtility');
		$this->filetransferUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\FiletransferUtility');

	    $this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
	    $this->settings = $this->settingsUtility->getSettings( 'tx_sfgzkurs_conf' );

	    $this->initiateFolders();
	}

	/**
	 * AusschreibungVorlage
	 *
     * @param \Sfgz\SfgzKurs\Domain\Model\Version $version
	 * @return void
	 */
	Public function AusschreibungVorlage(\Sfgz\SfgzKurs\Domain\Model\Version $version)
	{
		$kurs = $this->kursRepository->findByUid( $version->getKurs() );
		$this->aObjTables = [ 'kurs' => $kurs , 'version' => $version ];
		
		$this->createPlaceholders();
		
		$pathToNewDocx = $this->downloadFolder . $this->placeholder['#output_document_name#'];
		if ( ! copy($this->kurseingabeOrdner . $this->kurseingabeDatei , $pathToNewDocx)) return false;
		
		$this->substDataInDocxFile( $pathToNewDocx );
		
		return $this->filetransferUtility->downloadFile( $pathToNewDocx , '' , false );

	}
	
	/**
	 * VorlageHochladen
	 *
	 * @return string
	 */
	Public function VorlageHochladen()
	{
			
			if( !$_FILES[$this->pluginKey]['tmp_name'][$this->fileFieldname] ) return false;
		
			$fileName = $_FILES[$this->pluginKey]['name'][$this->fileFieldname];
			if( empty( $fileName ) || empty( $this->kurseingabeOrdner ) ){
				$this->flashMessages[] = 'VorlageHochladen: Keine Datei.';
				return false;
			}
			
			if( strtolower( pathinfo( $fileName , PATHINFO_EXTENSION)) != 'docx' ){
				$this->flashMessages[] = 'VorlageHochladen: Kein gueltiges Word DOCX-Dokument.';
				return false;
			}else{
				$this->filetransferUtility->clearFolder($this->settings['filePaths']['kurseingabe'] );
				GeneralUtility::upload_copy_move( $_FILES[$this->pluginKey]['tmp_name'][$this->fileFieldname] , $this->kurseingabeOrdner . $fileName );
				$this->flashMessages[] = 'VorlageHochladen: ' . $this->kurseingabeOrdner .$fileName . ' hochgeladen.';
				$this->kurseingabeDatei = $fileName;
			}
			
			return $fileName;
	}

	/**
	 * substDataInDocxFile
	 *
     * @param string $pathToDocx
	 * @return void
	 */
	Public function substDataInDocxFile( $pathToDocx )
	{
			$workDir = GeneralUtility::getFileAbsFileName( dirname( $pathToDocx ) ) . '/';
			
			// open docx and extract document.xml with the text-content
			$zip = new \ZipArchive;
			$res = $zip->open($pathToDocx);
			if ($res != TRUE) return false;
			$zip->extractTo( $workDir , array('word/document.xml') );
			
			// read the file and replace placeholders with data in its content
			$xml_document_contents = file_get_contents( $workDir . 'word/document.xml' );
			$new_document_contents = str_replace( array_keys($this->placeholder) , $this->placeholder , $xml_document_contents );
			
			$new_document_contents = $this->removeHtmlTags( $new_document_contents );
			
			$zip->addFromString( "word/document.xml" , $new_document_contents );
			$zip->close();
			$this->filetransferUtility->clearFolder( $this->settings['filePaths']['temp'] . '/word', true );
	}

	/**
	 * removeHtmlTags
	 *
     * @param string $strHtml
	 * @return string
	 */
	Private function removeHtmlTags( $strHtml )
	{
        // remove span and a -tag 
        foreach( [ 'span' , 'a' ] as $tag ) {
            // remove opening tag
            for( $pos = 0 ; $pos < strlen($strHtml) ; ++$pos ){
                $pos = strpos( ' ' . $strHtml , '<' . $tag, $pos );
                if( !$pos ) break;
                $end = strpos( ' ' . $strHtml , '>' , $pos );
                $strHtml = substr( $strHtml , 0 , $pos-1 ) . substr( $strHtml , $end );
                $pos = $end+1;
            }
            // remove closing tag
            $strHtml = str_replace( '</' . $tag . '>' , '' , $strHtml );
        }
        
        return $strHtml;
        
	}


	/**
	 * createPlaceholders
	 *
	 * @return string
	 */
	Public function createPlaceholders()
	{
		// document-name
		if( is_array( $this->settings['kurseingabe']['output_document_name']['source'] ) ) {
			foreach( $this->settings['kurseingabe']['output_document_name']['source'] as $ix => $srcTabFld){
				$sr[ '%' . $ix ] = $this->getFieldValue( $srcTabFld ) . '_' . date( 'ymdHis' ) ;
			}
			$this->placeholder['#output_document_name#'] = str_replace( array_keys($sr) , $sr , $this->settings['kurseingabe']['output_document_name']['pattern'] );
		}else{
			$this->placeholder['#output_document_name#'] = 'kurseingabe.docx';
		}
		
		// example placeholder
		$this->placeholder['#exampletable.example_field#'] = 'This is an example value';

		foreach( $this->aObjTables as $table => $objTable){
				$properties = $objTable->_getProperties() ;
				foreach ( $properties as $key => $value ) {
					if( is_a( $value , 'DateTime' ) ) {
						$value = $value->format('d.m.Y');
					}elseif( is_object( $value ) ) {
						continue;
					}
					$escapedResult = $this->htmlEscape( $value );
					$this->placeholder['#' . $table . '.' . GeneralUtility::camelCaseToLowerCaseUnderscored($key) . '#'] = $escapedResult;
				}
		}
		$this->placeholder_kurs_katergorien();
	}


	/**
	 * htmlEscape
	 * transform html-entities and html-tags
	 * Docx-Documents do not like entities (eg. &nbsp;) and <br> linebreak-tags
	 *
	 * @param string $value
	 * @return string
	 */
	Public function htmlEscape( $value )
	{
		$entitiesToLinebraks0 = str_replace(
			"\r\n",
			'',
			$value
		);
		$entitiesToLinebraks0 = str_replace(
			"\n",
			'',
			$entitiesToLinebraks0
		);
		$entitiesToLinebraks0 = str_replace(
			"\r",
			'',
			$entitiesToLinebraks0
		);
		$entitiesToChar = str_replace(
			$this->aHtmlReplace['search'],
			$this->aHtmlReplace['replace'],
			$entitiesToLinebraks0
		);
		$entitiesToLinebraks2 = str_replace(
			array_keys( $this->aHtmlReplace['linebreak'] ),
			$this->aHtmlReplace['linebreak'],
			$entitiesToChar
		);
		return $entitiesToLinebraks2;
	}

	/**
	 * placeholder_kurs_katergorien
	 * helper for createPlaceholders()
	 *
     * @param array $aData
	 * @return string
	 */
	Public function placeholder_kurs_katergorien()
	{
		$aObjsKats = $this->getFieldValue( 'kurs.k_kategorien' );
		foreach( $aObjsKats as $objKat ){
			$this->aObjTables['kategorie'] = $objKat;
			$aKats[] = $this->getFieldValue( 'kategorie.kategorie_name' );
		}

		if( count( $aKats ) ) {
			$this->placeholder['#kurs.kategorien#'] = implode( ', ' , $aKats );
		}else{
			$this->placeholder['#kurs.kategorien#'] = '';
		}
	}


	/**
	 * getFieldValue
	 *
     * @param string $tabFld
	 * @return string
	 */
	Public function getFieldValue( $tabFld )
	{
		$aTabFld = explode( '.' , $tabFld );
		$object = trim($aTabFld[0]);
		$sql_fieldname = trim($aTabFld[1]);
		$method = 'get' . ucFirst(GeneralUtility::underscoredToLowerCamelCase( $sql_fieldname ));
		if( !method_exists( $this->aObjTables[$object] , $method ) ) return 'no method '. $method . '() in ' . $object;
		$cellContent =  $this->aObjTables[$object]->$method();
		// dateTime object
		if (is_a($cellContent, 'DateTime')) return $cellContent->format('d.m.Y');
		return  $cellContent ;
	}

	/**
	 * initiateFolders
	 * started in constructor
	 *
     * @param array $aData
	 * @return string
	 */
	Public function initiateFolders()
	{
	    $uploadDir = rtrim(PATH_site, '/') . '/';
	    $uploadDir .= trim($this->settings['filePaths']['subfolder'], '/');
		$uploadFolder =  GeneralUtility::getFileAbsFileName($uploadDir) . '/';
		$this->filetransferUtility->createDirectory( $uploadFolder );
		
		$this->kurseingabeOrdner =  $uploadFolder . $this->settings['filePaths']['kurseingabe'] . '/' ;
		$this->filetransferUtility->createDirectory( $this->kurseingabeOrdner );
		
		$this->downloadFolder = $uploadFolder . $this->settings['filePaths']['temp'] . '/' ;
		$this->filetransferUtility->createDirectory( $this->downloadFolder );
		
		// look up for the first file in upload-directory.
		$firstFile = '';
		$filesInDir = $this->filetransferUtility->getFileList( $this->settings['filePaths']['kurseingabe'] );
		if( is_array($filesInDir) && count($filesInDir) ) $firstFile = array_shift( array_keys($filesInDir) );
		if( $firstFile ) {
			$this->kurseingabeDatei = $firstFile;
		}else{
			// if no file is in the upload-directory, then create a copy of the original
			$pathToTemplates = 'typo3conf/ext/sfgz_kurs/Resources/Public/templates/';
			$pathToOriginalDocx = GeneralUtility::getFileAbsFileName( $pathToTemplates . 'AusschreibungVorlage.docx' ); // zipped template file
			if( !file_exists($pathToOriginalDocx) ) return;
			$this->kurseingabeDatei = pathinfo( $pathToOriginalDocx , PATHINFO_BASENAME );
			copy( $pathToOriginalDocx , $this->kurseingabeOrdner . $this->kurseingabeDatei );
		}

		
	}

}
