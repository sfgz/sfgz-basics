<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class ImportUtility
 * 
 * 
 */
 
class ImportUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
     * flashMessages
     *
     * @var array
     */
    protected $flashMessages = null;

    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     */
    Public $kursRepository = null;

    /**
     * versionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\VersionRepository
     */
    protected $versionRepository = null;
    
    /**
     * durchfuehrungRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\DurchfuehrungRepository
     */
    protected $durchfuehrungRepository = null;

    /**
     * lektionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\LektionRepository
     */
    protected $lektionRepository = null;

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_lst';

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
	
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');

		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		
		$this->kursRepository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\KursRepository');
	    $this->kursRepository->setDefaultQuerySettings($querySettings);
		
		$this->versionRepository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\VersionRepository');
	    $this->versionRepository->setDefaultQuerySettings($querySettings);
		
		$this->durchfuehrungRepository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\DurchfuehrungRepository');
	    $this->durchfuehrungRepository->setDefaultQuerySettings($querySettings);
		
		$this->lektionRepository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\LektionRepository');
	    $this->lektionRepository->setDefaultQuerySettings($querySettings);
	    
		$this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
	    $this->settings = $this->settingsUtility->getSettings( $this->pluginKey );

		$this->filetransferUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\FiletransferUtility');
		$this->databaseReaderUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\DatabaseReaderUtility');
		$this->configUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ConfigUtility');

		$uploadDir = rtrim(PATH_site, '/') . '/' . trim($this->settings['filePaths']['subfolder'], '/')  . '/' ;
		$this->uploadFolder =  GeneralUtility::getFileAbsFileName($uploadDir);
		$this->filetransferUtility->createDirectory( $this->uploadFolder );

	}

    /**
     *  getImportList 
     *  reads the import file(s) 
     *  and compares the data with database-records if found
     *  and enrich data with configuration from configRecordsets
     *  finally look up for checked tables
     *
     * @return array
     */
    Public function getImportList()
    {
		$this->persistenceManager->persistAll();
		// read import-data from json-file(s) with camelCaseFieldName (domFormattedFieldNames):
		$aFileContents = $this->filetransferUtility->concatFileTables('course');
		
		// appends data from database (camelCaseFieldName):
		$disablingField = $this->databaseReaderUtility->disablingField;
		$this->databaseReaderUtility->disablingField = ''; // unset 'ausblenden' to recognize hidden old records!
		$aFileAndDbContents = $this->databaseReaderUtility->enrichFiletablesWithDbRecords($aFileContents);
		$this->databaseReaderUtility->disablingField = $disablingField; // reset the config in class databaseReader
		
        $aFileDbConfigContents = $this->configUtility->enrichFiletablesWithConfig($aFileAndDbContents);
        
        // read checkbox-settings from json-file and overwrite config
        $aFileDbConfigCheckedContents = $this->enrichFiletablesWithImportSelection($aFileDbConfigContents);
        
		return $aFileDbConfigCheckedContents;
	}

    /**
     *  setImportSelection updates / enriches the importSelection with incoming values
     *  This method stores selection of checkboxes in a json file
     *
     * @param array $aKeyValuePairs
     * @return boolean
     */
    Public function setImportSelection( $aKeyValuePairs )
    {
		if( !is_array($aKeyValuePairs) || !count($aKeyValuePairs) )return false;
		
		$jsonFilename = $this->uploadFolder . $this->settings['filePaths']['selection_filename'];
		if( file_exists($jsonFilename) ){
			$aFileContent = file_get_contents($jsonFilename);
			if( $aFileContent ) $aImportSelectionFileContents = json_decode( $aFileContent , true ) ;
		}
		if( !isset($aImportSelectionFileContents) ){
			$aImportSelectionFileContents = [];
		}
		$z=0;
		foreach( $aKeyValuePairs as $index => $aPairs ) {
			if( !is_array($aPairs) || !count($aPairs) ) continue;
			foreach( $aPairs as $key => $value ) {
				$aImportSelectionFileContents[ $index ][ $key ] = $value;
				++$z;
			}
		}
		file_put_contents( $jsonFilename , json_encode( $aImportSelectionFileContents ) );
		
		return $z > 0 ? true : false;
	}

    /**
     *  resetImportSelection
     *  This method deletes the json file for stored selection of checkboxes
     *
     * @return void
     */
    Public function resetImportSelection()
    {
		$jsonFilename = $this->uploadFolder . $this->settings['filePaths']['selection_filename'];
		if( file_exists( $jsonFilename ) ) @unlink( $jsonFilename );
	}

    /**
     *  getImportSelection 
     *  lists the importSelection
     *  This method reads selection of checkboxes from a json file
     *  returns an array with checkbox-markers for existing db-records like 
     *   array[ $index ][ $table ] = [ 0 | 1 ] 
     *  OR for new db-records or to disable existing db-records 
     *   array[ $index ][ 'general' ] = [ 0 | 1 ] 
     *
     * @return array like array[ $index ][ $table ] = [ 0 | 1 ] OR for new db-records or disabling of existing db-records array[ $index ][ 'general' ] = [ 0 | 1 ] 
     */
    Protected function getImportSelection()
    {
		$aImportSelectionFileContents = [];
		$jsonFilename = $this->uploadFolder . $this->settings['filePaths']['selection_filename'];
		if( file_exists($jsonFilename) ){
			$aFileContent = file_get_contents($jsonFilename);
			if( $aFileContent ) $aImportSelectionFileContents = json_decode( $aFileContent , true ) ;
		}
		return $aImportSelectionFileContents ;
	}

    /**
     *  enrichFiletablesWithImportSelection
     *
     * @param array $aFullData
     * @return array
     */
    Protected function enrichFiletablesWithImportSelection( $aFullData )
    {
		if( !is_array($aFullData) || !count($aFullData) ) return $aFullData;
		$aSelectedPairs = $this->getImportSelection();
		
		// if in orphan mode, take orphan config-db entries for table durchfuehrung
		
		foreach( $aFullData as $index => $rs ){
			$hasOrphan = $rs[ 'general' ]['isOrphan'];
			$selTables = [];
			foreach( $rs as $table => $aTabRow ) {
				if( $table == 'general' ) continue;
				if( $table == 'orphan' ) continue;
				$isOrphansParent = $hasOrphan && ( $table == 'kurs' || $table == 'version' ) ? 1 : 0;
				// check table for this record ($index)
				$intImportAction = isset($rs[ $table ]['table']['orphan']) ? $rs[ $table ]['table']['orphan']['importaction'] : $rs[ $table ]['table']['importaction'];
				$noCheckbox = isset($rs[ $table ]['table']['orphan']['noCheckbox']) ? $rs[ $table ]['table']['orphan']['noCheckbox'] : $rs[ $table ]['table']['noCheckbox'];
				if( empty( $noCheckbox ) && isset( $aSelectedPairs[ $index ][ $table ] ) ){
					// only enrich from checkbox-list if checkbox is enabled and if there is an corresponding item in checkbox-list
					$selTables[$table] = $aSelectedPairs[ $index ][ $table ];
				}else{
					// alway check new records - if set in ts
					if( $table == 'lektion' ){
						if( empty($aFullData[ $index ]['kurs']['table']['dbUid']) ){
							// new lektion: always check if set in ts
							$selTables[$table] = $this->settings['tables'][$table]['alwaysCheckNew'];
						}else{
							if( !isset($aFullData[ $index ]['lektion']['values']['db']) || !count($aFullData[ $index ]['lektion']['values']['db']) ){
								$selTables[$table] = $this->settings['tables'][$table]['alwaysCheckNew'];
							}else{
								// check if value is not 0 (never check) or 6 (lektion add+delete but dont check)) 
								$selTables[$table] = !empty($intImportAction) && $intImportAction != 6 ? 1 : 0;
							}
						}
					}else{
						if( empty($aFullData[ $index ][$table]['table']['dbUid']) ){
							$selTables[$table] = $this->settings['tables'][$table]['alwaysCheckNew'];
						}else{
							// check if value is not 0 (never check) and in case of Orphan-mode: this is not table 'kurs' nor 'version' (=$isOrphansParent)
							$selTables[$table] = !empty($intImportAction) && empty( $isOrphansParent ) ? 1 : 0;
						}
					}
					
				}
				$aFullData[ $index ][ $table ]['table']['checkImport'] = $selTables[$table];
			}
			// general table ist not done until now - do it here.
			if( isset( $aSelectedPairs[ $index ][ 'general' ] ) ){
				$aFullData[ $index ]['general']['checkImport'] = $aSelectedPairs[ $index ][ 'general' ];
			}else{
				$aFullData[ $index ]['general']['checkImport'] = empty($aFullData[ $index ]['kurs']['table']['dbUid']) || array_sum( $selTables ) ? 1 : 0;
			}
		}
		return $aFullData;
	}

    /**
     *  RunImport
     *
     * @param array $aFileDbConfigCheckedContents with full config and checkbox from method getImportList()
     * @return array
     */
    Public function RunImport( $aFileDbConfigCheckedContents )
    {
		
		if( !count($aFileDbConfigCheckedContents) ) return $aFileDbConfigCheckedContents;
		
		// handle orphan imports in own method
		foreach($aFileDbConfigCheckedContents as $kursKey => $kursImportObj ){
			if( empty($kursImportObj['general']['checkImport']) ) continue;
			if( $kursImportObj['general']['isOrphan'] ) {
				$aFileDbConfigCheckedContents[$kursKey] = $this->runImportModeOrphan( $kursImportObj );
			}else{
				$aFileDbConfigCheckedContents[$kursKey] = $this->runImportModeEdit( $kursImportObj );
			}
		}
		//return $this->getImportList();
		
		// if course is already stored then evaluate tables to update in: kurs, version, durchfuehrung. Remove and re-create lektion.
		// if course is not stored yet, then create complete new recordsets for kurs, version, durchfuehrung and lektion.

	}

    /**
     *  runImportModeEdit
     *  actions: edit or add-new 
     *  tables: kurs, version, duchfuehrung, lektion
     *
     * @param array $aFullDataConfSelectedContent with full config and checkbox from method getImportList()
     * @return array
     */
    Protected function runImportModeEdit( $aFullDataConfSelectedContent )
    {
			// decide whitch action has to be done for each table depending on config and checkboxes
			
			// error if kurs exists (this happens when a sibling durchfuehrung was passed before)
			//if( empty( $aFullDataConfSelectedContent['kurs']['table']['dbUid'] ) ){}
			if( !empty($aFullDataConfSelectedContent['kurs']['fields']['kursCode']['csvValue']) ){
				$objExistingCourses = $this->kursRepository->findByKursCode( trim($aFullDataConfSelectedContent['kurs']['fields']['kursCode']['csvValue']) );
				foreach($objExistingCourses as $objKurs){
					$aFullDataConfSelectedContent['kurs']['table']['dbUid'] = $objKurs->getUid();
					break; // only one object anyway
				}
			}
			
			if( empty( $aFullDataConfSelectedContent['kurs']['table']['dbUid'] ) ){
			// case: create all new
					// create kurs
					$objKurs = $this->runImport_createObject( $aFullDataConfSelectedContent , 'kurs' );
					$this->persistenceManager->persistAll();
					$UID['kurs'] = $objKurs->getUid();
					$aFullDataConfSelectedContent['kurs']['table']['dbUid'] = $UID['kurs'];
					$this->flashMessages[] = 'kurs created:' . $UID['kurs'];
			
			}elseif( $aFullDataConfSelectedContent['kurs']['table']['checkImport'] ){
			// case: kurs exists and checked
					// update kurs
					$objKurs = $this->runImport_updateObject( $aFullDataConfSelectedContent , 'kurs' );
					$UID['kurs'] = $objKurs->getUid();
					$this->flashMessages[] = 'kurs updated:' . $UID['kurs'];
					$this->persistenceManager->persistAll();
			}
			
			// like on course, look out for sibling records
			$englishStartDate = $this->filetransferUtility->dateUtility->getStichtag();
			
			// case: if a new version was created with actual stichtag (eg. today)
			if( empty( $aFullDataConfSelectedContent['version']['table']['dbUid'] ) ){
				$kVersionen = $this->versionRepository->findByKurs( $UID['kurs'] );
				foreach( $kVersionen as $objVersion ){
					$objStartDate = $objVersion->getVersionStart();
					if( is_object($objStartDate) ){
						$dbDate = $objStartDate->format('Y-m-d');
						if( $dbDate == $englishStartDate ){
							$UID['version'] = $objVersion->getUid();
						}
					}else{
						if( $objStartDate == $englishStartDate ){
							$UID['version'] = $objVersion->getUid();
						}
					}
				}
				if( isset($UID['version']) && !empty($UID['version']) ) $aFullDataConfSelectedContent['version']['table']['dbUid'] = $UID['version'];
			}else{
				$UID['version'] = $aFullDataConfSelectedContent['version']['table']['dbUid'];
			}
			
			if( !isset( $UID['version'] ) ){
					// create version
					$objVersion = $this->runImport_createObject( 
							$aFullDataConfSelectedContent , 
							'version' , 
							[ 
								'kurs' => $aFullDataConfSelectedContent['kurs']['table']['dbUid'] ,
								'versionStart' => $englishStartDate
							] 
					);
					$this->persistenceManager->persistAll();
					$aFullDataConfSelectedContent['version']['table']['dbUid'] = $objVersion->getUid();
					
			}elseif( $aFullDataConfSelectedContent['version']['table']['checkImport'] ){
			// case: version exists and checked
					// update version
					$objVersion = $this->runImport_updateObject( $aFullDataConfSelectedContent , 'version' );
					$this->persistenceManager->persistAll();
			}
			
			if( !empty($aFullDataConfSelectedContent['durchfuehrung']['table']['dbUid']) ){
				$objDurchfuehrung = $this->durchfuehrungRepository->findByUid( $aFullDataConfSelectedContent['durchfuehrung']['table']['dbUid'] );
				if( !$objDurchfuehrung ) $aFullDataConfSelectedContent['durchfuehrung']['table']['dbUid'] = 0;
			}
			if( empty( $aFullDataConfSelectedContent['durchfuehrung']['table']['dbUid'] ) ){
					// create durchfuehrung
					$objDurchfuehrung = $this->runImport_createObject( $aFullDataConfSelectedContent , 'durchfuehrung' , [ 'version' => $aFullDataConfSelectedContent['version']['table']['dbUid'] ] );
					$this->persistenceManager->persistAll();
					$aFullDataConfSelectedContent['durchfuehrung']['table']['dbUid'] = $objDurchfuehrung->getUid();
					
			}elseif( $aFullDataConfSelectedContent['durchfuehrung']['table']['checkImport'] ){
			// case: durchfuehrung exists and checked
					// update durchfuehrung
					$objDurchfuehrung = $this->runImport_updateObject( $aFullDataConfSelectedContent , 'durchfuehrung' );
					$this->persistenceManager->persistAll();
			}
			
			
			if( $aFullDataConfSelectedContent['lektion']['table']['checkImport'] ){
			// if importaction 6 || 7 then delete first else only append new records
					if( $aFullDataConfSelectedContent['lektion']['table']['importaction'] >= 6 ) {
						$objDurchfuehrung = $this->durchfuehrungRepository->findByUid( $aFullDataConfSelectedContent['durchfuehrung']['table']['dbUid'] );
						$objLektionen = $objDurchfuehrung->getDLektionen();
						foreach($objLektionen as $lektion) $this->lektionRepository->remove($lektion);
					}
					// create lektion
					$this->runImport_createSubObject( $aFullDataConfSelectedContent , 'lektion' , [ 'durchfuehrung' => $aFullDataConfSelectedContent['durchfuehrung']['table']['dbUid'] ] );
					$this->persistenceManager->persistAll();
			}
			
		
		return $aFullDataConfSelectedContent;
			
	}

    /**
     *  runImportModeOrphan
     *  actions: edit 
     *  tables: edit duchfuehrung and add lektion
     *
     * @param array $aFullDataConfSelectedContent with full config and checkbox from method getImportList()
     * @return array
     */
    Protected function runImportModeOrphan( $aFullDataConfSelectedContent )
    {
			if( $aFullDataConfSelectedContent['durchfuehrung']['table']['checkImport'] ){
			// case: durchfuehrung exists and checked
					// only update caluclated fields in durchfuehrung
					$aUpdate['durchfuehrung']['table'] = $aFullDataConfSelectedContent['durchfuehrung']['table'];
					foreach ($aFullDataConfSelectedContent['durchfuehrung']['fields'] as $domFormattedKey => $aField ) {
						if( isset($aField['calcValue']) ) $aUpdate['durchfuehrung']['fields'][$domFormattedKey]['csvValue'] = $aField['calcValue'];
					}
					// update durchfuehrung
					$objDurchfuehrung = $this->runImport_updateObject( $aUpdate , 'durchfuehrung' );
					$this->flashMessages[] = 'durchfuehrung ModeOrphan updated:' . $objDurchfuehrung->getUid();
					$this->persistenceManager->persistAll();
					
			}
			
			// FIXME make lektionen UNIQUE by full fieldset!
			if( $aFullDataConfSelectedContent['lektion']['table']['checkImport'] ){
			// if importaction 6 || 7 then delete first else only append new records
					if( $aFullDataConfSelectedContent['lektion']['table']['importaction'] >= 6 ) {
						$objDurchfuehrung = $this->durchfuehrungRepository->findByUid( $aFullDataConfSelectedContent['durchfuehrung']['table']['dbUid'] );
						$objLektionen = $objDurchfuehrung->getDLektionen();
						foreach($objLektionen as $lektion) $this->lektionRepository->remove($lektion);
						$this->persistenceManager->persistAll();
						if( !$aFullDataConfSelectedContent['durchfuehrung']['table']['checkImport'] ) $this->flashMessages[] = 'lektionen ModeOrphan: REMOVED' ;
					}
					// create lektion
					$this->runImport_createSubObject( $aFullDataConfSelectedContent , 'lektion' , [ 'durchfuehrung' => $aFullDataConfSelectedContent['durchfuehrung']['table']['dbUid'] ] );
					if( !$aFullDataConfSelectedContent['durchfuehrung']['table']['checkImport'] ) $this->flashMessages[] = 'lektionen ModeOrphan: ADDED' ;
					$this->persistenceManager->persistAll();
			}
			
		
		return $aFullDataConfSelectedContent;
	}

    /**
     *  runImport_updateObject
     *
     * @param array $aImportTable
     * @param string $tablename
     * @param array $aNewValuePairs [ 'parenttable' => $intParentUidToAppend , 'fieldname2' => someVal ]
     * @return \TYPO3\CMS\Extbase\Persistence\Repository $editObject
     */
    Protected function runImport_updateObject( $aImportTable , $tablename , $aNewValuePairs = array() )
    {
			$repository = strtolower($tablename) . 'Repository';
			$editObject = $this->$repository->findByUid( $aImportTable[strtolower($tablename)]['table']['dbUid'] );
			
			// insert new values: main work of the method
			foreach ($aImportTable[strtolower($tablename)]['fields'] as $domFormattedKey => $aField ) {
				if( isset($aNewValuePairs[$domFormattedKey]) ) continue;
				$importValue = isset($aField['calcValue']) ? $aField['calcValue']: '' ;
				$dbValue = isset($aField['dbValue']) ? $aField['dbValue']: '' ;
				if( $importValue != $dbValue ) $editObject->_setProperty( $domFormattedKey , $importValue );
			}
				
			// inputValue overrides importValue
			foreach ($aNewValuePairs as $domFormattedKey => $inputValue ) {
				$editObject->_setProperty( $domFormattedKey ,  $inputValue );
			}
			
			$this->$repository->update( $editObject );
			
			return $editObject;
	}

    /**
     *  runImport_createObject
     *
     * @param array $aImportTable
     * @param string $tablename
     * @param array $aNewValuePairs [ 'parenttable' => $intParentUidToAppend , 'fieldname2' => someVal ]
     * @return \TYPO3\CMS\Extbase\Persistence\Repository $newObject
     */
    Protected function runImport_createObject( $aImportTable , $tablename , $aNewValuePairs = array() )
    {
			$aImportList = [];
			foreach ($aImportTable[strtolower($tablename)]['fields'] as $domFormattedKey => $aField ) {
				$importValue = isset($aField['calcValue']) ? $aField['calcValue']: '' ;
				$aImportList[ $domFormattedKey ] = $importValue ;
			}
			return $this->runImport_createObjectFromGivenList( $aImportList , $tablename , $aNewValuePairs );
	}

    /**
     *  runImport_createSubObject
     *
     * @param array $aImportTable
     * @param string $tablename
     * @param array $aNewValuePairs [ 'parenttable' => $intParentUidToAppend , 'fieldname2' => someVal ]
     * @return \TYPO3\CMS\Extbase\Persistence\Repository $newObject
     */
    Protected function runImport_createSubObject( $aImportTable , $tablename , $aNewValuePairs = array() )
    {
			$aImportList = [];
			if( is_array($aImportTable[strtolower($tablename)]['values']['csv']) ){
				foreach ( $aImportTable[strtolower($tablename)]['values']['csv'] as $ix => $aRow ) {
					foreach ($aImportTable[strtolower($tablename)]['fields'] as $domFormattedKey => $aField ) {
						$aImportList[ $ix ][ $domFormattedKey ] = $aRow[$domFormattedKey] ;
					}
					$arrayOfLists[] = $this->runImport_createObjectFromGivenList( $aImportList[ $ix ] , $tablename , $aNewValuePairs );
				}
			}
			return $arrayOfLists;
	}

    /**
     *  runImport_createObjectFromGivenList
     *
     * @param array $aImportList
     * @param string $tablename
     * @param array $aNewValuePairs optional [ 'parenttable' => $intParentUidToAppend , 'fieldname2' => someVal ]
     * @return \TYPO3\CMS\Extbase\Persistence\Repository $newObject
     */
    Protected function runImport_createObjectFromGivenList( $aImportList , $tablename , $aNewValuePairs = array() )
    {
			$repository = strtolower($tablename) . 'Repository';
			
			$newObject = GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\\' . ucFirst($tablename) );
			
			// insert new values: main work of the method
			foreach ($aImportList as $domFormattedKey => $fieldValue ) {
				if( !isset($aNewValuePairs[$domFormattedKey]) ) $newObject->_setProperty( $domFormattedKey , $fieldValue );
			}
				
			// inputValue 'overrides' importValue
			foreach ($aNewValuePairs as $domFormattedKey => $aField ) {
				$newObject->_setProperty( $domFormattedKey ,  $aField );
			}
			
			$this->$repository->add( $newObject );
			
			return $newObject;
	}

    /**
     *  dispatchFlashMessages
     *
     * @param \TYPO3\CMS\Extbase\Mvc\Controller\ActionController $controllerInstance
     * @return array
     */
    Public function dispatchFlashMessages( $controllerInstance )
    {
		if( is_array($this->flashMessages ) && count( $this->flashMessages ) ){
			$controllerInstance->addFlashMessage( implode( ', ' , $this->flashMessages ), 'import', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			unset($this->flashMessages);
        }
		return true;
	}

}
