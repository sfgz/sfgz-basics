<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;
 
 /** 
 * Class KursbestaetigungUtility
 * 
 * 
 */
 
class KursbestaetigungUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * Property settings
	 *
	 * @var array
	 */
	protected $settings = NULL;

	/**
	 * Property dbData
	 *
	 * @var array
	 */
	protected $dbData = NULL;

	/**
	 * Property fileData
	 *
	 * @var array
	 */
	protected $fileData = NULL;

    /**
     * uploadFolder
     *
     * @var string
     */
    protected $uploadFolder = '/uploads/tx_sfgzkurs/';

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_vw';

    /**
     * fileFieldname
     *
     * @var string
     */
    protected $fileFieldname = 'memberlist';

	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
	    $this->spreadsheetUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SpreadsheetUtility');
	    $this->pdfUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\PdfUtility');
	    $this->filetransferUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\FiletransferUtility');
	    
	    // getting settings needs settingsUtility
	    $this->settings = $this->settingsUtility->getSettings( 'tx_sfgzkurs_conf' );
	    // initiating folders needs filetransferUtility
	    $this->initiateFolders();
	}
	
	/**
	 * TeilnehmerlisteHochladen
	 *
	 * @return string
	 */
	Public function TeilnehmerlisteHochladen()
	{
			$this->filetransferUtility->clearFolder( $this->settings['filePaths']['temp']  );
			
			if( !$_FILES[$this->pluginKey]['tmp_name'][$this->fileFieldname] ) return false;
		
			$fileName = $_FILES[$this->pluginKey]['name'][$this->fileFieldname];
			if( empty( $fileName ) || empty( $this->uploadFolder ) ) return false;
			
			GeneralUtility::upload_copy_move( $_FILES[$this->pluginKey]['tmp_name'][$this->fileFieldname] , $this->uploadFolder . $fileName );
			
			return $fileName;
	}
	
	/**
	* BestaetigungPdf
	* 
	* @param string $filename 
	* @param int $durchfuehrungUid 
    * @param \Sfgz\SfgzKurs\Domain\Model\Version $version
	* @return void
	*/
	public function BestaetigungPdf( $filename , $durchfuehrungUid , $version ) {
		// mebmer-data
		$this->getFileContent( $filename );
		if( !$this->fileData || !count( $this->fileData ) ) return;
		
		// course-data
		$this->getDbContent( $durchfuehrungUid , $version );
		if( !count( $this->dbData ) ) return;

		// titles and labels from language-file
		$this->getLocalLanguageContent();
		
		// can be done before or after initializing pdf
		$this->setHeaderData( $this->pdfUtility );
		
		// init pdf settings
		$this->pdfUtility->initializePdf();

		// draw page for each member
		foreach( $this->fileData as $aPerson ) {
			$this->dbData['teilnehmer_namen'] = $aPerson['vorname'] . ' ' . $aPerson['name'];
			$this->singlePage();
		}

		$documentName = urlencode(pathinfo( $filename , PATHINFO_FILENAME ).'.pdf');
		echo $this->pdfUtility->Output( $documentName , 'D' );
		
		exit();

	}

	/**
	* singlePage
	* 
	* @return void
	*/
	public function singlePage() {

		$lh = $this->pdfUtility->pageConf['lfeed'];
		$lh2 = 9;

		$kursleitungName = $this->dbData['kursleitung_vorname'] . ' ' . $this->dbData['kursleitung_nachname'];
		$totalLekt = round( $this->dbData['anzahl_lektionen'] * $this->dbData['anzahl_veranstaltungen'] );
		
		// start drwaing page
		$this->pdfUtility->AddPage();
		
		$this->pdfUtility->SetY( $this->settings['memberlist']['start_body'] );
		$this->pdfUtility->Cell( 0 , $lh , $this->dbData['titel_bestaetigung'] , '' , 1 , 'L' );
		$this->pdfUtility->mkTitle( $this->dbData['titel'] );
		
 		$this->pdfUtility->Ln( $lh2 );
		$this->pdfUtility->mkTitle( $this->dbData['teilnehmer_namen'] );
		
 		$this->pdfUtility->Ln( 11 );
		$this->pdfUtility->Cell( 0 , $lh , $this->dbData['titel_inhalte']  , '' , 1 , 'L' );
		$inh = str_replace( '  ' , ' ' , $this->dbData['kursinhalte']);
		$this->pdfUtility->MultiCell( 0 , $lh , str_replace( '  ' , ' ' , $inh) , '' , 'L' );

		$this->pdfUtility->Ln( 10 );
		$this->pdfUtility->Cell( 0 , 6 , $this->dbData['titel_leitung']  , '' , 1 , 'L' );
		$this->pdfUtility->mkSubTitle( $kursleitungName );
		
 		$this->pdfUtility->Ln( 10 );
		$this->pdfUtility->Cell( 0 , 6 , $this->dbData['titel_dauer']  , '' , 1 , 'L' );
			if( $this->pdfUtility->pageConf['own_fonts']){
				$this->pdfUtility->SetFont( 'HelveticaBlack','' , 14 );
			}else{
				$this->pdfUtility->SetFont( 'Helvetica','' , $this->pdfUtility->pageConf['fsize_subtitle'] );
			}
			$this->pdfUtility->SetFontSpacing( -0.4 );
			
			$w = $this->pdfUtility->GetStringWidth($this->dbData['datum_start']);
			$this->pdfUtility->Cell( $w , $lh , $this->dbData['datum_start'] , '' , 0 , 'L' );
			$w = $this->pdfUtility->GetStringWidth(chr(150));
			$this->pdfUtility->Cell( $w + 0.1 , $lh , chr(150) , '' , 0 , 'L' );
			$this->pdfUtility->Cell( 0 , $lh , $this->dbData['datum_ende'] , '', 1 , 'L'  );
// 		$this->pdfUtility->mkSubTitle( $this->dbData['datum_start'] . '' . chr(150)  . '' . $this->dbData['datum_ende'] );
		
		$this->pdfUtility->mkSubTitle( $totalLekt . ' Lektionen' );
		
 		$this->pdfUtility->drawLinesTillBottom( $this->settings['memberlist']['signature_linebreaks'] );
 		
		$this->pdfUtility->Cell( 0 , $lh , $kursleitungName , '' , 1 , 'L' );
	}
	

	/**
	 * setHeaderData
	 *
	 * @return void
	*/
	protected function setHeaderData( $pdfHandler )
	{
		for( $z=0 ; $z <10 ; ++$z ){
			$utf8cnt = LocalizationUtility::translate( $this->settings['memberlist']['headerText_language_key'] . $z , 'SfgzKurs' );
			if( !$utf8cnt ) break;
			$pdfHandler->headerText[] = $pdfHandler->encode( $utf8cnt );
		}
		
		$pdfHandler->pageConf['imagePath'] = GeneralUtility::getFileAbsFileName( $this->settings['memberlist']['logo_filepathname'] );
		
	}

	/**
	 * getLocalLanguageContent
	 *
	 * @return array
	*/
	protected function getLocalLanguageContent()
	{
		foreach( $this->settings['memberlist']['language_keys'] as $target => $llString ){
			$utf8cnt = LocalizationUtility::translate( $llString , 'SfgzKurs' );
			$this->dbData[$target] = $this->pdfUtility->encode( $utf8cnt );
		}

		return $this->dbData;
	}
	

	/**
	 * getFileContent
	 *
	* @param string $filename 
     * 
	 * @return array
	*/
	protected function getFileContent( $filename )
	{
		if( !file_exists($this->uploadFolder . $filename) || empty($filename) ) return false;
		
		$aSpreadsheet = $this->spreadsheetUtility->fileToArray( $this->uploadFolder . $filename );
		if( !count($aSpreadsheet) ) return false;
		
		$aOut = [];
		foreach( $aSpreadsheet as $ix => $row ){
			foreach( $this->settings['memberlist']['file_source'] as $target => $source ){
				if( isset( $row[$source] ) ) $this->fileData[$ix][$target] = $this->pdfUtility->encode($row[$source]);
			}
		}
		@unlink( $this->uploadFolder . $filename );
		return $this->fileData;
	}

	/**
	 * getDbContent
	 *
	 * @param int $durchfuehrungUid 
     * @param \Sfgz\SfgzKurs\Domain\Model\Version $objVersion
     * 
	 * @return void
	*/
	protected function getDbContent( $durchfuehrungUid , $objVersion )
	{
			if( empty($durchfuehrungUid) ) return false;
			if( !is_object($objVersion) ) return false;
			
			// get the selected durchfuehrung
			$aDrch = $objVersion->getVDurchfuehrungen();
			foreach( $aDrch as $objLoop ){
				if( $durchfuehrungUid == $objLoop->getUid() ){
					$objDurchfuehrung = $objLoop;
					break;
				}
			}
			// glue the two objects in one array
			$sourceTables = [ 'version'=> $objVersion , 'durchfuehrung'=> $objDurchfuehrung ];
			
			// assign data from database to output-array
			foreach( $this->settings['memberlist']['database_source'] as $target => $sourceFields ){
					$aFldList = explode( '.' , $sourceFields['source'] );
					$tablename = trim($aFldList[0]);
					$sql_fieldname = trim($aFldList[1]);
					$objName = GeneralUtility::underscoredToLowerCamelCase( $sql_fieldname );
					$method = 'get' . ucFirst( $objName );
					if( isset( $sourceTables[ $tablename ]) && method_exists( $sourceTables[ $tablename ] , $method ) ){
						$mixRes = $sourceTables[ $tablename ]->$method();
						if( isset($sourceFields['dateformat']) ){
							$this->dbData[$target] = $mixRes->format($sourceFields['dateformat']);
							
						}elseif( $this->settings['tables'][$tablename]['mapFields'][$sql_fieldname]['fieldType'] == 'date' ){
							$this->dbData[$target] = $mixRes->format('d.m.Y');
							
						}else{
							$htmlDecoded = $this->pdfUtility->encode( $mixRes );
							if( $htmlDecoded ) $this->dbData[$target] = $htmlDecoded;
						}
					}
			}
			return $this->dbData;
	}
	
	/**
	* initiateFolders
	* 
	* @return void
	*/
	private function initiateFolders() {
	    $uploadDir = rtrim(PATH_site, '/') . '/' . trim($this->settings['filePaths']['subfolder'], '/')  . '/' ;
		$uploadFolder =  GeneralUtility::getFileAbsFileName($uploadDir);
		$this->filetransferUtility->createDirectory( $uploadFolder );
		$this->uploadFolder  = $uploadFolder . $this->settings['filePaths']['temp'] . '/' ;
		$this->filetransferUtility->createDirectory( $this->uploadFolder );
	}
	
}
