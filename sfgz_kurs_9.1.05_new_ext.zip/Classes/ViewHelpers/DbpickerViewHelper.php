<?php
namespace Sfgz\SfgzKurs\ViewHelpers;

/**
 * View Helper which returns a value
 *
 * = Examples =
 * 
 * on top of template or partial: 
 * {namespace sfgz = Sfgz\SfgzKurs\ViewHelpers}
 * 
 * <code title="Example1">
 * <sfgz:dbpicker key="12" table="klasse" field="classShort" />
 * </code>
 *
 * <output>
 * MAM15 A
 * </output>
 *
 * default separer is a blank-space. BuiltIn separers ( ,;-/.) and additionalSeparer where removed from Fieldnames in 'field'
 * <code title="Example2">
 * <sfgz:dbpicker key="12" table="zimmer" field="uid) haus zimmer" additionalSeparer=")"  />
 * </code>
 *
 * <output title="Example2">
 * 12) Lp E56
 * </output>
 *
 * Data from foreign Extension (key is related to first table, in this example this would be the table 'belegung')
 * <code title="Example3">
 * <sfgz:dbpicker key="12" table="belegung.anlass.mieter" field="intern" extKey="Mffrps"  />
 * </code>
 * 
 * Data from foreign Vendor e.g. table 'fe_user'
 * <code title="Example4">
 * <sfgz:dbpicker key="{person.uid}" table="frontendUser" field="username" extKey="Extbase" vendor="TYPO3\CMS"  />
 * </code>
 * 
 *
 */
 
class DbpickerViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper {
    
	/**
	 * @var array
	 */
	public $built_in_separer = array( ' ' ,  ',' , ';' , '-' , '/' , '.' );

	/**
	 * Initialize the arguments.
	 *
	 * @return void
	 * @api
	 */
	public function initializeArguments() {
		parent::initializeArguments();
		$this->registerArgument('table',  	'string',  'Kurzname der Tabelle oder punkt-getrennte Kette von Tabellen (belegung.anlass.mieter)' , TRUE );
		$this->registerArgument('field',  	'string',  'Feld(er), dessen Inhalt(e) ausgesucht werden. Beispielsweise komasepariert.' , TRUE );
 		$this->registerArgument('key',    	'string',  'Uid des Datensatzes in der Fremdtabelle' , 							FALSE );
 		$this->registerArgument('extKey', 	'string',  'Key der Extension, in welcher die Fremdtabelle angelegt ist' , 		FALSE, 'SfgzKurs' );
 		$this->registerArgument('vendor', 	'string',  'vendor der Extension, in welcher die Fremdtabelle angelegt ist' , 	FALSE, 'Sfgz' );
 		$this->registerArgument('additionalSeparer',  'string', 'additional Separer' , 										FALSE );
 		$this->registerArgument('nowrap', 	'boolean', 'dont wrap in span-tags' , 											FALSE );
 		// registerArgument( $name ,  $type , $description , $required = false , $defaultValue = null )
	}
    
	/**
	 * Renders the textfield.
	 *
	 * @param boolean $required If the field is required or not
	 * @param string $type The field type, e.g. "text", "email", "url" etc.
	 * @return string
	 * @api
	 */
	public function render() {
		
		$key = $this->arguments['key'];
		if ($key == NULL) $key = $this->renderChildren();

		$extKey = $this->arguments['extKey'];
		$vendor = $this->arguments['vendor'];
		
		// wenn table = belegung.anlass.mieter dann durch-hangeln
		// 0=belegung 1=anlass 2=mieter OR anlass.mieter: 0=anlass 1=mieter
		$tabArr = explode( '.' , $this->arguments['table'] );
		if(count($tabArr)>1){
		    $table = $tabArr[ count($tabArr)-1 ]; // get name of last table for output
		    // search uid of output-table...
		    $firstObj = $this->getRepository( $tabArr[0] , $key , $extKey , $vendor); // eg. $tabArr[0] = belegung
		    $firstMethod = 'get'.ucfirst($tabArr[1]); // getAnlass
		    // ... then set $key = getAnlass (UID of Anlass)
		    if(method_exists( $firstObj , $firstMethod )) $key =  $firstObj->$firstMethod() ;
		    if(count($tabArr)>2){
			  $secondObj = $this->getRepository( $tabArr[1] , $key , $extKey , $vendor ); // eg. $tabArr[1] = anlass
			  $secondMethod = 'get'.ucfirst($tabArr[2]); // getMieter
			  if(method_exists( $secondObj , $secondMethod )) $key =  $secondObj->$secondMethod() ;
		    }
		}else{
		    $table = $this->arguments['table'];
		}
		
		$additionalSeparer = $this->arguments['additionalSeparer'];
		if($additionalSeparer != NULL) {
		    for($z=0;$z<strlen($additionalSeparer);++$z) $this->built_in_separer[] = substr($additionalSeparer,$z,1);
		}
		
		$fields = $this->arguments['field'];
		
		$obj = $this->getRepository( $table , $key , $extKey, $vendor );
		$rawFld = str_replace( $this->built_in_separer , '#' , $fields );
		$aFields = explode( '#' , $rawFld );
		foreach( $aFields as $sIx=>$cFld ){
		    $lFieldname = trim($cFld);
		    $method = 'get'.ucfirst($lFieldname);
		    $value = (method_exists( $obj , $method )) ? $obj->$method() : $lFieldname;
		    if( is_object($value) ) $value = $value->format('d.m.Y');
		    $sortReplacement[ strlen($lFieldname) ][$lFieldname]=$value;
		}
		// replace longest fildnames first (Hausnummer, Haus)
		krsort($sortReplacement);
		foreach( $sortReplacement as $replaecment ){
		    foreach( $replaecment as $lFieldname => $value ){
				$fields = str_replace( $lFieldname , $value , $fields );
		    }
		}
		if(count($tabArr)>1)return  $fields;
		if($this->arguments['nowrap'])return  $fields;
		return  '<span style="white-space:nowrap;">'.$fields.'</span>';
	}

	/**
	 * returns the object of a Model like "Klasse" or "Kurs"
	 *
	 * @param string $table The name of table to return
	 * @param string $key The needle used in findByUid( $key ) or leave it empty for all
	 * @param string $extKey The extKey of foreign table, or leave it empty for 'SfgzKurs'
	 * @param string $vendor $vendor of foreign table, or leave it empty for 'Sfgz'
	 * @return array
	 */
	protected function getRepository( $table , $key=0 , $extKey='SfgzKurs' , $vendor='Sfgz') {
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		
		// storage pid from config
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$tsConfig = $configurationManager->getConfiguration(\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$storagePid['SfgzKurs'] = $tsConfig['plugin.']['tx_sfgzkurs_vw.']['persistence.']['storagePid'];
		
		// set storage pid for requested Plugin
		$querySettings = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
		$querySettings->setStoragePageIds( array( 'storagePid'=>$storagePid[$extKey]) );
		
		// instanciate Repository
		$sr = array( '##TABLENAME##' => ucfirst($table) , '##EXT_KEY##'=> $extKey  , '##VENDOR##'=> $vendor  );
		$oneRepository = $objectManager->get( str_replace( array_keys($sr) , $sr , '##VENDOR##\##EXT_KEY##\Domain\Repository\##TABLENAME##Repository') );
		$oneRepository->setDefaultQuerySettings($querySettings);
		
		// find and return recordset(s)
		if(empty($key)){
		    return $oneRepository->findAll();
		}else{
		    return $oneRepository->findByUid($key);
		}
	}

}
