<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_config',
        'label' => 'fieldname',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
		'enablecolumns' => [
        ],
		'searchFields' => 'fieldname,fieldvalue,option1,option2,description,sorting',
        'iconfile' => 'EXT:sfgz_kurs/Resources/Public/Icons/tx_sfgzkurs_domain_model_config.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'fieldname, fieldvalue, option1, option2, description, sorting',
    ],
    'types' => [
		'1' => ['showitem' => 'fieldname, fieldvalue, option1, option2, description, sorting'],
    ],
    'columns' => [
        'fieldname' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_config.fieldname',
	        'config' => [
			    'type' => 'input',
			    'size' => 15,
			    'eval' => 'trim'
			],
	    ],
        'fieldvalue' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_config.fieldvalue',
	        'config' => [
			    'type' => 'input',
			    'size' => 20,
			    'eval' => 'trim'
			],
	    ],
        'option1' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_config.option1',
	        'config' => [
			    'type' => 'input',
			    'size' => 15,
			    'eval' => 'trim'
			],
	    ],
        'option2' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_config.option2',
	        'config' => [
			    'type' => 'input',
			    'size' => 15,
			    'eval' => 'trim'
			],
	    ],
        'description' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_config.description',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
        'sorting' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_config.sorting',
	        'config' => [
			    'type' => 'input',
			    'size' => 5,
			    'eval' => 'int'
			],
	    ],
    ],
];
