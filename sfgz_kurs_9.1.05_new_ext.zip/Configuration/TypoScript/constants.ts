# customcategory=sfgz_kursverwaltung=SfGZ Kursverwaltung
# customsubcategory=acategorien=Kategorien Gruppen
# customsubcategory=aftp=FTP-Server
# customsubcategory=bexport=Export
# customsubcategory=bpersistence=Speicher-Ordner
# customsubcategory=dpages=Seiten
# customsubcategory=aaclock=Uhr auf Display-Anzeige
# customsubcategory=gfile=Template-Grundeinstellung

plugin.tx_sfgzkurs_vw {
  view {
    # cat=sfgz_kursverwaltung/gfile; type=string; label=Path to template root (FE)
    templateRootPath = EXT:sfgz_kurs/Resources/Private/Templates/
    # cat=sfgz_kursverwaltung/gfile; type=string; label=Path to template partials (FE)
    partialRootPath = EXT:sfgz_kurs/Resources/Private/Partials/
    # cat=sfgz_kursverwaltung/gfile; type=string; label=Path to template layouts (FE)
    layoutRootPath = EXT:sfgz_kurs/Resources/Private/Layouts/
  }
  persistence {
    # cat=sfgz_kursverwaltung/bpersistence/a; type=string; label=Default storage PID
    storagePid =
  }
  settings {
	    # cat=sfgz_kursverwaltung/acategorien/a; type=text; label=Kategorien Gruppen:Die Hauptkategorien, duch Komma getrennt.
		kategoriegruppen = Angebotsbereiche, Berufe, WBZH Abschluss
	    # cat=sfgz_kursverwaltung/aftp/a; type=text; label=FTP URL:URL des FTP-Kontos.
		url = ftp.myserver.net
	    # cat=sfgz_kursverwaltung/aftp/b; type=text; label=FTP Username:Benutzername des FTP-Kontos.
	    username = zb_kurs
	    # cat=sfgz_kursverwaltung/aftp/c; type=text; label=FTP Passwort:Passwort des FTP-Kontos.
		password = zb_Aa1£
	    # cat=sfgz_kursverwaltung/dpages/boptions;  label= Page-uid of config page:Page uid where the config-plugin is stored.
		konfiguration = 44
		# cat=sfgz_kursverwaltung/bexport/aremoteurl; type=text; label=Import URL des Remotes:URL der Seite, welche die Exportdatei importiert.
		remote_url = https://sfgz.ch/signalwerk/course/import
		# cat=sfgz_kursverwaltung/aaclock/a; type=boolean; label=Display Clock Zeitquelle:Verwende Lokale Javascript Zeit anstelle von Serverseitiger PHP Zeit
		use_js_time_in_clock = 1
		# cat=sfgz_kursverwaltung/aaclock/b; type=boolean; label=Display Clock Design:Bahnhofsuhr statt mit Zahlen
		station_design = 1
		# cat=sfgz_kursverwaltung/aaclock/b; type=int+; label=Reload Display Page:Seite nach so vielen Sekunden neu laden. Bei 0 findet kein automatisches neu-laden statt. Voreingestellt sind 300 (5 Minuten)
		reload_page = 300
  }
}

plugin.tx_sfgzkurs_conf {
  persistence {
    # cat=sfgz_kursverwaltung/bpersistence/b; type=string; label=Configuration storage PID:Leave empty if the same as in tx_sfgzkurs_vw
    storagePid =
  }
}


