#
# Table structure for table 'tx_sfgzkurs_domain_model_config'
#
CREATE TABLE tx_sfgzkurs_domain_model_config (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	fieldname varchar(255) DEFAULT '' NOT NULL,
	fieldvalue varchar(255) DEFAULT '' NOT NULL,
	option1 varchar(255) DEFAULT '' NOT NULL,
	option2 varchar(255) DEFAULT '' NOT NULL,
	description varchar(255) DEFAULT '' NOT NULL,
	
	sorting int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_sfgzkurs_domain_model_kategorie'
#
CREATE TABLE tx_sfgzkurs_domain_model_kategorie (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	kategorie_gruppe int(11) DEFAULT '0' NOT NULL,
	kategorie_name varchar(255) DEFAULT '' NOT NULL,
	reihenfolge int(11) DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_sfgzkurs_domain_model_kurs'
#
CREATE TABLE tx_sfgzkurs_domain_model_kurs (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	titel varchar(255) DEFAULT '' NOT NULL,
	ausblenden int(11) unsigned DEFAULT '0' NOT NULL,
	kurs_code varchar(255) DEFAULT '' NOT NULL,
	stufe_wb varchar(255) DEFAULT '' NOT NULL,
	k_kategorien int(11) unsigned DEFAULT '0' NOT NULL,
	k_versionen int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	UNIQUE KEY kurs_code (kurs_code),
	KEY parent (pid),

);

#
# Table structure for table 'tx_sfgzkurs_domain_model_version'
#
CREATE TABLE tx_sfgzkurs_domain_model_version (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	kurs int(11) unsigned DEFAULT '0' NOT NULL,

	version_start date DEFAULT '0000-00-00',
	version_ende date DEFAULT '0000-00-00',
	neu_bis date DEFAULT '0000-00-00',
	titel varchar(255) DEFAULT '' NOT NULL,
	sub_titel varchar(255) DEFAULT '' NOT NULL,
	kurs_bezeichnung_lang varchar(255) DEFAULT '' NOT NULL,
	voraussetzungen text NOT NULL,
	text_lead text NOT NULL,
	zertifikat varchar(255) DEFAULT '' NOT NULL,
	kosten_material varchar(255) DEFAULT '' NOT NULL,
	ziel text NOT NULL,
	zielgruppe text NOT NULL,
	inhalt text NOT NULL,
	kursunterlagen text NOT NULL,
	methode text NOT NULL,
	hinweis text NOT NULL,
	weitere_infos text NOT NULL,
	v_durchfuehrungen int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_sfgzkurs_domain_model_durchfuehrung'
#
CREATE TABLE tx_sfgzkurs_domain_model_durchfuehrung (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	version int(11) unsigned DEFAULT '0' NOT NULL,

	durchfuehrungs_code varchar(255) DEFAULT '' NOT NULL,
	code_suffix varchar(255) DEFAULT '' NOT NULL,
	status int(11) DEFAULT '0' NOT NULL,
	publikation_start date DEFAULT '0000-00-00',
	publikation_ende date DEFAULT '0000-00-00',
	anmeldeschluss date DEFAULT '0000-00-00',
	kurskosten int(11) DEFAULT '0' NOT NULL,
	kosten_lernende int(11) DEFAULT '0' NOT NULL,
	kosten_extern int(11) DEFAULT '0' NOT NULL,
	maxteilnehmer int(11) DEFAULT '0' NOT NULL,
	anmerkung text NOT NULL,
	termin_ausblenden tinyint(4) unsigned DEFAULT '0' NOT NULL,
	lektionen varchar(255) DEFAULT '' NOT NULL,
	veranstaltungen int(11) DEFAULT '0' NOT NULL,
	periodika int(11) DEFAULT '0' NOT NULL,
	termin_start date DEFAULT '0000-00-00',
	termin_ende date DEFAULT '0000-00-00',
	zeit_von varchar(255) DEFAULT '' NOT NULL,
	zeit_bis varchar(255) DEFAULT '' NOT NULL,
	ort varchar(255) DEFAULT '' NOT NULL,
	zimmer varchar(255) DEFAULT '' NOT NULL,
	lehrer_eco_id varchar(255) DEFAULT '' NOT NULL,
	lehrperson_text varchar(255) DEFAULT '' NOT NULL,
	lehrperson_vorname varchar(255) DEFAULT '' NOT NULL,
	lehrperson_nachname varchar(255) DEFAULT '' NOT NULL,
	
	eco_mandant varchar(255) DEFAULT '' NOT NULL,
	eco_angebotid varchar(255) DEFAULT '' NOT NULL,
	eco_fachid varchar(255) DEFAULT '' NOT NULL,
	d_lektionen int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);


#
# Table structure for table 'tx_sfgzkurs_domain_model_lektion'
#
CREATE TABLE tx_sfgzkurs_domain_model_lektion (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	durchfuehrung int(11) unsigned DEFAULT '0' NOT NULL,

	lektionenzahl int(11) DEFAULT '0' NOT NULL,
	lektion_datum date DEFAULT '0000-00-00',
	zeit_von varchar(255) DEFAULT '' NOT NULL,
	zeit_bis varchar(255) DEFAULT '' NOT NULL,
	ort varchar(255) DEFAULT '' NOT NULL,
	zimmer varchar(255) DEFAULT '' NOT NULL,
	lehrer_eco_id varchar(255) DEFAULT '' NOT NULL,
	lehrperson_text varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_sfgzkurs_domain_model_info'
#
CREATE TABLE tx_sfgzkurs_domain_model_info (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	datum_anzeige date DEFAULT '0000-00-00',
	infotext text NOT NULL,
	i_belegungen int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_sfgzkurs_domain_model_belegung'
#
CREATE TABLE tx_sfgzkurs_domain_model_belegung (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	info int(11) unsigned DEFAULT '0' NOT NULL,

	belegungstext varchar(255) DEFAULT '' NOT NULL,
	zeit_von varchar(255) DEFAULT '' NOT NULL,
	zeit_bis varchar(255) DEFAULT '' NOT NULL,
	raum varchar(255) DEFAULT '' NOT NULL,
	person varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);


#
# Table structure for table 'tx_sfgzkurs_kurs_kategorie_mm'
#
CREATE TABLE tx_sfgzkurs_kurs_kategorie_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '0' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);

