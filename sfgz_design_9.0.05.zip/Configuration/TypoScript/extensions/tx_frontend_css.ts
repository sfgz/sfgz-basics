# make linklist sortable descending direction
tt_content.uploads.dataProcessing.10.sorting.direction = descending 
tt_content.uploads.dataProcessing.10.sorting.direction.if.isTrue.field = filelink_sorting_direction 

# css moved to sfgz_decor.css
plugin.tx_frontend_sfgz._CSS_DEFAULT_STYLE (
)
