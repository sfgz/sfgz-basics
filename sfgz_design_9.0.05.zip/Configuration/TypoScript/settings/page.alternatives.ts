# if shown as Popup then use a template without sidebars and border-column
contentonly = PAGE
contentonly < page
contentonly {
      typeNum = 95
      10.file.stdWrap.cObject =<
      10.file.stdWrap.cObject = TEXT
      10.file.stdWrap.cObject.value = {$plugin.sfgz_design.view.templateRootPaths.10}sfgz_1_column_without_menu.html
}

# type = 95 if shown as Popup then use a template without sidebars and border-column
contentonly.headerData.11 = TEXT
contentonly.headerData.11.value (
	<link rel="stylesheet" type="text/css" href="typo3conf/ext/sfgz_design/Resources/Public/Css/sfgz_main1column.css" media="all" />
)


# display only a specific element from page cnt=[uid]
[globalVar = GP:cnt!=""]
  tt_content.stdWrap.innerWrap.cObject.default = 
    lib.stdheader >
    contentonly.10 = COA_INT
    contentonly.10 {
      10 = RECORDS
      10 {
	  tables = tt_content
	  source = {GP:cnt}
	  source.insertData = 1
	  source.insertData.intval = 1
      }
    }
[global]
 
[globalVar = GP:type=100]
tt_content.stdWrap.innerWrap.cObject.default = 
lib.stdheader >
[global]

nurCel = PAGE
nurCel.typeNum = 100
nurCel.config {
   disableAllHeaderCode = 1
   disableCharsetHeader = 1
   disablePrefixComment = 1
}
nurCel.10 = COA_INT
nurCel.10 {
   10 = RECORDS
   10 {
      wrap = <DIV class="outer">|</DIV>
      stdWrap.dataWrap = <DIV class="data">|</DIV>
      innerWrap = <DIV class="inner">|</DIV>
      tables = tt_content
      source = {GP:cnt}
      source.insertData = 1
      source.insertData.intval = 1
   }
}
