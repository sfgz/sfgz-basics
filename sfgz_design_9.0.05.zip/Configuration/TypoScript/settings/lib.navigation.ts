## + navigation.ts

## public contents:
## lib.navigation
## lib.navigation_title_print
## lib.navigation_subtitle
## lib.navigation_toolbox
## lib.clicknavi_booklet
## lib.full_navigation
## lib.glider_sitetitle

## private contents:
## - lib.site_title
## - temp.navigation_pages

## Title navigation_title
lib.site_title = COA
lib.site_title {
	
	wrap = <div class="navigation_title site-title"><a title="zur Startseite" href="{$plugin.sfgz_design.settings.baseURL}">|</a></div>
	
	5 = TEXT
	5 {
        value = {$plugin.sfgz_design.settings.sitetitle}
    }
	
	10 = TEXT
	10 {
        value = {$plugin.sfgz_design.settings.sitesubtitle}
		noTrimWrap = |<span class="smallhint"> |</span>|
    }
    
}
lib.navigation_title_print < lib.site_title
lib.navigation_title_print.wrap = <div class="navigation_title site-title"><H1>|</H1></div>

lib.glider_sitetitle = COA
lib.glider_sitetitle {
	
	wrap = <div class="navigation_title site-title"><a title="zur Startseite" href="{$plugin.sfgz_design.settings.baseURL}">|</a></div>
	
	5 = TEXT
	5 {
        value = <span title="zur Startseite: {$plugin.sfgz_design.settings.sitetitle}"> {$plugin.sfgz_design.settings.siteshorttitle} </span>
    }
	
	10 = TEXT
	10 {
        value = {$plugin.sfgz_design.settings.sitesubtitle}
		noTrimWrap = |<span class="smallhint" title="zur Startseite: {$plugin.sfgz_design.settings.sitetitle}"> |</span>|
    }
    
}


## Title navigation_subtitle
lib.navigation_subtitle = COA_INT
lib.navigation_subtitle {
    
    wrap = <div class="navigation_subtitle under-title">|</div>
    # wenn kein subtitle dann anders wrappen
    wrap.override.if.isFalse.data = page:subtitle
    wrap.override = <div style="display:none;">|</div>
    
    # aktueller Seitentitel aus Tabelle page (ausgeblendet mit 10.wrap )
    10 = COA
    10.wrap = <div style="display:none;">|</div>
    10.1 = TEXT
    10.1 {
        insertData = 1
        value = {page:title}
        value.insertData = 1
        noTrimWrap = | |: |
        # wenn kein subtitle dann ohne doppelpunkt wrappen
        noTrimWrap.override.if.value.data = page:subtitle
        noTrimWrap.override.if.equals = .
        noTrimWrap.override = | | |
    }
    
    # aktueller Seiten-Untertitel aus Tabelle page
    15 = TEXT
    15 {
        insertData = 1
        value = {page:subtitle}
        noTrimWrap = | <H1>|</H1> |
        # wenn kein subtitle dann verstecken
        noTrimWrap.override.if.value.data = page:subtitle
        noTrimWrap.override.if.equals = .
        noTrimWrap.override = |<div style="display:none;">|</div>|
    }
    
}

## Title navigation_navAndSubtitle
lib.navigation_navAndSubtitle = COA_INT
lib.navigation_navAndSubtitle {
    
    wrap = <div class="navigation_navAndSubtitle under-title">|</div>
    # wenn kein subtitle dann anders wrappen
    wrap.override.if.isFalse.data = page:subtitle
    wrap.override = <div style="display:none;">|</div>
    
    # aktueller Seitentitel aus Tabelle page
    10 = TEXT
    10 {
        insertData = 1
        value = {page:nav_title}
        # wenn kein nav_title dann title einsetzen
        value.override.if.isFalse.data = page:nav_title
        value.override = {page:title}
        
        value.insertData = 1
        noTrimWrap = | |: |
        # wenn kein subtitle dann ohne doppelpunkt wrappen
        noTrimWrap.override.if.isFalse.data = page:subtitle
        noTrimWrap.override = | | |
    }
    10.value.override.override.if.isFalse.data = page:subtitle
    10.value.override.override = <!-- no subtitle for this page uid:{page:uid} -->
    
    # aktueller Seiten-Untertitel aus Tabelle page
    15 = TEXT
    15 {
        insertData = 1
        value = {page:subtitle}
        noTrimWrap = | <span class="selected">|</span> |
    }
    
}

## navigation_pages
temp.navigation_pages = COA
temp.navigation_pages.wrap = <div class="navigation_pages ">|</div>
temp.navigation_pages.10 = HMENU
temp.navigation_pages.10 {
		### Erste Ebene ###
		1 = TMENU
		1 {
			wrap = <div class="pages-menu">| <div class="clearer"></div></div>
			expAll = 1
			NO.wrapItemAndSub = <div class="pages-menuitem-normal navi">|</div> 
			NO.ATagParams.cObject = COA
			NO.ATagParams.cObject.10 = TEXT
			NO.ATagParams.cObject.10 {
					field = fe_group
					wrap = class="group|" onfocus="this.blur()"
					split{
							token = ,
							cObjNum = 1
							1.current = 1
							1.stdWrap {
									insertData = 1
									noTrimWrap = | fe_| |
							}
					}
			}
			NO.allStdWrap.insertData = 1
			ACT < .NO
			ACT = 1
			ACT.ATagParams.cObject.10.wrap = class="selected group|" onfocus="this.blur()"
			ACT.wrapItemAndSub = <div class="pages-menuitem-selected navi">|</div>
		}
}
temp.navigation_pages.20 = HMENU
temp.navigation_pages.20 < temp.navigation_pages.10
temp.navigation_pages.20.entryLevel = 1
temp.navigation_pages.20.1.wrap = <div class="sub-pages-menu">| <div class="clearer"></div></div>
temp.navigation_pages.20.1.NO.wrapItemAndSub = <div class="sub-pages-menuitem-normal navi">|</div> 
temp.navigation_pages.20.1.ACT.wrapItemAndSub = <div class="sub-pages-menuitem-selected navi">|</div> 

temp.navigation_pages.30 = HMENU
temp.navigation_pages.30 < temp.navigation_pages.10
temp.navigation_pages.30.entryLevel = 2
temp.navigation_pages.30.1.wrap = <div class="under-sub-pages-menu">| <div class="clearer"></div></div>
temp.navigation_pages.30.1.NO.wrapItemAndSub = <div class="under-sub-pages-menuitem-normal navi">|</div> 
temp.navigation_pages.30.1.ACT.wrapItemAndSub = <div class="under-sub-pages-menuitem-selected navi">|</div> 

temp.navigation_pages.40 = HMENU
temp.navigation_pages.40 < temp.navigation_pages.30
temp.navigation_pages.40.entryLevel = 3
temp.navigation_pages.40.1.wrap = <div class="deep-under-sub-pages-menu">| <div class="clearer"></div></div>
temp.navigation_pages.40.1.NO.wrapItemAndSub = <div class="deep-under-sub-pages-menuitem-normal navi">|</div> 
temp.navigation_pages.40.1.ACT.wrapItemAndSub = <div class="deep-under-sub-pages-menuitem-selected navi">|</div> 

temp.navigation_pages.50 = HMENU
temp.navigation_pages.50 < temp.navigation_pages.40
temp.navigation_pages.50.entryLevel = 4

temp.navigation_pages.60 = HMENU
temp.navigation_pages.60 < temp.navigation_pages.50
temp.navigation_pages.60.entryLevel = 5

temp.navigation_pages.70 = HMENU
temp.navigation_pages.70 < temp.navigation_pages.60
temp.navigation_pages.70.entryLevel = 6

temp.navigation_pages.80 = HMENU
temp.navigation_pages.80 < temp.navigation_pages.70
temp.navigation_pages.80.entryLevel = 7

## old_toolbox Kontakt ID = 43
lib.old_toolbox = COA
lib.old_toolbox {
		wrap = | <div class="clearer"> </div>
		10 = COA
		10 {
				wrap = <div class="navigation_toolbox navi toolbox-menu">| <div class="clearer"> </div> </div>
				# left side: Startpage
				30 = TEXT
				30.wrap = <div class="navi">|</div>
				30.insertData = 1
				30.value = {DB:pages:{$plugin.sfgz_design.settings.mainpage_uid}:title}
				30.typolink.parameter = {$plugin.sfgz_design.settings.mainpage_uid}
				30.typolink.ATagParams = target="_self" onfocus="this.blur()"
				# Contactpage
				35 < .30
				35.value = {DB:pages:{$plugin.sfgz_design.settings.kontakt_uid}:title}
				35.typolink.parameter = {$plugin.sfgz_design.settings.kontakt_uid}
				# Sitemap Page
				37 < .30
				37.value = {DB:pages:{$plugin.sfgz_design.settings.sitemap_uid}:title}
				37.typolink.parameter = {$plugin.sfgz_design.settings.sitemap_uid}
				
		}
		20 = COA
		20 {
				# right side: Print Button
				wrap = <div class="navigation_toolbox navi right toolbox-menu">| <div class="clearer"> </div> </div>
				47 = TEXT
				47.wrap = <div class="navi right print_button">|</div>
				47.value = Drucken
				47.typolink.parameter >
				47.typolink.parameter.data = TSFE:id
				47.typolink.ATagParams = onClick="window.print();return false;" onfocus="this.blur()"
				50 < lib.navigation_toolbox.10.30
				50.value = {DB:pages:{$plugin.sfgz_design.settings.loginpage_uid}:title}
				50.typolink.parameter = {$plugin.sfgz_design.settings.loginpage_uid}
		}
}


## navigation_toolbox Kontakt ID = 43
lib.navigation_toolbox = COA
lib.navigation_toolbox {
		wrap = | <div class="clearer"> </div>
		10 = COA
		10 < temp.navigation_pages.10
		10.1.wrap = <div class="navigation_toolbox navi toolbox-menu print_button">| <div class="clearer"> </div> </div>
		
		20 = COA
		20 {
				# right side: Print Button
				wrap = <div class="navigation_toolbox navi right toolbox-menu">| <div class="clearer"> </div> </div>
				47 = TEXT
				47.wrap = <div class="navi right print_button">|</div>
				47.value = Drucken
				47.typolink.parameter >
				47.typolink.parameter.data = TSFE:id
				47.typolink.ATagParams = onClick="window.print();return false;" onfocus="this.blur()"
				50 < lib.old_toolbox.10.30
				50.value = {DB:pages:{$plugin.sfgz_design.settings.loginpage_uid}:title}
				50.typolink.parameter = {$plugin.sfgz_design.settings.loginpage_uid}
		}
}


# navigation_toolbox Profil ID = 42
[globalVar = TSFE:fe_user|user|usergroup > 0]
		# Profilepage
		lib.navigation_toolbox.20.48 = TEXT
		lib.navigation_toolbox.20.48 < lib.old_toolbox.10.35
		lib.navigation_toolbox.20.48.value = {DB:pages:{$plugin.sfgz_design.settings.profil_uid}:title}
		lib.navigation_toolbox.20.48.typolink.parameter = {$plugin.sfgz_design.settings.profil_uid}
		
		# Logout Button
		lib.navigation_toolbox.20.50 < lib.old_toolbox.10.35
		lib.navigation_toolbox.20.50.typolink.title = Logout!
		lib.navigation_toolbox.20.50.value = Abmelden
		lib.navigation_toolbox.20.50.wrap = <div class="navi right">|</div>
		lib.navigation_toolbox.20.50.typolink.additionalParams = &logintype=logout
		lib.navigation_toolbox.20.50.typolink.parameter = {$plugin.sfgz_design.settings.loginpage_uid}
		lib.navigation_toolbox.20.50.typolink.ATagParams =  onfocus="this.blur()"
[global]


## new navigation! the following 30 lines are unused now.
## ## display contact in toolbox
##[PIDinRootline = {$plugin.sfgz_design.settings.kontakt_uid} ]
##		lib.navigation_toolbox.10.35.typolink.ATagParams = class="selected" onfocus="this.blur()"
##[global]

## ## display sitemap in toolbox
##[PIDinRootline = {$plugin.sfgz_design.settings.sitemap_uid} ]
##		lib.navigation_toolbox.10.37.typolink.ATagParams = class="selected" onfocus="this.blur()"
##[global]

## ## select profile-item in toolbox if in subpage
##[PIDinRootline = {$plugin.sfgz_design.settings.profil_uid}]
##		lib.navigation_toolbox.10.40.typolink.ATagParams = class="selected" onfocus="this.blur()"
##[global]

## ## display profile page if logged in
##[globalVar = TSFE:fe_user|user|usergroup <= 0]
##		lib.navigation_toolbox.10.40 = 
##[global]

## ## display startpage in toolbox
##[globalVar = TSFE:id = {$plugin.sfgz_design.settings.mainpage_uid}]
##		lib.navigation_toolbox.10.30.typolink.ATagParams = class="selected" onfocus="this.blur()"
##[global]

## ## only if mainpage_uid > 0 ! 
##[PIDinRootline = {$plugin.sfgz_design.settings.mainpage_uid}]
##		lib.navigation_toolbox.10.30.typolink.ATagParams = class="selected" onfocus="this.blur()"
##[global]
## 

lib.navigation = COA_INT
lib.navigation.10 < lib.navigation_toolbox
lib.navigation.20 < lib.site_title
lib.navigation.30 < temp.navigation_pages
lib.navigation.40 < lib.navigation_subtitle

## new navigation...
temp.navigation_pages.10 =
lib.navigation.30.10 =
## ... new navigation.


lib.full_navigation = HMENU
lib.full_navigation.includeNotInMenu = 0
lib.full_navigation {
			### Erste Ebene ###
			1 = TMENU
			1 {
				wrap = <ul class="pages-menu">|</ul>
				expAll = 1
				NO.wrapItemAndSub = <li class="pages-menuitem-normal">|</li> 
				NO.ATagParams.cObject = COA
				NO.ATagParams.cObject.10 = TEXT
				NO.ATagParams.cObject.10.value = onfocus="this.blur()"
				ACT < .NO
				ACT = 1
				ACT.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
				ACT.wrapItemAndSub = <li class="pages-menuitem-selected">|</li>
			}
			### weitere Ebenen ###
			2 < .1
			2.wrap = <ul class="sub-pages-menu">|</ul>
			2.NO = 1
			3 < .2
			3.NO = 1
			4 < .2
			4.NO = 1
}

 lib.clicknavi_booklet = HMENU

## navigation_toolbox Kontakt und Profil
##[PIDinRootline = {$plugin.sfgz_design.settings.sitemap_uid},{$plugin.sfgz_design.settings.profil_uid},{$plugin.sfgz_design.settings.kontakt_uid}] 
##	lib.clicknavi_booklet < lib.full_navigation
##	lib.clicknavi_booklet {
##		wrap = <div class="clicknavi_booklet">|</div>
##		special = directory
##		special.value = {$plugin.sfgz_design.settings.kontakt_uid}
##		1.NO.wrapItemAndSub = <li class="sub-pages-menuitem-normal" style="color:#444;">|</li> 
##		1.ACT.wrapItemAndSub = <li class="sub-pages-menuitem-selected" style="color:#444;">|</li> 
##		2.NO.wrapItemAndSub < lib.clicknavi_booklet.1.NO.wrapItemAndSub
##		2.ACT.wrapItemAndSub < lib.clicknavi_booklet.1.ACT.wrapItemAndSub
##		2.wrap = <ul class="under-sub-pages-menu">| </ul>
##		2 < lib.clicknavi_booklet.2
##		3 < lib.clicknavi_booklet.2
##		4 < lib.clicknavi_booklet.2
##	}
##[global]

##[PIDinRootline = {$plugin.sfgz_design.settings.sitemap_uid}] 
##	lib.clicknavi_booklet.special.value = {$plugin.sfgz_design.settings.sitemap_uid}
##[global]

##[PIDinRootline = {$plugin.sfgz_design.settings.profil_uid}] 
##	lib.clicknavi_booklet.special.value = {$plugin.sfgz_design.settings.profil_uid}
##[global]
