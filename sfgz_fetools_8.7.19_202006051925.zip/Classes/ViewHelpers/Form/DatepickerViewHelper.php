<?php
namespace Sfgz\SfgzFetools\ViewHelpers\Form;

/**
 * View Helper which creates a text field (<input type="text">).
 * 
 * Tigra Calendar
 * 
 * Used together with JS-script calendar_eu.js Tigra Calendar v4.0.4  
 * https://www.softcomplex.com/products/tigra_calendar/
 *
 * = Examples =
 * 
 * 1. The form containing this field requires a form-name!
 * 
 * 2. On top of template or partial: 
 *    {namespace mff = Sfgz\SfgzFetools\ViewHelpers}
 * 
 * < code title="Example" >
 * <mff:form.datepicker name="myDate" value="16.07.1993" />
 * < /code >
 * 
 * < output >
 * <input type="text" name="myDate" value="16.07.1993" />
 * < /output >
 *
 */
 
class DatepickerViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper {
    
	/**
	 * @var string
	 */
	protected $tagName = 'input';
    
	/**
	 * @var string
	 */
	protected $dateFormat = 'd.m.Y';

	/**
	 * Initialize the arguments.
	 *
	 * @return void
	 * @api
	 */
	public function initializeArguments() {
		parent::initializeArguments();
		$this->registerArgument('form','string','als Beispiel kalender',FALSE);
		$this->registerArgument('wrap','string','als Beispiel div',FALSE);
	}
    
	/**
	 * Renders the textfield.
	 *
	 * @return string
	 */
	public function render() {
		$name = $this->getName();
		
		$form = $this->arguments['form'] !== NULL ? $this->arguments['form'] : $this->viewHelperVariableContainer->get('TYPO3\\CMS\\Fluid\\ViewHelpers\\FormViewHelper', 'formObjectName');
		
		$css = $this->arguments['class'] !== NULL ? $this->arguments['class'] : '';
		
		$field = $this->arguments['property'] !== NULL ? $this->arguments['property'] : $this->arguments['name'];
		$id = $this->arguments['id'] !== NULL ? $this->arguments['id'] : $field;
		
		$dateValue = $this->getValueAttribute();
		if ($dateValue == NULL) $dateValue = $this->renderChildren();
		
        $required = $this->arguments['required'];
		if ($required) $this->tag->addAttribute('required', 'required');
		
		$this->tag->addAttribute('value', $dateValue);
// 		if (strlen($dateValue)>=8) {$this->tag->addAttribute('value', $dateValue);}else{$this->tag->addAttribute('value', '');}

        $type = $this->arguments['type'];
		$this->tag->addAttribute('type', $type);
		$this->tag->addAttribute('name', $name);
		$this->tag->addAttribute( 'id' , $id );
		
		if( $this->arguments['wrap'] == 'div' ){
		      $this->tag->addAttribute( 'class' , 'tx-sfgz_design' );
		}else{
		      $this->tag->addAttribute( 'class' , trim($css . ' tx-sfgz_design') );
		}
		
		$this->registerFieldNameForFormTokenGeneration($name);
		
		$this->setErrorClassAttribute();
		
		$jsText = $this->getJavaScript($id,$form);
		
		$renderedTag =  $jsText . $this->tag->render();
		
		if( $this->arguments['wrap'] == 'div'){
		      return '<div class="'.trim($css . ' tx-sfgz_design').'" style="width:auto;float:left;margin-right:2px;">' . $renderedTag . '</div>'  ;
		}elseif( $this->arguments['wrap'] ){
		      return '<'.$this->arguments['wrap'].' class="'.trim($css . ' tx-sfgz_design').'">' . $renderedTag . '</'.$this->arguments['wrap'].'>'  ;
		}else{
		      return $renderedTag;
		}
		
	}

	/**
	 * Get the js part
	 *
	 * @param string $field name of the field e.g. datumbeginn
	 * @param string $form name of the form
	 * @return mixed
	 */
	protected function getJavaScript($field,$form) {
		
		$jsText = '<div id="tcal'.$field.'" class="tcal"></div>';
		$jsText.= '<script language="JavaScript">';
		$jsText.= "new tcal ({'formname': '".$form."','controlname': '".$field."'});";
		$jsText.= "$(document).ready(function(){";
// 		$jsText.= " if($( '#".$field."' ).val()){";
// 		$jsText.= "  $( '#".$field."' ).addEventListener('onfocusout', alert( $( '#".$field."' ).val() ) );";
// 		$jsText.= " }";
		$jsText.= "});";
		$jsText.= '</script> ';
		return $jsText;
	}

	// HINTS to getJavaScript():
		// bind here to id $field some event like
		//  var thisfield = $( '#' + field ), timefield = $( '#time_' + field ); 
		//  thisfield.onfocusout( thisfield.value( date_time2timestamp( thisfield.value() , timefield.value() ) ) ); 
		//  or onsubmit or onchange
		//  $jsText.= ' <input type="text"  placeholder="hh:mm" style="width:4.5em;" name="time_'.$field.'" id="time_'.$field.'" value="" />';

		// more possible Variables
		// $formObjectName = $this->viewHelperVariableContainer->get('TYPO3\\CMS\\Fluid\\ViewHelpers\\FormViewHelper', 'formObjectName');
		// $formObjectName_and_field = $this->getNameWithoutPrefix();


}
