<?php
namespace Sfgz\SfgzFetools\ViewHelpers\Form;

/**
 * View Helper which creates a text field (<input type="text">).
 * 
 * pureJSCalendar
 * 
 * Used together with JS-script pureJSCalendar.js 
 * https://github.com/MrGuiseppe/pureJSCalendar
 *
 * = Examples =
 * 
 * 1. The form containing this field requires a form-name!
 * 
 * 2. On top of template or partial: 
 *    {namespace sfgz = Sfgz\SfgzFetools\ViewHelpers}
 * 
 * < code title="Example" >
 * <sfgz:form.datechooser name="myDate" value="16.07.1993" pastDays="10" futureDays="5" />
 * < /code >
 * 
 * < output >
 * <input type="text" name="myDate" value="16.07.1993" />
 * < /output >
 *
 */
 
class DatechooserViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper {
    
	/**
	 * @var string
	 */
	protected $tagName = 'input';
    
	/**
	 * @var string
	 */
	protected $dateFormat = 'd.m.Y';

	/**
	 * Initialize the arguments.
	 *
	 * @return void
	 * @api
	 */
	public function initializeArguments() {
		parent::initializeArguments();
		$this->registerArgument('pastDays','integer','zB. 30',FALSE );
		$this->registerArgument('futureDays','integer','zB. 5',FALSE );
	}
    
	/**
	 * Renders the textfield.
	 *
	 * @return string
	 */
	public function render() {
		$name = $this->getName();
		
		$daysInPast = strlen($this->arguments['pastDays']) ? round( $this->arguments['pastDays'] ) : 3653;
		$daysInFuture = strlen($this->arguments['futureDays']) ? round( $this->arguments['futureDays'] ) : 3653;
		$css = $this->arguments['class'] !== NULL ? $this->arguments['class'] : '';
		$field = $this->arguments['property'] !== NULL ? $this->arguments['property'] : $this->arguments['name'];
		$id = $this->arguments['id'] !== NULL ? $this->arguments['id'] : $field;
        $type = $this->arguments['type'];
		
        $required = $this->arguments['required'];
		if ($required) $this->tag->addAttribute('required', 'required');
		
		$dateValue = $this->getValueAttribute();
		if ($dateValue == NULL) $dateValue = $this->renderChildren();
		
		$this->tag->addAttribute('value', $dateValue);
		$this->tag->addAttribute('type', $type);
		$this->tag->addAttribute('name', $name);
		$this->tag->addAttribute( 'id' , $id );
		$this->tag->addAttribute( 'class' , trim($css . ' tx-sdb-adminer') );

		$this->registerFieldNameForFormTokenGeneration($name);
		
		$this->setErrorClassAttribute();
		
		$jsText = $this->getJavaScript( $id , $daysInPast , $daysInFuture );
		
		$renderedTag =  $this->tag->render();
		
		return $jsText . $renderedTag;
		
	}

	/**
	 * Get the js part
	 *
	 * @param string $field name of the field e.g. datumbeginn
	 * @param integer $daysInPast 
	 * @param integer $daysInFuture
	 * @return mixed
	 */
	protected function getJavaScript( $field , $daysInPast , $daysInFuture ) {
		
		$jsText = '$(document).ready(function(){';
		
 		$jsText.= "registerCalendarField( '$field' , $daysInPast , $daysInFuture );";
 		
		$jsText.= '});';
		
		return '<script language="JavaScript">' . $jsText . '</script> ';
	}

}
