<?php
namespace Sfgz\SfgzFetools\ViewHelpers;

/**
 * View Helper which returns a value
 *
 * = Examples =
 * 
 * on top of template or partial: 
 * {namespace sfgz = Sfgz\SfgzFetools\ViewHelpers}
 * 
 * <code title="Example1">
 *   <sfgz:registermap register="Page One,Page Two" id="hauptregister1" >
 *      <div> Content of Page one </div>
 *      <div> Content of Page two </div>
 *   </sfgz:registermap>
 * </code>
 *
 * <output>
 * "Displays the Register"
 * </output>
 * 
 * <code title="Example2">
 *   <sfgz:registermap direction="horizontal" register="Page One,Page Two" id="hauptregister2" >
 *      <div class="register_inhalt"> Content of Page one </div>
 *      <div class="register_inhalt"> Content of Page two <div> with a inner div </div> </div>
 *   </sfgz:registermap>
 * </code>
 * 
 * HINT: if you have a FORM to place, doe this out of this viewHelper:
 * <code title="ExampleForm">
 *   <f:form ... >
 *     <sfgz:registermap register="Page One,Page Two" id="hauptregister3" >
 *          <div> Content of Page one </div>
 *          <div> Content of Page two </div>
 *     </sfgz:registermap>
 *   </f:form>
 * </code>
 *
 */

class RegistermapViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper {
 
    protected $escapeOutput = false;
    protected $escapeChildren = false;
    
    public function initializeArguments() {
        $this->registerArgument('register','string','general,options',true);
        $this->registerArgument('id','hauptregister1',false);
        $this->registerArgument('direction','vertical',false);
    }
    /**
    * render
    * 
    * @param string $param
    */
     public function render($param='') 
    {
        $directionOfRegister =  empty($this->arguments['direction']) ? 'horizontal' : $this->arguments['direction'] ;
        $mainContainerId =  empty($this->arguments['id']) ? 'hauptregister1' : $this->arguments['id'] ;
        $aTabnames = explode( ',' , $this->arguments['register'] );
        
        $htmlRegister = "\n\t" . '<ul class="register">';
        foreach( $aTabnames as $ix => $tabname ){
            $cleanCssClassname = strtolower( str_replace( ' ' , '_' , $tabname ) );
            $htmlRegister .= "\n\t\t" .'<li class="user_' . $ix . '">';
            $htmlRegister .= ucFirst( $tabname );
            $htmlRegister .= '</li>';
        }
        $htmlRegister .= "\n\t" . '</ul>';
        
        $output = "\n" . '<div id="' . $mainContainerId . '" class="fetools_registermap ' . $directionOfRegister . '">';
        $output .= $htmlRegister;
        $output .= $this->renderChildDivs();
        $output .= "\n" . '</div>';
        
        $textCss = '#' . $mainContainerId . ' > DIV { border:thin solid #bbb; padding:3px 5px; }';
        $textJavascript = '$(document).ready(function(){fetoolsInitiateRegister( "div.fetools_registermap" );});';
        
         $GLOBALS['TSFE']->setCSS( 'fetools_addcss' , $textCss );
         $GLOBALS['TSFE']->setJS( 'fetools_addjs' , $textJavascript );
        return $output;
        
    }
    /**
    * renderChildDivs
    * 
    * @param string $aTabnames
    */
     private function renderChildDivs() 
    {
        $sChilDiv = $this->renderChildren();
        $openDiv = 0;
        $divPos = ['start'=>[] ,'end' =>[]];
        // set position of end-tags
        for( $pos = 0 ; $pos < strlen( $sChilDiv ) ; ++$pos){
            if( substr( strtolower($sChilDiv) , $pos , 4 ) == '<div' ) $openDiv += 1;
            if( substr( strtolower($sChilDiv) , $pos , 6 ) == '</div>' ){
                $openDiv -= 1;
                if($openDiv<=0) $divPos['end'][count($divPos['end'])] = $pos;
            }
        }
        // set position of start-tags
        for( $pos = 0 ; $pos < strlen( $sChilDiv ) ; ++$pos){
            if( substr( strtolower($sChilDiv) , $pos , 4 ) == '<div' ){
                $ix = count($divPos['start']);
                if( !isset($divPos['end'][$ix-1]) ){
                    $divPos['start'][$ix] = $pos;
                }else{
                    if( $pos > $divPos['end'][$ix-1] )
                    $divPos['start'][$ix] = $pos;
                }
            }
        }
        // create rendered output
        $sRendered = '';
        foreach( $divPos['start'] as $ix => $iStartPos ){
            $posRestOfOpt = strpos( strtolower($sChilDiv) , '>' , $iStartPos );
                $newOptions = 'id="user_'.$ix.'"';
                $restOfOpt = substr( $sChilDiv , $iStartPos+4 , $posRestOfOpt-($iStartPos+4) );
                $rplOpt = str_replace( ' id="' , ' data="' , $restOfOpt );
                $startPosOfCnt = $posRestOfOpt+1;
                $lengthOfCnt = $divPos['end'][$ix]-1 - $startPosOfCnt;
                $content = substr( $sChilDiv , $startPosOfCnt , $lengthOfCnt );
                $sRendered .='<div '.$newOptions.' ' . $rplOpt . '>' . $content . '</div>' ;
            
        }
        return $sRendered;
    }
}
