<?php
namespace Sfgz\SfgzFetools\Utility;

 
	$spoutFilpath = \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('sfgz_fetools') . 'Resources/Private/PHP/Spout/Autoloader/autoload.php';
	if( !file_exists($spoutFilpath) ) return false;

	include_once($spoutFilpath);
	
	use Box\Spout\Reader\ReaderFactory;
	use Box\Spout\Writer\WriterFactory;
	use Box\Spout\Common\Type;
	use Box\Spout\Writer\Style\StyleBuilder;
	use Box\Spout\Writer\Style\Color;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class SpreadsheetUtility
 * 
 */

class SpreadsheetUtility {
		
		/**
		* arrayToSpreadSheet
		* 
		* @param array $spoutRs 2- or 3-dim array
		* @param string $fullFilename 
		* @param boolean $prependColumnNames optional, default is false
		* @return void
		*/
		public function arrayToSpreadSheet( $spoutRs, $fullFilename , $prependColumnNames = false ) 
		{
				
				if( !is_array($spoutRs) ) return false;
				$testRow = current($spoutRs);
				if( !is_array($testRow) ) return false;

				if( $prependColumnNames ) $spoutRs = $this->arrayPrependKeynames( $spoutRs );
				
				$prefixfNam = pathinfo( $fullFilename , PATHINFO_FILENAME );
				$type = pathinfo( $fullFilename , PATHINFO_EXTENSION );
				
				switch( $type ){
					case 'ods' : $writer = WriterFactory::create(Type::ODS); break;
					case 'xlsx' : $writer = WriterFactory::create(Type::XLSX); break;
					default : return false; break;
				}

				$dwnFileName = $prefixfNam . trim( '_' . date('ymdHis') ) . '.' . $type ;
				$writer->openToBrowser(  $dwnFileName ); // stream data directly to the browser
				
				$style = (new StyleBuilder())
					->setFontBold()
					->setFontItalic()
					->setFontSize(12)
					->build();
				
				$testField = current($testRow);
				if( is_array($testField) ){
					$ix = 0; // add index because sheetName must be unique!
					foreach( $spoutRs as $sheet => $shtRs ){
                        ++$ix;
						$writer->addRowWithStyle(array_shift($shtRs), $style);
						$writer->addRows( $shtRs ); // add multiple rows at a time
						$sheetname = strlen($sheet) < 30 ? $sheet : substr( $sheet , 0 , 30-strlen($ix) ) . '_' . $ix;
						$writer->getCurrentSheet()->setName( $sheetname );
						if( $ix < count($spoutRs) ) $writer->addNewSheetAndMakeItCurrent();
					}
				}else{
					$writer->addRowWithStyle(array_shift($spoutRs), $style);
					
					$writer->addRows( $spoutRs ); // add multiple rows at a time
					$sheetName = substr( $prefixfNam , 0 , 31 ); // only 31 chars in tabname allowed
					$writer->getCurrentSheet()->setName( $sheetName );
				}
				
				$writer->close();
				exit();
		}
		
		/**
		* arrayPrependKeynames
		*  prependColumnNames for table headrow
		* 
		* @param array $spoutRs 2- or 3-dim array
		* @return void
		*/
		Protected function arrayPrependKeynames( $spoutRs ) 
		{
				if( !is_array($spoutRs) ) return false;
				$testRow = current($spoutRs);
				if( !is_array($testRow) ) return false;
				
				$testField = current($testRow);
				if( is_array($testField) ){
					foreach( $spoutRs as $sheet => $shtRs ){
						$aFirstRow = current( $shtRs );
						$aVarNames = array_keys( $aFirstRow );
						array_unshift( $spoutRs[$sheet] , $aVarNames );
					}
				}else{
					$aFirstRow = current( $spoutRs );
					$aVarNames = array_keys( $aFirstRow );
					array_unshift( $spoutRs , $aVarNames );
				}
				return $spoutRs;
		}
		
		/**
		* spreasheetToArray
		* 
		* @param string $filePathName
		* @param boolean $prependHeadrow
		* @return array
		*/
		public function spreadsheetToArray( $filePathName , $prependHeadrow = FALSE ) 
		{
				$uploadedFileExtension = strtolower( pathinfo( $filePathName , PATHINFO_EXTENSION ) );

				switch( $uploadedFileExtension ){
					case 'ods' : $reader = ReaderFactory::create(Type::ODS); break;
					case 'xlsx' : $reader = ReaderFactory::create(Type::XLSX); break;
					default : return false; break;
				}
// 				$reader->setShouldFormatDates(true);
				
				$spoutRs = array();
				$reader->open($filePathName);
				
				foreach ($reader->getSheetIterator() as $sNr => $sheet) {
					$sheetname = urlencode( str_replace( '.csv' , '' , $sheet->getName() ) );
					foreach ($sheet->getRowIterator() as $rNr => $row) {
						if( !isset($fieldnames[$sNr]) ) {$fieldnames[$sNr] = $row; if(!$prependHeadrow) continue;}
						foreach($fieldnames[$sNr] as $fix=>$fld) if( trim($fld) != '' ) $spoutRs[$sheetname][$rNr][$fld] = $row[$fix];
					}
				}
				$reader->close();
				return $spoutRs;
		}
		
}
