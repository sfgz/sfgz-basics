// extension sfgz_fetools: handle register-tabs. events for REGISTERS
// display tab when click or simulate-click on register-tab 
// registermap_id = #hauptregister
function fetools_registerTabChange( tab , registermap_id ) {
        // contents: remove all div with class register_inhalt, then add specific by id
        $( '#' + registermap_id + ' > div').hide();
        
        $( '#' + tab ).show();
        // contents: add child elements  with own form-wrap
        $( '#' + registermap_id + ' .child_of_' + tab ).show();
        // register-tabs: remove selected on all tabs, then append on one specific tab by class
        $( '#' + registermap_id + ' UL.register LI' ).removeClass( 'selected' );
        $( '#' + registermap_id + ' UL.register LI.' + tab ).addClass( 'selected' );
}

// store tab-name when click on register-tab 
function fetools_storeActualRegisterTabName( tab , mainregisterclass ) {
        var registermap_id = $( 'li.' + tab ).closest( mainregisterclass ).prop( 'id' );
        localStorage.setItem('fetools_registerpage_' + registermap_id , tab );
}

// get tab-name 
function fetools_actualRegisterTabName( registermap_id ) {
        var tab = localStorage.getItem( 'fetools_registerpage_' + registermap_id );
        return tab;
}

// get form-name 
function fetoolsInitiateRegister( mainregisterclass ) {
        // events for REGISTERS called in header like fetoolsInitiateRegister("div.fetools_registermap")
        // bind click-event with registerTab-setter
        $( mainregisterclass + ' UL.register LI' ).on( 'click', function() {
            registermap_id = $( this ).closest( 'div' ).prop( 'id' ); // #hauptregister
            // detect the class, that for first remove class 'selected' if set
            $( this ).removeClass('selected');
            var tab = $( this ).attr('class');
            if( tab ){
                fetools_registerTabChange( tab , registermap_id ); 
                fetools_storeActualRegisterTabName( tab , mainregisterclass  ); 
            }
        });
        // choose tab after page-loading (trigger the klick)
        $( mainregisterclass ).each(function( index ) {
                var tab = fetools_actualRegisterTabName( this.id );
//                 var registermap_id = $( mainregisterclass ).prop( 'id' );
                if( $('#' + tab ).length ){
                    fetools_registerTabChange( tab , this.id );
                } else {
                    $( '#' + this.id + ' UL.register LI' ).first().trigger( 'click' );
                }
        });
}
        
$(document).ready(function(){
//     fetoolsInitiateRegister( 'div.fetools_registermap' );
});
 
