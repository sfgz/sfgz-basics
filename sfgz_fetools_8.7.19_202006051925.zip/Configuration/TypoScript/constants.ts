# customcategory=sfgz_fetools=SfGZ Frontend Tools
# customsubcategory=1design=Design, Funktionen und Elemente
# customsubcategory=2basis=System

plugin.sfgz_fetools {
	settings {
	    # cat=sfgz fe tools/2basis/21; type=int; label=Meldungen nach x Sekunden ausblenden, oder nicht 0.
	    hideAlerts = 15
	    # cat=sfgz fe tools/2basis/22; type=boolean; label=JQuery laden: Markierung aufheben wenn JQuery anderweitig geladen wird
	    loadjquery = 0
	    # cat=sfgz fe tools/1design/14; type=boolean; label=Te Editor laden: Markierung aufheben wenn Rich-Text-Editor im Frontend nicht genutzt wird
	    te_editor = 0
	    # cat=sfgz fe tools/1design/11; type=boolean; label=Css mit file-extension icons:Css mit Icons der Dateitypen laden.
	    css_file_extensions = 1
	    # cat=sfgz fe tools/1design/12; type=boolean; label=Css mit Buttons:Css mit Button-design laden.
	    css_buttons = 1
	    # cat=sfgz fe tools/1design/13; type=boolean; label=JS und Css für Register-Tabs laden.
	    lib_register = 1
	}
}


