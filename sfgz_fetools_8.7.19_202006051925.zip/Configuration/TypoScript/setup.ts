## sfgz_fetools
## include JS-extensions CSS

## include JS-extension behavor ask (on delete), popUp , toggleCheck , clickCheckgroup.
page.includeJS.fetools_helpers = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/fetools_helpers.js

## include te_editor JavaScript to enable RichTextEditor in Frontend
[globalVar = LIT:0<{$plugin.sfgz_fetools.settings.te_editor}]
		# give rte-behavor to all elements with class="editor" and class="smalleditor"
        page.includeJS.jquery_te_140 = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/jquery-te-1.4.0.js
		page.includeCSS.jqte = typo3conf/ext/sfgz_fetools/Resources/Public/Css/jquery-te-1.4.0.css
		page.32 = COA
		page.32 {
			stdWrap.noTrimWrap (
		|<!-- sfgz_fetools --><script>
		|
</script><!-- /sfgz_fetools -->
		|
				)
			10 = TEXT
			10.value (
$('.editor').jqte();$('.smalleditor').jqte({'ol': false,'ul':false,'formats':false,'fsize':false,'link':false,'unlink':false,'color':false});
			)
		}
[global]

## include JavaScript and jquery 
[globalVar = LIT:0<{$plugin.sfgz_fetools.settings.loadjquery}]
		page.includeJS.jquery = https://code.jquery.com/jquery-3.4.1.js
		page.includeJS.jquery_min = https://code.jquery.com/jquery-3.4.1.min.js
		page.includeJS.jquery_uimin = https://code.jquery.com/ui/1.12.1/jquery-ui.min.js
[global]

## tigra calendar datepicker
page.includeCSS.calendar_eu = typo3conf/ext/sfgz_fetools/Resources/Public/Css/calendar.css
page.includeJS.calendar_eu = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/calendar_eu.js

## pureJsCalendar datechooser
page.includeCSS.pureJSCalendarT = typo3conf/ext/sfgz_fetools/Resources/Public/Css/pureJSCalendar.css
page.includeJS.pureJSCalendarT = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/pureJSCalendar.js


## table sorter
page.includeCSS.pager = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/tablesorter/pager/jquery.tablesorter.pager.css
page.includeJSFooter.tablesorter = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/tablesorter/js/jquery.tablesorter.js
page.includeJSFooter.tablesorter_widgets = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/tablesorter/js/jquery.tablesorter.widgets.js
page.includeJSFooter.tablesorter_pager = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/tablesorter/pager/jquery.tablesorter.pager.js
page.includeJSFooter.sfgz_tablesorter = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/fetools_tablesorter.js

## mark multiple checkboxes with shift
page.includeJSFooter.jquery_shiftcheckbox = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/gistfile1.js

## hide alerts after a given time
[globalVar = LIT:0<{$plugin.sfgz_fetools.settings.hideAlerts}]
    <INCLUDE_TYPOSCRIPT: source="FILE:EXT:sfgz_fetools/Configuration/TypoScript/optional/page.hide_alerts.ts">
[global]

[globalVar = LIT:0<{$plugin.sfgz_fetools.settings.css_file_extensions}]
    page.includeCSS.fetools_extensions_css = typo3conf/ext/sfgz_fetools/Resources/Public/Css/fetools_fileicons.css
[global]

[globalVar = LIT:0<{$plugin.sfgz_fetools.settings.css_buttons}]
    page.includeCSS.fetools_buttons_css = typo3conf/ext/sfgz_fetools/Resources/Public/Css/fetools_buttons.css
[global]

[globalVar = LIT:0<{$plugin.sfgz_fetools.settings.lib_register}]
    page.includeJS.fetools_register_js = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/fetools_register.js
    page.includeCSS.fetools_register_css = typo3conf/ext/sfgz_fetools/Resources/Public/Css/fetools_register.css
[global]

## kind of a google map by search.ch
## page.includeJS.search = https://map.search.ch/api/map.js
