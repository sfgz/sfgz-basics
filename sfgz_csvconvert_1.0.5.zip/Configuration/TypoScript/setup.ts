plugin.tx_sfgzcsvconvert_csv {
  view {
    templateRootPaths.0 = EXT:sfgz_csvconvert/Resources/Private/Templates/
    partialRootPaths.0 = EXT:sfgz_csvconvert/Resources/Private/Partials/
    layoutRootPaths.0 = EXT:sfgz_csvconvert/Resources/Private/Layouts/
  }
  settings {
		csv_attributes {
			enclosure {
				0 = 
				1 = "
				2 = '
			}
			delimiter {
				0 = ;
				1 = ,
				2 = t
			}
			charset {
				0 = ISO-8859-15
				1 = UTF-8
			}
			linebreak {
				0 = rn
				1 = n
				2 = r
				3 = nr
			}
		}
		
		output {
			enclosure = 1
			delimiter = 0
			charset = 0
			linebreak = 0
			group_by_date = 1
			group_if_time_less = 20
		}
  }
}

plugin.tx_sfgzcsvconvert._CSS_DEFAULT_STYLE (
    textarea.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    input.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    .tx-sfgz-csvconvert table {
        border-collapse:separate;
        border-spacing:10px;
    }

    .tx-sfgz-csvconvert table th {
        font-weight:bold;
    }

    .tx-sfgz-csvconvert table td {
        vertical-align:top;
    }

    .typo3-messages .message-error {
        color:red;
    }

    .typo3-messages .message-ok {
        color:green;
    }
    
	.tx-sfgz-csvconvert TABLE {
		border-collapse:collapse;
		
	}
	.tx-sfgz-csvconvert TD {
		padding:2px;
	}
	
	.tx-sfgz-csvconvert .widget:hover {
		box-shadow: 0 0 10px #00BDFF;
		border-radius: 4px;
	}
)
