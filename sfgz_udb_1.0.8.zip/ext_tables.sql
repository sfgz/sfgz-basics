#
# Table structure for table 'tx_sfgzudb_domain_model_cloudquota'
#
CREATE TABLE tx_sfgzudb_domain_model_cloudquota (

	bezeichnung varchar(255) DEFAULT '' NOT NULL,
	speicherplatz varchar(255) DEFAULT '' NOT NULL,

);

#
# Table structure for table 'tx_sfgzudb_domain_model_fachbereich'
#
CREATE TABLE tx_sfgzudb_domain_model_fachbereich (

	fachbereichname varchar(255) DEFAULT '' NOT NULL,
	cloud_key varchar(255) DEFAULT '' NOT NULL,
	usergroup int(11) DEFAULT '0' NOT NULL,
	fb_teacher int(11) unsigned DEFAULT '0' NOT NULL,

);

#
# Table structure for table 'fe_users'
#
CREATE TABLE fe_users (

	eco_acronym varchar(255) DEFAULT '' NOT NULL,
	eco_key varchar(255) DEFAULT '' NOT NULL,
	cloud_quota varchar(255) DEFAULT 0,
	eco_klasse int(11) unsigned DEFAULT '0',
	abteilung mediumtext

);

#
# Table structure for table 'tx_sfgzudb_domain_model_kurzklasse'
#
CREATE TABLE tx_sfgzudb_domain_model_kurzklasse (

	kurzbezeichnung varchar(255) DEFAULT '' NOT NULL,
	krz_cloudquota int(11) unsigned DEFAULT '0',
	krz_klasse int(11) unsigned DEFAULT '0' NOT NULL,

);

#
# Table structure for table 'tx_sfgzudb_domain_model_klasse'
#
CREATE TABLE tx_sfgzudb_domain_model_klasse (

	kurzklasse int(11) unsigned DEFAULT '0' NOT NULL,

	class_short varchar(255) DEFAULT '' NOT NULL,
	klassenname varchar(255) DEFAULT '' NOT NULL,
	klasse_kurz varchar(255) DEFAULT '' NOT NULL,
	klasse_jahr int(11) DEFAULT '0' NOT NULL,
	klasse_zug varchar(255) DEFAULT '' NOT NULL,
	klasse_start datetime DEFAULT NULL,
	klasse_ende datetime DEFAULT NULL,
	department_id int(11) DEFAULT '0' NOT NULL,
	classteacher_id int(11) DEFAULT '0' NOT NULL,
	class_id varchar(255) DEFAULT '' NOT NULL,

);

#
# Table structure for table 'tx_sfgzudb_domain_model_exportusers'
#
CREATE TABLE tx_sfgzudb_domain_model_exportusers (

	username varchar(255) DEFAULT '' NOT NULL,
	firstname varchar(255) DEFAULT '' NOT NULL,
	lastname varchar(255) DEFAULT '' NOT NULL,
	email varchar(255) DEFAULT '' NOT NULL,
	quotaspace varchar(255) DEFAULT '' NOT NULL,
	grp1 varchar(255) DEFAULT '' NOT NULL,
	grp2 varchar(255),
	grp3 varchar(255),
	grp4 varchar(255),
	grp5 varchar(255),

);

#
# Table structure for table 'tx_sfgzudb_domain_model_teacherrelation'
#
CREATE TABLE tx_sfgzudb_domain_model_teacherrelation (

	fachbereich int(11) unsigned DEFAULT '0' NOT NULL,

	leiter smallint(5) unsigned DEFAULT '0' NOT NULL,
	tea_ecouser int(11) unsigned DEFAULT '0',

);

#
# Table structure for table 'tx_sfgzudb_domain_model_teacherrelation'
#
CREATE TABLE tx_sfgzudb_domain_model_teacherrelation (

	fachbereich int(11) unsigned DEFAULT '0' NOT NULL,

);

#
# Table structure for table 'tx_sfgzudb_domain_model_klasse'
#
CREATE TABLE tx_sfgzudb_domain_model_klasse (

	kurzklasse int(11) unsigned DEFAULT '0' NOT NULL,

);
