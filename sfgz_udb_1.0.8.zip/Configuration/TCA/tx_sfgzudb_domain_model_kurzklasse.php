<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_kurzklasse',
        'label' => 'kurzbezeichnung',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'versioningWS' => true,
        'enablecolumns' => [
        ],
        'searchFields' => 'kurzbezeichnung',
        'iconfile' => 'EXT:sfgz_udb/Resources/Public/Icons/tx_sfgzudb_domain_model_kurzklasse.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'kurzbezeichnung, krz_cloudquota, krz_klasse',
    ],
    'types' => [
        '1' => ['showitem' => 'kurzbezeichnung, krz_cloudquota, krz_klasse'],
    ],
    'columns' => [
        't3ver_label' => [
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.versionLabel',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'max' => 255,
            ],
        ],

        'kurzbezeichnung' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_kurzklasse.kurzbezeichnung',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'krz_cloudquota' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_kurzklasse.krz_cloudquota',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
				'items' => array( array('keine', 0)),
                'foreign_table' => 'tx_sfgzudb_domain_model_cloudquota',
                'minitems' => 0,
                'maxitems' => 1,
            ],
        ],
        'krz_klasse' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_kurzklasse.krz_klasse',
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_sfgzudb_domain_model_klasse',
                'foreign_field' => 'kurzklasse',
                'maxitems' => 9999,
                'appearance' => [
                    'collapseAll' => 1,
                    'levelLinksPosition' => 'top',
                    'showSynchronizationLink' => 1,
                    'showPossibleLocalizationRecords' => 1,
                    'showAllLocalizationLink' => 1
                ],
            ],

        ],
    
    ],
];
