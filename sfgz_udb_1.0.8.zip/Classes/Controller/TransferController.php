<?php
namespace Sfgz\SfgzUdb\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
*
* This file is part of the "SfgzUdb" Extension for TYPO3 CMS.
*
* For the full copyright and license information, please read the
* LICENSE.txt file that was distributed with this source code.
*
*  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
*
***/

/**
* TransferController
*/
class TransferController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
    * action upload
    * 
    * @return void
    */
    public function uploadAction()
    {
        
        $iconnfile = $this->import();
        
        $this->view->assign('iconnfile', $iconnfile);
    }

    /**
    * action downloads
    * and export
    * 
    * @return void
    */
    public function downloadsAction()
    {
        
        if($this->request->hasArgument('exportfile')) {
            $this->download();
            
        }elseif($this->request->hasArgument('export')) {
            $this->export();

        }
        
    }

    /**
    * import
    * 
    * @return void
    */
    protected function import()
    {
        $path['uploadFilePathName'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->settings['uploadFilePathName']);
        $path['uploadPath'] = rtrim( dirname( $path['uploadFilePathName'] ) , '/' ) . '/';
        $path['defaultFileName'] = pathinfo( $this->settings['uploadFilePathName'] , PATHINFO_BASENAME );

        if( $this->request->hasArgument('dateiname') ){
            // new file uploaded 
            $studentUploadUtility = new \Sfgz\SfgzUdb\Utility\StudentUploadUtility();
            $uploadFilename = $studentUploadUtility->uploadFile( $path['uploadPath'] );
            if($uploadFilename){
                // transform, delete and rewrite
                $messages = $studentUploadUtility->StudentUpload( $path['uploadPath'].$uploadFilename , $path['defaultFileName'] );
                $this->addFlashMessage('Datei '. pathinfo( $uploadFilename , PATHINFO_BASENAME ) .' hochgeladen und umbenannt zu ' . $path['defaultFileName']  , 'Hochladen', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
            }
        }
        
        if($this->request->hasArgument('ecoklasse')) {
            // klicked upload button with or without file upload
            $studClassFromFileCommand = new \Sfgz\SfgzUdb\Command\StudClassFromFileCommandController();
            $aMsgs = $studClassFromFileCommand->execute();
            if( is_array($aMsgs) ){
                $this->addFlashMessage('Lernende mit Klassen verbunden am '.date('d.m.y H:i') . ' ' . implode(',',$aMsgs) , 'Verbinden', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
                
            }else{
                $this->addFlashMessage('Misslungen Lernende mit Klassen verbinden.'  , 'Verbinden', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
            }
            $this->export();
        }
        
        $iconnfile = (file_exists($path['uploadFilePathName'])) ? filemtime($path['uploadFilePathName']): '' ;
        return $iconnfile;
    }

    /**
    * export
    * 
    * @return void
    */
    protected function export()
    {
            $sqlCreateTableCommandController = new \Sfgz\SfgzUdb\Command\FillExportTableCommandController();
            $aMsgs = $sqlCreateTableCommandController->execute();
            $this->addFlashMessage('Export-Tabelle beschrieben ' . $aMsgs , 'Export', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
    }

    /**
    * download
    * 
    * @return void
    */
    protected function download()
    {
            $sqlCreateTableCommandController = new \Sfgz\SfgzUdb\Command\FillExportTableCommandController();
            $tablecontent = $sqlCreateTableCommandController->getExportTable();

            $title = 'export_users';
            $delimiter = $this->settings['csv_import']['delimiter'];
            $tq = $this->settings['csv_import']['text_qualifier'];
            if(!count($tablecontent)) return;
            $z=0;
            $delimiter = empty($delimiter) ? ';' : $delimiter;
            $firstRow = array_shift( $tablecontent );
            if(is_array($firstRow) && count($firstRow)) {
                    $strOut = $tq . implode( $tq . $delimiter . $tq , $firstRow ) . $tq."\n";
            }else{
                    return false;
            }
            foreach( $tablecontent as $idx => $row ){
                $rowArr=array();
                foreach( $firstRow as $rowNr ){
                        if(!isset($row[$rowNr])){
                            $rowArr[] =  '' ;
                        }else{
                            $cell = $row[$rowNr];
                            if(is_numeric($cell)){
                                    $rowArr[] =  $cell ;
                            }else{
                                    $rowArr[] = $tq . $cell . $tq;
                            }
                        }
                }
                $strOut .= implode( $delimiter  , $rowArr) ."\n";
            }
            
            $headers = array(
                'Pragma'                    => 'public', 
                'Expires'                   => 0, 
                'Cache-Control'             => 'must-revalidate, post-check=0, pre-check=0',
                'Cache-Control'             => 'public',
                'Content-Description'       => 'File Transfer',
                'Content-Type'              => 'application/vnd.ms-excel',
                'Content-Disposition'       => 'attachment; filename="'.$title.'.csv"',
                'Content-Transfer-Encoding' => 'binary'        
            );

            foreach($headers as $header => $data) $this->response->setHeader($header, $data); 

            $this->response->sendHeaders();  
            
            echo $strOut;
            
            exit;
    }

}
