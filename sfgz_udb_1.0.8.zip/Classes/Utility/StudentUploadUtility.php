<?php
namespace Sfgz\SfgzUdb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, SfGZ
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class StudentUploadUtility
 */

class StudentUploadUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
     * aShortclassUids
     * 
     * @var array
     */
    protected $aShortclassUids = null;

	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() 
	{
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$this->typoScriptService =  $objectManager->get('TYPO3\\CMS\\Extbase\\Service\\TypoScriptService');
		$this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray( $settings['plugin.']['tx_sfgzudb_edit.']['settings.'] );
		
		$this->loadShortClassUids();
	}
			

	/**
	 * StudentUpload
	 * adjusts fieldnames and contents
	 *
	 * @param string uploadPathFilename
	 * @param string defaultFileName
	 * @return void
	 */
	public function StudentUpload( $uploadPathFilename , $defaultFileName ) 
	{
		$uploadDir = rtrim(dirname($uploadPathFilename), '/' ) . '/' ;
		$files = $this->cmpr_getFileList($uploadDir);

		// select joungest file which is not named is2users.csv
		$joungest = '';
		foreach($files as $filnam=>$filArr){
		    if($filArr['filename']==$basename) continue;
		    if( empty($joungest) || $filArr['time'] > $files[$joungest]['time'] ) $joungest = $filnam;
		}
		$defaultFilename = $this->preProcessFieldsReWriteFile( $uploadDir.$files[$joungest]['filename'] , $defaultFileName );
		return $defaultFilename;
	}

	/**
	 * uploadFile
	 * handles file upload and deletion 
	 * returns string with filename, if action successful
	 *
	 * @param string $uploadDir
	 * @return string
	 */
	public function uploadFile( $uploadDir  ) {
		$fileName = '';
		$extKeyPlgNam = 'tx_sfgzudb_edit';
		if ($_FILES[$extKeyPlgNam]['tmp_name']['dateiname']) {
			// UPLOAD
			$fileName = $_FILES[$extKeyPlgNam]['name']['dateiname'];
			if( file_exists($uploadDir.$fileName) ) @unlink($uploadDir.$fileName);
			\TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move( $_FILES[$extKeyPlgNam]['tmp_name']['dateiname'] , $uploadDir.$fileName );
		}
		return $fileName;
	}


	/**
	 * preProcessFieldsReWriteFile 
	 * if field 'Benutzername' is missing, then extract it from 'EMail'
	 * if field 'Klasse' is missing, then try to find field 'Klassen' and rename it.
	 *
	 * @param string uploadPathFilename
	 * @param string defaultFileName
	 * @return array
	 */
	Private function preProcessFieldsReWriteFile( $uploadPathFilename , $defaultFileName ) {
		if(!file_exists($uploadPathFilename)) return false;
		$aFileRows = file($uploadPathFilename);
		
		$tq = $this->settings['csv_import']['text_qualifier'];
		
		$headrow = array_shift($aFileRows);
		$rowFields = explode( $this->settings['csv_import']['delimiter'] , trim($headrow) );
		foreach( $rowFields as $fieldIx => $cell ){ $aFieldnames[trim( $cell , $tq)] = $fieldIx ;}
		
		// only process if at least one of specific fieldnames existing
		if( !isset( $aFieldnames['EMail'] ) || ( !isset( $aFieldnames['Klasse'] ) && !isset( $aFieldnames['Klassen'] ) ) ){
				$newHeadrow = implode( $this->settings['csv_import']['delimiter'] , array_keys($aFieldnames) );
				array_unshift( $aFileRows , $newHeadrow );
				return $aFileRows; 
		}
		
		// change Klassen to Klasse
		if( isset( $aFieldnames['Klassen'] ) ) {
				$aFieldnames['Klasse'] = $aFieldnames['Klassen'];
				unset( $aFieldnames['Klassen'] );
				asort( $aFieldnames );
		}
        
		// write table header
		$newTableContent[] = implode( $this->settings['csv_import']['delimiter'] , array_keys($this->settings['csv_import']['fields']) );
		// loop thirst trough datarows, then loop fields by config
		foreach($aFileRows as $ix => $rawLine ){
//                $line = utf8_decode( $rawLine );
                $line = $rawLine;
				$row = explode( $this->settings['csv_import']['delimiter'] , trim(str_replace( '"' , '' , $line )) );
				$aNewValue = [];
                foreach( $this->settings['csv_import']['fields'] as $newFieldName => $newFieldConf ){
                
                        if( isset($newFieldConf['proc']) ){
                                $methodname = 'preProc_' . $newFieldConf['proc'];
                                if( isset($newFieldConf['source']) ){
                                    $aFlds = explode( ',' , $newFieldConf['source'] );
                                    $aOptionValue = [];
                                    foreach( $aFlds as $srcFldName ){
                                            $aOptionValue[] = $row[$aFieldnames[trim($srcFldName)]];
                                    }
                                    $options = implode( ',' , $aOptionValue );
                                }else{
                                    $options = '';
                                }
                                // run method if does exist 
                                if( method_exists( $this , $methodname ) ){
                                    $aNewValue[ $newFieldName ] = $this->$methodname( $options );
                                    
                                }else{
                                    $aNewValue[ $newFieldName ] = 'x';
                                }
                            
                        }elseif( isset($newFieldConf['map']) ){
                                $aNewValue[ $newFieldName ] = $row[$aFieldnames[$newFieldConf['map']]];
                            
                        }elseif( isset($newFieldConf['value']) ){
                                $aNewValue[ $newFieldName ] = $newFieldConf['value'];
                            
                        }else{
                                $aNewValue[ $newFieldName ] = NULL;
                        }
                }
                
				$newTableContent[] = implode( $this->settings['csv_import']['delimiter'] , $aNewValue );
		}
		
		$defaultFilename = rtrim(dirname($uploadPathFilename), '/' ) . '/' . $defaultFileName;
		
 		unlink($uploadPathFilename);
 		file_put_contents( $defaultFilename , implode("\n",$newTableContent) );
 		return $defaultFilename;
	}
	
	/**
	 * preProc_splitAtGetFirst
	 *
	 * @param string $value
	 * @return string
	 */
	Private function preProc_splitAtGetFirst( $value = '' ) {
            $aFromMail = explode( '@' , $value );
            return $aFromMail[0];
	}
	
	/**
	 * preProc_concatWhitespace
	 *
	 * @param string $value
	 * @return string
	 */
	Private function preProc_concatWhitespace( $value = '' ) {
        $aVals = explode( ',' , $value );
        $aCleanVals = [];
        foreach( $aVals as $v ) $aCleanVals[] = trim($v);
        return implode( ' ' , $aCleanVals );
	}
	
	/**
	 * preProc_classIdFromShortname
	 *
	 * @param string $value
	 * @return string
	 */
	Private function preProc_classIdFromShortname( $value = '' ) {
		return $this->aShortclassUids[$value];
	}

	/**
	 * loadShortClassUids
	 *
	 * @return void
	 */
	Private function loadShortClassUids() {
		$classAdjustHelper = new \Sfgz\SfgzUdb\Utility\AdjustScoolclassUtility();
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$klasseRepository = $objectManager->get('Sfgz\SfgzUdb\Domain\Repository\KlasseRepository');
		$classes = $klasseRepository->findAll();
		foreach($classes as $row){
                $this->aShortclassUids[trim($row->getClassShort())] = trim($row->getUid());
		}
		
	}

	/**
	 * create a list of files 
	 * and return the sum of all filesizes
	 *
	 * @param string $uploadDir
	 * @return array
	 */
	Private function cmpr_getFileList($uploadDir , $afforedExtension = 'csv') {
		$d = dir( $uploadDir );
		$filelist = array();
		while (false !== ($entry = $d->read())) {
		      $filename = pathinfo($entry , PATHINFO_FILENAME);
		      $extension = pathinfo($entry , PATHINFO_EXTENSION);
		      if( empty($afforedExtension) || $afforedExtension == $extension  ){
			  $filelist[$filename] = array(
				'filename' => $entry ,
				'basename' => pathinfo($entry , PATHINFO_BASENAME) ,
				'size' => round( filesize($uploadDir.$entry) / 1024 , 3 ),
				'time' => filemtime( $uploadDir.$entry )
			  );
		      }
		}
		$d->close();
		krsort($filelist);

		return $filelist;
	}
}
