<?php
namespace Sfgz\SfgzUdb\Domain\Repository;


/***
 *
 * This file is part of the "Sfgz User DB" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * The repository for Kurzklasses
 */
class KurzklasseRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{

    /**
     * @var array
     */
    protected $defaultOrderings = ['kurzbezeichnung' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING];

    public function findAllOrderByKurzbezeichnung() {
	      $query = $this->createQuery();
	      $query->setOrderings( array('kurzbezeichnung'=> \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING) );
	  
	      return $query->execute();
	  }
	  
	  public function callSqlStatement( $qryStatement , $ReturnRawQueryResult = TRUE) {
	      $Query = $this->createquery();
// 	      $Query->getQuerySettings()->setReturnRawQueryResult($ReturnRawQueryResult);
	      $Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
	      $Query->getQuerySettings()->setRespectStoragePage(FALSE);
	      $Query->statement($qryStatement); 
	      return $Query->execute($ReturnRawQueryResult);
	  }
	  
	  public function execQueryStatement( $qryStatement ) {
	      $Query = $this->createquery();
	      $Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
	      $Query->getQuerySettings()->setRespectStoragePage(FALSE);
	      $Query->statement( $qryStatement ); 
	      return $Query->execute(TRUE);
	  }
	
}
