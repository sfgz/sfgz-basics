<?php
namespace Sfgz\SfgzUdb\Domain\Repository;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Ecouser
 * used to extend \TYPO3\CMS\Extbase\Persistence\Repository
 */
class EcouserRepository extends \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository {

	/**
	 * @var array
	 */
	protected $defaultOrderings = array(
		'username' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
	);


	  /**
	  *  Find by user-field tx_extbase_type e.g. 'Tx_SfgzUdb_Ecouser'
	  * 
	  */
	  public function findTeachers() {
	      $query = $this->createQuery();
	      
		  $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		  $pidArr['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];

		  $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		  $querySettings->setIgnoreEnableFields( TRUE );
		  $querySettings->setRespectStoragePage(TRUE);
		  $querySettings->setStoragePageIds( $pidArr );
		  $this->setDefaultQuerySettings($querySettings);
		  
	      $query->matching(
            $query->logicalAnd(
                    $query->greaterThan('username', ''),
                    $query->equals('deleted', 0),
                    $query->equals('disable', 0)
            )
	      );
	      $query->setOrderings(
		  array(
		      'username' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
		  )
	      );	  
	      return $query->execute();
	  }


	  /**
	  *  Find by user-field tx_extbase_type e.g. 'Tx_SfgzUdb_Ecouser'
	  * (not used yet) new: used by mff_serialmail 15.3.2018
	  */
	  public function findStudents( $filter = array( 'username'=>1 ,'eco_key'=>1 ,'deleted'=>0 ,'disable'=>0 ) , $ReturnRawQueryResult = TRUE ) {
		  $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		  $pidArr['studentPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];

		  $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		  $querySettings->setIgnoreEnableFields( TRUE ); // include disabled and deleted records
		  $querySettings->setRespectStoragePage( TRUE ); // include only students, there are on page studentPid
		  $querySettings->setStoragePageIds( $pidArr );
		  $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      $conditions = array(
				'tx_extbase_type' => $query->equals('tx_extbase_type', 'Tx_SfgzUdb_Ecouser')
	      );
	      if( !empty( $filter['username'] ) ) $conditions['eco_key'] = $query->greaterThan('username', '');
	      if( !empty( $filter['eco_key'] ) ) $conditions['eco_key'] = $query->greaterThan('eco_key', '');
	      if( !empty( $filter['deleted'] ) ) $conditions['deleted'] = $query->equals('deleted', 0);
	      if( !empty( $filter['disable'] ) ) $conditions['disable'] = $query->equals('disable', 0);
	      $query->matching(
			$query->logicalAnd( $conditions )
	      );
	      $query->setOrderings(
			array(
				'username' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
			)
	      );	  
	      return $query->execute($ReturnRawQueryResult);
	  }

	  /**
	  *  Find by 'uid' IgnoreEnableFields
	  * 
	  */
	  public function findeByUid( $uid ) {
		  $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		  $querySettings->setIgnoreEnableFields(TRUE);
		  $querySettings->setRespectStoragePage(FALSE);
		  $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      if( !empty($uid) ){
		  $query->matching(
		      $query->equals('uid', $uid)
		  );
	      }
	      return $query->execute();
	  }
	  public function callSqlStatement( $qryStatement , $ReturnRawQueryResult = TRUE) {
	      $Query = $this->createquery();
	      $Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
	      $Query->getQuerySettings()->setRespectStoragePage(FALSE);
	      $Query->statement($qryStatement); 
	      return $Query->execute($ReturnRawQueryResult);
	  }
}
