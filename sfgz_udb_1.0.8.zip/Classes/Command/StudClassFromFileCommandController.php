<?php
namespace Sfgz\SfgzUdb\Command;

/**
 * Class StudClassFromFileCommandController
 * Creates relations between fe_users and tx_mffdb_domain_model_klasse
 * takes relations between students and classes from iConn-export-file
 * 
 */
class StudClassFromFileCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {

    /**
        * ingredients
        *
        * @var array
        */
    protected $ingredients = NULL;

    private function init()
    {
        $this->ingredients = $GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default'];
        $objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
        $configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
        $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
        $this->typoScriptService =  $objectManager->get('TYPO3\\CMS\\Extbase\\Service\\TypoScriptService');
        $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray( $settings['plugin.']['tx_sfgzudb_edit.']['settings.'] );
    }

    public function execute()
    {
        $status=[ 'update'=>[] , 'create'=>[] ];
        $this->init();
        
        $path['uploadFilePathName'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->settings['uploadFilePathName']);
        if(!file_exists($path['uploadFilePathName'])) return false;
        
        $aFileRows = file($path['uploadFilePathName']);
        $tq = $this->settings['csv_import']['text_qualifier'];
        
        $headrow = array_shift($aFileRows);
        $rowFields = explode( $this->settings['csv_import']['delimiter'] , str_replace( $tq , '' , $headrow) );
        foreach( $rowFields as $fieldIx => $cell ){ $aFieldnames[trim($cell)] = $fieldIx ;}
        
        $this->connection = new \mysqli( $this->ingredients['host'] , $this->ingredients['user'] , $this->ingredients['password'] , $this->ingredients['dbname'] );

        $this->removeDeletedObjects();

        foreach($aFileRows as $ix => $line ){
                $row = explode( $this->settings['csv_import']['delimiter'] , trim(str_replace( $tq , '' , $line )) );
                $syncFieldNr = $aFieldnames[ $this->settings['csv_import']['sync_key'] ];
                $uid = $this->getUsersUidByEcoKey( trim($row[ $syncFieldNr ]) );
                if($uid){//update
                            $aFldValue=['tstamp' => time()];
                            foreach( $this->settings['csv_import']['fields'] as $fldName => $fldConf ){
                                if( !$fldConf['sync_override'] ) continue;
                                $aFldValue[ $fldName ] = is_numeric($row[$aFieldnames[ $fldName ]]) ? $row[ $aFieldnames[ $fldName ] ] : $tq.$row[$aFieldnames[ $fldName ]].$tq;
                            }
                            $status['update'][$uid] =  ' u' .$uid ;
                            $this->updateUser( $aFldValue , $uid );
                            
                }else{// create
                            $aUser = [ 'tstamp' => time() , 'crdate' => time() , ];
                            foreach( $aFieldnames as $fldName => $ix ){
                                $aUser[ $fldName ] = is_numeric($row[$ix]) ? $row[$ix] : $tq.$row[$ix].$tq ;
                            }
                            $status['create'][$row[ $syncFieldNr ]] =  ' c' .$aUser[ 'username' ] ;
                            $this->createUser($aUser);
                }
                $status['pid'][$row[ $aFieldnames[ 'pid' ] ]] = $row[ $aFieldnames[ 'pid' ] ];
        }
        $this->connection->close();
        
        $cr = 'Estellt: ' . count($status['create'])    . '. ';
        $ed = 'Bearbeitet: ' . count($status['update']) . '. ';
        $pg = 'SeitenNr:' . implode(',',$status['pid']) . '. ';
        return [ $cr . $ed ];

    }

    /**
        * removeDeletedObjects
        * 
        * @return array
        */
    private function removeDeletedObjects()
    {
        $qryStatement = 'DELETE FROM `fe_users` WHERE `fe_users`.`deleted` = 1';
        $this->connection->query( $qryStatement );
        return true;
    }

    /**
        * createUser
        * 
        * @param array $aUser
        * @return array
        */
    private function createUser( $aUser )
    {
        $sql = "INSERT INTO `fe_users` (";
        $sql .= implode( ',' , array_keys($aUser) );
        $sql .= ") VALUES (";
        $sql .= implode( ',' , $aUser );
        $sql .= ");";
        $this->connection->query( $sql );
        return true;
    }

    /**
        * updateUser
        * 
        * @param array $aUser
        * @param int $uid
        * @return array
        */
    private function updateUser( $aUser , $uid )
    {
        $aFields = [];
        foreach( $aUser as $key => $val ) $aFields[] = "" . $key . " = " . $val . "";
        $sql = "UPDATE `fe_users` SET ";
        $sql .= implode(',',$aFields);
        $sql .= " WHERE `fe_users`.`uid` = " . $uid . ";";
        
        $this->connection->query( $sql );
        return true;
    }

    /**
        * getUsersUidByEcoKey
        * 
        * @param int $eco_key
        * @return int
        */
    private function getUsersUidByEcoKey( $eco_key )
    {
        $sql = "SELECT fe_users.uid FROM fe_users WHERE eco_key = " . $eco_key . ";";
        $table = $this->connection->query( $sql );
        foreach($table as $row){
            $first = $row['uid'];
            break;
        }
        return $first;
    }

}
