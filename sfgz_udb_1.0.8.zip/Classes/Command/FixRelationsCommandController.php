<?php
namespace Sfgz\SfgzUdb\Command;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Dani Rüegg <dani@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class FixRelationsCommandController
 * 
 * the main method 'execute' in this class
 * calls the method 'fixTable' with parameter 'ecoklasse'
 * 
 * The method 'fixTable' creates relations between tables, depending on the param $activeTable
 * see below for details 
 * 
 * Called from:
 * Main method execute() is called by scheduler after import. Without params, thus with default-value 'ecoklasse'
 * 
 * Method fixTable() called from BE-Plugin IscontrolController 
 * - when user starts Restore-Action
 * - by clicking one of the specific 'fix-relations' button
 * 
 */
class FixRelationsCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {

	/**
	 * Repos
	 * severeal Repository objects in a array
	 *
	 * @var array
	 */
	protected $Repos = NULL;

	/**
	 * conf
	 * Configuration
	 *
	 * @var array
	 */
	public $conf = array(
	    'extVendor'=>'Sfgz',
	    'extKey'=>'SfgzUdb',
	    'tables'=>array(
		    'ecoklasse' => array( 
				'hook'=>'StudClassFromFileCommandController',
				'editTable'=>'fe_users',
				'editKey'=>'ref_class_id',
				'editField'=>'eco_klasse',
				'foreignTable'=>'tx_sfgzudb_domain_model_klasse',
				'foreignKey'=>'class_id' 
		    ),
		    'kurzklasse' => array( 
				'editTable'=>'tx_sfgzudb_domain_model_klasse',
				'editKey'=>'klasse_kurz',
				'editField'=>'kurzklasse',
				'foreignTable'=>'tx_sfgzudb_domain_model_kurzklasse',
				'foreignKey'=>'kurzbezeichnung' 
		    )
	    )
	);
	
	/**
	* execute
	* main method of class FixRelationsCommandController
	* calls the method 'fixTable' with parameter 'ecoklasse'
	* 
	* @return void
	*/
	public function execute(){
 		$res = $this->fixTable( 'ecoklasse' );
 		return !empty($res);
 	}
 	
	/**
	* fixTable
	* called from main method 'execute'
	* 
	* this method creates relations between tables, depending on the param $activeTable
	* - with 'ecoklasse' relations between fe_users and tx_sfgzudb_domain_model_klasse
	* - with 'kurzklasse' relations between tx_sfgzudb_domain_model_klasse and tx_sfgzudb_domain_model_kurzklasse
	* 
	* @param string $activeTable 
	 * @return void
	*/
	public function fixTable( $activeTable ){
 		$tableConf = $this->conf['tables'];
 		
 		if( isset($tableConf[$activeTable]['hook']) ){
		      // ecoklasse: StudClassFromFileCommandController() sanitizes the file and renames it!
		      $controllername = str_replace( '##HOOK##' , $tableConf[$activeTable]['hook'] , '\Sfgz\SfgzUdb\Command\##HOOK##' );
		      $studClassFromFileTask = new $controllername();
		      $messages =  $studClassFromFileTask->execute();
 		}else{
		      $messages = false;
 		}

 		// if we produced new relations then they are empty... 
 		$emptyRecordsets = $this->findEmptyRecords( $tableConf[$activeTable] );
		if(!count($emptyRecordsets)) return $messages;
		// connect only if there are some empty records
 		
		// define Repository-Names and the name of method 
 		$editReposName = $this->table2repository( $tableConf[$activeTable]['editTable'] );
		if( !isset($this->Repos[$editReposName]) ) $this->Repos[$editReposName] = $this->objectManager->get('' . $this->conf['extVendor'] . '\\' . ucfirst($this->conf['extKey']) . '\\Domain\\Repository\\'.$editReposName.'Repository');
		$foreignReposName = $this->table2repository( $tableConf[$activeTable]['foreignTable'] );
		if( !isset($this->Repos[$foreignReposName]) ) $this->Repos[$foreignReposName] = $this->objectManager->get('' . $this->conf['extVendor'] . '\\' . ucfirst($this->conf['extKey']) . '\\Domain\\Repository\\'.$foreignReposName.'Repository');
		$editCmd = 'set'.$this->field2property( $tableConf[$activeTable]['editField'] ) ;
		// e.g. setEcoKlasse
		
 		// insert foreign object to edit field
		foreach($emptyRecordsets as $corrRs){
		    $connectRecord = $this->Repos[$foreignReposName]->findByUid( $corrRs['foreign_uid'] );
		    $editRecord = $this->Repos[$editReposName]->findByUid($corrRs['edit_uid']);
		    if( $editRecord && $connectRecord ){
			  $editRecord->$editCmd( $connectRecord );
			  $this->Repos[$editReposName]->update($editRecord);
		    }
		}
		
		// persist 
		$persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		$persistenceManager->persistAll();
		
 		return $messages;
 		
	}

	public function table2repository( $tableName ){
		$tableNameReplacements = array( 'fe_users' => 'Ecouser' );
		if( !empty($tableNameReplacements[$tableName]) ) return $tableNameReplacements[$tableName];
		$namRest = substr( $tableName , strlen('tx_' . strtolower( $this->conf['extKey'] ) . '_domain_model_') );
		if(empty($namRest)) return $tableName;
		return ucfirst($namRest);
	}
	
	public function field2property( $fieldName ){
		$namArr = explode( '_' , $fieldName );
		$namRest='';
		foreach($namArr as $part){ $namRest .= ucfirst($part); }
		return ucfirst($namRest);
	}
	public function findEmptyRecords( $activeTableConf ){
		$this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$tablesRepository = $this->objectManager->get('' . $this->conf['extVendor'] . '\\SfgzUdb\\Domain\\Repository\\KurzklasseRepository');
		
		$eT = $activeTableConf['editTable'];
		$eK = $activeTableConf['editKey'];
		$eF = $activeTableConf['editField'];
		$fT = $activeTableConf['foreignTable'];
		$fK = $activeTableConf['foreignKey'] ;
		
		$sql = 'SELECT '.$eT.'.uid as edit_uid,  '.$fT.'.uid as foreign_uid ';
		$sql.= 'FROM '.$eT.' JOIN '.$fT.' ';
		$sql.= 'ON '.$eT.'.'.$eK.'='.$fT.'.'.$fK.' ';
		$sql.= 'WHERE NOT '.$eT.'.'.$eK.' IS NULL ';
		$sql.= 'AND (NOT '.$eT.'.'.$eF.' = '.$fT.'.uid OR '.$eT.'.'.$eF.' IS NULL) ';
		$sql.= 'AND NOT '.$fT.'.'.$fK.' IS NULL';
		return $tablesRepository->execQueryStatement( $sql );
	}

}
