<?php
namespace Sfgz\SfgzUdb\Command;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Dani Rüegg <dani@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class UsergroupsCommandController
 * Creates relations between fe_groups and fe_users
 * Called by TeacherrelationsCommandController()
 * 
 * this relations are taken from table tx_sfgzudb_domain_model_teacherrelation
 * the fe_groups for Fachbereich are stored in the  sfgz_udb container
 * before building new relations, this script deletes all relations to Fachbereich-fe_groups
 * 
 * please store manually edited usergroups in same page (container) as fe_users, 
 * and insert there the Fachbereich-Usergroups from sfgz_udb container
 * 
 */
 
class UsergroupsCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {

	/**
	 * fachbereichRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\FachbereichRepository
	 */
	protected $fachbereichRepository = NULL;

	/**
	 * teacherRelationRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\TeacherRelationRepository
	 */
	protected $teacherRelationRepository = NULL;

	/**
	 * ecouserRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\EcouserRepository
	 */
	protected $ecouserRepository = NULL;
	
	/**
	 * frontendUserGroupRepository
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserGroupRepository
	 */
	protected $frontendUserGroupRepository = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 */
	protected $persistenceManager = NULL;

	/**
	 * storagePid
	 *
	 * @var integer
	 */
	protected $storagePid = NULL;

	public function execute( ){
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$this->storagePid = $fullsettings['plugin.']['tx_sfgzudb_edit.']['persistence.']['storagePid'];
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setStoragePageIds( array( $this->storagePid ) );
		$this->teacherRelationRepository = $objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\TeacherRelationRepository');
		$this->teacherRelationRepository->setDefaultQuerySettings($querySettings);

		$this->fachbereichRepository = $objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\FachbereichRepository');
		$this->fachbereichRepository->setDefaultQuerySettings($querySettings);

		$dQuerySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$dQuerySettings->setRespectStoragePage(FALSE);
		$this->frontendUserGroupRepository = $objectManager->get('TYPO3\\CMS\\Extbase\\Domain\\Repository\\FrontendUserGroupRepository');
		$this->frontendUserGroupRepository->setDefaultQuerySettings($dQuerySettings);

		$teachersQuerySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$teacherStorage['storagePid'] = $fullsettings['plugin.']['tx_sfgzudb_edit.']['settings.']['teacherPid'];
		$teachersQuerySettings->setStoragePageIds( $teacherStorage );
		$this->ecouserRepository = $objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\EcouserRepository');
		$this->ecouserRepository->setDefaultQuerySettings($teachersQuerySettings);

		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		
		// look up for possible relations and crete them
		$this->deleteAutoRelations( $dbStorage['storagePid'] );
		$createResult = $this->createAutoRelations();
		return $createResult;
	}
	
	/**
	 * deleteAutoRelations
	 *
	 * @param \TYPO3\CMS\Extbase\Domain\Model\FrontendUser $objTeacher
	 * @param int $fachbereichUid 
	 * @return void
	 */
	private function updateOneAutoRelation( $objTeacher , $fachbereichUid ){
		// collect groups stored in db-container
		$repGroups = $this->frontendUserGroupRepository->findByPid($storagePid);
		foreach( $repGroups as $ix => $objGroup ) $pluginGroup[$objGroup->getUid()] = $objGroup;
		// erase specified group-uid's from usergroup-field
		$oUsergroups = $objTeacher->getUsergroup();
		if($oUsergroups){
			foreach($oUsergroups as $uGrp){ 
				$grp = $uGrp->getUid();
				if( isset($pluginGroup[$grp]) )  {
                        $objTeacher->removeUsergroup( $pluginGroup[$grp] ); 
				}
			}
		}

		// get group-uid's of fachbereiches
		$repFachbereichs = $this->fachbereichRepository->findByUid($fachbereichUid);
		$fbUsergroupUid = $repFachbereichs->getUsergroup();
		$objFachbereichGroup =  $this->frontendUserGroupRepository->findByUid($fbUsergroupUid);
		
		$setGroups = array();
		$oUsergroups = $objTeacher->getUsergroup();
		if( $oUsergroups ) {
		    foreach($oUsergroups as $gIx => $uGrp){ 
			  $setGroups[ $uGrp->getUid() ] = $gIx ;
		    }
		}
		if( !isset($setGroups[ $fbUsergroupUid ]) && $objFachbereichGroup ){
		      $objTeacher->addUsergroup($objFachbereichGroup); 
		}
		$this->ecouserRepository->update($objTeacher);
	}
	
	/**
	 * deleteAutoRelations
	 *
	 * @param int $storagePid 
	 * @return void
	 */
	private function deleteAutoRelations( $storagePid ){
		// collect groups stored in db-container
		$repGroups = $this->frontendUserGroupRepository->findByPid($storagePid);
		foreach( $repGroups as $ix => $objGroup ) $pluginGroup[$objGroup->getUid()] = $objGroup;
		
		// erase specified group-uid's from usergroup-field
		$repTeachers = $this->ecouserRepository->findAll();
		foreach( $repTeachers as $objTeacher ){
		      $oUsergroups = $objTeacher->getUsergroup();
		      if(!$oUsergroups) continue;
		      foreach($oUsergroups as $uGrp){ 
                    $grp = $uGrp->getUid();
                    if( isset($pluginGroup[$grp]) )  {
                            $objTeacher->removeUsergroup( $pluginGroup[$grp] ); 
                    }
		      }
		      $this->ecouserRepository->update($objTeacher);
		}
		$this->persistenceManager->persistAll();
		return true;
	}
	
	/**
	 * createAutoRelations
	 *
	 * @return void
	 */
	private function createAutoRelations( ){
		// get group-uid's of fachbereiches
		$repFachbereichs = $this->fachbereichRepository->findAll();
		foreach( $repFachbereichs as $objFachbereich ){
		      $fbUsergroupUid = $objFachbereich->getUsergroup();
		      if(empty($fbUsergroupUid) ) continue;
		      $fachbereichGroupUid[ $objFachbereich->getUid() ] = $fbUsergroupUid;
		      $oGroups =  $this->frontendUserGroupRepository->findByUid($fbUsergroupUid);
		      $pidGroups = $oGroups->getPid();
		      if( $pidGroups == $this->storagePid ) $fbGroupObj[ $fbUsergroupUid ] = $oGroups;
		}
		if( !is_array($fbGroupObj) || !count($fbGroupObj) ) return true;;
		// set usergroup related to fachbereich, 
		// possibly some user belongs to more than a single group
		$teaRelRepository = $this->teacherRelationRepository->callSqlStatement( 'SELECT * FROM tx_sfgzudb_domain_model_teacherrelation;' );
		foreach($teaRelRepository as $row){
		      $fbUsergroupUid = $fachbereichGroupUid[ $row['fachbereich'] ];
		      $objTeacher = $this->ecouserRepository->findByUid( $row['tea_ecouser'] );
		      if(!$objTeacher) continue;
		      $setGroups = array();
		      $oUsergroups = $objTeacher->getUsergroup();
		      if( $oUsergroups ) {
                    foreach($oUsergroups as $gIx => $uGrp){ 
                        $setGroups[ $uGrp->getUid() ] = $gIx ;
                    }
		      }
		      if( !isset($setGroups[ $fbUsergroupUid ]) && $fbGroupObj[ $fbUsergroupUid ] ){
                    $objTeacher->addUsergroup($fbGroupObj[ $fbUsergroupUid ]); 
		      }
		      $this->ecouserRepository->update($objTeacher);
		}
		$this->persistenceManager->persistAll();
		return true;
	}

}
