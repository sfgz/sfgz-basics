<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_fachbereich',
        'label' => 'fachbereichname',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
        'versioningWS' => true,
        'enablecolumns' => [
        ],
        'searchFields' => 'fachbereichname,cloud_key',
        'iconfile' => 'EXT:sfgz_udb/Resources/Public/Icons/tx_sfgzudb_domain_model_fachbereich.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'fachbereichname, cloud_key, usergroup, fb_teacher',
    ],
    'types' => [
        '1' => ['showitem' => 'fachbereichname, cloud_key, usergroup, fb_teacher'],
    ],
    'columns' => [
        't3ver_label' => [
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.versionLabel',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'max' => 255,
            ],
        ],

        'fachbereichname' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_fachbereich.fachbereichname',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'cloud_key' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_fachbereich.cloud_key',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'usergroup' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_fachbereich.usergroup',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
				'items' => array( array('keine', 0)),
				'foreign_table' => 'fe_groups',
				'minitems' => 0,
				'maxitems' => 1,
                'size' => 1,
                'eval' => ''
            ],
        ],
        'fb_teacher' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_fachbereich.fb_teacher',
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_sfgzudb_domain_model_teacherrelation',
                'foreign_field' => 'fachbereich',
                'maxitems' => 9999,
                'appearance' => [
                    'collapseAll' => 1,
                    'levelLinksPosition' => 'top',
                    'showSynchronizationLink' => 1,
                    'showPossibleLocalizationRecords' => 1,
                    'showAllLocalizationLink' => 1
                ],
            ],

        ],
    
    ],
];
