<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers',
        'label' => 'username',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'versioningWS' => true,
        'enablecolumns' => [
        ],
        'searchFields' => 'username,firstname,lastname,email,quotaspace,grp1,grp2,grp3,grp4,grp5',
        'iconfile' => 'EXT:sfgz_udb/Resources/Public/Icons/tx_sfgzudb_domain_model_exportusers.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'username, firstname, lastname, email, quotaspace, grp1, grp2, grp3, grp4, grp5',
    ],
    'types' => [
        '1' => ['showitem' => 'username, firstname, lastname, email, quotaspace, grp1, grp2, grp3, grp4, grp5'],
    ],
    'columns' => [
        't3ver_label' => [
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.versionLabel',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'max' => 255,
            ],
        ],

        'username' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers.username',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'firstname' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers.firstname',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'lastname' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers.lastname',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'email' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers.email',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'quotaspace' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers.quotaspace',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'grp1' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers.grp1',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'grp2' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers.grp2',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'grp3' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers.grp3',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'grp4' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers.grp4',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'grp5' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_exportusers.grp5',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
    
    ],
];
