<?php
namespace Sfgz\SfgzUdb\Controller;


/***
 *
 * This file is part of the "Sfgz User DB" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * KurzklasseController
 */
class KurzklasseController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * kurzklasseRepository
     * 
     * @var \Sfgz\SfgzUdb\Domain\Repository\KurzklasseRepository
     * @inject
     */
    protected $kurzklasseRepository = null;

    /**
     * cloudquotaRepository
     * 
     * @var \Sfgz\SfgzUdb\Domain\Repository\CloudquotaRepository
     * @inject
     */
    protected $cloudquotaRepository = null;

	/**
	 * ecouserRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\EcouserRepository
	 */
	protected $ecouserRepository = NULL;

	public function initializeAction() {
		
            $dQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $dQuerySettings->setRespectStoragePage(FALSE);
            $this->cloudquotaRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\CloudquotaRepository');
            $this->cloudquotaRepository->setDefaultQuerySettings($dQuerySettings);

            $userQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $userQuerySettings->setRespectStoragePage(TRUE);
            $userQuerySettings->setStoragePageIds( [ $this->settings['studentPid'] ] );
            $this->ecouserRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\EcouserRepository');
            $this->ecouserRepository->setDefaultQuerySettings($userQuerySettings);
	}

    /**
     * action list
     * 
     * @return void
     */
    public function listAction()
    {
        if( $this->request->hasArgument('submit') ){
            $tc = $this->request->getArgument('submit');
            if( isset($tc['set_quota']) && isset($tc['kurzklasse']) ) {
                $oKurzklasse = $this->kurzklasseRepository->findByUid( $tc['kurzklasse'] );
                $oQuota = $this->cloudquotaRepository->findByUid( $tc['set_quota'] );
                if( $oQuota ){
                    $oKurzklasse->setKrzCloudquota( $oQuota );
                    $this->kurzklasseRepository->update($oKurzklasse);
                    $this->addFlashMessage('Quota gespeichert.', 'gespeichert' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
                }else{
                    $this->addFlashMessage('Die Quota kann nicht geleert werden.', 'Quota entfernen aus Kurzklasse Nr. ' . $tc['kurzklasse'] .'...', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
                }
            }
        }
        $kurzklasses = $this->kurzklasseRepository->findAll();
        $cloudquotas = $this->cloudquotaRepository->findAll();
        $this->view->assign('cloudquotas', $cloudquotas);
        
        $cloudQuotaUtility = new \Sfgz\SfgzUdb\Utility\IntranetUsersUtility();
        $kurzklasseList = $cloudQuotaUtility->getKurzklasseList();
        $this->view->assign('classes', $kurzklasseList );
        
    }

    /**
     * action new
     * 
     * @return void
     */
    public function newAction()
    {
    }

    /**
     * action create
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Kurzklasse $newKurzklasse
     * @return void
     */
    public function createAction(\Sfgz\SfgzUdb\Domain\Model\Kurzklasse $newKurzklasse)
    {
        $this->addFlashMessage('The object was created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->kurzklasseRepository->add($newKurzklasse);
        $this->redirect('list');
    }

    /**
     * action edit
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Kurzklasse $kurzklasse
     * @ignorevalidation $kurzklasse
     * @return void
     */
    public function editAction(\Sfgz\SfgzUdb\Domain\Model\Kurzklasse $kurzklasse)
    {
        $this->view->assign('kurzklasse', $kurzklasse);
    }

    /**
     * action update
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Kurzklasse $kurzklasse
     * @return void
     */
    public function updateAction(\Sfgz\SfgzUdb\Domain\Model\Kurzklasse $kurzklasse)
    {
        $this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->kurzklasseRepository->update($kurzklasse);
        $this->redirect('list');
    }

    /**
     * action delete
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Kurzklasse $kurzklasse
     * @return void
     */
    public function deleteAction(\Sfgz\SfgzUdb\Domain\Model\Kurzklasse $kurzklasse)
    {
        $this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->kurzklasseRepository->remove($kurzklasse);
        $this->redirect('list');
    }
}
