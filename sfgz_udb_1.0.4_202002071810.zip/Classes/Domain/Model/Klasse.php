<?php
namespace Sfgz\SfgzUdb\Domain\Model;


/***
 *
 * This file is part of the "Sfgz User DB" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * Klasse
 */
class Klasse extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

	/**
	 * kurzklasse
	 *
	 * @var int
	 */
	protected $kurzklasse = 0;

    /**
     * classShort
     * 
     * @var string
     */
    protected $classShort = '';

    /**
     * klassenname
     * 
     * @var string
     */
    protected $klassenname = '';

    /**
     * klasseKurz
     * 
     * @var string
     */
    protected $klasseKurz = '';

    /**
     * klasseJahr
     * 
     * @var int
     */
    protected $klasseJahr = 0;

    /**
     * klasseZug
     * 
     * @var string
     */
    protected $klasseZug = '';

    /**
     * klasseStart
     * 
     * @var \DateTime
     */
    protected $klasseStart = null;

    /**
     * klasseEnde
     * 
     * @var \DateTime
     */
    protected $klasseEnde = null;

    /**
     * departmentId
     * 
     * @var int
     */
    protected $departmentId = 0;

    /**
     * classteacherId
     * 
     * @var int
     */
    protected $classteacherId = 0;

    /**
     * classId
     * 
     * @var string
     */
    protected $classId = '';

	/**
	 * Returns the kurzklasse
	 *
	 * @return string $kurzklasse
	 */
	public function getKurzklasse() {
		return $this->kurzklasse;
	}

	/**
	 * Sets the kurzklasse
	 *
	 * @param string $kurzklasse
	 * @return void
	 */
	public function setKurzklasse($kurzklasse) {
		$this->kurzklasse = $kurzklasse;
	}

    /**
     * Returns the classShort
     * 
     * @return string $classShort
     */
    public function getClassShort()
    {
        return $this->classShort;
    }

    /**
     * Sets the classShort
     * 
     * @param string $classShort
     * @return void
     */
    public function setClassShort($classShort)
    {
        $this->classShort = $classShort;
    }

    /**
     * Returns the klassenname
     * 
     * @return string $klassenname
     */
    public function getKlassenname()
    {
        return $this->klassenname;
    }

    /**
     * Sets the klassenname
     * 
     * @param string $klassenname
     * @return void
     */
    public function setKlassenname($klassenname)
    {
        $this->klassenname = $klassenname;
    }

    /**
     * Returns the klasseKurz
     * 
     * @return string $klasseKurz
     */
    public function getKlasseKurz()
    {
        return $this->klasseKurz;
    }

    /**
     * Sets the klasseKurz
     * 
     * @param string $klasseKurz
     * @return void
     */
    public function setKlasseKurz($klasseKurz)
    {
        $this->klasseKurz = $klasseKurz;
    }

    /**
     * Returns the klasseJahr
     * 
     * @return int $klasseJahr
     */
    public function getKlasseJahr()
    {
        return $this->klasseJahr;
    }

    /**
     * Sets the klasseJahr
     * 
     * @param int $klasseJahr
     * @return void
     */
    public function setKlasseJahr($klasseJahr)
    {
        $this->klasseJahr = $klasseJahr;
    }

    /**
     * Returns the klasseZug
     * 
     * @return string $klasseZug
     */
    public function getKlasseZug()
    {
        return $this->klasseZug;
    }

    /**
     * Sets the klasseZug
     * 
     * @param string $klasseZug
     * @return void
     */
    public function setKlasseZug($klasseZug)
    {
        $this->klasseZug = $klasseZug;
    }

    /**
     * Returns the klasseStart
     * 
     * @return \DateTime $klasseStart
     */
    public function getKlasseStart()
    {
        return $this->klasseStart;
    }

    /**
     * Sets the klasseStart
     * 
     * @param \DateTime $klasseStart
     * @return void
     */
    public function setKlasseStart(\DateTime $klasseStart)
    {
        $this->klasseStart = $klasseStart;
    }

    /**
     * Returns the klasseEnde
     * 
     * @return \DateTime $klasseEnde
     */
    public function getKlasseEnde()
    {
        return $this->klasseEnde;
    }

    /**
     * Sets the klasseEnde
     * 
     * @param \DateTime $klasseEnde
     * @return void
     */
    public function setKlasseEnde(\DateTime $klasseEnde)
    {
        $this->klasseEnde = $klasseEnde;
    }

    /**
     * Returns the departmentId
     * 
     * @return int $departmentId
     */
    public function getDepartmentId()
    {
        return $this->departmentId;
    }

    /**
     * Sets the departmentId
     * 
     * @param int $departmentId
     * @return void
     */
    public function setDepartmentId($departmentId)
    {
        $this->departmentId = $departmentId;
    }

    /**
     * Returns the classteacherId
     * 
     * @return int $classteacherId
     */
    public function getClassteacherId()
    {
        return $this->classteacherId;
    }

    /**
     * Sets the classteacherId
     * 
     * @param int $classteacherId
     * @return void
     */
    public function setClassteacherId($classteacherId)
    {
        $this->classteacherId = $classteacherId;
    }

    /**
     * Returns the classId
     * 
     * @return string $classId
     */
    public function getClassId()
    {
        return $this->classId;
    }

    /**
     * Sets the classId
     * 
     * @param string $classId
     * @return void
     */
    public function setClassId($classId)
    {
        $this->classId = $classId;
    }
}
