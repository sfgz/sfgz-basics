<?php
namespace Sfgz\SfgzUdb\Domain\Model;


/***
 *
 * This file is part of the "Sfgz User DB" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
 
/**
 * Ecouser
 * used to extend \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
 */
class Ecouser extends \TYPO3\CMS\Extbase\Domain\Model\FrontendUser {

    /**
     * ecoAcronym
     * 
     * @var string
     */
    protected $ecoAcronym = '';

    /**
     * ecoKey
     * 
     * @var string
     */
    protected $ecoKey = '';

    /**
     * cloudQuota
     * 
     * @var string
     */
    protected $cloudQuota = '';

    /**
     * Bei Lernenden die Klasse (automatisch)
     * 
     * @var \Sfgz\SfgzUdb\Domain\Model\Klasse
     */
    protected $ecoKlasse = null;

    /**
     * Returns the ecoAcronym
     * 
     * @return string $ecoAcronym
     */
    public function getEcoAcronym()
    {
        return $this->ecoAcronym;
    }

    /**
     * Sets the ecoAcronym
     * 
     * @param string $ecoAcronym
     * @return void
     */
    public function setEcoAcronym($ecoAcronym)
    {
        $this->ecoAcronym = $ecoAcronym;
    }

    /**
     * Returns the ecoKey
     * 
     * @return string $ecoKey
     */
    public function getEcoKey()
    {
        return $this->ecoKey;
    }

    /**
     * Sets the ecoKey
     * 
     * @param string $ecoKey
     * @return void
     */
    public function setEcoKey($ecoKey)
    {
        $this->ecoKey = $ecoKey;
    }

    /**
     * Returns the cloudQuota
     * 
     * @return string $cloudQuota
     */
    public function getCloudQuota()
    {
        return $this->cloudQuota;
    }

    /**
     * Sets the cloudQuota
     * 
     * @param string $cloudQuota
     * @return void
     */
    public function setCloudQuota($cloudQuota)
    {
        $this->cloudQuota = $cloudQuota;
    }

    /**
     * Returns the ecoKlasse
     * 
     * @return \Sfgz\SfgzUdb\Domain\Model\Klasse $ecoKlasse
     */
    public function getEcoKlasse()
    {
        return $this->ecoKlasse;
    }

    /**
     * Sets the ecoKlasse
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Klasse $ecoKlasse
     * @return void
     */
    public function setEcoKlasse(\Sfgz\SfgzUdb\Domain\Model\Klasse $ecoKlasse)
    {
        $this->ecoKlasse = $ecoKlasse;
    }
}
