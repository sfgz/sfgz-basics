<?php
namespace Sfgz\SfgzUdb\Domain\Model;


/***
 *
 * This file is part of the "SfgzUdb" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * Fachbereich
 */
class Fachbereich extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * fachbereichname
     * 
     * @var string
     */
    protected $fachbereichname = '';

    /**
     * cloudKey
     * 
     * @var string
     */
    protected $cloudKey = '';

    /**
     * usergroup
     * 
     * @var int
     */
    protected $usergroup = 0;

    /**
     * fbTeacher
     * 
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzUdb\Domain\Model\TeacherRelation>
     * @TYPO3\CMS\Extbase\Annotation\ORM\Cascade("remove")
     */
    protected $fbTeacher = null;

    /**
     * Returns the fachbereichname
     * 
     * @return string $fachbereichname
     */
    public function getFachbereichname()
    {
        return $this->fachbereichname;
    }

    /**
     * Sets the fachbereichname
     * 
     * @param string $fachbereichname
     * @return void
     */
    public function setFachbereichname($fachbereichname)
    {
        $this->fachbereichname = $fachbereichname;
    }

    /**
     * Returns the cloudKey
     * 
     * @return string $cloudKey
     */
    public function getCloudKey()
    {
        return $this->cloudKey;
    }

    /**
     * Sets the cloudKey
     * 
     * @param string $cloudKey
     * @return void
     */
    public function setCloudKey($cloudKey)
    {
        $this->cloudKey = $cloudKey;
    }

    /**
     * Returns the usergroup
     * 
     * @return int $usergroup
     */
    public function getUsergroup()
    {
        return $this->usergroup;
    }

    /**
     * Sets the usergroup
     * 
     * @param int $usergroup
     * @return void
     */
    public function setUsergroup($usergroup)
    {
        $this->usergroup = $usergroup;
    }

    /**
     * __construct
     */
    public function __construct()
    {

        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     * 
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->fbTeacher = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Adds a TeacherRelation
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\TeacherRelation $fbTeacher
     * @return void
     */
    public function addFbTeacher(\Sfgz\SfgzUdb\Domain\Model\TeacherRelation $fbTeacher)
    {
        $this->fbTeacher->attach($fbTeacher);
    }

    /**
     * Removes a TeacherRelation
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\TeacherRelation $fbTeacherToRemove The TeacherRelation to be removed
     * @return void
     */
    public function removeFbTeacher(\Sfgz\SfgzUdb\Domain\Model\TeacherRelation $fbTeacherToRemove)
    {
        $this->fbTeacher->detach($fbTeacherToRemove);
    }

    /**
     * Returns the fbTeacher
     * 
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzUdb\Domain\Model\TeacherRelation> $fbTeacher
     */
    public function getFbTeacher()
    {
        return $this->fbTeacher;
    }

    /**
     * Sets the fbTeacher
     * 
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzUdb\Domain\Model\TeacherRelation> $fbTeacher
     * @return void
     */
    public function setFbTeacher(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $fbTeacher)
    {
        $this->fbTeacher = $fbTeacher;
    }
}
