<?php

/***************************************************************
 * Extension Manager/Repository config file for ext: "sfgz_fetools"
 *
 ***************************************************************/

$EM_CONF[$_EXTKEY] = [
	'title' => 'SfGZ Fe Tools',
	'description' => 'Js and Icons Collection',
	'category' => 'plugin',
	'author' => 'Daniel Rueegg',
	'author_email' => 'colormixture@verarbeitung.ch',
	'state' => 'beta',
	'uploadfolder' => '0',
	'createDirs' => '',
	'clearCacheOnLoad' => 0,
	'version' => '8.7.11',
    'constraints' => [
        'depends' => [
            'typo3' => '7.6.0-9.9.99',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];
