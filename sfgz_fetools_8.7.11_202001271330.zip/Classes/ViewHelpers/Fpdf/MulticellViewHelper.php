<?php
namespace Sfgz\SfgzFetools\ViewHelpers\Fpdf;
 
class MulticellViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper {
 
    public function initializeArguments() {
	$this->registerArgument('font','string','Helvetica',FALSE);
	$this->registerArgument('size','int',12,FALSE);
	$this->registerArgument('markup','string','B|I|',FALSE);
	$this->registerArgument('x','int','0,n',FALSE);
    }
    
    /**
     * 
     * @param string $width 
     * @param int $height
     * @param string $text
     * @param string $border
     * @param string $align
     * @param int $fill
     */
    public function render($width='0', $height=12, $text='', $border='', $align='L', $fill=0){

	$pdf = $this->templateVariableContainer->get('fpdf');
	$margins = $this->templateVariableContainer->get('margins');

	if(empty($text)) $text = $this->renderChildren();
	$decodedText = utf8_decode($text);
	
	if( ($this->arguments['font']) || ($this->arguments['size']) || ($this->arguments['markup']) ){
	      $fontFamily = ($this->arguments['font']) ? $this->arguments['font'] : 'Helvetica';
	      $fontSize = ($this->arguments['size']) ? $this->arguments['size'] : 12;
	      $markup = ($this->arguments['markup']) ? $this->arguments['markup'] : '';
	      $pdf->SetFont($fontFamily,$markup,$fontSize);
        }
        
	if( $this->arguments['x'] >= 1 ){
	      $pdf->SetX($this->arguments['x']);
	}
	$pdf->MultiCell($width, $height, $decodedText , $border , $align , $fill );
	$pdf->SetX( $margins['left'] );
 
    }
 
}
