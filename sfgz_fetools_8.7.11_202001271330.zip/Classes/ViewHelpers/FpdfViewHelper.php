<?php
namespace Sfgz\SfgzFetools\ViewHelpers;

$extDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName('typo3conf/ext/sfgz_fetools/Resources/Private/PHP/fpdf/');
define( 'FPDF_FONTPATH' , $extDir .  'font/' ); 
set_include_path($extDir);
include $extDir.'html2pdf.php';
include $extDir.'PdfPageGroup.php';

class FpdfViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper {
 
    public function initializeArguments() {
	$this->registerArgument('documentname','string','Report',FALSE);
	$this->registerArgument('style','string','pagina',FALSE);
	$this->registerArgument('keywords','string','Mathe Klausur generiert Educalc',FALSE);
	$this->registerArgument('margins','array','{left:10 , top:15 , right:25 , bottom:10 }',FALSE);
    }
    public function render() {
        if( count($this->arguments['margins']) ) {
	    $margins = $this->arguments['margins'];
        }else{
	    $margins = array( 'left'=>10,'top'=>15,'right'=>5,'bottom'=>10,'fontFamily'=>'Helvetica');
        }
        
        if( $this->arguments['style'] == 'pagina' ) {
	    $pdf = new \PdfPageGroup('P','mm','A4');
        }else{
	    $pdf = new \mffPDF('P','mm','A4');
        }
        
        if( !empty($this->arguments['keywords']) ) {
	    $pdf->SetKeywords( utf8_decode( $this->arguments['keywords']) );
        }else{
	    $pdf->SetKeywords( 'Mathe Rechnen Klausur generiert Educalc' );
	}
        if( !empty($this->arguments['documentname']) ) {
	    $dokumentname =  $this->arguments['documentname'] ;
        }else{
	    $dokumentname =  'Report' ;
	}
	
	$pdf->SetTopMargin( $margins['top'] );
	$pdf->SetLeftMargin( $margins['left'] );
	$pdf->SetRightMargin( $margins['right'] );
// 	$pdf->SetAutoPageBreak( TRUE , $margins['bottom'] );
	$pdf->SetAutoPageBreak( FALSE  );
	$pdf->SetTextColor(0,0,0);
	$pdf->SetDrawColor(0,0,0);
	$pdf->SetFont('Helvetica','',12);
 
        $tpdf = new \HTML2PDF('P','mm','A4');
	$tpdf->SetTopMargin( $margins['top'] );
	$tpdf->SetLeftMargin( $margins['left'] );
	$tpdf->SetRightMargin( $margins['right'] );
	$tpdf->SetFont('Helvetica','',12);

        $this->templateVariableContainer->add('tpdf', $tpdf);
        $this->templateVariableContainer->add('fpdf', $pdf);
        $this->templateVariableContainer->add('margins', $margins);
        
        $this->renderChildren();

        $pdf->Output($dokumentname.'.pdf', 'I');
 
        $this->templateVariableContainer->remove('tpdf');
        $this->templateVariableContainer->remove('fpdf');
        $this->templateVariableContainer->remove('margins');
 
        exit();
    }
}
