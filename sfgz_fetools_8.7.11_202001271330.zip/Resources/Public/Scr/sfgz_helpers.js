// ask bevore delete-behavor
$(document).ready(function(){
	$("A.delete").click( function(){
		if( window.confirm('Wirklich löschen?') ) return true;
		return false;
	} );	

});

function popUpRawUrl( id_string , raw_url, win , w , h , t , l ) {
      return popUp( rawUrl2url( id_string , raw_url ), win , w , h , t , l );
}
function popUp( url, win , w , h , t , l ) {
      vHWin=window.open(
	    url,
	    win,
	    'width=' + w + ',height=' + h + ',top=' + t + ',left=' + l + ',scrollbars=1,resizable=1,status=0,menubar=0,toolbar=0'
      );
      vHWin.focus();
      return false;
}
function rawUrl2url( id_string , raw_url ) {
      var arr = id_string.split('_');
      var url = raw_url.replace( '_REP_VALUE_' , arr[1] ).replace( '_REP_NAME_' , arr[0] );
      return url;
}


function date_time2timestamp( dateString , timeString ) {
		// dateString = '17-09-2013 10:08'
		var dateTimeParts = dateString.split(' ');
		var dateParts = dateTimeParts[0].split('-'),
			date;
		if( timeString.length >= 3 ) {
			var timeParts = timeString.split(':');
		}else{
			var timeParts = ['12', '00'];
		}

		date = new Date(dateParts[2], parseInt(dateParts[1], 10) - 1, dateParts[0], timeParts[0], timeParts[1]);

		console.log(date.getTime()); //1379426880000
		console.log(date); //Tue Sep 17 2013 10:08:00 GMT-0400
		//return date.toISOString();
		return date.getTime();
}

function datetime2timestamp( dateString ) {
		// dateString = '17-09-2013 10:08'
		var date;
		var dateParts = dateString.match(/(\d+)-(\d+)-(\d+) (\d+):(\d+)/);
		date = new Date(dateParts[2], parseInt(dateParts[1], 10) - 1, dateParts[0], timeParts[0], timeParts[1]);
		return date.getTime();
}

function toggleCheck( divClassName ) {
    $('.' + divClassName + ' input[type="checkbox"]').each(function () {
        if ($(this).is(':checked'))
            $(this).prop('checked', false);
        else
            $(this).prop('checked', true);
    });
    return false;
}


function clickCheckgroup( id ) {
		
		var checklist = new Array();
		var z = 0;
		$('.chk-' + id + '').each(function ( index ) {
			if ($(this).is(':checked')) {
				checklist[z] = $(this).val();
				z = z +1;
			}
		});
		$( '#' + id ).val( checklist.join(',') );
		
}
