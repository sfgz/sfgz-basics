# customsubcategory=basis=Grundeinstellungen
 
plugin.sfgz_fetools {
	settings {
	    # cat=sfgz fe tools/basis/1; type=boolean; label=JQuery laden: Markierung aufheben wenn JQuery anderweitig geladen wird
	    loadjquery=1
	    # cat=sfgz fe tools/basis/2; type=boolean; label=Te Editor laden: Markierung aufheben wenn Rich-Text-Editor im Frontend nicht genutzt wird
	    te_editor=1
	}
}


