<?php

namespace Box\Spout\Reader\Exception;

/**
 * Class ReaderNotOpenedException
 *
 * @api
 * @package Box\Spout\Reader\Exception
 */
class ReaderNotOpenedException extends ReaderException
{
}
