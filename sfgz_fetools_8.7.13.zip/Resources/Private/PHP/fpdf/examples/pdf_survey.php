<?php
require('pdf_rotate.php');

class PDF_SURVEY extends PDF_Rotate {
      function Header() {
      }
      function Footer() {
      }
}
class PDF_MFF_SURVEY extends PDF_SURVEY {
      function Header() {
	      $L = '0.5';
	      $S = '0.15';
	      $this->SetLineWidth($S);
	      $x1=113.5;
	      $x2=$x1+41;
	      $x3=$x1+79;
	      $y=19;
	      $y2=19.175;
	      $this->Line( $x1 , $y , $x2  , $y );
	      $this->SetLineWidth($L);
	      $this->Line( $x2 , $y2 , $x3  , $y2 );
	      $this->SetY($y+0);
	      $this->SetX( 155 );
	      $this->SetFont('Helvetica','',7);
	      $this->SetTextColor(0,0,0);
	      $this->Cell(39 , 5 , $this->HeaderText ,'0',1,'R');
	      $this->SetFont('Helvetica','',8);
	      $this->SetY($this->TopMargin);
      }
      function Footer() {
	      $L = '0.5';
	      $S = '0.15';
	      $this->SetLineWidth($S);
	  $pNr = $this->GroupPageNo();
	  $aNr = $this->PageGroupAlias();
	  $pagina = trim('Seite '.$pNr.'/'.$aNr.'');
	  $printed = ' Gedruckt am '.date('d.m.y');
	  $this->SetY(-15);
	  $this->SetFont('Helvetica','',8);
	  $this->Cell(0,5, $this->FooterText ,0,0,'L');
	  $this->Cell(0,5, ''.$pNr.' | '.$this->FooterDateText ,0,1,'R');
	  $this->SetFont('Helvetica','',8);
	  $this->Cell(0,5, $this->FooterSubText .' '.$printed ,0,0,'L');
	  $this->SetX( 160 );//instead of 155
//	  $this->Cell(20,5, $pagina ,0,1,'R');
      }
}
class PDF_NOTEN extends PDF_Rotate {
      function Header() {
	  $pd = __DIR__ . '/logo.png';
	  $this->Image( $pd,10,6,150);
	  $this->SetFont('Helvetica','',12);
	  $this->Ln(10);
      }
      function Footer() {
	  $pNr = $this->GroupPageNo();
	  $aNr = $this->PageGroupAlias();
	  $pagina = trim('Seite '.$pNr.'/'.$aNr.'');
	  $printed = 'Gedruckt am '.date('d.m.y');
	  $this->SetY(-15);
	  $this->SetFont('Helvetica','I',8);
	  $this->Cell(0,5, $this->FooterText ,0,0,'L');
	  $this->Cell(0,5, $this->FooterDateText ,0,1,'R');
	  $this->SetFont('Helvetica','',8);
	  $this->Cell(0,5, $this->FooterSubText . $printed ,0,0,'L');
	  $this->SetX( 160 );//instead of 155
	  $this->Cell(20,5, $pagina ,0,1,'R');
	  
      }
}


?>