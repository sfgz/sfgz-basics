<?php
namespace Sfgz\SfgzFetools\ViewHelpers\Form;

  
class CheckgroupViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper {
    
	/**
	 * @var string
	 */
	protected $tagName = 'input';

	/**
	 * Initialize the arguments.
	 *
	 * @return void
	 * @api
	 */
	public function initializeArguments() {
		parent::initializeArguments();
		$this->registerArgument('options','array','array with all avaiable option as index, array-value used as label',FALSE);
		$this->registerArgument('split','string','a char to split choosen options',FALSE);
	}
    
	/**
	 * Renders the textfield.
	 *
	 * @return string
	 */
	public function render() {

		$name = $this->getName();
        $type = $this->arguments['type'];
		$css = $this->arguments['class'] !== NULL ? $this->arguments['class'] : '';
		$options = $this->arguments['options'];
		$split = empty( $this->arguments['split'] ) ? ',' : $this->arguments['split'];
		
		$field = $this->arguments['property'] !== NULL ? $this->arguments['property'] : $this->arguments['name'];
		$id = $this->arguments['id'] !== NULL ? $this->arguments['id'] : $field;
		
		$rawValue = $this->getValueAttribute();
		if ($rawValue == NULL) $rawValue = $this->renderChildren();

		if( $rawValue ){
				$aVal = explode( $split , $rawValue );
				foreach( $aVal  as $chknam ){ if($chknam) $aChecked[ htmlentities(  $chknam ) ] = $chknam; }
		}
		
		$renderedTag='<div class="' . trim($css . ' tx-sfgz_fetools') . '">';
		if( $options && is_array($options) ){
			foreach( $options  as $key => $chknam ) {
				
				$labelclass = '' . trim($css . ' tx-sfgz_fetools');
				$jsCmd = ' onClick="clickCheckgroup( \''.$id.'\' );" ';
				$isChecked =  isset($aChecked[htmlentities($key)]) ? ' checked="checked" ' : '';
				
				$renderedTag .= '<label class="' . $labelclass . '">';
				$renderedTag .= '<input class="chk-' . $id . '" type="checkbox"' . $jsCmd . $isChecked . 'value="' . $key . '">';
				$renderedTag .= '' . $chknam . '</label> ';
			}
		}
		$renderedTag.='</div>';
		
		$this->tag->addAttribute('value', $rawValue);
		$this->tag->addAttribute('type', 'hidden');
		$this->tag->addAttribute('name', $name);
		$this->tag->addAttribute('id', $id);

		$hiddenTag = $this->tag->render();
		
		return $renderedTag . $hiddenTag;
		
	}
}
