<?php
namespace Sfgz\SfgzFetools\ViewHelpers\Fpdf;
 
class PageViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper {
 
    public function initializeArguments() {
	$this->registerArgument('linetop','array','{firstpage:1,nextpage:0} Line starts 1...n mm from top. 0 = no line',FALSE);
	$this->registerArgument('title','string','ein Titel falls Seitenumbruch',FALSE);
    }
    
    /**
    * 
    * add new page with choosen linetop [ 1-n | none ]
    * 
    */
    public function render(){
        $pdf = $this->templateVariableContainer->get('fpdf');
	$margins = $this->templateVariableContainer->get('margins');
	$pageOptions = array( 'title'=>$this->arguments['title'] , 'linetop'=>$this->arguments['linetop'] );
	
	$headLn = 5;
	$titleHeight = 5*8;
        
	$pdf->StartPageGroup();
        $pdf->AddPage('P');
        if( $this->arguments['linetop']['firstpage'] > 0 ) {
	    $pdf->Line( 210-$margins['right'] , $margins['top']+$this->arguments['linetop']['firstpage'], 210-$margins['right'] , 297-$margins['bottom']);
        }
	$pdf->MyFooter($this->arguments['title']);
 
        $this->templateVariableContainer->add('pageOptions', $pageOptions);
        $this->renderChildren();
        $this->templateVariableContainer->remove('pageOptions');
    }
 
}
