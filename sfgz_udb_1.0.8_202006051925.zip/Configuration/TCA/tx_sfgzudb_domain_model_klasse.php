<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse',
        'label' => 'class_short',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'versioningWS' => true,
        'enablecolumns' => [
        ],
        'searchFields' => 'class_short,klassenname,klasse_kurz,klasse_zug,class_id',
        'iconfile' => 'EXT:sfgz_udb/Resources/Public/Icons/tx_sfgzudb_domain_model_klasse.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'class_short, klassenname, klasse_kurz, klasse_jahr, klasse_zug, klasse_start, klasse_ende, department_id, classteacher_id, class_id',
    ],
    'types' => [
        '1' => ['showitem' => 'class_short, klassenname, klasse_kurz, klasse_jahr, klasse_zug, klasse_start, klasse_ende, department_id, classteacher_id, class_id'],
    ],
    'columns' => [
        't3ver_label' => [
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.versionLabel',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'max' => 255,
            ],
        ],

        'class_short' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse.class_short',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'klassenname' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse.klassenname',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'klasse_kurz' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse.klasse_kurz',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'klasse_jahr' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse.klasse_jahr',
            'config' => [
                'type' => 'input',
                'size' => 4,
                'eval' => 'int'
            ]
        ],
        'klasse_zug' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse.klasse_zug',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'klasse_start' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse.klasse_start',
            'config' => [
                'dbType' => 'datetime',
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'size' => 12,
                'eval' => 'datetime',
                'default' => null,
            ],
        ],
        'klasse_ende' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse.klasse_ende',
            'config' => [
                'dbType' => 'datetime',
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'size' => 12,
                'eval' => 'datetime',
                'default' => null,
            ],
        ],
        'department_id' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse.department_id',
            'config' => [
                'type' => 'input',
                'size' => 4,
                'eval' => 'int'
            ]
        ],
        'classteacher_id' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse.classteacher_id',
            'config' => [
                'type' => 'input',
                'size' => 4,
                'eval' => 'int'
            ]
        ],
        'class_id' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_klasse.class_id',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
    
        'kurzklasse' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
        'ref_class_id' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];
