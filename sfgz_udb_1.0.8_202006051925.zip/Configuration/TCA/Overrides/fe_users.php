<?php
defined('TYPO3_MODE') || die();

if (!isset($GLOBALS['TCA']['fe_users']['ctrl']['type'])) {
    // no type field defined, so we define it here. This will only happen the first time the extension is installed!!
    $GLOBALS['TCA']['fe_users']['ctrl']['type'] = 'tx_extbase_type';
    $tempColumnstx_sfgzudb_fe_users = [];
    $tempColumnstx_sfgzudb_fe_users[$GLOBALS['TCA']['fe_users']['ctrl']['type']] = [
        'exclude' => true,
        'label'   => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb.tx_extbase_type',
        'config' => [
            'type' => 'select',
            'renderType' => 'selectSingle',
            'items' => [
                ['',''],
                ['Ecouser','Tx_SfgzUdb_Ecouser'],
            ],
            'default' => 'Tx_SfgzUdb_Ecouser',
            'size' => 1,
            'maxitems' => 1,
        ]
    ];
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns('fe_users', $tempColumnstx_sfgzudb_fe_users);
}

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'fe_users',
    $GLOBALS['TCA']['fe_users']['ctrl']['type'],
    '',
    'after:' . $GLOBALS['TCA']['fe_users']['ctrl']['label']
);

$tmp_sfgz_udb_columns = [

    'eco_acronym' => [
        'exclude' => false,
        'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_ecouser.eco_acronym',
        'config' => [
            'type' => 'input',
            'size' => 30,
            'eval' => 'trim'
        ],
    ],
    'eco_key' => [
        'exclude' => false,
        'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_ecouser.eco_key',
        'config' => [
            'type' => 'input',
            'size' => 30,
            'eval' => 'trim'
        ],
    ],
    'cloud_quota' => [
        'exclude' => false,
        'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_ecouser.cloud_quota',
        'config' => [
            'type' => 'input',
            'size' => 30,
            'eval' => 'trim'
        ],
    ],
    'eco_klasse' => [
        'exclude' => false,
        'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_ecouser.eco_klasse',
        'config' => [
            'type' => 'select',
            'renderType' => 'selectSingle',
			'items' => [ [ 'keine', 0 ] ],
            'foreign_table' => 'tx_sfgzudb_domain_model_klasse',
            'minitems' => 0,
            'maxitems' => 1,
        ],
    ],

    'abteilung' => [
        'exclude' => false,
        'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_ecouser.abteilung',
        'config' => [
            'type' => 'text',
            'cols' => 20,
            'rows' => 2,
            'eval' => 'trim',
        ],
    ],
];

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns('fe_users',$tmp_sfgz_udb_columns);

/* inherit and extend the show items from the parent class */

if (isset($GLOBALS['TCA']['fe_users']['types']['0']['showitem'])) {
    $GLOBALS['TCA']['fe_users']['types']['Tx_SfgzUdb_Ecouser']['showitem'] = $GLOBALS['TCA']['fe_users']['types']['0']['showitem'];
} elseif(is_array($GLOBALS['TCA']['fe_users']['types'])) {
    // use first entry in types array
    $fe_users_type_definition = reset($GLOBALS['TCA']['fe_users']['types']);
    $GLOBALS['TCA']['fe_users']['types']['Tx_SfgzUdb_Ecouser']['showitem'] = $fe_users_type_definition['showitem'];
} else {
    $GLOBALS['TCA']['fe_users']['types']['Tx_SfgzUdb_Ecouser']['showitem'] = '';
}
$GLOBALS['TCA']['fe_users']['types']['Tx_SfgzUdb_Ecouser']['showitem'] .= ',--div--;LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_ecouser,';
$GLOBALS['TCA']['fe_users']['types']['Tx_SfgzUdb_Ecouser']['showitem'] .= 'eco_acronym, eco_key, cloud_quota, eco_klasse, abteilung';

$GLOBALS['TCA']['fe_users']['columns'][$GLOBALS['TCA']['fe_users']['ctrl']['type']]['config']['items'][] = ['LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:fe_users.tx_extbase_type.Tx_SfgzUdb_Ecouser','Tx_SfgzUdb_Ecouser'];
