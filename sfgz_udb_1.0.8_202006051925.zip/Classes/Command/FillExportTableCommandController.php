<?php
namespace Sfgz\SfgzUdb\Command;
/**
 * Class FillExportTableCommandController
 */
class FillExportTableCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {

	/**
	 * sExportTableName
	 *
	 * @var string
	 */
	protected $sExportTableName = 'tx_sfgzudb_domain_model_exportusers';
    
    public function execute(){
		
        // get Data from table fe_users
        $intranetUsersUtility = new \Sfgz\SfgzUdb\Utility\IntranetUsersUtility();
		$fe_users =  $intranetUsersUtility->readIntranetUsersAndCloudgroups( time() );
		$aHeadrow = array_shift($fe_users);
        if( !is_array($aHeadrow) ) return 0;
		
		// Connect to DB. Ingredients to access cms-db separately since Typo3-9 no more constants TYPO3_db_host, TYPO3_db_username etc...
        $connection = $this->getDatabaseConnection();
        
        // DELETE (1/2) from export-table
        // if exists in fe_user DELETE all with plugin-storage pid from export-table
        // remove all recordset with same pid at once
        $apid = [];
        foreach( $fe_users as $username => $user ){
            // if this is the first record with this pid 
            // then delete all with this plugin-storage pid
            if( !isset($apid[$user['pid']]) ){
                $apid[$user['pid']] = $user['pid'];
                $connection->query('DELETE FROM `'.$this->sExportTableName.'` WHERE `'.$this->sExportTableName.'`.`pid` = ' . $user['pid']) ;
            }
        }
        
        // DELETE (2/2) from variable $fe_users if still exists in export-table
        // doubles managed on other Page 
        foreach( $fe_users as $username => $user ){
                $exists = 0;
                $table = $connection->query('SELECT * FROM '.$this->sExportTableName.' WHERE '.$this->sExportTableName.'.username = "' . $username . '";');
                if( $table ){
                    foreach( $table as $row ){
                        if( $row['uid'] ) unset( $fe_users[$username] );
                    }
                }
        }
        
        // INSERT VALUES in to table.
        // Collect row in a string, store as array and implode afterward
        $aValues = [];
        foreach( $fe_users as $username => $user ){
                if( empty($user['grp1']) ) continue; // prevent "nogroup" records
                $sSqlLine = ''. $user['pid'] .', ';
                $sSqlLine .= '"'. $username .'", ';
                $sSqlLine .= '"' . $user['firstname'] .'", ';
                $sSqlLine .= '"'. $user['lastname'] .'", ';
                $sSqlLine .= '"'. $user['email'] .'", ';
                $sSqlLine .= $user['quotaspace'] ? $user['quotaspace'] : 0;
                for( $gNr = 1 ; $gNr <= 5 ; ++$gNr){ $sSqlLine .= ', "' . $user['grp'.$gNr] . '"';}
                $aValues[]= '('.$sSqlLine.')';
        }

        $loops = ceil(count($aValues)/100);
        for( $index = 0 ; $index <= $loops*100 ; $index+=100 ){
            $sTabInsert = "INSERT INTO " . $this->sExportTableName . " ";
            $sTabInsert.= "(" . implode( ',' , $aHeadrow ) . ") ";
            $sTabInsert.= "VALUES ";
            $sTabInsert.= implode( "," , array_slice( $aValues , $index , 100 ) ) . ";";
            $connection->query( $sTabInsert );
        }
        
//         $result = $this->createTeacherrelationView($connection);
        
        $connection->close();
		
		return;
     }
	
	/**
	* getExportTable
	* 
	* @return array
	*/
	Public function getExportTable() {
        
        $this->execute();
        
        $connection = $this->getDatabaseConnection();
        $table = $connection->query('SELECT * FROM '.$this->sExportTableName.';');
        $connection->close();
        
        $fe_users = [];
        if( !$table ) return $fe_users;
        
        foreach( $table as $i => $row ){
            if( empty( $i ) ) $fe_users[] = array_keys( $row );
            $aUser = [];
            foreach( $row as $fldName => $value ) $aUser[$fldName] = utf8_encode( $value );
            $fe_users[] = $aUser;
        }
        return $fe_users;
    }
	
	/**
	* getDatabaseConnection
	* 
	* @return array
	*/
	Private function getDatabaseConnection() {
        $aDbIngr = $GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default'];
        $connection = new \mysqli( $aDbIngr['host'] , $aDbIngr['user'] , $aDbIngr['password'] , $aDbIngr['dbname'] );
        return $connection;
	}

//     /**
//     * createFachbereichView
//     *
//     * @param void $connection
//     * @return int
//     */
// 	Private function createTeacherrelationView($connection){
//         $select = 'SELECT fachbereichname,leiter,tea_ecouser FROM `tx_sfgzudb_domain_model_teacherrelation` join tx_sfgzudb_domain_model_fachbereich ON tx_sfgzudb_domain_model_teacherrelation.fachbereich = tx_sfgzudb_domain_model_fachbereich.uid  ORDER BY `fachbereich` ASC';
//         $view = 'CREATE VIEW teacherrelationView AS ' . $select;
//         $result = $connection->query($view) ;
//         //if( !$result ) $result = 'FillExportTableCommandController->createTeacherrelationView() on Line 84: OK.';
//         return $result;
//     }

//     /**
//     * createBenutzerView
//     *
//     * @param void $connection
//     * @return int
//     */
// 	Private function createBenutzerView($connection){
//         $select = 'SELECT uid, name, email, cloud_quota AS quota, disable AS `dis.` FROM fe_users';
//         $view = 'DROP VIEW IF EXISTS benutzerView; CREATE VIEW benutzerView AS ' . $select;
//         return $connection->query($view) ;
//     }

}
 
