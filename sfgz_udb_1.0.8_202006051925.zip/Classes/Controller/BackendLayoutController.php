<?php
namespace Sfgz\SfgzUdb\Controller;

use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2017
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * BackendLayoutController
 */
class BackendLayoutController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

	/**
	 * IntranetUsersUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $IntranetUsersUtility = NULL;

	/**
	* initiate
	*
	* @return void
	*/
	public function initializeAction( ) {
			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$flashMessageService = $this->objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
			$this->messageQueue = $flashMessageService->getMessageQueueByIdentifier();
 			$this->IntranetUsersUtility = GeneralUtility::makeInstance(\Sfgz\SfgzUdb\Utility\IntranetUsersUtility::class);
	}

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
		$ts = $this->configurationManager->getConfiguration('FullTypoScript');
		$this->view->assign('baseURL', $ts['config.']['baseURL']);
        if($this->request->hasArgument('chk')){
            $checkboxes = $this->request->getArgument('chk');
        }else{
            $checkboxes = [
                'readIntranetUsers'=> 1 , 
                'export'=> 1 , 
                'shortclass'=>1 , 
                'connectClass'=>1 , 
                'teacherGroup'=>1 , 
                'reqSurvey'=>1 , 
                'delSurvey'=>0 , 
                'mailSurvey' => 0 ,
                'timetableImport'=>1 , 
                'displayBelegImport'=>1 , 
                'displayBelegDelete'=>0 , 
                'kursBackup'=>1,
                'kursKalender'=>0 ,
            ];
        }
	    if($this->request->hasArgument('import')){
            if( $checkboxes['readIntranetUsers'] ) {
                    $readIntranetUsers = $this->IntranetUsersUtility->readIntranetUsersAndCloudgroups( time() );
                    $icon = !count($readIntranetUsers) ? \TYPO3\CMS\Core\Messaging\FlashMessage::INFO : \TYPO3\CMS\Core\Messaging\FlashMessage::OK;
                    $this->addFlashMessage( count($readIntranetUsers) . ' Benutzernamen ab Intranet Sek II eingelesen am '. date('d.m.y H:i:s'), '', $icon );
		    }
            if( $checkboxes['connectClass'] ) $udbStudFromFileOk = GeneralUtility::makeInstance(\Sfgz\SfgzUdb\Command\StudClassFromFileCommandController::class)->execute();
            if( $checkboxes['shortclass'] ) $udbKurzklasseOk = GeneralUtility::makeInstance(\Sfgz\SfgzUdb\Command\KurzklasseCommandController::class)->execute();
            if( $checkboxes['export'] ) $udbExportTableOk = GeneralUtility::makeInstance(\Sfgz\SfgzUdb\Command\FillExportTableCommandController::class)->execute();
            if( $checkboxes['teacherGroup'] ) $udbTeacherGroupOk = GeneralUtility::makeInstance(\Sfgz\SfgzUdb\Command\UsergroupsCommandController::class)->execute();
            
            if( ExtensionManagementUtility::isLoaded('mff_lsb') ){
                if( $checkboxes['reqSurvey'] ) $lsbRequestsOk = GeneralUtility::makeInstance(\Mff\MffLsb\Task\RequestTask::class)->execute();
//                 if( $checkboxes['mailSurvey'] ) $lsbRemoteMailOk = GeneralUtility::makeInstance(\Mff\MffLsb\Task\RemotemailTask::class)->execute();
//                 if( $checkboxes['delSurvey'] ) $lsbRequestsOk = GeneralUtility::makeInstance(\Mff\MffLsb\Task\DeleteTask::class)->execute();
            }
            if( $checkboxes['timetableImport'] && ExtensionManagementUtility::isLoaded('sfgz_plan') ) $planImportOk = GeneralUtility::makeInstance(\SfGZ\SfgzPlan\Task\ImportTask::class)->execute();
                
            $this->addFlashMessage('Import-Aktionen und ausgeführt und Export-Tabelle beschrieben am '.date('d.m.y H:i:s') , '', \TYPO3\CMS\Core\Messaging\FlashMessage::INFO );
        }
        $this->view->assign('chk', $checkboxes );
    }

    /**
     * action details
     *
     * @return void
     */
    public function detailsAction()
    {
		$ts = $this->configurationManager->getConfiguration('FullTypoScript');
		$this->view->assign('baseURL', $ts['config.']['baseURL']);
    }

}
