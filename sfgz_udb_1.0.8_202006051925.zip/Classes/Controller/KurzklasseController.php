<?php
namespace Sfgz\SfgzUdb\Controller;


/***
 *
 * This file is part of the "Sfgz User DB" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * KurzklasseController
 */
class KurzklasseController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * kurzklasseRepository
     * 
     * @var \Sfgz\SfgzUdb\Domain\Repository\KurzklasseRepository
     * @inject
     */
    protected $kurzklasseRepository = null;

    /**
     * cloudquotaRepository
     * 
     * @var \Sfgz\SfgzUdb\Domain\Repository\CloudquotaRepository
     * @inject
     */
    protected $cloudquotaRepository = null;

	/**
	 * ecouserRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\EcouserRepository
	 */
	protected $ecouserRepository = NULL;

    /**
     * fachbereichRepository
     * 
     * @var \Sfgz\SfgzUdb\Domain\Repository\FachbereichRepository
     * @inject
     */
    protected $fachbereichRepository = null;

	public function initializeAction() {
		
            $dQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $dQuerySettings->setRespectStoragePage(FALSE);
            $this->cloudquotaRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\CloudquotaRepository');
            $this->cloudquotaRepository->setDefaultQuerySettings($dQuerySettings);

            $userQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $userQuerySettings->setRespectStoragePage(TRUE);
            $userQuerySettings->setStoragePageIds( [ $this->settings['studentPid'] ] );
            $this->ecouserRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\EcouserRepository');
            $this->ecouserRepository->setDefaultQuerySettings($userQuerySettings);

            $FbQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $FbQuerySettings->setRespectStoragePage(FALSE);
            $FbQuerySettings->setStoragePageIds( [ $this->settings['storagePid'] ] );

            $this->fachbereichRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\FachbereichRepository');
            $this->fachbereichRepository->setDefaultQuerySettings($FbQuerySettings);
	}

    /**
     * action list
     * 
     * @return void
     */
    public function listAction()
    {
        $fachbereiches = $this->fachbereichRepository->findAll();
        $this->view->assign('fachbereiches', $fachbereiches);
        
        
        $aMsg = [ 'nicht-gespeichert'=>[] , 'gespeichert'=>[] ];
        
        if( $this->request->hasArgument('cloudquota') ){
            $oAllQuota = $this->cloudquotaRepository->findAll();
            foreach( $oAllQuota as $aFirstQuota ) break;
            
            $qutaChanges = $this->request->getArgument('cloudquota');
            foreach( $qutaChanges as $uid => $quotaUid ){
                $oKurzklasse = $this->kurzklasseRepository->findByUid( $uid );
                $quotaIst = $oKurzklasse->getKrzCloudquota( $oQuota );
                if( !$quotaIst ) $quotaIst = $aFirstQuota;
                
                if( $quotaIst->getUid() == $quotaUid ) continue;
                
                $oQuota = $this->cloudquotaRepository->findByUid( $quotaUid );
                if( $oQuota ){
                    $oKurzklasse->setKrzCloudquota( $oQuota );
                    $this->kurzklasseRepository->update($oKurzklasse);
                    $aMsg[ 'gespeichert' ][] = 'Quota gespeichert für Kurzklasse uid ' . $uid . '';
                }else{
                    $aMsg[ 'nicht-gespeichert' ][] = 'Die Quota kann nicht geleert werden';
                }
            }
        }
        
        if( $this->request->hasArgument('feedbacktyp') ){
            $feedbacktypChanges = $this->request->getArgument('feedbacktyp');
            foreach( $feedbacktypChanges as $uid => $feedbacktypUid ){
                $oKurzklasse = $this->kurzklasseRepository->findByUid( $uid );

                // dont change if already same value
                if( $oKurzklasse->getFeedbacktyp() == $feedbacktypUid ) continue;
                
                $oKurzklasse->setFeedbacktyp( $feedbacktypUid );
                $this->kurzklasseRepository->update($oKurzklasse);
                $aMsg[ 'gespeichert' ][] = 'Feedbacktyp gespeichert für Kurzklasse uid ' . $uid . '';
            }
        }
        
        if( $this->request->hasArgument('krzFachbereich') ){
            $fachbereichChanges = $this->request->getArgument('krzFachbereich');
            foreach( $fachbereichChanges as $uid => $fachbereichUid ){
                $oKurzklasse = $this->kurzklasseRepository->findByUid( $uid );
                
                $objFachbereich = $this->fachbereichRepository->findByUid( $fachbereichUid );
                if( $objFachbereich ){
                    $oKurzklasse->setKrzFachbereich( $objFachbereich );
                }else{
                    $this->addFlashMessage( 'Fachbereich nicht gespeichert' , 'nicht-gespeichert' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
//                     $oKurzklasse->setKrzFachbereich( '' );
                }
                $this->kurzklasseRepository->update($oKurzklasse);
                $aMsg[ 'gespeichert' ][] = 'Fachbereich gespeichert für Kurzklasse uid ' . $uid . '';
                
            }
        }
        if( count($aMsg[ 'nicht-gespeichert' ]) ){
            $this->addFlashMessage( implode( ', ' , $aMsg[ 'nicht-gespeichert' ] ) , 'nicht-gespeichert' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
        }
        if( count($aMsg[ 'gespeichert' ]) ){
            $this->addFlashMessage( implode( ', ' , $aMsg[ 'gespeichert' ] ) , 'gespeichert' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        }
        $cloudquotas = $this->cloudquotaRepository->findAll();
        $this->view->assign('cloudquotas', $cloudquotas);
        
        $cloudQuotaUtility = new \Sfgz\SfgzUdb\Utility\IntranetUsersUtility();
        $kurzklasseList = $cloudQuotaUtility->getKurzklasseList();
        $this->view->assign('classes', $kurzklasseList );
        
    }
}
