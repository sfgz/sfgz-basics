<?php
namespace Sfgz\SfgzUdb\Controller;


/***
 *
 * This file is part of the "SfgzUdb" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * CloudquotaController
 */
class CloudquotaController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * cloudquotaRepository
     * 
     * @var \Sfgz\SfgzUdb\Domain\Repository\CloudquotaRepository
     * @inject
     */
    protected $cloudquotaRepository = null;

    /**
     * action list
     * 
     * @param Sfgz\SfgzUdb\Domain\Model\Cloudquota
     * @return void
     */
    public function listAction()
    {
        $cloudquotas = $this->cloudquotaRepository->findAll();
        $this->view->assign('cloudquotas', $cloudquotas);
        $this->view->assign('settings', $this->settings);
    }

    /**
     * action new
     * 
     * @param Sfgz\SfgzUdb\Domain\Model\Cloudquota
     * @return void
     */
    public function newAction()
    {
    }

    /**
     * action create
     * 
     * @param Sfgz\SfgzUdb\Domain\Model\Cloudquota
     * @return void
     */
    public function createAction(\Sfgz\SfgzUdb\Domain\Model\Cloudquota $newCloudquota)
    {
        $this->addFlashMessage('The object was created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->cloudquotaRepository->add($newCloudquota);
        $this->redirect('list');
    }

    /**
     * action edit
     * 
     * @param Sfgz\SfgzUdb\Domain\Model\Cloudquota
     * @ignorevalidation $cloudquota
     * @return void
     */
    public function editAction(\Sfgz\SfgzUdb\Domain\Model\Cloudquota $cloudquota)
    {
        $this->view->assign('cloudquota', $cloudquota);
        $this->view->assign('settings', $this->settings);
    }

    /**
     * action update
     * 
     * @param Sfgz\SfgzUdb\Domain\Model\Cloudquota
     * @return void
     */
    public function updateAction(\Sfgz\SfgzUdb\Domain\Model\Cloudquota $cloudquota)
    {
        $this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->cloudquotaRepository->update($cloudquota);
        $this->redirect('list');
    }

    /**
     * action delete
     * 
     * @param Sfgz\SfgzUdb\Domain\Model\Cloudquota
     * @return void
     */
    public function deleteAction(\Sfgz\SfgzUdb\Domain\Model\Cloudquota $cloudquota)
    {
        $this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->cloudquotaRepository->remove($cloudquota);
        $this->redirect('list');
    }
}
