<?php
namespace Sfgz\SfgzUdb\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "SfgzUdb" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * FachbereichController
 */
class FachbereichController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * fachbereichRepository
     * 
     * @var \Sfgz\SfgzUdb\Domain\Repository\FachbereichRepository
     * @inject
     */
    protected $fachbereichRepository = null;

	/**
	 * ecouserRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\EcouserRepository
	 */
	protected $ecouserRepository = NULL;

	/**
	 * teacherRelationRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\TeacherRelationRepository
     * @inject
	 */
	protected $teacherRelationRepository = NULL;

	/**
	 * cloudquotaRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\CloudquotaRepository
	 */
	protected $cloudquotaRepository = NULL;
	
	public function initializeAction() {
		/** get PIDs where users are stored from plugin tx_sfgzudb_edit **/
		/** set PIDs for ecouserRepository **/
		
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		$querySettings->setStoragePageIds( [ $this->settings['teacherPid'] , $this->settings['studentPid'] ] );
		
        $this->ecouserRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\EcouserRepository');
		$this->ecouserRepository->setDefaultQuerySettings($querySettings);
		
		$dQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$dQuerySettings->setRespectStoragePage(FALSE);
        $this->teacherRelationRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\TeacherRelationRepository');
		$this->teacherRelationRepository->setDefaultQuerySettings($dQuerySettings);
		
        $this->cloudquotaRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\CloudquotaRepository');
        $this->cloudquotaRepository->setDefaultQuerySettings($dQuerySettings);

        $this->feUserRepository = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Domain\\Repository\\FrontendUserRepository');
		$this->feUserRepository->setDefaultQuerySettings($dQuerySettings);

		$this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
	}

    /**
     * getUsedSpace
     * 
     * @return array
     */
    public function getUsedSpaceTeacher()
    {
        $aTea = [];
            $teacherUtility = new \Sfgz\SfgzUdb\Utility\IntranetUsersUtility();
            $teaEcouserGroups = $teacherUtility->getTeacherFachbereich();

        $defaultTeacherQuota = $this->cloudquotaRepository->findByUid( $this->settings['quotaUidTeacher'] );
        $strSpeicherplatz = trim(str_replace( 'GB' , '' , $defaultTeacherQuota->getSpeicherplatz() ));
        $speicherplatz = $strSpeicherplatz ? 0+$strSpeicherplatz : 0;
    
        $fachbereiches = $this->fachbereichRepository->findAll();
        foreach( $fachbereiches as $objFachbereich ){
            $objTeachers = $objFachbereich->getFbTeacher();
            foreach( $objTeachers as $objTeacher){
                $userObj = $objTeacher->getTeaEcouser();
                if($userObj){
                    $userUid = $userObj->getUid();
                    $persQuota = $teaEcouserGroups[$userUid]['quotaspace'];
                    if( $speicherplatz > $persQuota ) $persQuota = $speicherplatz;
                    $aTea[$userObj->getUsername()] = $persQuota;
                }
            }
        }
        $iTeacherAmount = count($aTea);
        $iTeacherQuotas = array_sum($aTea);
        ksort($aTea);
        $aQuota = [ 'einzeln'=>$aTea ,'speicherplatz' => $speicherplatz , 'users'=> $iTeacherAmount , 'standard'=> ( $speicherplatz * $iTeacherAmount ) , 'summe'=> $iTeacherQuotas ];
        return $aQuota;
	}

    /**
     * action list
     * 
     * @return void
     */
    public function listAction()
    {
        $fachbereiches = $this->fachbereichRepository->findAll();
        $this->view->assign('fachbereiches', $fachbereiches);
        
        $aQuota = $this->getUsedSpaceTeacher();
        $this->view->assign('quota', $aQuota );
    }

    /**
     * action new
     * 
     * @return void
     */
    public function newAction()
    {
    }

    /**
     * action create
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $newFachbereich
     * @return void
     */
    public function createAction(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $newFachbereich)
    {
        $this->addFlashMessage('Der Fachbereich wurde erfasst.', 'Erfassen', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->fachbereichRepository->add($newFachbereich);
        $this->redirect('list');
    }

    /**
     * action edit
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return void
     */
    public function editAction(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
        $this->editTeacherInFachbereich($fachbereich);

        $aFbTea = $this->getMemberObjects($fachbereich);
        $aSelectorList = $this->getTeacherSelector($fachbereich);
        
        $this->view->assign('fachbereich', $fachbereich);
        $this->view->assign('fbTeacher', $aFbTea );
        $this->view->assign('users', $aSelectorList );
        
        $fachbereiches = $this->fachbereichRepository->findAll();
        $this->view->assign('fachbereiches', $fachbereiches);
    }

    /**
     * editTeacherInFachbereich
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return array
     */
    public function editTeacherInFachbereich(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
        $tc = [];
        if( $this->request->hasArgument('submit') && $this->request->getArgument('submit')){
            $tc = $this->request->getArgument('submit');
            if( isset($tc['add_member']) ) {
                $ecouser = $this->feUserRepository->findByUid( $tc['add_member'] );
                $oRelation = GeneralUtility::makeInstance('Sfgz\SfgzUdb\Domain\Model\TeacherRelation');
                $oRelation->setFachbereich( $fachbereich->getUid() );
                $oRelation->setTeaEcouser( $ecouser );
                $fachbereich->addFbTeacher($oRelation);
                $this->fachbereichRepository->update($fachbereich);
                $this->addFlashMessage('Person angefuegt.', 'Anfuegen ', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
            
            }elseif( isset($tc['rem_member']) ) {
                $oRelation = $this->teacherRelationRepository->findByUid( $tc['rem_member'] );
                $fachbereich->removeFbTeacher($oRelation);
                $this->fachbereichRepository->update($fachbereich);
//                 $this->teacherRelationRepository->remove($oRelation);
                $this->addFlashMessage('Person entfernt.', 'Entfernen ', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
            
            }elseif( isset($tc['change_member']) ) {
                $oRelation = $this->teacherRelationRepository->findByUid( $tc['change_member'] );
                $isLeiter = $oRelation->getLeiter();
                $oRelation->setLeiter( $isLeiter ? 0 : 1 );
                $this->teacherRelationRepository->update($oRelation);
                $this->addFlashMessage('Leiter ' . ($isLeiter?'entfernt':'angefuegt') . '.', 'Aenderung Leiter', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
            
            }
 			$this->persistenceManager->persistAll();
        }
        return $fachbereich;
    }

    /**
     * getMemberObjects
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return array
     */
    public function getMemberObjects(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
        $fbTeacher = $fachbereich->getFbTeacher();
        $aFbTea=['Leiter'=>[],'Member'=>[]];
        foreach( $fbTeacher as $member ){
            $oUSer = $member->getTeaEcouser();
            if( !$oUSer ) continue;
            $leiter = $member->getLeiter();
            $username = $oUSer->getUsername();
            if( $leiter ){
                $aFbTea['Leiter'][$username] = $member;
            }else{
                $aFbTea['Member'][$username] = $member;
            }
        }
        ksort($aFbTea['Leiter']);
        ksort($aFbTea['Member']);
        $aFbAll = [];
        foreach($aFbTea as $typ => $row ) {
            foreach( $row as $nam => $memb ){
                $aFbAll[$nam] = $memb;
            }
        }
        return $aFbAll;
    }

    /**
     * getTeacherSelector
     * return teachers that not are members
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return array
     */
    public function getTeacherSelector(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
            // collect members to exclude them
            $aFbUsers = [];
            $objFbusers = $fachbereich->getFbTeacher();
            foreach($objFbusers as $fblink ){
                $oUSer = $fblink->getTeaEcouser();
                if( !$oUSer ) continue;
                $aFbUsers[ $oUSer->getUid() ] = 1;
            }
            // collect teacher except members
            $aSort = [];
            $ecousers = $this->feUserRepository->findByPid($this->settings['teacherPid']);
            foreach( $ecousers as $user ){
                $uid = $user->getUid();
                $username = $user->getUsername();
                $aNameTest = explode( '.' , $username );
                if( empty($aNameTest[0]) || empty($aNameTest[1]) ) continue;
                if( empty($user->getEmail()) ) continue;
                if( isset($aFbUsers[$uid]) ) continue;
                $aSort[$username]=$user;
            }
            ksort($aSort);
            $aFbUserlist = [];
            foreach($aSort as $user) $aFbUserlist[$user->getUid()] = [ 'value'=>$user->getUid() , 'label'=>$user->getName() ];
            // return teachers that not are members
            return $aFbUserlist;
    }

    /**
     * action update
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return void
     */
    public function updateAction(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
		if( $this->request->hasArgument('abort') ){
            $this->redirect('list');
        }
        $this->addFlashMessage('Der Fachbereich wurde gespeichert.', 'Speichern', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        $this->fachbereichRepository->update($fachbereich);
		if( $this->request->hasArgument('ok') ){
		    $this->forward('edit', NULL, NULL, array('fachbereich' => $fachbereich));
        }
        $this->redirect('list');
    }

    /**
     * action delete
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return void
     */
    public function deleteAction(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
        $this->addFlashMessage('Der Fachbereich wurde geloescht.', 'Loeschen', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->fachbereichRepository->remove($fachbereich);
        $this->redirect('list');
    }
}
