<?php
namespace Sfgz\SfgzUdb\Domain\Model;


/***
 *
 * This file is part of the "Sfgz User DB" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * Kurzklasse
 */
class Kurzklasse extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * kurzbezeichnung
     * 
     * @var string
     */
    protected $kurzbezeichnung = '';

    /**
     * feedbacktyp
     * 
     * @var int
     */
    protected $feedbacktyp = '';

    /**
     * krzCloudquota
     * 
     * @var \Sfgz\SfgzUdb\Domain\Model\Cloudquota
     */
    protected $krzCloudquota = null;

    /**
     * krzFachbereich
     * 
     * @var \Sfgz\SfgzUdb\Domain\Model\Fachbereich
     */
    protected $krzFachbereich = null;

    /**
     * krzKlasse
     * 
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzUdb\Domain\Model\Klasse>
     * @TYPO3\CMS\Extbase\Annotation\ORM\Cascade("remove")
     */
    protected $krzKlasse = null;

    /**
     * Returns the kurzbezeichnung
     * 
     * @return string $kurzbezeichnung
     */
    public function getKurzbezeichnung()
    {
        return $this->kurzbezeichnung;
    }

    /**
     * Sets the kurzbezeichnung
     * 
     * @param string $kurzbezeichnung
     * @return void
     */
    public function setKurzbezeichnung($kurzbezeichnung)
    {
        $this->kurzbezeichnung = $kurzbezeichnung;
    }

    /**
     * Returns the feedbacktyp
     * 
     * @return string $feedbacktyp
     */
    public function getFeedbacktyp()
    {
        return $this->feedbacktyp;
    }

    /**
     * Sets the feedbacktyp
     * 
     * @param string $feedbacktyp
     * @return void
     */
    public function setFeedbacktyp($feedbacktyp)
    {
        $this->feedbacktyp = $feedbacktyp;
    }

    /**
     * Returns the krzCloudquota
     * 
     * @return \Sfgz\SfgzUdb\Domain\Model\Cloudquota $krzCloudquota
     */
    public function getKrzCloudquota()
    {
        return $this->krzCloudquota;
    }

    /**
     * Sets the krzCloudquota
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Cloudquota $krzCloudquota
     * @return void
     */
    public function setKrzCloudquota(\Sfgz\SfgzUdb\Domain\Model\Cloudquota $krzCloudquota)
    {
        $this->krzCloudquota = $krzCloudquota;
    }

    /**
     * Returns the krz
     * 
     * @return \Sfgz\SfgzUdb\Domain\Model\Fachbereich $krzFachbereich
     */
    public function getKrzFachbereich()
    {
        return $this->krzFachbereich;
    }

    /**
     * Sets the krzFachbereich
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $krzFachbereich
     * @return void
     */
    public function setKrzFachbereich(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $krzFachbereich)
    {
        $this->krzFachbereich = $krzFachbereich;
    }

    /**
     * __construct
     */
    public function __construct()
    {

        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     * 
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->krzKlasse = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Adds a Klasse
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Klasse $krzKlasse
     * @return void
     */
    public function addKrzKlasse(\Sfgz\SfgzUdb\Domain\Model\Klasse $krzKlasse)
    {
        $this->krzKlasse->attach($krzKlasse);
    }

    /**
     * Removes a Klasse
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Klasse $krzKlasseToRemove The Klasse to be removed
     * @return void
     */
    public function removeKrzKlasse(\Sfgz\SfgzUdb\Domain\Model\Klasse $krzKlasseToRemove)
    {
        $this->krzKlasse->detach($krzKlasseToRemove);
    }

    /**
     * Returns the krzKlasse
     * 
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzUdb\Domain\Model\Klasse> $krzKlasse
     */
    public function getKrzKlasse()
    {
        return $this->krzKlasse;
    }

    /**
     * Sets the krzKlasse
     * 
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzUdb\Domain\Model\Klasse> $krzKlasse
     * @return void
     */
    public function setKrzKlasse(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $krzKlasse)
    {
        $this->krzKlasse = $krzKlasse;
    }
}
