<?php
namespace Sfgz\SfgzUdb\Domain\Model;


/***
 *
 * This file is part of the "Sfgz User DB" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * ExportUsers
 */
class ExportUsers extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * username
     * 
     * @var string
     */
    protected $username = '';

    /**
     * firstname
     * 
     * @var string
     */
    protected $firstname = '';

    /**
     * lastname
     * 
     * @var string
     */
    protected $lastname = '';

    /**
     * email
     * 
     * @var string
     */
    protected $email = '';

    /**
     * quotaspace
     * 
     * @var string
     */
    protected $quotaspace = '';

    /**
     * grp1
     * 
     * @var string
     */
    protected $grp1 = '';

    /**
     * grp2
     * 
     * @var string
     */
    protected $grp2 = '';

    /**
     * grp3
     * 
     * @var string
     */
    protected $grp3 = '';

    /**
     * grp4
     * 
     * @var string
     */
    protected $grp4 = '';

    /**
     * grp5
     * 
     * @var string
     */
    protected $grp5 = '';

    /**
     * Returns the username
     * 
     * @return string $username
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Sets the username
     * 
     * @param string $username
     * @return void
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * Returns the firstname
     * 
     * @return string $firstname
     */
    public function getFirstname()
    {
        return $this->firstname;
    }

    /**
     * Sets the firstname
     * 
     * @param string $firstname
     * @return void
     */
    public function setFirstname($firstname)
    {
        $this->firstname = $firstname;
    }

    /**
     * Returns the lastname
     * 
     * @return string $lastname
     */
    public function getLastname()
    {
        return $this->lastname;
    }

    /**
     * Sets the lastname
     * 
     * @param string $lastname
     * @return void
     */
    public function setLastname($lastname)
    {
        $this->lastname = $lastname;
    }

    /**
     * Returns the email
     * 
     * @return string $email
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Sets the email
     * 
     * @param string $email
     * @return void
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * Returns the grp1
     * 
     * @return string $grp1
     */
    public function getGrp1()
    {
        return $this->grp1;
    }

    /**
     * Sets the grp1
     * 
     * @param string $grp1
     * @return void
     */
    public function setGrp1($grp1)
    {
        $this->grp1 = $grp1;
    }

    /**
     * Returns the grp2
     * 
     * @return string $grp2
     */
    public function getGrp2()
    {
        return $this->grp2;
    }

    /**
     * Sets the grp2
     * 
     * @param string $grp2
     * @return void
     */
    public function setGrp2($grp2)
    {
        $this->grp2 = $grp2;
    }

    /**
     * Returns the grp3
     * 
     * @return string $grp3
     */
    public function getGrp3()
    {
        return $this->grp3;
    }

    /**
     * Sets the grp3
     * 
     * @param string $grp3
     * @return void
     */
    public function setGrp3($grp3)
    {
        $this->grp3 = $grp3;
    }

    /**
     * Returns the grp4
     * 
     * @return string $grp4
     */
    public function getGrp4()
    {
        return $this->grp4;
    }

    /**
     * Sets the grp4
     * 
     * @param string $grp4
     * @return void
     */
    public function setGrp4($grp4)
    {
        $this->grp4 = $grp4;
    }

    /**
     * Returns the grp5
     * 
     * @return string $grp5
     */
    public function getGrp5()
    {
        return $this->grp5;
    }

    /**
     * Sets the grp5
     * 
     * @param string $grp5
     * @return void
     */
    public function setGrp5($grp5)
    {
        $this->grp5 = $grp5;
    }

    /**
     * Returns the quotaspace
     * 
     * @return string quotaspace
     */
    public function getQuotaspace()
    {
        return $this->quotaspace;
    }

    /**
     * Sets the quotaspace
     * 
     * @param string $quotaspace
     * @return void
     */
    public function setQuotaspace($quotaspace)
    {
        $this->quotaspace = $quotaspace;
    }
}
