<?php
namespace Sfgz\SfgzUdb\Task;

 /** 
 * Class GeneralTask
 *  runs all possible tasks
 * 
 * 
 */
 
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Scheduler\Task\AbstractTask;
 
class GeneralTask extends AbstractTask {
	
	/**
	* userSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\UserSurveyRepository
	*/
	protected $userSurveyRepository = null;

	/**
	 * IntranetUsersUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $IntranetUsersUtility = NULL;

	/**
	* initiate
	*
	* @return void
	*/
	public function initiate( ) {
			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$flashMessageService = $this->objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
			$this->messageQueue = $flashMessageService->getMessageQueueByIdentifier();
			$this->IntranetUsersUtility = GeneralUtility::makeInstance(\Sfgz\SfgzUdb\Utility\IntranetUsersUtility::class);
	}

	public function execute(){
	    $this->initiate();
	    $success = FALSE;
	    
	    $objListDelete = $this->IntranetUsersUtility->readIntranetUsersAndCloudgroups( time() );

	    GeneralUtility::makeInstance(\Sfgz\SfgzUdb\Command\StudClassFromFileCommandController::class)->execute();
	    GeneralUtility::makeInstance(\Sfgz\SfgzUdb\Command\KurzklasseCommandController::class)->execute();
	    GeneralUtility::makeInstance(\Sfgz\SfgzUdb\Command\FillExportTableCommandController::class)->execute();
	    
	    // create flashMessage
	    $plur = $objListDelete == 1 ? 'Umfrage wurde' : 'Umfragen wurden';
	    $message = GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
		    'Befehl ausgeführt: readIntranetUsersAndCloudgroups() ...' . $updateMsg ,
		    'Ausgeführt', 
		    empty($objListDelete) ? \TYPO3\CMS\Core\Messaging\FlashMessage::INFO : \TYPO3\CMS\Core\Messaging\FlashMessage::OK
	    );
	    $this->messageQueue->addMessage($message);
	    
	    $success = TRUE;
	    return $success;
	}

}
