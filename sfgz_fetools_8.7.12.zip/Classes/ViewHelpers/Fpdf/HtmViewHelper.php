<?php
namespace Sfgz\SfgzFetools\ViewHelpers\Fpdf;
 
class HtmViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper {
 
    public function initializeArguments() {
	$this->registerArgument('x','int','0,n',FALSE);
	$this->registerArgument('size','int',11,FALSE);
    }
    
    /**
     * 
     * @param string $text
     * @param int $additionallines
     */
    public function render($text='',$additionallines=0){

	$pageOptions = $this->templateVariableContainer->get('pageOptions');
	$title = $pageOptions['title'];
	$pdf = $this->templateVariableContainer->get('fpdf');
	$tpdf = $this->templateVariableContainer->get('tpdf');
	$margins = $this->templateVariableContainer->get('margins');
	$pageBreakAt = 297 - $margins['bottom'];

	if(empty($text)) $text = $this->renderChildren();
	// remove p-tags
	$text = str_replace( array( '<p>' , '</p>' ) , array( '' , '<br>' ) , $text );
	$decodedText = utf8_decode($text);
	$decodedText.=  str_repeat( '<br>' , $additionallines );
	
	
	$tpdf->AddPage('P');
 	$ty1 = $tpdf->getY();
	if($this->arguments['size']) $tpdf->SetFont('','', $this->arguments['size']);
	if( $this->arguments['x'] >= 1 ){
	      $tpdf->SetLeftMargin( $this->arguments['x'] );
	      $tpdf->SetX($this->arguments['x']);
	}
	$tpdf->WriteHTML($decodedText);
	$textHeight =$tpdf->GetY() - $ty1 ;
	
 	if( $pdf->getY() + $textHeight >= $pageBreakAt ){
	    $pdf->AddPage('P');
	    $pdf->AddPageGroup();
	    $pdf->SetFont($margins['fontFamily'],'I','8');
	    $pdf->MyFooter($title);
	    if($pageOptions['linetop']['nextpage']) $pdf->Line( 210-$margins['right'] , $margins['top']+$pageOptions['linetop']['nextpage'] , 210-$margins['right'] , 297-$margins['bottom']);
 	}
	
	if($this->arguments['size']) {
	    $pdf->SetFont('','', $this->arguments['size']);
	}
	if( $this->arguments['x'] >= 1 ){
	      $pdf->SetLeftMargin( $this->arguments['x'] );
	      $pdf->SetX($this->arguments['x']);
	}
	$pdf->WriteHTML($decodedText);
	$pdf->SetX( $margins['left'] );
	$pdf->SetLeftMargin( $margins['left'] );
 
    }
 
}
