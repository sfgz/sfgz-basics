<?php
namespace Sfgz\SfgzFetools\ViewHelpers\Fpdf;
 
class TextViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper {
 
    public function initializeArguments() {
	$this->registerArgument('font','string','Helvetica',FALSE);
	$this->registerArgument('size','int',11,FALSE);
	$this->registerArgument('markup','string','B|I|',FALSE);
	$this->registerArgument('x','int','0,n',FALSE);
    }
    
    /**
     * 
     * @param string $width 
     * @param int $height
     * @param string $text
     * @param string $border
     * @param int $ln
     * @param string $align
     * @param int $fill
     * @param string $link
     */
    public function render($width='0', $height=0, $text='', $border='0', $ln=1, $align='L', $fill=0, $link=''){

	$pdf = $this->templateVariableContainer->get('fpdf');
	$margins = $this->templateVariableContainer->get('margins');

	if(empty($text)) $text = $this->renderChildren();
	$decodedText = utf8_decode($text);
	
	//if( 'auto'==$width || ($this->arguments['font']) || ($this->arguments['size']) || ($this->arguments['markup']) ){
	      $fontFamily = ($this->arguments['font']) ? $this->arguments['font'] : 'Helvetica';
	      $fontSize = ($this->arguments['size']) ? $this->arguments['size'] : 11;
	      $markup = ($this->arguments['markup']) ? $this->arguments['markup'] : '';
	      $pdf->SetFont($fontFamily,$markup,$fontSize);
        //}
	$newWith = ('auto'==$width) ? $pdf->GetStringWidth($decodedText) : ($width + 0);
        
	if( $this->arguments['x'] >= 1 ){
	      $pdf->SetX($this->arguments['x']);
	}
	
	$pdf->Cell($newWith, $height, $decodedText , $border , $ln , $align , $fill , $link);
	
	if($ln) {
	    $pdf->SetX( $margins['left'] );
	}
 
    }
 
}
