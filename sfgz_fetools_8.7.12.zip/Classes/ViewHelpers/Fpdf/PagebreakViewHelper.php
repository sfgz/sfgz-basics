<?php
namespace Sfgz\SfgzFetools\ViewHelpers\Fpdf;
 
class PagebreakViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper {
 
    /**
     * 
     * @param int $ifnospacefor
     * @param int $height
     * @param int $addingheight
     */
    public function render($ifnospacefor=0,$height=5,$addingheight=0){

	$pageOptions = $this->templateVariableContainer->get('pageOptions');
	$pdf = $this->templateVariableContainer->get('fpdf');
	$margins = $this->templateVariableContainer->get('margins');
	$pageBreakAt = 297 - $margins['bottom'];
	
	$textHeight = 0;
	$textHeight += ($ifnospacefor * $height);
	$textHeight += $addingheight;
	
	$isY = $pdf->getY();
 	if( empty($textHeight) || ($isY + $textHeight >= $pageBreakAt) ){
	    $pdf->AddPage('P');
	    $pdf->AddPageGroup();
	    $pdf->SetFont($margins['fontFamily'],'I','8');
	    $pdf->MyFooter($pageOptions['title']);
	    if($pageOptions['linetop']['nextpage']) $pdf->Line( 210-$margins['right'] , $margins['top']+$pageOptions['linetop']['nextpage'] , 210-$margins['right'] , 297-$margins['bottom']);
 	}

    }
 
}
