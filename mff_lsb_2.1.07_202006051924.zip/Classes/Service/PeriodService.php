<?php
namespace Mff\MffLsb\Service;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <daten@verarbeitung.ch>, sfgz
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class PeriodService
 */

class PeriodService implements \TYPO3\CMS\Core\SingletonInterface {
	
	/**
	 * log
	 *
	 * @var array
	 */
	Public $log = null;
	
	/**
	 * settings
	 *  HACK get overriden by plugin ts-settings !
	 *  
	 * @var array
	 */
	Protected $settings = [
        'url' => 'https://tcs.tam.ch/home/termine@sfgz.ch/calendar?fmt=json&query=tag:urlaub' ,
        'period_keywords' => [
            'Sportferien' => 'FS' ,
            'Sommerferien' => 'HS' ,
        ] ,
        'exclude' => [
            'schulTerminMorgen' => 'stunde_ab >= 8 UND stunde_bis <= 12' ,
            'schulTerminAbMorgen' => 'stunde_ab >= 8 UND stunde_ab <= 12' ,
            'Sportwoche' => 'strpos( anlass , "portwoche" ) > 0' ,
            'Weiterbildung' => 'strpos( anlass , "eiterbildung" ) > 0' ,
        ] ,
	];
	
	/**
	* periodsRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\PeriodsRepository
	*/
	protected $periodsRepository = null;
	
	/**
	* __construct
	*
	* @return void
	*/
	Public function __construct() {
          
        $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
        $this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');

            $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
            $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
            
            $tmpSettings = $fullsettings['plugin.'][ 'tx_mfflsb_survey.' ]['settings.'];
            if( $$tmpSettings ) $this->settings = $tmpSettings; // fallback is own variable settings in header of this script.
            
            $this->settings['periodsStoragePid'] = $fullsettings['plugin.'][ 'tx_mfflsb_survey.' ]['persistence.']['periodsStoragePid'];
            // the periodsStoragePid we use in createObjectPeriod() about line 142

        $this->periodsRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\PeriodsRepository');
        $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
        // HACK new code to add period. See  in createObjectPeriod() about line 161
        $querySettings->setRespectStoragePage(FALSE);
        $querySettings->setStoragePageIds( [ $this->settings['periodsStoragePid'] ] );
        $this->periodsRepository->setDefaultQuerySettings( $querySettings );
        
/*         should be by typo3 standard code but this DONT WORKs */
//         $querySettings->setRespectStoragePage(TRUE);
//         $querySettings->setStoragePageIds( [ $this->settings['periodsStoragePid'] ] );
//         $this->periodsRepository->setDefaultQuerySettings( $querySettings );
	}

	/**
	* addPeriodToRepository
	*  needs public calendar termine@sfgz.ch/calendar
	*
	* @param string $strEngDateFrom format Y-m-d or d.m.Y Optional, default is 10 years ago
	* @param int $futureMonths Optional, default is 84 (7 Years)
	* @return array
	*/
	Public function addPeriodToRepository( $strEngDateFrom = '' , $futureMonths = 120 ) {
            if( $strEngDateFrom == '' ){
                $datBeginn = new \DateTime( date('Y-m-d') . "-10 year" );
                $strEngDateFrom = $datBeginn->format('Y-m-d');
            }
            
            $arrPeriodsFromCalendar = $this->calendarGetPeriods( $strEngDateFrom , $futureMonths );
            
            $created = 0;
            foreach( $arrPeriodsFromCalendar as $aPeriod ){
                $objPeriods = $this->periodsRepository->findBySemester( $aPeriod['semester'] );
                if( !$objPeriods || !count($objPeriods) ) {
                    if( $this->createObjectPeriod( $aPeriod ) ) $created += 1;
                }else{
                    foreach( $objPeriods as $objPeriode ){
                        $this->log[] = 'Period sem(' . $aPeriod['semester'] . ') already exist on pid=' . $objPeriode->getPid() . ' with uid=' . $objPeriode->getUid() . '';
                        break;
                    }
                }
            }
            if( $created ) $this->persistenceManager->persistAll();

            $logMsgOk = 'Total Perioden ab Kalender gelesen: ' . count($arrPeriodsFromCalendar) . '. Total neue erstellt: ' . $created . '.';
            $this->log[] = $logMsgOk;
            
            $objAllPeriods = $this->periodsRepository->findAll();
            
            if( !$objAllPeriods || !count($objAllPeriods) ) {
                $message = 'Keine Perioden vorhanden. Unbekannter Fehler.';
            }else{            
                $message = $logMsgOk;
            }
            
            return $message;
	}

	/**
	* createObjectPeriod
	*
	* @param array $aPeriod 
	* @return boolean
	*/
	Private function createObjectPeriod( $aPeriod ) {
        // verify contents
        foreach ($aPeriod as $fieldName => $strField ) {
            if( empty($strField) ){
                $this->log[] = 'Dont created semester ' . $aPeriod['semester'] . ': Feld ' . $fieldName . ' is empty.';
                return false;
            }
        }
        // HACK 
        $aPeriod['pid'] = $this->settings['periodsStoragePid'];
        
        $newObject = GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\Periods');
        foreach ($aPeriod as $fieldName => $strField ) {
			$domFormattedKey = GeneralUtility::underscoredToLowerCamelCase( trim( $fieldName ) ) ;
            $newObject->_setProperty( $domFormattedKey ,  $strField );
        }
        
        $this->periodsRepository->add( $newObject );
		
        $this->log[] = 'Semester ' . $aPeriod['semester'] . ' created.';
        return true;
	}

	/**
	* calendarGetPeriod
	*  needs public calendar termine@sfgz.ch/calendar
	* 
	* @param string $strEngDateFrom format Y-m-d or d.m.Y
	* @param int $futureMonths
	* @return array
	*/
	Public function calendarGetPeriods( $strEngDateFrom , $futureMonths ) {
            $aCalendarDB = $this->calendarReadData( $strEngDateFrom , $futureMonths );
            $aPeriods = [];
            $aSort = [];
            foreach( $aCalendarDB as $event ){
                if( !$event['semestergrenze'] ) continue;
                $aSort[ $event['beginn'] . '.' . $event['uid'] ] = $event;
            }
            ksort($aSort);
            
            $z = 0;
            foreach( $aSort as $event ){
                $datBeginn = new \DateTime( $event['beginn'] . "-2 day" );
                $datEnde = new \DateTime( $event['ende'] . "+2 day" );
                $aPeriods[$z] = [
                    'semester' => $this->settings['period_keywords'][$event['anlass']] . $datBeginn->format('y'),
                    'davor_bis' => $datBeginn,
                    'datum_ab' => $datEnde,
                    'datum_bis' => '',
                    'danach_ab' => '',
                ];
                if( $z ){
                        $aPeriods[$z-1]['datum_bis'] = $datBeginn;
                        $aPeriods[$z-1]['danach_ab'] = $datEnde;
                }
                ++$z;
            }
            
            return $aPeriods;
	}

	/**
	* calendarReadData
	*  reads from public calendar termine@sfgz.ch/calendar with params ?fmt=json&query=tag:urlaub
	*
	* @param string $strEngDateFrom format Y-m-d or d.m.Y
	* @param int $futureMonths
	* @return array or false
	*/
	Private function calendarReadData( $strEngDateFrom , $futureMonths ) {
            // default time now
            if( empty($strEngDateFrom) ) $strEngDateFrom = date( 'Y-m-d' );
	      
            $calendarArray = $this->readFromUri( $strEngDateFrom , $futureMonths );
            if( count($calendarArray) ){
                $aCalendarDbUnfiltered =  $this->sanitizeDataFromUri( $calendarArray );
                if( count($aCalendarDbUnfiltered) ){
                    $aCalendarDB = $this->filterSanitizedData( $strEngDateFrom , $aCalendarDbUnfiltered );
                    return $aCalendarDB;
                }
            }
            // emergency exit
            return [];
	}

	/**
	* readFromUri
	* reads calendar from url
	* returns json-data as array
	*
	* @param str $strEngDateFrom
	* @param int $futureMonths
	* @return array
	*/
	Private function readFromUri( $strEngDateFrom , $futureMonths ) {
            
            $strEngDateTo = $this->addMonthsToEnglishDate( $strEngDateFrom , $futureMonths );
            $startOption = '&start=' . str_replace( '-' , '/' , $strEngDateFrom );
            $endOption = '&end=' . str_replace( '-' , '/' , $strEngDateTo );
        
            $URL = $this->settings['url'].$startOption.$endOption;
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $URL);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $content_utf8 = curl_exec($ch);
            curl_close($ch);
            $raw = json_decode( $content_utf8 , true );
            
            if( !$raw ){
                die( 'Fehler: ' .  $URL);
            }
            
            return $raw ? $raw: [];
	}
	
	/**
	* addMonthsToEnglishDate
	* adds or substracts a given amount of months to a given EnglishDate and returns in EnglishDate
	*
	* @param str $strEngDateFrom
	* @param int $iAddMonths signed, negative values possible
	* @return str
	*/
    Private function addMonthsToEnglishDate( $strEngDateFrom , $iAddMonths )
    {
        $datetimeFrom = new \DateTime( $strEngDateFrom );
        
        if( $iAddMonths < 0 ){
            $interval = new \DateInterval('P' . ( (-1) * $iAddMonths ) . 'M');
            $datetimeFrom->sub($interval);
        }else{
            $interval = new \DateInterval('P' . $iAddMonths . 'M');
            $datetimeFrom->add($interval);
        }
        return $datetimeFrom->format( 'Y-m-d' );
            
	}

    /**
    * sanitizeDataFromUri
    * translates multi-dimensional clendar-array
    * returns 2-dimensional array with index and Fieldnames as array-keys
    *
    * @param array $calendarArray
    * @return array
    */
    Private function sanitizeDataFromUri( $calendarArray ) {
        $calDB = [];
        
        $calendar = $calendarArray['appt'];
        if(!is_array($calendar)) return $calDB;
        
        foreach($calendar as $calIdx=>$cals){
                // evaluate Date and Time
                $aStartDatum = $this->sanitizeCompressedDateString( $cals['inv'][0]['comp'][0]['s'][0]['d'] , true );
                $aEndDatum = $this->sanitizeCompressedDateString( $cals['inv'][0]['comp'][0]['e'][0]['d'] , true );
                
                $iZeitAb = ( 3600 * ( 0 + $aStartDatum['His']['H'] ) ) + ( 60 * ( 0 + $aStartDatum['His']['i'] ) ) + ( 0 + $aStartDatum['His']['s'] );
                $sStartDate = implode( '-' , $aStartDatum['Ymd'] );
                $sStartTime = implode( ':' , $aStartDatum['His'] );
                $sEndDate = implode( '-' , $aEndDatum['Ymd'] );
                $sEndTime =  implode( ':' , $aEndDatum['His'] );
                
                $calIndex = strtotime($sStartDate .' '. $sStartTime ) . '.' . $cals['uid'];
                $calDB[$calIndex]['uid'] = $cals['uid'];
                $calDB[$calIndex]['beginn'] = trim( $sStartDate . ' ' .  $sStartTime );
                $calDB[$calIndex]['ende']  = trim( $sEndDate . ' ' . $sEndTime );
                $calDB[$calIndex]['zeit_start'] = $sStartTime;
                $calDB[$calIndex]['zeit_ende'] = $sEndTime;
                $calDB[$calIndex]['array_start'] = $aStartDatum;
                $calDB[$calIndex]['array_ende'] = $aEndDatum;
                $calDB[$calIndex]['semestergrenze'] = 0;
                $calDB[$calIndex]['anlass'] = $cals['inv'][0]['comp'][0]['name'];
                $calDB[$calIndex]['zeitAb'] = $iZeitAb;
                $calDB[$calIndex]['zeit_ab'] = $iZeitAb;
                $calDB[$calIndex]['zeitAbString'] = $this->secondsToTimestring( $iZeitAb ) ;

                // detect if it is a period-border
//                 $periodKeywords = explode( ',' , $this->settings['period_keywords'] );
                foreach( array_keys($this->settings['period_keywords']) as $kword ){
                    if( strtolower(trim($calDB[$calIndex]['anlass'])) == strtolower(trim($kword)) ){
                        $calDB[$calIndex]['semestergrenze'] = 1;
                    }
                }
        }
        ksort($calDB);
        return $calDB;
    }

    /**
     * secondsToTimestring
     * 
     * @param int $iSeconds
     * @return void
     */
    Private function secondsToTimestring( $iSeconds )
    {
            if( empty($iSeconds) ) return '';
            return date( 'H:i:s' , $iSeconds );
    }

    /**
    * filterSanitizedData
    *
    * @param str $strEngDateFrom
    * @param array $calDB
    * @return array
    */
    Private function filterSanitizedData( $strEngDateFrom , $calDB ) {
        foreach( $calDB as $idx => $row ){
            // exclude older items
            
            $sr = [ 
                'anlass'    => '"' . $row['anlass'] . '"' , 
                'jahr_ab'    => 0+$row['array_start']['Ymd']['Y'] , 
                'monat_ab'   => 0+$row['array_start']['Ymd']['m'] , 
                'tag_ab'     => 0+$row['array_start']['Ymd']['d'] , 
                'datum_ab'   => 0+implode( '' , $row['array_start']['Ymd']) , 
                'stunde_ab'  => 0+$row['array_start']['His']['H'] , 
                'minute_ab'  => 0+$row['array_start']['His']['i'] , 
                'jahr_bis'   => 0+$row['array_ende']['Ymd']['Y'] , 
                'monat_bis'  => 0+$row['array_ende']['Ymd']['m'] , 
                'tag_bis'    => 0+$row['array_ende']['Ymd']['d'] , 
                'datum_bis'  => 0+implode( '' , $row['array_ende']['Ymd']) , 
                'stunde_bis' => 0+$row['array_ende']['His']['H'] , 
                'minute_bis' => 0+$row['array_ende']['His']['i'] , 
                'UND'=>'&&' , 'AND'=>'&&' , 'ODER'=>'||' , 'OR'=>'||' , 'UNGLEICH'=>'!='  , 'NICHT'=>'!=' , 'NOT'=>'!=' , 'GLEICH'=>'==' , 'EQUAL'=>'==' 
            ];
            
            // exclude clauses from settings
            $skipThisItem = 0;
            foreach( $this->settings['exclude'] as $strCondition ){
                // $strCondition something like ' zeit_ab >= 8 UND zeit_bis <= 12 '
                $match = false;
                $execCond = '$match = ' . str_replace( array_keys($sr) , $sr , $strCondition ) . ';';
                eval($execCond);
                $skipThisItem += $match ? 1 : 0;
            }
            if( $skipThisItem ) unset($calDB[$idx]);
        }
        
        return $calDB;
	}
    
    /**
    * sanitizeCompressedDateString
    *  date in format 'YYYYMMDD HH:ii:ss'
    *  - to array[ 'Ymd' => [ 'Y'=>'2012' , 'm'=>'02' , 'd'=>'28' ] , 'His' => [ 'H'=>'23' , 'i'=>'59' , 's'=>'59' ] ]
    *  - or to string yyyy-mm-dd hh:ii:ss
    *
    * @param string $strDate
    * @param bool $asArray optional
    * @return mixed
    */
    Private function sanitizeCompressedDateString( $strDate , $asArray = false ) {
        // split into DatePart and TimePart
        $aDate = explode( 'T' , $strDate );
        
        // separe and reconstruct the date part
        $aDateParts = array( 'Y' => substr($aDate[0] , 0 , 4) , 'm' => substr($aDate[0] , 4 , 2) , 'd' => substr($aDate[0] , 6 , 2) );
        $datePart = $aDateParts['Y'] .'-' . $aDateParts['m'] .'-' . $aDateParts['d'];
        
        // separe and reconstruct the time part
        if( !isset($aDate[1]) ){ // no time given
            $timePart = '';
            $aTimeParts = [];
            
        }elseif( strpos( $aDate[1] , ':' ) ){ // time separed by colon 23:54:59
            $aTs = explode( ':' , $aDate[1] );
            $aTimeParts = [ 'H' => $aTs[0] ,  'i' => $aTs[1] ,  's' => $aTs[2] ];
            $timePart = $aDate[1];
            
        }elseif( strlen($aDate[1]) == 6 ){ // time not separed ad all: 235459
            $aTimeParts = [ 'H' => substr($aDate[1] , 0 , 2) , 'i' => substr($aDate[1] , 2 , 2) , 's' => substr($aDate[1] , 4 , 2) ];
            $timePart = implode( ':' , $aTimeParts );
            
        }
        if( $asArray ) return [ 'Ymd' => $aDateParts , 'His' => $aTimeParts ];
        return $datePart . ' ' . $timePart ;
    }
	
	/**
	* unused_germanToEnglishDate
	*
	* @param string $strDate german d.m.Y [H:i:s] or english Y-m-d [H:i:s] to english Y-m-d [H:i:s]
	* @param bool $cutTime default is true
	* @return int
	*/
	Private function unused_germanToEnglishDate( $strDate , $cutTime = true ) {
            // separe date from time
            $strDate = str_replace( '\T' , 'T' , trim($strDate) );
            $strDate = str_replace( 'T' , ' ' , trim($strDate) );
            $strTime = '';
            if( strpos( $strDate , ' ' ) ){
                $aDatTim = explode( ' ' , $strDate );
                $strDate = $aDatTim[0];
                $strTime = ' ' . $aDatTim[1];
            }
            
            // transform to englishdate
            if( strpos( $strDate , '.' ) ){
                $aGermDate = explode(  '.' , $strDate );
                $aDat = [ $aGermDate[2] , $aGermDate[1] , $aGermDate[0] ];// Y m d
                
            }elseif( strpos( $strDate , '-' ) ){
                $strEngDate = $strDate;
                $aDat = explode( '-' , $strDate );// Y m d
                
            }else{ // perhaps unixdate or something else like Ymd
                return null;
                
            }
            $englishDateString = implode( '-' , $aDat );
            
            if($cutTime) return $englishDateString;
            
            return trim( $englishDateString . $strTime );
	}
	
}
