<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class XmlToPhpArrayUtility
 */

class XmlToPhpArrayUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* surveyDB
	*
	* @var array
	*/
	public $surveyDB = array();
	
	/**
	 * readFromFile
	 * 
	 * @param string $fullFilePathName
	 * @return array
	 */
	public function readFromFile( $fullFilePathName , $noCdata = false ) {
	      if($noCdata){
		    $xObj = simplexml_load_file( $fullFilePathName , 'SimpleXMLElement' , LIBXML_NOCDATA);
	      }else{
		    $xObj = simplexml_load_file( $fullFilePathName , 'SimpleXMLElement');
	      }
	      return $this->xmlToArr( $xObj );
	}
	
	/**
	 * readFromString
	 * 
	 * @param string $xmlString
	 * @param bool $noCdata
	 * @return array
	 */
	public function readFromString( $xmlString , $noCdata = false ) {
	      if($noCdata){
		    $xObj = simplexml_load_string( $xmlString , 'SimpleXMLElement' , LIBXML_NOCDATA );
	      }else{
		    $xObj = simplexml_load_string( $xmlString , 'SimpleXMLElement' );
	      }
	      return $this->xmlToArr( $xObj );
	}
	
	public function xmlToArr( $xObj ) {
	      $outJson = json_encode( $xObj );
	      $aSurveyDB = json_decode( $outJson , TRUE );
	      if( !is_array($aSurveyDB) ) return [];
	      $this->surveyDB = $aSurveyDB;
	      return $this->surveyDB;
	}
	
	/**
	 * readFromString
	 * 
	 * @param array $limeSurveyArrFromXml
	 * @return array
	 */
	public function limeSurveyArrToFlatDbArr( $limeSurveyArrFromXml ) {
	      $dbArr = array();
	      // get subquestions $dbArr['subquestions']
	      if( isset( $limeSurveyArrFromXml['subquestions']['rows']['row']['gid'] ) ){
		    $subquests[] = $limeSurveyArrFromXml['subquestions']['rows']['row'];
	      }elseif( is_array( $limeSurveyArrFromXml['subquestions']['rows']['row'] ) ){
		    $subquests = $limeSurveyArrFromXml['subquestions']['rows']['row'];
	      }
	      if( is_array($subquests) ){
		    foreach($subquests as $x=>$sQuest){
			  $dbArr['subquestions'][$sQuest['parent_qid']][ $sQuest['question_order'] . '.' . $sQuest['qid'] ] = array(
				'question'=> $sQuest['question'],
				'question_order'=>$sQuest['question_order'],
			  );
		    }
	      }

	      // get question-attributes $dbArr['questionwidth']
	      if( isset( $limeSurveyArrFromXml['question_attributes']['rows']['row']['gid'] ) ){
		    $attribs[] = $limeSurveyArrFromXml['question_attributes']['rows']['row'];
	      }elseif( is_array( $limeSurveyArrFromXml['question_attributes']['rows']['row'] ) ){
		    $attribs = $limeSurveyArrFromXml['question_attributes']['rows']['row'];
	      }
	      if( is_array($attribs) ){
		    foreach($attribs as $x=>$attrib){
			  if( $attrib['attribute'] == 'text_input_width' || $attrib['attribute'] == 'answer_width' ){
				$dbArr['questionwidth'][ $attrib['qid'] ] = $attrib['value'];
			  }
		    }
	      }
	      
	      // get answers and sort them $dbArr['sortQanswers']
	      if( is_array( $limeSurveyArrFromXml['answers']['rows']['row'] ) ){
		    foreach($limeSurveyArrFromXml['answers']['rows']['row'] as $x=>$quest){
			  $answers[ $quest['qid'] ][ $quest['sortorder'] . '.' . $x ] = $quest;
		    }
		    if( is_array($answers) ){
			  foreach($answers as $qix=>$unsortAnsers){
				ksort($unsortAnsers);
				foreach($unsortAnsers as $qAnswer){
				      $dbArr['sortQanswers'][$qix][$qAnswer['code']] = $qAnswer['answer'] . '=' . $qAnswer['assessment_value'];
				}
			  }
		    }
	      }
	      
	      // get questions $dbArr['questions']
	      if( isset( $limeSurveyArrFromXml['questions']['rows']['row']['gid'] ) ){
		    $quest = $limeSurveyArrFromXml['questions']['rows']['row'];
		    $quest['answers'] = 
		    $dbArr['questions'][$quest['gid']][$quest['question_order'] . '.0'] = $quest;
	      }elseif( is_array( $limeSurveyArrFromXml['questions']['rows']['row'] ) ){
		    foreach($limeSurveyArrFromXml['questions']['rows']['row'] as $x=>$quest){
			  $dbArr['questions'][ $quest['gid'] ][ $quest['question_order'] . '.' . $x ] = $quest;
		    }
	      }
	      
	      // get groups $dbArr['groups']
	      if(is_array($limeSurveyArrFromXml['groups']['rows']['row'])){
		    if( isset( $limeSurveyArrFromXml['groups']['rows']['row']['gid'] ) ){
			  $dbArr['groups'][0] = $limeSurveyArrFromXml['groups']['rows']['row'];
		    }elseif( is_array( $limeSurveyArrFromXml['groups']['rows']['row'] ) ){
			  $dbArr['groups'] = $limeSurveyArrFromXml['groups']['rows']['row'];
		    }
	      }
	      
	      return $dbArr;
	}

}
