<?php
namespace Mff\MffLsb\Utility;
use \DateTime;
use TYPO3\CMS\Core\Utility\GeneralUtility;

 /** 
 * Class UpdateResponsesUtility
 * look up if a mail job is open
 * sends the Email if trigger is on
 * 
 * 
 */
 
class UpdateResponsesUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* userSurveyController
	*
	* @var \Mff\MffLsb\Controller\UserSurveyController
	*/
	protected $userSurveyController = null;
	
	/**
	* __construct
	*
	* @return void
	*/
	public function __construct(  ) {
// 			$this->timeZone = new \DateTimeZone('Europe/Zurich');
// 			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
// 			$this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
// 
// 			$this->querySettings->setRespectStoragePage(FALSE);
// 			$this->userSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\UserSurveyRepository');
// 			$this->userSurveyRepository->setDefaultQuerySettings($this->querySettings);
// 			$this->persistenceManager = GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");
			$this->userSurveyController = new \Mff\MffLsb\Controller\UserSurveyController();
			
	}

	/**
	* updateReponses
	*
	* @return array
	*/
	public function updateReponses() {
			$aSurveys = $this->userSurveyController->userSurveyRepository->findByUid(208);
			$this->userSurveyController->updateSurveyFromApi($aSurveys);
	}
}
