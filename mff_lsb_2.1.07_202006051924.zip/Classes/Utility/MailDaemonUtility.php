<?php
namespace Mff\MffLsb\Utility;
use \DateTime;
use TYPO3\CMS\Core\Utility\GeneralUtility;

 /** 
 * Class MailDaemonUtility
 * look up if a mail job is open
 * sends the Email if trigger is on
 * 
 * 
 */
 
class MailDaemonUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* userSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\UserSurveyRepository
	*/
	protected $userSurveyRepository = null;

	/**
	 * mailUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $mailUtility = NULL;
	
	/**
	 * options UNUSED
	 *
	 * @var array
	 */
	public $options = array(
			'notification_subject' => 'Maildämon hat ##EX## Nachrichten gesendet' ,
			'email_footer' => '<br /><p>logo_mailfooter.gif</p>',
			'aImages' => array(
					'logo_mailfooter.gif' => 'typo3conf/ext/mffdesign/Resources/Public/images/logo/sfgz_v.svg'
			)
	);

	/**
	* settings
	* 
	* @var array
	*/
	protected $settings = array();
	
	/**
	* __construct
	*
	* @return void
	*/
	public function __construct(  ) {
			$this->timeZone = new \DateTimeZone('Europe/Zurich');
			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');

			$this->querySettings->setRespectStoragePage(FALSE);
			$this->userSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\UserSurveyRepository');
			$this->userSurveyRepository->setDefaultQuerySettings($this->querySettings);
			$this->persistenceManager = GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");
			$this->mailUtility = new \Mff\MffLsb\Utility\MailUtility();
			$this->settings = $this->mailUtility->getSettings(); 
	}

	
	/**
	* evaluateMailJobs
	*
	* @param string $service
	* @return array
	*/
	public function evaluateMailJobs( $service ) {
	    // first run reminder instead to run invitation before reminder to provide 2 mails on same day
	    $objList = array();
	    $job = array();
	    if( $service == 'alle' || $service == 'erinnerung' ) $job['Erinnerungen'] = 1;
	    if( $service == 'alle' || $service == 'einladung' ) $job['Einladungen'] = 1;
	    if( $service == 'alle' || $service == 'vorlagen' ) $job['Vorlagen'] = 1;
	    
	    if( isset($job['Erinnerungen']) ) $this->updateJobGetAnswers();
	    
	    if( isset($job['Erinnerungen']) ) $objList['Erinnerungen'] = $this->mailjobReminder();
	    if( isset($job['Einladungen']) ) $objList['Einladungen'] = $this->mailjobInvitation();
	    if( isset($job['Vorlagen']) ) $objList['Vorlagen'] = $this->mailjobHandout();
	    
	    if( !count($objList) ){return 0;}
	    foreach( $objList as $stadium => $stadeObj ) {
				if( !count($stadeObj) ) continue;
				foreach($stadeObj as $uid => $userSurvey) {
						$objSurveys[$userSurvey->getUserUid()][$stadium][$uid] = $userSurvey;//->getUid() . ', (state:' . $userSurvey->getMailState() . '), ' . $userSurvey->getEnquirerName() . ': ' . $userSurvey->getCourseName() . ', ' . $userSurvey->getSubject() . ' (' . $userSurvey->getSurveyUid() . ')';
				}
	    }
	    $counter = 0;
	    if( !count($objSurveys) ) return 0;
		foreach( $objSurveys as $userUid => $userObj ) {
				$aInfo = array();
				foreach( $userObj as $stadium => $stadeObj ) {
						foreach( $stadeObj as $uid => $userSurvey ) {
								$aInfo[$stadium][$uid] = $userSurvey->getEnquirerName() . ': ' . $userSurvey->getCourseName() . ', ' . $userSurvey->getSubject() . ' (' . $userSurvey->getSurveyUid() . ' | uid:'.$uid.')';
								++$counter;
						}
				}
				$this->mailNotificationForJobs( $userUid , $aInfo );
		}
		return $counter;
	}
	
	/**
	* mailjobInvitation
	* returns an Array with userSurvey objects
	*
	* @return array 
	*/
	public function mailjobInvitation() {
			$unixMaxStartDate = time();
			$mailState = 1 ;
			$respectResponses = FALSE;
			$objForInvitaion = $this->userSurveyRepository->findRemotedByDateMailstateAndResponses( $unixMaxStartDate , $mailState , $respectResponses );
			if(!count($objForInvitaion)) return;
			$aObj = array();
			$aInfo = array();
			foreach($objForInvitaion as $obj) {
					$endDate = $obj->getStartDate()->format('U') + ( 3600*24* $obj->getExpireDays()  );
					if( $endDate < $unixMaxStartDate && date('Ymd',$endDate) != date('Ymd',$unixMaxStartDate) ) continue;// end date is passed
					$aObj[]=$obj;
			}
			// do mailwork here!
			foreach($aObj as $userSurvey) {
					$success = $this->mailUtility->sendLinkAndUpdate( $userSurvey );
					if($success) $aInfo[$userSurvey->getUid()] = $userSurvey;//$userSurvey->getUid() . ', (state:' . $userSurvey->getMailState() . '), ' . $userSurvey->getEnquirerName() . ': ' . $userSurvey->getCourseName() . ', ' . $userSurvey->getSubject() . ' (' . $userSurvey->getSurveyUid() . ')';
			}
			return $aInfo;
    }
    
	/**
	* mailjobHandout
	* returns an Array with userSurvey objects
	*
	* @return array 
	*/
	public function mailjobHandout() {
			$unixMaxStartDate = time();
			$mailState = 6 ;
			$respectResponses = FALSE;
			$objForInvitaion = $this->userSurveyRepository->findRemotedByDateMailstateAndResponses( $unixMaxStartDate , $mailState , $respectResponses );
			if(!count($objForInvitaion)) return;
			$aObj = array();
			$aInfo = array();
			foreach($objForInvitaion as $obj) {
					$endDate = $obj->getStartDate()->format('U') + ( 3600*24* $obj->getExpireDays()  );
					if( $endDate < $unixMaxStartDate && date('Ymd',$endDate) != date('Ymd',$unixMaxStartDate) ) continue;// end date is passed
					$aObj[]=$obj;
			}
			// do mailwork here!
			foreach($aObj as $userSurvey) {
					$success = $this->mailUtility->sendHandoutAndUpdate( $userSurvey );
					if($success) $aInfo[$userSurvey->getUid()] = $userSurvey;//$userSurvey->getUid() . ', (state:' . $userSurvey->getMailState() . '), ' . $userSurvey->getEnquirerName() . ': ' . $userSurvey->getCourseName() . ', ' . $userSurvey->getSubject() . ' (' . $userSurvey->getSurveyUid() . ')';
			}
			return $aInfo;
    }
	
	/**
	* mailjobReminder
	*
	* @return array
	*/
	public function mailjobReminder() {
			$unixMaxStartDate = time();
			$mailState = 3 ;
			$respectResponses = TRUE;// remind only if no responses found
			$objForReminder = $this->userSurveyRepository->findRemotedByDateMailstateAndResponses( $unixMaxStartDate , $mailState , $respectResponses );
			if(!count($objForReminder)) return;
			$uxSecondsToEnd = (3600*24) * $this->settings['remind_daysleft'];
			$aObj = array();
			$aInfo = array();
			foreach($objForReminder as $obj) {
					$startDate = $obj->getStartDate()->format('U');
					$createDate = $obj->getCrdate();
					if( empty($createDate) ) continue;
					if( $createDate > $startDate ) $startDate = $createDate;
					$endDate = $startDate + ( 3600*24* $obj->getExpireDays()  );
					if( $endDate < $unixMaxStartDate && date('Ymd',$endDate) != date('Ymd',$unixMaxStartDate) ) continue; // end date is passed
					$remindDay = $endDate - $uxSecondsToEnd;
					if( $remindDay <= $startDate ) continue; // remind day is before or equal startDay
					if( $startDate + $uxSecondsToEnd >= $unixMaxStartDate) continue; // now is short after startDay
					if( $remindDay > $unixMaxStartDate ) continue; // remind day not yet
					$aObj[]=$obj;
			}
			// do mailwork here!
			foreach($aObj as $userSurvey) {
					$success = $this->mailUtility->sendReminderAndUpdate( $userSurvey );
					if($success) $aInfo[$userSurvey->getUid()] = $userSurvey;//$userSurvey->getUid() . ', (state:' . $userSurvey->getMailState() . '), ' . $userSurvey->getEnquirerName() . ': ' . $userSurvey->getCourseName() . ', ' . $userSurvey->getSubject() . ' (' . $userSurvey->getSurveyUid() . ')';
			}
			return $aInfo;
    }
	
	/**
	* updateSurveysFromApi
	*
	* @return array
	*/
	public function updateJobGetAnswers() {
			$userSurveyController = $this->mailUtility->getUserSurveyController();
			$unixMaxStartDate = time();
			$mailState = 3 ;// update only if invited
			$respectResponses = TRUE;// update only if no responses found
			$objForReminder = $this->userSurveyRepository->findRemotedByDateMailstateAndResponses( $unixMaxStartDate , $mailState , $respectResponses );
			if(!count($objForReminder)) return;
			$uxSecondsToEnd = (3600*24) * $this->settings['remind_daysleft'];
			$aObj = array();
			$aInfo = array();
			foreach($objForReminder as $userSurvey) {
					$startDate = $userSurvey->getStartDate()->format('U');
					$endDate = $startDate + ( 3600*24* $userSurvey->getExpireDays()  );
					if( $endDate < $unixMaxStartDate && date('Ymd',$endDate) != date('Ymd',$unixMaxStartDate) ) continue; // end date is passed
					$remindDay = $endDate - $uxSecondsToEnd;
					if( $remindDay <= $startDate ) continue; // remind day is before or equal startDay
					if( $startDate + $uxSecondsToEnd >= $unixMaxStartDate) continue; // now is short after startDay
					if( $remindDay > $unixMaxStartDate ) continue; // remind day not yet
					$userSurveyController->updateSurveyFromApi($userSurvey);
					$aInfo[$userSurvey->getUid()] = $userSurvey;
			}
			$this->persistenceManager->persistAll();
			return $aInfo;
    }
	
	/**
	* mailNotificationForJobs
	* draw formatted Email, sends the Notification Mail to Admin
	* 
	* @param int $userUid
	* @param array $objSurveys
	* @return array
	*/
	public function mailNotificationForJobs( $userUid , $objSurveys ) {
			if(!count($objSurveys) ) return false;
			$oUser = $this->mailUtility->getFrontendUserRepository()->findByUid($userUid);
			if( !$oUser ) return false;
			$adminEmail = $oUser->getEmail();
			if( !filter_var($adminEmail, FILTER_VALIDATE_EMAIL) ) return false;
			
			$reminderText = array();
			$msgCount = 0;
			foreach($objSurveys as $stadium => $stadeObj) {
				$reminderText[]= count($stadeObj) . ' ' . $stadium . ' gesendet<br />'.implode( ',<br />' , $stadeObj) .'. <br /><br />';
				$msgCount += count($stadeObj);
			}

			$footer = str_replace( '|' , $this->settings['mail']['logo']['imagename'] , $this->settings['mail']['logo']['wrap_image'] );
			$rawSubject = $msgCount == 1 ? $this->settings['mail']['notification_subject'][0] : $this->settings['mail']['notification_subject'][1];
			
			$mailData = array(
					'Subject' => str_replace('##EX##',$msgCount,$rawSubject),
					'Body' => implode('<br />',$reminderText).'<hr>'.$footer,
					'From' => $this->settings['mail']['sender_adress'],
					'To' => $adminEmail,
					'Images' => array( $this->settings['mail']['logo']['imagename'] => $this->settings['mail']['logo']['path'] )
			);
			$this->mailUtility->sendWithAttatchment($mailData);

			return $reminderText;
    }
	
}
