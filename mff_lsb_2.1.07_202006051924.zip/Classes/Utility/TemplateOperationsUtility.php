<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class TemplateOperationsUtility
 */

class TemplateOperationsUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* tpSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\TpSurveyRepository
	*/
	protected $tpSurveyRepository = null;
    
    /**
     * tpGroupRepository
     *
     * @var \Mff\MffLsb\Domain\Repository\TpGroupRepository
     * @inject
     */
    protected $tpGroupRepository = null;
    
    /**
     * tpQuestionRepository
     *
     * @var \Mff\MffLsb\Domain\Repository\TpQuestionRepository
     * @inject
     */
    protected $tpQuestionRepository = null;
    
    /**
     * tpSubquestionRepository
     *
     * @var \Mff\MffLsb\Domain\Repository\TpSubquestionRepository
     * @inject
     */
    protected $tpSubquestionRepository = null;
    
    protected $objectManager ;

    /**
      * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
      */
    protected $persistenceManager = NULL;

	/**
	* @var array
	*/
	protected $settings = array();

	/**
	 * typoScriptService
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $typoScriptService = NULL;

	/**
	* __construct
	* 
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings = array() ) {
	      if(count($settings)) $this->settings = $settings;
	      $this->loadRepositorySettings();
	}
 	public function loadRepositorySettings( ) {
	  $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	  $this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $pluginStoragePid = $fullsettings['plugin.']['tx_mfflsb_template.' ]['persistence.']['storagePid'];
	      $this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $this->querySettings->setStoragePageIds( array( 'storagePid_template'=>$pluginStoragePid ) );
	      $this->tpSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpSurveyRepository');
	      $this->tpSurveyRepository->setDefaultQuerySettings($this->querySettings);
	      $this->tpGroupRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpGroupRepository');
	      $this->tpGroupRepository->setDefaultQuerySettings($this->querySettings);
	      $this->tpQuestionRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpQuestionRepository');
	      $this->tpQuestionRepository->setDefaultQuerySettings($this->querySettings);
	      $this->tpSubquestionRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpSubquestionRepository');
	      $this->tpSubquestionRepository->setDefaultQuerySettings($this->querySettings);
 	}

    /**
     * duplicateTpSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\TpSurvey $tpSurvey
     * @return void
     */
    public function duplicateTpSurvey(\Mff\MffLsb\Domain\Model\TpSurvey $tpSurvey) {
 		  $newSurvey = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\TpSurvey');
		  $properties = $tpSurvey->_getProperties() ;
		  $oldUid = $properties['uid'];
		  unset($properties['uid']) ;
		  foreach ($properties as $key => $value ) $newSurvey->_setProperty( $key , $value );
		  $this->tpSurveyRepository->add( $newSurvey );
		  $this->persistenceManager->persistAll();
		  $newUid = $newSurvey->getUid();
		  
		  $grps = $tpSurvey->getTpSurveyGroup();
		  if(count($grps)){
			foreach ($grps as $i => $grp) {
			      $newGroup = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\TpGroup');
 			      $gProperties = $grp->_getProperties();
 			      unset($gProperties['uid']) ;
 			      unset($gProperties['tpGroupQuestion']) ;
 			      $gProperties['tpsurvey'] = $newUid;
 			      foreach ($gProperties as $key => $value )$newGroup->_setProperty( $key , $value );
			      $this->tpGroupRepository->add( $newGroup );
			      $this->persistenceManager->persistAll();
			      $newGroupUid = $newGroup->getUid();
			      $quests = $grp->getTpGroupQuestion();
			      if(count($quests)){
				    foreach ($quests as $qst) {
					$newQuestion = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\TpQuestion');
					$qProperties = $qst->_getProperties() ;
					unset($qProperties['uid']) ;
					$qProperties['tpgroup'] = $newGroupUid ;
					foreach ($qProperties as $key => $value )$newQuestion->_setProperty( $key , $value );
					$this->tpQuestionRepository->add( $newQuestion );
					$this->persistenceManager->persistAll();
					$newQuestionUid = $newQuestion->getUid();
					$subquests = $qst->getTpQuestionSubquestion();
					if(count($subquests)){
					      foreach ($subquests as $sqst) {
						    $newSubquestion = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\TpSubquestion');
						    $sqProperties = $sqst->_getProperties() ;
						    unset($sqProperties['uid']) ;
						    $sqProperties['tpquestion'] = $newQuestionUid ;
						    foreach ($sqProperties as $key => $value )$newSubquestion->_setProperty( $key , $value );
						    $this->tpSubquestionRepository->add( $newSubquestion );
						    $this->persistenceManager->persistAll();
					      }
					}
				    }
			      }
			}
		  }
		  $this->persistenceManager->persistAll();
		  return $newSurvey;
    }

    /**
     * addQuestionsToSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\TpSurvey $tpSurvey
     * @param array $aCreateRecords
     * @return void
     */
    public function addQuestionsToSurvey(\Mff\MffLsb\Domain\Model\TpSurvey $tpSurvey , $aCreateRecords) {
	if( !is_array($aCreateRecords['groups']) ) return false;
	$surveyUid = $tpSurvey->getUid();
	$aQuestionTypes = array_flip($this->settings['keymap']['type']);
	foreach( $aCreateRecords['groups'] as $group){
	      $gid = $group['gid'];
	      $newGroup = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\TpGroup');
	      $newGroup->setGroupName( $group['group_name'] );
	      $newGroup->setGroupDescription( $group['description'] );
	      $newGroup->setReportPartials( 3 );
	      $newGroup->setSorting( $group['group_order'] );
	      $newGroup->setTpsurvey( $surveyUid );
	      $tpSurvey->addTpSurveyGroup($newGroup);
// 	      $this->tpGroupRepository->add( $newGroup );
 	      $this->persistenceManager->persistAll();
 	      $this->tpSurveyRepository->update($tpSurvey);
	      $newGroupUid = $newGroup->getUid();
	      if( is_array($aCreateRecords['questions'][$gid]) ){
		    ksort( $aCreateRecords['questions'][$gid] );
		    foreach( $aCreateRecords['questions'][$gid] as $aQuestion){
			  $newQuestion = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\TpQuestion');
			  if( empty($aQuestion['question']) ){
					$newQuestion->setQuestion( $aQuestion['title'] );
					$newQuestion->setHideTitle( 1 );
			  }else{
					$newQuestion->setQuestion( $aQuestion['question'] );
			  }
			  $newQuestion->setMandatory( $aQuestion['mandatory'] == 'Y' ? 1 : 0 );
			  $newQuestion->setQuestionType( $aQuestionTypes[ $aQuestion['type'] ] );
			  $newQuestion->setQuestionWidth( $aCreateRecords['questionwidth'][$aQuestion['qid']] );
			  $newQuestion->setAnswers( is_array($aCreateRecords['sortQanswers'][$aQuestion['qid']]) ? implode(';',$aCreateRecords['sortQanswers'][$aQuestion['qid']]) : '' );
			  $newQuestion->setSorting( $aQuestion['question_order'] );
			  $newQuestion->setTpgroup( $newGroupUid );
			  $newGroup->addTpGroupQuestion($newQuestion);
			 // $this->tpQuestionRepository->add( $newQuestion );
 			  $this->persistenceManager->persistAll();
			  $newQuestionUid = $newQuestion->getUid();
			  if( is_array($aCreateRecords['subquestions'][$aQuestion['qid']]) ){
				//Matrix or Textfields
				ksort( $aCreateRecords['subquestions'][$aQuestion['qid']] );
				foreach( $aCreateRecords['subquestions'][$aQuestion['qid']] as $aSubquestion){
				      $newSubquestion = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\TpSubquestion');
				      $newSubquestion->setTpquestion( $newQuestionUid );
				      $newSubquestion->setQuestion( $aSubquestion['question'] );
				      $newSubquestion->setSorting( $aSubquestion['question_order'] );
				      $newQuestion->addTpQuestionSubquestion($newSubquestion);
				      //$this->tpSubquestionRepository->add( $newSubquestion );
				}
				$this->tpQuestionRepository->update( $newQuestion );
			  }elseif( $aQuestion['type'] == 'T' ){ // Textarea
				      $newSubquestion = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\TpSubquestion');
				      $newSubquestion->setTpquestion( $newQuestionUid );
				      $newSubquestion->setQuestion( $aQuestion['question'] );
				      //$this->tpSubquestionRepository->add( $newSubquestion );
				      $newQuestion->addTpQuestionSubquestion($newSubquestion);
				      $this->tpQuestionRepository->update( $newQuestion );
			  }
			  $this->tpGroupRepository->update( $newGroup );
		    }
		    $this->tpSurveyRepository->update($tpSurvey);
	      }
	}
	$this->persistenceManager->persistAll();
	return $tpSurvey;
    }
	
}

