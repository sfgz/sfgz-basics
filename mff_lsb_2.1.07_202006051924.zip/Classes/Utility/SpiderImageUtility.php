<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class SpiderImageUtility
 */

class SpiderImageUtility {
	
	Public $conf = array(
		'mainValues' => '0.5,3,1.21,1.12,3,1.12,1.21,3',
		'overlayValues' => '0.6,2,2.75,2,1.1,2,2.75,2',
		'outerRadius' => 300,
		'outerBorder' => 2,
		'raytipLength' => 10,
		'innerRadius' => 30,
		'graduationSteps' => 4,
		'dotSize' => 0,
		'filledDot' => 2,
		'dotSize2' => 0,
		'filledDot2' => 2,
		'offset' => 0,
		'scale' => 1,
		'scale_offset' => 15,
		'scale_fontsize' => 2,
		'scale_round' => 0,
		'x' => NULL ,
		'y' => NULL
	);
	
	Public $colors = array(
	    'green' => array( 0xCA , 0xEF , 0x90 ),
	    'darkgreen' => array( 0x20, 0xCC, 0x20 ),
	    'black' => array( 0x00, 0x00, 0x00 ),
	    'gray' => array( 0xC0, 0xC0, 0xC0 ),
	    'darkgray' => array( 0x90, 0x90, 0x90 ),
	    'background' => array( 255, 255, 255 ),
	    'blue' => array( 0xBF, 0xBA, 0xFF ),
	    'darkblue' => array( 0x00, 0x00, 0xFF ),
	);
	
	Private $keyMap = array(
		'val' => 'mainValues',
		'val2' => 'overlayValues',
		'v' => 'mainValues',
		'v2' => 'overlayValues',
		'r' => 'outerRadius',
		'b' => 'outerBorder',
		't' => 'raytipLength',
		'i' => 'innerRadius',
		's' => 'graduationSteps',
		'd' => 'dotSize',
		'fd' => 'filledDot',
		'd2' => 'dotSize2',
		'fd2' => 'filledDot2',
		'o' => 'offset',
		'sc' => 'scale',
		'so' => 'scale_offset',
		'sf' => 'scale_fontsize',
		'h' => 'help'
	);

	/**
	* __construct
	*
	* @param array $conf
	* @return void
	*/
	Public function __construct( $conf = array() ){
	
	      foreach( $this->keyMap as $key => $map ){
		    if( isset( $conf[$key] ) ) {
			  $this->conf[$map] = $conf[$key];
		    }elseif(isset( $conf[$map] ) ){
			  $this->conf[$map] = $conf[$map];
		    }
	      }
	
	      $this->setConfigurationFromRequest();
	      
	      $this->setXY();
	      
	}
	
	Public function main(){
	    if( isset( $_REQUEST['info'] ) || isset( $_REQUEST['h'] ) || isset($_REQUEST['help']) ) return $this->info();
	    
	    if(!empty($this->conf['mainValues'])) $firstImage = $this->createImage();
	    
	    if(empty($this->conf['overlayValues'])) return $this->outputImage($firstImage);
 	    $val2Arr = explode( ',' , $this->conf['overlayValues'] );
 	    if( min($val2Arr) < 0 )  return $this->outputImage($firstImage);
	    
	    $secondImage = $this->createSecondImage();
	    if(empty($this->conf['mainValues'])) return $this->outputImage($secondImage);
	    
	    imagecopymerge($secondImage, $firstImage, 0, 0, 0, 0, 2 * $this->conf['x'], 2 * $this->conf['y'], 75);
	    
	    return $this->outputImage($secondImage);
	    
	}

	Private function createImage(){
	    $values = explode(',',$this->conf['mainValues']);
	    $gradation = ($this->conf['outerRadius'] -  $this->conf['innerRadius']) / ($this->conf['graduationSteps']-1);
	    
	    $strWidth = imagefontwidth(5)/2;
	    $strHeight = imagefontheight(5)/2;
	    
	    // evaluate total width and height
	    $mainRadius = $this->conf['outerRadius'] + $this->conf['raytipLength'];
	    
	    // Evaluate center of circles
	    $x = $this->conf['x'];
	    $y = $this->conf['y'];
	    // count rays, get value and calc lenght of each ray
	    for( $rays=0 ; $rays < count($values) ; ++$rays){
		$calcValue = $values[$rays]; // corr -1 because 1 ist lowest Point (and not 0)
		$results[$rays+1] = $this->conf['innerRadius']+( $calcValue * $gradation ); 
	    }
	    
	    // evaluate radiants of results (dots)
	    $slice = 360 / $rays;
	    for($step=1,$grd=0;$grd<=360;$grd+=$slice,++$step){
		$xp[$step] = $x+$this->xDiff( $results[$step] , $grd );
		$yp[$step] = $y-$this->yDiff( $results[$step] , $grd );
	    }

	    // create image and colors
	    $image = imagecreatetruecolor( (2*$x) , (2*$y) );
	    $bg = imagecolorallocate($image, $this->colors['background'][0], $this->colors['background'][1], $this->colors['background'][2] );
	    //$bg = ImageColorAllocateAlpha($image, 255, 255, 255, 127); // (PHP 4 >= 4.3.2, PHP 5)
	    $darkgray = imagecolorallocate($image, $this->colors['darkgray'][0], $this->colors['darkgray'][1], $this->colors['darkgray'][2] );
	    $gray = imagecolorallocate($image, $this->colors['gray'][0], $this->colors['gray'][1], $this->colors['gray'][2] );
	    $black = imagecolorallocate($image, $this->colors['black'][0], $this->colors['black'][1], $this->colors['black'][2] );
	    $darkgreen = imagecolorallocate($image, $this->colors['darkgreen'][0], $this->colors['darkgreen'][1], $this->colors['darkgreen'][2] );
	    $green = imagecolorallocate($image, $this->colors['green'][0], $this->colors['green'][1], $this->colors['green'][2] );

	    // Fill the background with the color selected above.
	    imagefill($image, 0, 0, $bg);
	  // imagecolortransparent( $image, $bg);

	    // draw shape of figure: lines to connect points
	    for($z=2;$z<=$rays;++$z) {
		imageline ( $image , $xp[$z-1] , $yp[$z-1] ,  $xp[$z] , $yp[$z] , $darkgreen );
	    }
	    imageline ( $image , $xp[$z-1] , $yp[$z-1] ,  $xp[1] , $yp[1] , $darkgreen );

	    // fill figure in center
	    //if( array_sum($values)>count($values) ) 
	    if( array_sum($values) ) imagefill($image, $x , $y , $green);

	    // evaluate radiants of rays
	    // draw rays
	    for($z=1;$z<=$rays;++$z) {
		imageline ( $image , $x , $y ,  $x+$this->xDiff( $mainRadius , $slice*$z ) , $y-$this->yDiff( $mainRadius , $slice*$z ) , $darkgray );
	    }

	    // circles
	    $circleStart = ($this->conf['innerRadius'] <10 ) ? ($this->conf['innerRadius']*2)+($gradation*2) : ($this->conf['innerRadius']*2);
	    
	    for($wh = $circleStart;$wh<=(2*$mainRadius);$wh+=($gradation*2)){
		imageellipse ( $image , $x , $y , $wh , $wh , $gray );
	    }
	    
	    // optional: scale 0% - 100%
	    if(!empty($this->conf['scale'])){
		  $scaleDeg = round( 360 / ( 3*$rays ) * ( 3*$rays-2 ) );
		  $offsetXY = $this->conf['scale_offset'];
		  for( $step = 0; $step < $this->conf['graduationSteps'] ; ++$step){
			$px = ( $step * $gradation ) + $this->conf['innerRadius'] + $offsetXY;
			$prz = round( $step * 100 / ($this->conf['graduationSteps']-1) , $this->conf['scale_round'] );
			imagestring($image, $this->conf['scale_fontsize'] , $x + $this->XDiff($px,$scaleDeg) , $y - $this->yDiff($px,$scaleDeg) ,  $prz.'%' , $gray);
		  }
	    }

	    // optional: numbers (text)
	    // evaluate radiants of labeltext
	    if(!empty($this->conf['offset'])){
		for($z=0;$z<$rays;++$z){
		    $xt = $x + $this->xDiff( $this->conf['offset']+$mainRadius , $slice*$z ) - $strWidth;
		    $yt = $y - $this->yDiff( $this->conf['offset']+$mainRadius , $slice*$z ) - $strHeight;
		    imagestring($image, 5, $xt , $yt, $z+1 , $black);
		}
	    }
	    // optional: dots
	    if(!empty($this->conf['dotSize'])){
		for($z=1;$z<=$rays;++$z) imageellipse ( $image , $xp[$z] , $yp[$z] , $this->conf['dotSize'] , $this->conf['dotSize'] , $black );
	    }
	    // optional: filled-dots
	    if(!empty($this->conf['filledDot'])){
		for($z=1;$z<=$rays;++$z) imagefilledellipse ( $image , $xp[$z] , $yp[$z] , $this->conf['filledDot'] , $this->conf['filledDot'] , $black );
	    }
	    return $image;
	}

	Private function createSecondImage(){
	    $values = explode(',',$this->conf['overlayValues']);
	    
	    // evaluate total width and height
	    $gradation = ($this->conf['outerRadius'] - $this->conf['innerRadius']) / ($this->conf['graduationSteps']-1);
	    
	    // Evaluate center of circles
	    $x = $this->conf['x'];
	    $y = $this->conf['y'];
	    
	    // count rays, get value and calc lenght of each ray
	    for( $rays=0 ; $rays < count($values) ; ++$rays){
		$calcValue = $values[$rays]; // corr -1 because 1 ist lowest Point (and not 0)
		$results[$rays+1] = $this->conf['innerRadius']+( $calcValue * $gradation ); 
	    }
	    
	    // evaluate radiants of results (dots)
	    $slice = 360 / $rays;
	    for($step=1,$grd=0;$grd<=360;$grd+=$slice,++$step){
		$xp[$step] = $x+$this->xDiff( $results[$step] , $grd );
		$yp[$step] = $y-$this->yDiff( $results[$step] , $grd );
	    }

	    // create image and colors
	    $image = imagecreatetruecolor( (2*$x) , (2*$y) );
	    $bg = imagecolorallocate($image, $this->colors['background'][0], $this->colors['background'][1], $this->colors['background'][2] );
	    $black = imagecolorallocate($image, $this->colors['black'][0], $this->colors['black'][1], $this->colors['black'][2] );
	    $blue = imagecolorallocate($image, $this->colors['blue'][0], $this->colors['blue'][1], $this->colors['blue'][2] );
	    $darkblue = imagecolorallocate($image, $this->colors['darkblue'][0], $this->colors['darkblue'][1], $this->colors['darkblue'][2] );

	    // Fill the background with the color selected above.
	    imagefill($image, 0, 0, $bg);

	    // draw shape of figure: lines to connect points
	    for($z=2;$z<=$rays;++$z) {
		imageline ( $image , $xp[$z-1] , $yp[$z-1] ,  $xp[$z] , $yp[$z] , $darkblue );
	    }
	    imageline ( $image , $xp[$z-1] , $yp[$z-1] ,  $xp[1] , $yp[1] , $darkblue );

	    // fill figure in center
	    imagefill($image, $x , $y , $blue);
	    
	    // optional: dots
	    if(!empty($this->conf['dotSize2'])){
		for($z=1;$z<=$rays;++$z) imageellipse ( $image , $xp[$z] , $yp[$z] , $this->conf['dotSize2'] , $this->conf['dotSize2'] , $black );
	    }
	    // optional: filled-dots
	    if(!empty($this->conf['filledDot2'])){
		for($z=1;$z<=$rays;++$z) imagefilledellipse ( $image , $xp[$z] , $yp[$z] , $this->conf['filledDot2'] , $this->conf['filledDot2'] , $black );
	    }
	    return $image;
	    
	}
	
	Private function info() {
	    $imageHeight = 50+17*count($this->keyMap);
	    $image = imagecreatetruecolor( 300 , $imageHeight );
	    $bg = imagecolorallocate($image, $this->colors['background'][0], $this->colors['background'][1], $this->colors['background'][2] );
	    $black = imagecolorallocate($image, $this->colors['black'][0], $this->colors['black'][1], $this->colors['black'][2] );
	    $darkgreen = imagecolorallocate($image, $this->colors['darkgreen'][0], $this->colors['darkgreen'][1], $this->colors['darkgreen'][2] );
	    // Fill the background with the color selected above.
	    imagefill($image, 0, 0, $bg);
	    $y = 8;
	    imagestring($image, 8 , 10 , $y ,  'Spider Image' , $black);
	    $y += 17;
	    imagestring($image, 8 , 10 , $y ,  'Help / Input options' , $black);
	    $y += 17;
	    imageline ( $image , 8 , $y ,  292 , $y , $darkgreen );
	    foreach( $this->keyMap as $key => $map ) {
			imagestring($image, 8 , 10 , $y ,  $key.' = '.$map , $black);
			$y += 17;
	    }
	    return $this->outputImage($image);
	}
	
	Private function setConfigurationFromRequest(){
	
	    foreach( $this->keyMap as $key => $map ) if( isset( $_REQUEST[$key] ) ) $this->conf[$map] = $_REQUEST[$key];
	    
	}
	
	Public function xDiff( $iHypothenuse , $alpha ){
	    // Laenge in Pixel
	    // ergibt Laenge der Gegenkathete "X" 
	    // aus Hypothenusen-Laenge in pixel (radiant,strahl) 
	    // und Winkel alpha in Grad
	    return round(($iHypothenuse*sin(deg2rad($alpha))));
	}
	
	Public function yDiff( $iHypothenuse , $alpha ){
	    // Laenge in Pixel
	    // ergibt Laenge der Ankathete "Y" 
	    // aus Hypothenusen-Laenge in pixel (radiant,strahl) 
	    // und Winkel alpha in Grad
	    return round(($iHypothenuse*cos(deg2rad($alpha))));
	}

	Private function setXY(){
	    $dim = array();
	    $strWidth = imagefontwidth(5)/2;
	    $strHeight = imagefontheight(5)/2;
	    $mainRadius = $this->conf['outerRadius'] + $this->conf['raytipLength'];
	    $dim['x'] = $mainRadius+$this->conf['outerBorder'];
	    $dim['y'] = $mainRadius+$this->conf['outerBorder'];
	    if($this->conf['offset']>0){
		$dim['x'] += $this->conf['offset']+$strWidth;
		$dim['y'] += $this->conf['offset']+$strHeight;
	    }
	    $this->conf['x'] = $dim['x'];
	    $this->conf['y'] = $dim['y'];
	    return $dim;
	}
	
	Private function outputImage( $image ){
	    header('Content-type: image/png');
	    imagepng($image);
	    imagedestroy($image);
	}
	
}
