<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class TemplateDataUtility
 */

class TemplateDataUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* wrapValueAsCdata
	*
	* @var boolean
	*/
	public $wrapValueAsCdata = false;
	
	/**
	* tpSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\TpSurveyRepository
	*/
	protected $tpSurveyRepository = null;

	/**
	* @var array
	*/
	protected $settings = array();

	/**
	 * typoScriptService
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $typoScriptService = NULL;

	/**
	* __construct
	*
	* @return void
	*/
	public function __construct( ) {
	      $this->loadRepositorySettings();
	}
	
 	public function loadRepositorySettings( ) {
			$this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
			$this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			// getPluginStoragePid: get settings
			$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
			$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
			// getPluginStoragePid: integer value of Pid
			$pluginStoragePid = $fullsettings['plugin.']['tx_mfflsb_template.' ]['persistence.']['storagePid'];
			// set the template repository
			$this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
			$this->querySettings->setStoragePageIds( array( 'storagePid_template'=>$pluginStoragePid ) );
			$this->tpSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpSurveyRepository');
			$this->tpSurveyRepository->setDefaultQuerySettings($this->querySettings);
			$this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_mfflsb_template.']['settings.']);
 	}
   
	/**
	* showObjectData
	* replaces values in xml-fields with db-values or values from TypoScript
	* returns a copy of the survey-object
	*
	* @param int $uid uid of template 
	* @return void
	*/
	public function showObjectData( $uid ){

		    $objSurveyTemplate = $this->tpSurveyRepository->findByUid( $uid );
		    
		    $xmlDb = $this->getObjectData( $objSurveyTemplate );
		    
 		    return $xmlDb;
 	}

	/**
	* getSettings
	*
	* @return array
	*/
	public function getSettings(){
 		    return $this->settings;
 	}

	/**
	 * getObjectData
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\Repository $objSurveyTemplate
	 * @return array
	 */
	public function getObjectData( $objSurveyTemplate ){ 
 		    $t3Db = array();
 		    $xmlDb = array();
 		    $tmpObj =  $objSurveyTemplate->getTemplateXml();
  		    $tmpObjArr = json_decode( $tmpObj , true );
 		    if(is_array($tmpObjArr['surveys']['rows']['row'])) $t3Db['surveys'] = $tmpObjArr['surveys']['rows']['row'];
 		    if(is_array($tmpObjArr['surveys_languagesettings']['rows']['row'])) $t3Db['surveys_languagesettings'] = $tmpObjArr['surveys_languagesettings']['rows']['row'];
		    // fill array with values from typo3-database
 		    $cropLength = $this->settings['limesurvey_maxlength_question_title']-4;
		    foreach( $this->settings['mapPropertiesToLimeSurveyXml'] as $section => $overrideField ){
			foreach( $overrideField as $xmlName => $dbField ){ 
				$atoms = explode( '_' , $dbField );
				foreach($atoms as $i=>$w){ $atoms[$i] = ucFirst($w); }
				$method = 'get' . implode($atoms);
				if( method_exists($objSurveyTemplate,$method) ) {
				      $fieldValue = $objSurveyTemplate->$method();
				      $t3Db[$section][$xmlName] = $this->wrapValueAsCdata( $fieldValue );
				}
			}
		    }
		    $grps = $objSurveyTemplate->getTpSurveyGroup();
		    if($grps){
			  $groupIx = 0;
			  $questionIx = 0;
			  foreach($grps as $grp){
			      $gid = $grp->getUid();
			      ++$groupIx;
			      $xmlDb[$gid]['groups']['gid'] = $gid;
			      $xmlDb[$gid]['groups']['group_name'] = $grp->getGroupName();
			      $xmlDb[$gid]['groups']['group_description'] = $grp->getGroupDescription() ;
			      $xmlDb[$gid]['groups']['report_partials'] = $grp->getReportPartials();
			      $xmlDb[$gid]['groups']['report_header_vertical'] = $grp->getReportHeaderVertical();
			      $xmlDb[$gid]['groups']['report_hide_header'] = $grp->getReportHideHeader();
			      $xmlDb[$gid]['groups']['sorting'] =  $grp->getSorting();
			      $questions = $grp->getTpGroupQuestion();
			      if($questions){
				  foreach($questions as $question){
					$quid = $question->getUid();
					++$questionIx;
					$xmlDb[$gid]['questions'][$quid]['qid'] = $quid;
					$xmlDb[$gid]['questions'][$quid]['gid'] = $gid;
					$xmlDb[$gid]['questions'][$quid]['question'] =$question->getQuestion() ;
					$xmlDb[$gid]['questions'][$quid]['answers'] = $question->getAnswers();
					$xmlDb[$gid]['questions'][$quid]['mandatory'] = $question->getMandatory();
					$xmlDb[$gid]['questions'][$quid]['hide_title'] = $question->getHideTitle();
					$xmlDb[$gid]['questions'][$quid]['question_type'] = $question->getQuestionType();
					$xmlDb[$gid]['questions'][$quid]['question_width'] = $question->getQuestionWidth();
					$xmlDb[$gid]['questions'][$quid]['sorting'] = $question->getSorting();
					$xmlDb[$gid]['questions'][$quid]['title'] = substr($this->stringToMinimalCharset( $xmlDb[$gid]['questions'][$quid]['question'] ) , 0 , $cropLength ) . sprintf('%02s',$groupIx) . sprintf('%02s',$questionIx);
					$subquestions = $question->getTpQuestionSubquestion();
					$aAnsOpt = explode( ';' , $xmlDb[$gid]['questions'][$quid]['answers'] );
					if(count($aAnsOpt)){
					      foreach( $aAnsOpt as $ix => $ansPairs){
						  $aPair = explode( '=' , $ansPairs );
						  if(!count($aPair)==2)continue;
						  $code = 'A'.  sprintf('%02s',$questionIx) . sprintf( '%02s' , $ix + 1 );
						  $xmlDb[$gid]['answers'][$quid][$ix]['qid'] = $quid;
						  $xmlDb[$gid]['answers'][$quid][$ix]['code'] = $code;
						  $xmlDb[$gid]['answers'][$quid][$ix]['answer'] = $aPair[0];
						  $xmlDb[$gid]['answers'][$quid][$ix]['sortorder'] =  $xmlDb[$gid]['questions'][$quid]['sorting'] . sprintf('%02s',$ix);
						  $xmlDb[$gid]['answers'][$quid][$ix]['assessment_value'] = $aPair[1];
						  $xmlDb[$gid]['answers'][$quid][$ix]['language'] = 'de';
						  $xmlDb[$gid]['answers'][$quid][$ix]['scale_id'] = 0;
					      }
					}
					
					if($subquestions){
					      $subquestIx = 0;
					      foreach($subquestions as $subquestion){
						    ++$subquestIx;
						    $squid = ( 1000 * $quid ) + $subquestion->getUid();
						    $title = 'UF' . sprintf('%02s',$groupIx) . sprintf('%02s',$questionIx) . sprintf('%02s',$subquestIx);
						    $xmlDb[$gid]['subquestions'][$quid][$squid]['qid'] = $squid;
						    $xmlDb[$gid]['subquestions'][$quid][$squid]['gid'] = $gid;
						    $xmlDb[$gid]['subquestions'][$quid][$squid]['parent_qid'] = $quid;
						    $xmlDb[$gid]['subquestions'][$quid][$squid]['question'] = $subquestion->getQuestion();
						    $xmlDb[$gid]['subquestions'][$quid][$squid]['editable'] = $subquestion->getEditable();
						    $xmlDb[$gid]['subquestions'][$quid][$squid]['sorting'] = $subquestion->getSorting();
						    $xmlDb[$gid]['subquestions'][$quid][$squid]['optional'] = $subquestion->getOptional();
						    $xmlDb[$gid]['subquestions'][$quid][$squid]['title'] = $title;
					      }
					}
				  }
				    
			      }
			  }
		    }
		    return array('survey' => $t3Db , 'question' => $xmlDb);
	}
	    
	/**
	 * stringToMinimalCharset
	 * transforms a given string to a string with a small range of chars
	 *
	 * @param string $value
	 * @param int $words if not empty then only the given amount of words is returned
	 * @return string
	 */
	public function stringToMinimalCharset( $value , $words = 0 ){ 
	      if($words){
		    $aVal = explode(' ',$value);
		    $lCvalue = strtolower( implode(' ' , array_slice( $aVal , 0 , $words ) ) );
	      }else{
		    $lCvalue = strtolower($value);
	      }

	      for( $strOut = '', $p=0 ; $p < strlen($lCvalue); ++$p ){
		  $char = substr( $lCvalue , $p , 1 );
		  if( ord( $char ) >=97 && ord( $char ) <=122 ) $strOut .= $char;
	      }
	      
	      return substr( $strOut , 0 , 18 );
	      
	}
	    
	/**
	 * wrapValueAsCdata
	 *
	 * @param string $value
	 * @return string
	 */
	public function wrapValueAsCdata( $value ){ 
	      return $this->wrapValueAsCdata ? '<![CDATA['.$value. ']]>' : $value;
	}
	

	/**
	  * repairMacCharset
	  *
	  * @param string $string
	  * @return void
	  */
	public function repairMacCharset( $string ){
		$rp = array(
		    '–'=> '-' ,
		    '’'=> "'" ,
		    'a\u0308'=> 'ä' ,
		    'o\u0308' => 'ö' ,
		    'u\u0308' => 'ü' ,   
		    'A\u0308' => 'Ä' ,   
		    'O\u0308' => 'Ö' ,   
		    'U\u0308' => 'Ü'
		);
		return str_replace( array_keys($rp) , $rp , $string );
	}
	
	/**
	 * questionsFieldToArray
	 * store quesions-number in editableQuestions
	 *
	 * @param string $questionsFieldValue
	 * @return void
	 */
	public function questionsFieldToArray($questionsFieldValue ) {
		$aGroups = array();
		$aSortGroups = array();
		$xmlDb = json_decode( $questionsFieldValue , true);
		if(!count($xmlDb)) return array();
		foreach($xmlDb as $gid=>$grp){
		      $gSort = $grp['groups']['sorting'];
		      $aGroups[$gSort.'.'.$gid]['group'] = $grp['groups'];
		      $aGroups[$gSort.'.'.$gid]['group']['reportPartials'] = $this->deflateOptionGroupValue( $grp['groups']['report_partials'] , 4 );
		      foreach($grp['questions'] as $qid=>$quest){
			    
			    if( !count($grp['subquestions'][$qid]) ) continue; // questions are already included
			    $qSort = $quest['sorting'];
			    if( isset($quest['subquestions']) ) unset($quest['subquestions']);// guess it does not exist anyway
			    $aAnswers = explode( ';' , $quest['answers'] );
			    $aSubquestAnswers = array();
			    foreach($aAnswers as $anspair){
				$ans = explode( '=' , $anspair );
				$aSubquestAnswers[] = $ans[0];
			    }
			    $aGroups[$gSort.'.'.$gid]['questions'][$qSort.'.'.$qid] =  $quest;
			    // if type == matrix loop origin assessments
			    if( 3 == $quest['question_type'] && is_array($grp['answers'][$qid]) ) {
				  // if spider activated set options for self-assessment
				  if( $aGroups[$gSort.'.'.$gid]['group']['reportPartials'][4] == 4){
					$aGroups[$gSort.'.'.$gid]['questions'][$qSort.'.'.$qid]['assessments'] = $this->granulateAssessmentOptions( $grp['answers'][$qid] , 1);
				  }
				  foreach( $grp['answers'][$qid] as $oAss){
					$aGroups[$gSort.'.'.$gid]['questions'][$qSort.'.'.$qid]['originassessments'][ $oAss['code'] ] =  $oAss ;
				  }
			    }
			    $aGroups[$gSort.'.'.$gid]['questions'][$qSort.'.'.$qid]['answers'] =  implode(', ',$aSubquestAnswers);
			    $aGroups[$gSort.'.'.$gid]['questions'][$qSort.'.'.$qid]['question_width'] = empty($aGroups[$gSort.'.'.$gid]['questions'][$qSort.'.'.$qid]['question_width']) ? '100%' : $aGroups[$gSort.'.'.$gid]['questions'][$qSort.'.'.$qid]['question_width'] . 'ex';
			    foreach($grp['subquestions'][$qid] as $sqid=>$subquest){
				    // value for question type text-arera is in (first) subquestion!
				    if($quest['question_type'] == 1){
					  $aGroups[$gSort.'.'.$gid]['questions'][$qSort.'.'.$qid]['question'] = $subquest['question'];
				    }
				    $aGroups[$gSort.'.'.$gid]['questions'][$qSort.'.'.$qid]['subquestions'][$subquest['sorting'].'.'.$sqid] = $subquest;
				    $aGroups[$gSort.'.'.$gid]['questions'][$qSort.'.'.$qid]['subquestions'][$subquest['sorting'].'.'.$sqid]['checked'] = !empty($subquest['question']) ? 1 : 0;
			    }
		      }
		}
		if(count($aGroups)){
		    ksort($aGroups);
		    foreach($aGroups as $id=>$group){
			$aSortGroupsGid = $aGroups[$id]['group']['gid'];
			$aSortGroups[$aSortGroupsGid] = $aGroups[$id]['group'];
			$aSortGroups[$aSortGroupsGid]['editableQuestions'] = 0;
			if(is_array($aGroups[$id]['questions'])){
			    ksort($aGroups[$id]['questions']);
			    foreach($aGroups[$id]['questions'] as $qid=>$quests){
				if(
				    is_array($aGroups[$id]['questions'][$qid]['subquestions']) ||
				    $this->settings['empty_subquests'][ $quests['question_type'] ]
				){
				    $aSortGroups[$aSortGroupsGid]['questions'][$quests['title']] = $aGroups[$id]['questions'][$qid] ;
				    unset($aSortGroups[$aSortGroupsGid]['questions'][$quests['title']]['subquestions']);
				    if(is_array($aGroups[$id]['questions'][$qid]['subquestions'])){
					ksort($aGroups[$id]['questions'][$qid]['subquestions']);
					foreach($aGroups[$id]['questions'][$qid]['subquestions'] as $subQid=>$subQuest){
					      if( empty($subQuest['question']) && !$subQuest['editable'] ) continue;
					      $aSortGroups[$aSortGroupsGid]['questions'][$quests['title']]['subquestions'][ $subQuest['title'] ] = $subQuest;
					      $aSortGroups[$aSortGroupsGid]['editableQuestions'] += $subQuest['editable'] ? 1 : 0;
					}
				    }
				}
			    }
			}
		    }
		}
		return $aSortGroups;
	}
	
	/**
	 * deflateOptionGroupValue
	 *
	 * @param int $optionValue
	 * @param int $maxOptionValue
	 * @return void
	 */
	public function deflateOptionGroupValue( $optionValue , $maxOptionValue = 8 ) {
	      $reportPart = array();
	      for( $actOptionValue = $maxOptionValue ; $actOptionValue >= 1 ; $actOptionValue = floor( $actOptionValue / 2) ){
		    if( $optionValue >= $actOptionValue ){
			  $reportPart[ $actOptionValue ] = $actOptionValue;
			  $optionValue -= $actOptionValue;
		    }else{
			  $reportPart[ $actOptionValue ] = 0;
		    }
	      }
	      ksort($reportPart);
	      return $reportPart;
	}
	
	/**
	 * granulateAssessmentOptions
	 *
	 * @param array $options
	 * @param int $additionalSteps
	 * @return void
	 */
	public function granulateAssessmentOptions( $options , $additionalSteps = 1 ) {
	      $ass = array();
	      $ix = 0;
	      $last = count($options);
	      // FIXME display percent instead of values
	      foreach($options as $code => $assRow) {
		    $valList[] = $assRow['assessment_value']-1;
	      }
	      $maxVal = max($valList)/100;
	      foreach($options as $code => $assRow) {
		    ++$ix;
		    $key = $assRow['assessment_value']*10;
		    $key2 = $assRow['assessment_value']*10-5;
		    $value = round(($assRow['assessment_value']-1)/$maxVal,1).'% '.$assRow['answer'];
		    $value2 = round(($assRow['assessment_value']-1.5)/$maxVal,1).'% ';
		    $ass[ $key ] = array( 'assessment_value'=>$key , 'answer'=> $value  );
		    if( $ix != $last ) $ass[ $key2 ] = array( 'assessment_value'=>$key2 , 'answer'=>$value2 );
	      }
	      return $ass;
	}
	
}

