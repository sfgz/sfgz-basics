<?php
namespace Mff\MffLsb\Task;

 /** 
 * Class MailTask
 * look up if a mail job is open
 * sends the Email if trigger is on
 * 
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */
 
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Scheduler\Task\AbstractTask;
 
/**
 * PeriodTask class for the Scheduler
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 * @package TYPO3
 * @subpackage tx_mfflsb
 */
class PeriodTask extends AbstractTask {
	
	/**
	* initiate
	*
	* @return void
	*/
	public function initiate() {
			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$flashMessageService = $this->objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
			$this->messageQueue = $flashMessageService->getMessageQueueByIdentifier();
	}

	public function execute(){
	    $this->initiate();
	    $success = FALSE;
	    
        $calendarService = new \Mff\MffLsb\Service\PeriodService();
        
        $datBeginn = new \DateTime( date('Y-m-d') . "-10 year" );
        $futureMonths = 144;
	    $answer = $calendarService->addPeriodToRepository( $datBeginn->format('Y-m-d') , $futureMonths );

	    $message = GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
		    $answer ,
		    'Datenbank-Abfrage Ausgeführt', 
		    \TYPO3\CMS\Core\Messaging\FlashMessage::INFO
	    );

	    $this->messageQueue->addMessage($message);
	    
	    $success = TRUE;
	    return $success;
	}
	

}

