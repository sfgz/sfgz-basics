<?php
namespace Mff\MffLsb\Task;

 /** 
 * Class MailTask
 * look up if a mail job is open
 * sends the Email if trigger is on
 * 
 * 
 */
 
use Mff\MffLsb\Utility\DeleteOldSurveysUtility;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Scheduler\Task\AbstractTask;
 
class DeleteTask extends AbstractTask {
	
	/**
	* userSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\UserSurveyRepository
	*/
	protected $userSurveyRepository = null;

	/**
	 * deleteOldSurveysUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $deleteOldSurveysUtility = NULL;

	/**
	* initiate
	*
	* @return void
	*/
	public function initiate( ) {
			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$flashMessageService = $this->objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
			$this->messageQueue = $flashMessageService->getMessageQueueByIdentifier();
			$this->deleteOldSurveysUtility = GeneralUtility::makeInstance(\Mff\MffLsb\Utility\DeleteOldSurveysUtility::class);
	}

	public function execute(){
	    $this->initiate();
	    $success = FALSE;
	    
	    $objListDelete = $this->deleteOldSurveysUtility->deleteOldSurveysNow( );
	    
	    // create flashMessage
	    $plur = $objListDelete == 1 ? 'Umfrage wurde' : 'Umfragen wurden';
	    $message = GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
		    $objListDelete . ' alte ' . $plur . ' gelöscht. ',
		    'Gelöscht', 
		    empty($objListDelete) ? \TYPO3\CMS\Core\Messaging\FlashMessage::INFO : \TYPO3\CMS\Core\Messaging\FlashMessage::OK
	    );
	    $this->messageQueue->addMessage($message);
	    
	    $success = TRUE;
	    return $success;
	}

}
