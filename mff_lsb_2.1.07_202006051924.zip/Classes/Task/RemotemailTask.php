<?php
namespace Mff\MffLsb\Task;

 /** 
 * Class MailTask
 * look up if a mail job is open
 * sends the Email if trigger is on
 * 
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */
 
use Mff\MffLsb\Utility\MailDaemonUtility;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Scheduler\Task\AbstractTask;
 
/**
 * RemotemailTask class for the Scheduler
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 * @package TYPO3
 * @subpackage tx_mfflsb
 */
class RemotemailTask extends AbstractTask {

    /**
     * @var string Name of the message to mail ("all" for all services)
     */
    public $service;

	/**
	 * mailDaemonUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $mailDaemonUtility = NULL;
	
	/**
	* initiate
	*
	* @return void
	*/
	public function initiate() {
			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$flashMessageService = $this->objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
			$this->messageQueue = $flashMessageService->getMessageQueueByIdentifier();
			$this->mailDaemonUtility = GeneralUtility::makeInstance(MailDaemonUtility::class);
	}

	public function execute(){
	    $this->initiate();
	    $success = FALSE;
	    $result = 0;
 	    $mailJobs = $this->mailDaemonUtility->evaluateMailJobs( $this->service );
	    
	    // create flashMessage
        $info = $GLOBALS['LANG']->sL('LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:scheduler.mail_daemon.field.'.$this->service);
	    $message = GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
		    $mailJobs . ' Email(s) wurden gesendet,  service: '.$info,
		    'Gesendet', 
		    \TYPO3\CMS\Core\Messaging\FlashMessage::INFO
	    );
	    $this->messageQueue->addMessage($message);
	    
	    $success = TRUE;
	    return $success;
	}

    /**
     * This method returns the synchronized service and index as additional information
     *
     * @return    string    Information to display
     */
    public function getAdditionalInformation()
    {
        $info = $GLOBALS['LANG']->sL('LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:scheduler.mail_daemon.field.'.$this->service);
        return $info;
    }
	

}
