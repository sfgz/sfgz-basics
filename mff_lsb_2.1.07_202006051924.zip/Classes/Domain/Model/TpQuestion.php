<?php
namespace Mff\MffLsb\Domain\Model;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * TpQuestion
 */
class TpQuestion extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * tpgroup
     *
     * @var int
     */
    protected $tpgroup = 0;
    
    /**
     * question
     *
     * @var string
     */
    protected $question = '';

    /**
     * hideTitle
     *
     * @var bool
     */
    protected $hideTitle = false;

    /**
     * mandatory
     *
     * @var bool
     */
    protected $mandatory = false;

    /**
     * questionType
     *
     * @var int
     */
    protected $questionType = 0;

    /**
     * questionWidth
     *
     * @var int
     */
    protected $questionWidth = 70;

    /**
     * reportHideHeader
     *
     * @var bool
     */
    protected $reportHideHeader = false;

    /**
     * answers answer1=value1;answer2=value2
     *
     * @var string
     */
    protected $answers = '';

    /**
     * sorting
     *
     * @var int
     */
    protected $sorting = 0;

    /**
     * tpQuestionSubquestion
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffLsb\Domain\Model\TpSubquestion>
     * @cascade remove
     */
    protected $tpQuestionSubquestion = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->tpQuestionSubquestion = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the tpgroup
     *
     * @return int $tpgroup
     */
    public function getTpgroup()
    {
        return $this->tpgroup;
    }

    /**
     * Sets the tpgroup
     *
     * @param int $tpgroup
     * @return void
     */
    public function setTpgroup($tpgroup)
    {
        $this->tpgroup = $tpgroup;
    }

    /**
     * Returns the question
     *
     * @return string $question
     */
    public function getQuestion()
    {
        return $this->question;
    }

    /**
     * Sets the question
     *
     * @param string $question
     * @return void
     */
    public function setQuestion($question)
    {
        $this->question = $question;
    }

    /**
     * Returns the hideTitle
     *
     * @return bool $hideTitle
     */
    public function getHideTitle()
    {
        return $this->hideTitle;
    }

    /**
     * Sets the hideTitle
     *
     * @param bool $hideTitle
     * @return void
     */
    public function setHideTitle($hideTitle)
    {
        $this->hideTitle = $hideTitle;
    }

    /**
     * Returns the boolean state of hideTitle
     *
     * @return bool
     */
    public function isHideTitle()
    {
        return $this->hideTitle;
    }

    /**
     * Returns the mandatory
     *
     * @return bool $mandatory
     */
    public function getMandatory()
    {
        return $this->mandatory;
    }

    /**
     * Sets the mandatory
     *
     * @param bool $mandatory
     * @return void
     */
    public function setMandatory($mandatory)
    {
        $this->mandatory = $mandatory;
    }

    /**
     * Returns the boolean state of mandatory
     *
     * @return bool
     */
    public function isMandatory()
    {
        return $this->mandatory;
    }

    /**
     * Returns the questionType
     *
     * @return int $questionType
     */
    public function getQuestionType()
    {
        return $this->questionType;
    }

    /**
     * Sets the questionType
     *
     * @param int $questionType
     * @return void
     */
    public function setQuestionType($questionType)
    {
        $this->questionType = $questionType;
    }

    /**
     * Returns the reportHideHeader
     *
     * @return bool $reportHideHeader
     */
    public function getReportHideHeader()
    {
        return $this->reportHideHeader;
    }

    /**
     * Sets the reportHideHeader
     *
     * @param bool $reportHideHeader
     * @return void
     */
    public function setReportHideHeader($reportHideHeader)
    {
        $this->reportHideHeader = $reportHideHeader;
    }

    /**
     * Returns the boolean state of reportHideHeader
     *
     * @return bool
     */
    public function isReportHideHeader()
    {
        return $this->reportHideHeader;
    }

    /**
     * Returns the questionWidth
     *
     * @return int $questionWidth
     */
    public function getQuestionWidth()
    {
        return $this->questionWidth;
    }

    /**
     * Sets the questionWidth
     *
     * @param int $questionWidth
     * @return void
     */
    public function setQuestionWidth($questionWidth)
    {
        $this->questionWidth = $questionWidth;
    }

    /**
     * Returns the answers
     *
     * @return string $answers
     */
    public function getAnswers()
    {
        return $this->answers;
    }

    /**
     * Sets the answers
     *
     * @param string $answers
     * @return void
     */
    public function setAnswers($answers)
    {
        $this->answers = $answers;
    }

    /**
     * Returns the sorting
     *
     * @return string $sorting
     */
    public function getSorting()
    {
        return $this->sorting;
    }

    /**
     * Sets the sorting
     *
     * @param string $sorting
     * @return void
     */
    public function setSorting($sorting)
    {
        $this->sorting = $sorting;
    }

    /**
     * Adds a TpSubquestion
     *
     * @param \Mff\MffLsb\Domain\Model\TpSubquestion $tpQuestionSubquestion
     * @return void
     */
    public function addTpQuestionSubquestion(\Mff\MffLsb\Domain\Model\TpSubquestion $tpQuestionSubquestion)
    {
        $this->tpQuestionSubquestion->attach($tpQuestionSubquestion);
    }

    /**
     * Removes a TpSubquestion
     *
     * @param \Mff\MffLsb\Domain\Model\TpSubquestion $tpQuestionSubquestionToRemove The TpSubquestion to be removed
     * @return void
     */
    public function removeTpQuestionSubquestion(\Mff\MffLsb\Domain\Model\TpSubquestion $tpQuestionSubquestionToRemove)
    {
        $this->tpQuestionSubquestion->detach($tpQuestionSubquestionToRemove);
    }

    /**
     * Returns the tpQuestionSubquestion
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffLsb\Domain\Model\TpSubquestion> $tpQuestionSubquestion
     */
    public function getTpQuestionSubquestion()
    {
        return $this->tpQuestionSubquestion;
    }

    /**
     * Sets the tpQuestionSubquestion
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffLsb\Domain\Model\TpSubquestion> $tpQuestionSubquestion
     * @return void
     */
    public function setTpQuestionSubquestion(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $tpQuestionSubquestion)
    {
        $this->tpQuestionSubquestion = $tpQuestionSubquestion;
    }
}
