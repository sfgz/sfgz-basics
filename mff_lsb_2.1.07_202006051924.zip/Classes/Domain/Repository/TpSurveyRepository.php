<?php
namespace Mff\MffLsb\Domain\Repository;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * The repository for TpSurveys
 */
class TpSurveyRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {

	/**
	* @var array
	*/
	protected $defaultOrderings = array(
	    'sorting' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
	);
	
	/**
	* initialize querySettings
	*/
	public function initializeObject() {
		  $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		  $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		  //Disable Storage pid
		  $querySettings->setRespectStoragePage(FALSE);
		  $querySettings->setIgnoreEnableFields(TRUE);
		  $this->setDefaultQuerySettings($querySettings);
		  // Get Hidden and Deleted Records not working: $querySettings->getQuerySettings()->setIgnoreEnableFields(true);
	}
	
	/**
	*  Find by pattern 'sPidList'
	* 
	* @param string $sPidList pids separed by commas
	* @param bool $ReturnRawQueryResult returns an array instead of an object if set to true
	* @param bool $IgnoreEnableFields returns also hidden and deleted records if set to true
	* @return void
	*/
	public function findByPidS( $sPidList , $ReturnRawQueryResult = false , $IgnoreEnableFields = false ) {
	    $query = $this->createQuery();
	    
	    $query->getQuerySettings()->setIgnoreEnableFields($IgnoreEnableFields);
	    $query->getQuerySettings()->setRespectStoragePage(FALSE); // not workin in function initializeObject()
	    
	    $aPids = explode( ',' , $sPidList );
	    if($IgnoreEnableFields){
		  foreach($aPids as $pid){
			  $constraints[] = $query->equals('pid', trim($pid) );
		  }
	    }else{
		  foreach($aPids as $pid){
			  $constraints[] = $query->logicalAnd(
			      array( 
				    $query->equals('pid', trim($pid) ),
				    $query->equals('versteckt', 0 )
			      ) 
			  );
		  }
	    }
	    
	    $query->matching(
		    $query->logicalOr($constraints)
	    );
	    
	    $query->setOrderings(
		array(
		    'sorting' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
		)
	    );
	    return $query->execute($ReturnRawQueryResult);
	}
	  
}
