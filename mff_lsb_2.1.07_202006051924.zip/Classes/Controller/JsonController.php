<?php
namespace Mff\MffLsb\Controller;

/**
 * JsonController
 */
class JsonController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	* @var string
	*/
	protected $defaultViewObjectName = 'TYPO3\CMS\Extbase\Mvc\View\JsonView';
	
	/**
	 * frontendUserRepository
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository
	 * @inject
	 */
	protected $frontendUserRepository = NULL;

	/**
	* @var array
	*/
	protected $foreignSettings = array();

	/**
	  * initializeAction
	  *
	  */
	public function initializeAction() {
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
 	      $this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $fullsettings = $this->configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $teacherStorage['teacherPid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];

	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setRespectStoragePage(FALSE);
	      $querySettings->setStoragePageIds( $teacherStorage );
	      
	      $this->frontendUserRepository = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Domain\\Repository\\FrontendUserRepository');
	      $this->frontendUserRepository->setDefaultQuerySettings( $querySettings );
	}

	/**
	* Action update
	* replaces values in xml-fields with db-values or values from TypoScript
	* returns a copy of the survey-object
	*
	* @return void
	*/
	public function updateAction(){
	    $updateTable = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST('table');
	    $useroptions = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST($updateTable);
	    
	    if(empty($updateTable)){ return 'no table'; return false; }
	    
	    switch($updateTable){
	    
			case 'useroptions':
				$userObj = $GLOBALS['TSFE']->fe_user;
				if( $userObj && is_array($useroptions) ){
					$settings_useroptions = $userObj->getKey('user', 'useroptions');
					foreach($useroptions as $field => $value){
						$settings_useroptions[$field] = $value;
					}
					$userObj->setKey("user","useroptions", $settings_useroptions);
					$userObj->sesData_change = true;
					$userObj->storeSessionData();
				}
				return 'ok: ' . array_keys($settings_useroptions);
			break;
			
	    }
	    
	    return 'not ok';
	}

	/**
	* Action show
	* replaces values in xml-fields with db-values or values from TypoScript
	* returns a copy of the survey-object
	*
	* @return void
	*/
	public function showAction(){
	    $templateUid = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('uid');
	    if(empty($templateUid)) return false;
	    
	    $templateDataUtility = new \Mff\MffLsb\Utility\TemplateDataUtility();
 	    $xmlDb = $templateDataUtility->showObjectData( $templateUid );
	    if(!is_array( $xmlDb )) return false;
	    $this->foreignSettings = $templateDataUtility->getSettings();
	    
	    return  $this->arrayAsHtml( $xmlDb ) ;
	}
	    
	/**
	 * arrayAsHtml
	 *
	 * @param array $xmlDb
	 * @return string
	 */
	public function arrayAsHtml( $xmlDb ){
	
		$outStr = '';
		$edLab = array(  false=> '<i>[bearbeitbar]</i> ', true=>'<i>+ [leer] [bearbeitbar]</i> '  );
		$hidden = array(  false=>'' , true=>' <i>[Titel versteckt]</i>' );
		$optLab = array(  false=>'' , true=>'<i>[optional]</i> ' );
		$obsoleteCss = array( false=>'' , true=>' class="obsolete"' );
		$listDecor = array( false => '' , true => '-' );

	    foreach($xmlDb['question'] as $gid=>$grp){
		    $outStr .= '<h1>'.$grp['groups']['group_name']."</h1>\n";
		    $outStr .= '<div style="padding:3px 5px;">';
		    foreach($xmlDb['question'][ $gid ]['questions'] as $qid=>$quest){
				
				$strAnswers = $this->drawQuestionInfo( $xmlDb['question'][ $gid ] , $qid );
				$outStr .= '<p><b>'.$quest['question'].'</b>'.$hidden[$quest['hide_title']].$strAnswers.'<br />'."\n";
				
				if(is_array($xmlDb['question'][ $gid ]['subquestions'][$qid])){
					foreach($xmlDb['question'][ $gid ]['subquestions'][$qid] as $sqid=>$subquest){
						$editableTxt = $subquest['editable'] ? $edLab[empty($subquest['question'])] : '';
						$outStr .= '<span'.$obsoleteCss[ $subquest['optional']==1 && $subquest['editable']==1 ].'>'.$listDecor[ 3 == $quest['question_type'] ].'  '.$subquest['question'].' '. $editableTxt  . $optLab[ $subquest['optional'] ] . "</span><br />\n";
					}
				}
				$outStr .= '</p>';
		    }
		    $outStr .= '</div>';
		}
		
		return '<div class="preview">' . $outStr . '</div>';
		
// 	    ob_start();
// 	    print_r($xmlDb);
// 	    $output = ob_get_clean();
// 		return '<pre>'.$output.'</pre><div class="preview">' . $outStr . '</div>';
	}
	    
	/**
	 * drawQuestionInfo
	 * part of mathos arrayAsHtml()
	 *
	 * @param array $xmlDb
	 * @param in $qid
	 * @return string
	 */
	public function drawQuestionInfo( $xmlGroup , $qid ){
			if( !$this->foreignSettings['show_questiontype_in_preview'] ) return;
			$qTypes = array( 1 => 'mehrzeiliger Text' , 2 => 'Texte' , 3 => 'Matrixfragen' );
			$quest = $xmlGroup['questions'][$qid];
//			$strAnswers = 'Fragetyp ';
			$strAnswers = '';
			$strAnswers .= '&laquo;' . $qTypes[ $quest['question_type'] ] . '&raquo;';
			if( 3 == $quest['question_type'] ){
					$ansGrp = array();
					foreach($xmlGroup['answers'][$qid] as $ansRecord){ $ansGrp[] = $ansRecord['answer']; }
					$strAnswers .= ', Antworten: ' . implode( ' / ' , $ansGrp );
			}
			return ' <i style="color:#3A5;white-space:nowrap;width:auto;overflow:visible;">' . str_replace( ' ' , '&nbsp;' , $strAnswers) . '</i>';
	}
}
