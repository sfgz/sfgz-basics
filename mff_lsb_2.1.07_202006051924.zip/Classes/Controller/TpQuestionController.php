<?php
namespace Mff\MffLsb\Controller;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * TpQuestionController
 */
class TpQuestionController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * tpQuestionRepository
     *
     * @var \Mff\MffLsb\Domain\Repository\TpQuestionRepository
     * @inject
     */
    protected $tpQuestionRepository = null;
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $tpQuestions = $this->tpQuestionRepository->findAll();
        $this->view->assign('tpQuestions', $tpQuestions);
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {

    }

    /**
     * action create
     *
     * @param \Mff\MffLsb\Domain\Model\TpQuestion $newTpQuestion
     * @return void
     */
    public function createAction(\Mff\MffLsb\Domain\Model\TpQuestion $newTpQuestion)
    {
        $this->addFlashMessage('The object was created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->tpQuestionRepository->add($newTpQuestion);
        $this->redirect('list');
    }

    /**
     * action edit
     *
     * @param \Mff\MffLsb\Domain\Model\TpQuestion $tpQuestion
     * @return void
     */
    public function editAction(\Mff\MffLsb\Domain\Model\TpQuestion $tpQuestion)
    {
        $this->view->assign('tpQuestion', $tpQuestion);
        $pageType = 0;
        if($this->request->hasArgument('pageType')){
	      $pageType=$this->request->getArgument('pageType');
        }else{
	      $pageType = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('type');
        }
        $this->view->assign('pageType', $pageType);
	$contentUid = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('cnt');
        if($contentUid) $this->view->assign('contentUid', $contentUid );
        if($this->request->hasArgument('sid')){
	      $this->view->assign('sid',$this->request->getArgument('sid') );
        }
    }

    /**
     * action update
     *
     * @param \Mff\MffLsb\Domain\Model\TpQuestion $tpQuestion
     * @return void
     */
    public function updateAction(\Mff\MffLsb\Domain\Model\TpQuestion $tpQuestion)
    {
        $this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->tpQuestionRepository->update($tpQuestion);
//         $this->redirect('list');
	$pageType = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('type');
        if( $pageType != 95 ) $this->redirect('list');
	$forwardingArguments['tpQuestion'] = $tpQuestion;
	$forwardingArguments['pageType'] = $pageType;
//         if($this->request->hasArgument('sid')){
// 	    $forwardingArguments['tpSurvey'] = $this->request->getArgument('sid');
// 	    $this->forward('edit', 'TpSurvey', 'MffLsb', $forwardingArguments);
//         }
	$this->forward('edit', NULL, NULL, $forwardingArguments);
    }

    /**
     * action delete
     *
     * @param \Mff\MffLsb\Domain\Model\TpQuestion $tpQuestion
     * @return void
     */
    public function deleteAction(\Mff\MffLsb\Domain\Model\TpQuestion $tpQuestion)
    {
        $this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->tpQuestionRepository->remove($tpQuestion);
        $this->redirect('list');
    }
}
