<?php
namespace Mff\MffLsb\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * RemoteSurveyController
 */
class RemoteSurveyController extends \Mff\MffLsb\Controller\UserSurveyController
{
	/**
	* userSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\UserSurveyRepository
	* @inject
	*/
	protected $userSurveyRepository = null;

	/**
	* tpSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\TpSurveyRepository
	* @inject
	*/
	protected $tpSurveyRepository = null;

	/**
	* classtemplateRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\ClasstemplateRepository
	*/
	protected $classtemplateRepository = null;

	/**
	 * timetableRepository
	 *
	 * @var \SfGZ\SfgzPlan\Domain\Repository\TimetableRepository
	 */
	protected $timetableRepository = NULL;

	/**
	 * periodsRepository
	 *
	 * @var \Mff\MffLsb\Domain\Repository\PeriodsRepository
	 */
	protected $periodsRepository = NULL;
	
	/**
	 * frontendUserRepository
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository
	 */
	protected $frontendUserRepository = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;
    
    protected $objectManager ;
	
    public function initializeAction() {
		$this->initialize_basics();
		$this->initialize_useroptions();
		if( !$this->request->hasArgument('action') && $this->settings['startlayout'] == 2 )  $this->forward('list', NULL, NULL, array( 'action' => 'list' ) );
    }
	
    public function initialize_basics() {
	      date_default_timezone_set( 'Europe/Zurich' );
	      $this->GmtZone = new \DateTimeZone('GMT');
 	      $this->timeZone = new \DateTimeZone('Europe/Zurich');
	      
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
 	      $this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $this->contentObj = $this->configurationManager->getContentObject();
	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $templateStoragePid['templateStoragePid'] = $fullsettings['plugin.']['tx_mfflsb_template.']['persistence.']['storagePid'];
	      

	      if(!$this->settings['autoupdate_after_minutes'])$this->settings['autoupdate_after_minutes']=1;
	      
	      $this->settings['storagePid'] = $fullsettings['plugin.']['tx_mfflsb_remote.']['persistence.']['storagePid'];
	      
	      $this->settings['teacherPid'] = $fullsettings['plugin.']['tx_sfgzudb_edit.']['settings.']['teacherPid'];
	      
	      $this->settings['baseUrl'] = $fullsettings['config.']['baseURL'];
	      $this->settings['token'] = $fullsettings['plugin.']['tx_mfflsb_remote.']['settings.']['anonymous.']['token'];
	      
	      $userQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $userQuerySettings->setRespectStoragePage(FALSE);
	      $userQuerySettings->setStoragePageIds( array( $this->settings['storagePid'] ) );
	      $this->userSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\UserSurveyRepository');
	      $this->userSurveyRepository->setDefaultQuerySettings( $userQuerySettings );

	      $feUserQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $feUserQuerySettings->setRespectStoragePage(FALSE);
	      $feUserQuerySettings->setStoragePageIds( array($this->settings['teacherPid']) );
	      $this->frontendUserRepository = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Domain\\Repository\\FrontendUserRepository');
	      $this->frontendUserRepository->setDefaultQuerySettings( $feUserQuerySettings );
	      
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setRespectStoragePage(FALSE);
	      $querySettings->setStoragePageIds( $templateStoragePid );
	      $this->tpSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpSurveyRepository');
	      $this->tpSurveyRepository->setDefaultQuerySettings( $querySettings );
	      $this->classtemplateRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\ClasstemplateRepository');
	      $this->classtemplateRepository->setDefaultQuerySettings( $querySettings );

	      $storage['timetableStoragePid'] = $fullsettings['plugin.']['tx_sfgzplan_tt.']['persistence.']['storagePid'];
	      $storage['shortclassStoragePid'] = $fullsettings['plugin.']['tx_sfgzudb_edit.']['persistence.']['storagePid'];
	      $ttQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $ttQuerySettings->setRespectStoragePage(FALSE);
          // $ttQuerySettings->setStoragePageIds( $storage );
	      $this->timetableRepository = $this->objectManager->get('SfGZ\\SfgzPlan\\Domain\\Repository\\TimetableRepository');
	      $this->timetableRepository->setDefaultQuerySettings($ttQuerySettings);
	      
	      $this->kurzklasseRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\KurzklasseRepository');
	      $this->kurzklasseRepository->setDefaultQuerySettings($ttQuerySettings);
	      
	      $this->periodsRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\PeriodsRepository');
	      $this->periodsRepository->setDefaultQuerySettings($ttQuerySettings);
	      
    }
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction(){
	    $aPeriods = $this->periodsRepository->findByYearsPassed( $this->settings['semesterYearsPassed'] );
	    $this->view->assign('periods', $aPeriods );
	    
	    $period = $this->getUserChoosenPeriod( $aPeriods );
	    $this->view->assign('period', $period );
	    
	    // Send- Actions
	    $plural = array( true=>'e' , false=>'' );
	    $remoteSurvey = array(); 
	    $mailCopyCodes = array( 0 => '' , 1 => 'Cc' , 2 => 'Bcc' );
	    if( $this->request->hasArgument('sendLink') ){ // sendLink listAction from editform (submit-button)
			$surveyUid = $this->request->getArgument('sendLink');
			$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
			$mailStatus = $userSurvey->getMailState();
			$MailUtility = new \Mff\MffLsb\Utility\MailUtility();
			if($mailCopyCodes[ $this->settings['useroptions']['manualmailcopy'] ]) $MailUtility->interim[$mailCopyCodes[ $this->settings['useroptions']['manualmailcopy'] ]] = $GLOBALS['TSFE']->fe_user->user['email'];
			if( $mailStatus  <=2 ) {
					$success = $MailUtility->sendLinkAndUpdate( $userSurvey );
			}elseif( $mailStatus <=5 ){
					$success = $MailUtility->sendReminderAndUpdate( $userSurvey );
			}elseif( $mailStatus <=7 ){
					$success = $MailUtility->sendHandoutAndUpdate( $userSurvey );
			}elseif( $mailStatus ==8 ){
					$success = $MailUtility->sendPdfHandout( $userSurvey , $this->settings['mail']['printout_reminder_text'] );
			}
			if($success){
				$this->persistenceManager->persistAll();
				$this->addFlashMessage(  $success , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}else{
				$this->addFlashMessage(  'Link nicht gesendet!' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}
	    }elseif( $this->request->hasArgument('sendPdfData') ){
			$surveyUid = $this->request->getArgument('sendPdfData');
			$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
			$MailUtility = new \Mff\MffLsb\Utility\MailUtility();
			if($mailCopyCodes[ $this->settings['useroptions']['manualmailcopy'] ]) $MailUtility->interim[$mailCopyCodes[ $this->settings['useroptions']['manualmailcopy'] ]] = $GLOBALS['TSFE']->fe_user->user['email'];
			$success = $MailUtility->sendPdfData( $userSurvey );
			if($success){
				$this->addFlashMessage(  $success , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}else{
				$this->addFlashMessage(  'Email nicht gesendet!' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}
	    }
	    
	    // data actions
	    if( 
            $this->request->hasArgument('editSurvey')  && !$this->request->hasArgument('delete') 
	    ){ 
	    // updateAction from editform (submit-button)
			$editSurvey = $this->request->getArgument('editSurvey');
			$remoteSurvey = $this->l_EditUpdate($editSurvey);
	    }elseif( 
            $this->request->hasArgument('checkedSurvey')
        ){ 
        // update batchEditAction from checkboxes in list-form (submit-button)
			$editSurvey = $this->request->getArgument('checkedSurvey');
			$remoteSurvey = $this->l_BatchUpdate($editSurvey);
	    }elseif( 
            $this->request->hasArgument('userSurvey') && !$this->request->hasArgument('delete')  
	    ){ 
	    // editAction link in list
			$surveyUid =  $this->request->getArgument('userSurvey');
			if( $this->request->hasArgument('dupliz') ){
				$editSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
				$newRemoteSurvey = $this->duplicateSurvey( $editSurvey );
				$remoteSurvey = $this->l_EditorFillForm( $newRemoteSurvey->getUid() );
			}else{
				$remoteSurvey = $this->l_EditorFillForm($surveyUid);
			}
	    }elseif(
            $this->request->hasArgument('downloadReport')
	    ){ 
	    // editAction download link in list
			$surveyUid =  $this->request->getArgument('downloadReport');
			$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
			$this->updateSurveyFromApi($userSurvey);
			$this->persistenceManager->persistAll();
			$reportUtility = new \Mff\MffLsb\Utility\ReportPdfDataUtility( $this->settings );
			$reportData = $reportUtility->PDFDataForReports( $userSurvey  );
			if( !is_array($reportData) ) {
					$this->addFlashMessage(  'Keine Daten zum herunterladen gefunden!' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}else{
					$pdfUtility = new \Mff\MffLsb\Utility\PdfReportUtility( $this->settings );
					$pdfUtility->pdfReport( $reportData , 'D' ); 
			}
	    }elseif(
            $this->request->hasArgument('downloadPrintout')
	    ){ 
	    // editAction download link in list
			$surveyUid =  $this->request->getArgument('downloadPrintout');
			$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
			$reportUtility = new \Mff\MffLsb\Utility\ReportPdfDataUtility( $this->settings );
			$noData = false;
			$reportData = $reportUtility->PDFDataForPrintouts( $userSurvey , $noData  );
			$pdfUtility = new \Mff\MffLsb\Utility\PdfPrintoutUtility( $this->settings );
			$pdfUtility->pdfTemplate( $reportData ); // causes exit();
		}
	    
	    $userSurveys = $this->getSurveysList($period);
	    $enrichedUserSurveys = $this->l_enrichSurveysWithData($userSurveys , $remoteSurvey );
	    $this->view->assign('userSurveys', $enrichedUserSurveys);
	    
	    if ($this->request->hasArgument('download')) $this->l_downloadListAsExcel($enrichedUserSurveys);
	    
	    $data = $this->getFlexformData();
	    $this->view->assign('data', $data);
	    $this->view->assign('settings', $this->settings );
	    $this->view->assign('contentUid', $this->contentObj->data['uid'] );
    }


	/**
	* getSurveysList
	*
	* @param int $period
	* @return void
	*/
	Public function getSurveysList($period=0) {
	    if( !$period ){
		  $period = $this->getUserChoosenPeriod();
	    }
	    return $this->userSurveyRepository->findByPidAndSemesterUid( $this->settings['storagePid'] , $period );
	}
    
	/**
	* getUserChoosenPeriod
	*
	* @return void
	*/
	Private function getUserChoosenPeriod($aPeriods = null){
			if( !$aPeriods ) $aPeriods = $this->periodsRepository->findAll();
			$userObj = $GLOBALS['TSFE']->fe_user;
			if($this->request->hasArgument('period')){
				$period = $this->request->getArgument('period');
				if($userObj){
					$myData = $userObj->getKey('user', 'useroptions');
					$myData['period'] = $period;
					$userObj->setKey("user","useroptions", $myData);
					$userObj->sesData_change = true;
					$userObj->storeSessionData();
				}
			}else{
					if($userObj){
						$myData = $userObj->getKey('user', 'useroptions');
						if( $myData['period'] ) $period = $myData['period'] ;
					}
					if(!isset($period)){
						$jetzt = time();
						foreach( $aPeriods as $aPer) {
							if( $aPer->getDavorBis()->format('U') <= $jetzt && $aPer->getDanachAb()->format('U') >= $jetzt){
								$aktPeriode = $aPer; break;
							}
						}
						$period = ($aktPeriode) ? $aktPeriode->getUid() : 0;
					}
			}
			return $period;
	}
    
    /**
     * l_downloadListAsExcel
     *
     * @param array $enrichedUserSurveys
     * @return void
     */
    Private function l_downloadListAsExcel($enrichedUserSurveys){
  				if( !is_array( $enrichedUserSurveys ) ) return false;
  				$aMailstates = array( 0=>'nie Mail senden',1=>'Link senden',2=>'(sendend...)',3=>'Gesendet',4=>'(erinnernd...)',5=>'Erinnert',6=>'Kopiervorlage senden',7=>'(am Vorlage senden...)',8=>'Vorlage gesendet');
  				foreach($enrichedUserSurveys as $uid => $fs){
						if(!isset($fs['survey']))continue;
						$userSurvey = $fs['survey'];
						$oStartDate = $userSurvey->getStartDate();
						if($oStartDate) $uxStartDate = $oStartDate->format('U');
						$endDate = $uxStartDate + ( $userSurvey->getExpireDays() * (3600*24) );
						$dbPeriodUid = $userSurvey->getSemesterUid();
						$oPeriod = $this->periodsRepository->findByUid($dbPeriodUid);
						$semester = $oPeriod->getSemester();
						$userUid = $userSurvey->getUserUid();
						$oUser = $this->frontendUserRepository->findByUid($userUid);
						$adminName = trim($oUser->getFirstname() . ' ' . $oUser->getLastname());
						$objUpdated = $userSurvey->getResponsesUpdated();
						$dateUpdated = $objUpdated ? $objUpdated->format('d.m.Y') : '';
						$startDatum = !empty($uxStartDate) ? date('d.m.Y',$uxStartDate):'';
						$endDatum = !empty($endDate) ? date('d.m.Y',$endDate):'';
						$sortStartDatum = !empty($uxStartDate) ? date('ymd',$uxStartDate):'';
						$sortEndDatum = !empty($endDate) ? date('ymd',$endDate):'';
						$sortAbgerufen = $objUpdated ? $objUpdated->format('ymd') : '';
						$mailState = $userSurvey->getMailState();
						$anlaesseGefilter[] = array(
								'surveyUid' => $userSurvey->getSurveyUid() ,
								'mailStatus'=> $aMailstates[ $mailState ],
								'Antworten'=> $userSurvey->getResponsesCount(),
								'abgerufenAm'=> $dateUpdated,
								'startDatum'=> $startDatum,
								'endDatum'=> $endDatum,
								'nameDozent'=> $userSurvey->getEnquirerName(),
								'emailDozent' => $userSurvey->getEnquirerEmail(),
								'Kurs'=> $userSurvey->getCourseName(),
								'Fach'=> $userSurvey->getSubject(),
								'Semester'=>$semester,
								'Admin'=>$adminName,
								'sortMailStatus'=> $mailState,
								'sortStart'=> $sortStartDatum,
								'sortEnd'=> $sortEndDatum,
								'sortAbgerufen'=> $sortAbgerufen,
								'uid' => $userSurvey->getUid() , 
						);
  				}
  				if( !count( $anlaesseGefilter ) ) return false;
				$downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
				$downloader->downloadAsXls( array('Umfragen'=>$anlaesseGefilter), 'Umfragen_' . date('ymd_Hi') . '.xlsx');
				return;
    }
    
    /**
     * l_getTacherList
     *
     * @return void
     */
    Private function l_getTacherList(){
	    $objBearbeiter = $this->frontendUserRepository->findByPid( $this->settings['teacherPid'] );
	    $aBearbeiter = [];
	    foreach( $objBearbeiter  as $objUser ){
		    $firstName = $objUser->getFirstName();
		    $lastName = $objUser->getLastName();
		    $aBearbeiter[$objUser->getEmail()] = trim( $lastName . ' ' . $firstName );
	    }
	    asort($aBearbeiter);
	    return $aBearbeiter;
    }

    /**
     * l_getInvitationSenderAdressByUserSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
     * @param boolean $asString optional, default returns object or array
     * @return void
     */
    Private function l_getInvitationSenderAdressByUserSurvey($userSurvey , $asString = false ){
		// from TsConf
		$clearEmail = $this->settings['mail']['fix_invitation_from'];
		if( $this->settings['mail']['use_fix_invitation'] && filter_var($clearEmail, FILTER_VALIDATE_EMAIL) ){
				$emailBearbeiter = $asString ? $clearEmail : array( 'email' => $clearEmail );
				return $emailBearbeiter;
		}
		
		// from recordset userSurvey
		if($userSurvey) {
			$userUid = $userSurvey->getUserUid();
			if( $userUid ) $feUserObj = $this->frontendUserRepository->findByUid($userUid);
			if( $feUserObj ){
				$clearEmail = $feUserObj->getEmail();
				$emailBearbeiter = $asString ? $clearEmail : $feUserObj;
				if( filter_var( $clearEmail , FILTER_VALIDATE_EMAIL) ) return $emailBearbeiter;
			}
		}
		
		$clearEmail = $this->settings['mail']['sender_adress'];
		$emailBearbeiter = $asString ? $clearEmail : array( 'email' => $clearEmail );
		if( filter_var( $clearEmail , FILTER_VALIDATE_EMAIL) ) return $emailBearbeiter;
		
		return false;
    }
    
    /**
     * l_EditorFillForm
     *
     * @param int $surveyUid
     * @return void
     */
    Private function l_EditorFillForm($surveyUid){
	    if( !$surveyUid ) return array();
	    
	    $remoteSurvey['chk'][$surveyUid] = 1;
	    
	    if($this->request->hasArgument('abort'))return $remoteSurvey;
	    
		$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
		
		$emailBearbeiter = $this->l_getInvitationSenderAdressByUserSurvey($userSurvey);
		
		$this->view->assign('userSurvey', $userSurvey);
		$this->view->assign('bearbeiter' , $this->l_getTacherList() );
		$this->view->assign('emailBearbeiter' , $emailBearbeiter );
		$this->view->assign('manualdate' , $this->l_getDatesFromTimespan($userSurvey) );
		$this->view->assign('md5RemoteKey' , md5($userSurvey->getRemoteKey()) );
	    return $remoteSurvey;
		
		$toRefresh = $this->isUpdateAffored($userSurvey, true); // $this->settings['autoupdate_after_minutes'] must be > 0
		if( $toRefresh ) $this->updateSurveyFromApi($userSurvey);
	    return $remoteSurvey;
    }
    
    /**
     * l_getDatesFromTimespan
     *
     * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
     * @return void
     */
    Private function l_getDatesFromTimespan($userSurvey){
		  $dtTo = new \DateTime($userSurvey->getStartDate()->format('Y-m-d'));
		  $dtTo->add(new \DateInterval('P'.$userSurvey->getExpireDays().'D'));
		  $dtRemote = new \DateTime($dtTo->format('Y-m-d'));
		  $dtRemote->add(new \DateInterval('P'.$userSurvey->getRemoteDays().'D'));
		  $aSurveys = array(
		      'endDate'=>$dtTo->format('U'),
		      'remoteDate'=>$dtRemote->format('U')
		  );
		  return $aSurveys;
    }
    
    /**
     * l_BatchUpdate
     *
     * @param array $editSurvey
     * @return void
     */
    Private function l_BatchUpdate($editSurvey){
	    if( !is_array($editSurvey['chk']) ) return array();
	    $dateField = array( 'startDate'=>1 , 'deletionDate'=>1 );
	    $plural = array( true=>'e' , false=>'' );
	    foreach($editSurvey['chk'] as $surveyUid=>$sel) if( $sel ) $remoteSurvey['chk'][$surveyUid] = $sel;
	    if( !is_array($remoteSurvey['chk']) ) return array();
		$data['user_uid'] = $GLOBALS['TSFE']->fe_user->user['uid'];
	    if( $this->request->hasArgument('delete') ){
			foreach($remoteSurvey['chk'] as $surveyUid=>$sel) {
			      $userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
					$result = $this->deleteDistantLimeSurvey($userSurvey);
			      if($result) $this->userSurveyRepository->remove($userSurvey);
			}
			$this->persistenceManager->persistAll();
			$this->addFlashMessage(  count($remoteSurvey['chk']) . ' Objekt'.$plural[ $remoteSurvey['chk'] != 1 ].' gel&ouml;scht. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
	    }elseif( $this->request->hasArgument('ok') && $this->request->hasArgument('edit') ){// batchEditAction update
		  $editfields = array();
		  $rawEditfields = $this->request->getArgument('edit');
		  foreach ($rawEditfields as $key => $value ) { if( !empty($value) ) $editfields[$key]=$value;}
		  if( count($editfields) ){
			foreach($remoteSurvey['chk'] as $surveyUid=>$sel) {
			      $userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
			      foreach ($editfields as $key => $value ) {
				    if( isset( $dateField[ $key ] ) ){
					  $userSurvey->_setProperty( $key ,  new \DateTime(date('Y-m-d',strtotime($value)).'T06:00:00' , $this->timeZone) );
				    }else{
					  if( 'mailState' == $key) $value-=10;
					  $userSurvey->_setProperty( $key , $value );
				    }
			      }
			      if( !empty($data['user_uid']) ) $userSurvey->setUserUid($data['user_uid']);
			      $this->userSurveyRepository->update($userSurvey);
			}
			$updatedSurveys = array_sum($remoteSurvey['chk']);
			$this->addFlashMessage(  $updatedSurveys. ' Objekt'.$plural[ $updatedSurveys != 1 ].' gespeichert. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			$this->persistenceManager->persistAll();
			$this->view->assign('editfields', $editfields);
		  }
	    }
	    return $remoteSurvey;
    }
    
    /**
     * l_EditUpdate
     *
     * @param array $editSurvey
     * @return void
     */
    Private function l_EditUpdate($editSurvey){
	    if( !count($editSurvey) ) return array();
	    $surveyUid =  $editSurvey['uid'];
	    
	    if(!$surveyUid) return array();
		$remoteSurvey['chk'][$surveyUid] = 1;
		if($this->request->hasArgument('abort')) return $remoteSurvey;
		$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
		
	    if(!$userSurvey) return array();
		$data['user_uid'] = $GLOBALS['TSFE']->fe_user->user['uid'];
		  
		if( $this->request->hasArgument('ok') || $this->request->hasArgument('dupliz') ){
				$dateField = array( 'startDate'=>1 , 'deletionDate'=>1 );
				$dateToIntField = array( 'endDate'=> 'expireDays' , 'abrufDatum'=> 'remoteDays'  );
				foreach ($editSurvey as $key => $value ) {
						if( isset( $dateToIntField[ $key ] ) ) continue;
						if( isset( $dateField[ $key ] ) ){
							$usaDate = strtotime($this->getUSformattedDateString($value));
							$userSurvey->_setProperty( $key ,  new \DateTime(date('Y-m-d',$usaDate).'T06:00:00' , $this->timeZone) );
						}else{
							$userSurvey->_setProperty( $key , $value );
						}
				}
				if( !empty( $editSurvey['endDate'] ) ){
						$usaDate = strtotime($this->getUSformattedDateString($editSurvey['endDate']));
						$dtStart = new \DateTime( date( 'Y-m-d' , $userSurvey->getStartDate()->format('U') ) );
						$dtStart->setTimeZone( $this->timeZone );
// 						if( $dtStart->format('d.m.Y') == date('d.m.Y') ) $dtStart->add(new \DateInterval('P1D'));
						$dtEnd = new \DateTime( date( 'Y-m-d' , $usaDate ) );
						$dtEnd->setTimeZone( $this->timeZone );
						$interval = date_diff($dtStart, $dtEnd)->format('%a');
						$userSurvey->setExpireDays( $interval );
				}
				$surveyState = $userSurvey->getSurveyState();
				$enqMail = $userSurvey->getEnquirerEmail();
				if( !empty($enqMail) ){
						if( filter_var($enqMail, FILTER_VALIDATE_EMAIL) ){
								$surveyUid = $userSurvey->getSurveyUid();
								if( $surveyState == 2 && $surveyUid > 0 ){
									// UPDATE  LimeSurvey
									$result = $this->updateDistantLimeSurvey($userSurvey);
									$this->addFlashMessage('LimeSurvey '.$result['action'].'d.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
								}elseif( $surveyState < 2  ){
									// CREATE  LimeSurvey
									$this->createDistantLimeSurvey($userSurvey);
									$this->addFlashMessage('LimeSurvey Umfrage aktiviert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
								}
						}else{
								$userSurvey->setEnquirerEmail('');
						}
				}
				if( !empty($data['user_uid']) ) $userSurvey->setUserUid($data['user_uid']);
				$this->userSurveyRepository->update($userSurvey);
				$this->addFlashMessage('Das Objekt wurde gespeichert. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
				$this->persistenceManager->persistAll();
		}
		if( $this->request->hasArgument('dupliz') ){
				$userSurvey = $this->duplicateSurvey( $userSurvey );
		}
		
		$this->view->assign('userSurvey', $userSurvey);
		$this->view->assign('bearbeiter' , $this->l_getTacherList() );
		$emailBearbeiter = $this->l_getInvitationSenderAdressByUserSurvey($userSurvey);
		$this->view->assign('emailBearbeiter' , $emailBearbeiter );
		$this->view->assign('manualdate' , $this->l_getDatesFromTimespan($userSurvey) );
		$this->view->assign('md5RemoteKey' , md5($userSurvey->getRemoteKey()) );

	    return $remoteSurvey;
    }
	
	/**
	* l_enrichSurveysWithData
	*
	* @return void
	*/
	Private function l_enrichSurveysWithData($userSurveys , $remoteSurvey = array() ) {
	    $enrichedSurveys = $this->enrichSurveysWithState($userSurveys);
	    $enrichedUserSurveys = array();
	    foreach($enrichedSurveys as $newSurvey){
				$dtTo = new \DateTime($newSurvey->getStartDate()->format('Y-m-d'));
				$dtTo->add(new \DateInterval('P'.$newSurvey->getExpireDays().'D'));
				$dtRemote = new \DateTime($dtTo->format('Y-m-d'));
				$dtRemote->add(new \DateInterval('P'.$newSurvey->getRemoteDays().'D'));
				$uid = $newSurvey->getUid();
				$aSurveys = array(
					'chk'=> isset($remoteSurvey['chk'][$uid]) ? $remoteSurvey['chk'][$uid]:0,
					'crDate'=>$newSurvey->getCrdate(),
					'endDate'=>$dtTo->format('U'),
					'remoteDate'=>$dtRemote->format('U'),
					'overdue'=>$dtTo->format('U') <= time()
				);
				$enrichedUserSurveys[$uid] = array( 'survey' => $newSurvey , 'additional' => $aSurveys );
	    }
	    return $enrichedUserSurveys;
	}

    
    /**
     * action dispo
     *
     * @return void
     */
    public function dispoAction()
    {
        // basics assign string / array
        $this->view->assign( 'contentUid' , $this->contentObj->data['uid'] );
        $this->view->assign( 'settings' , $this->settings );
        
        
	    $aPeriods = $this->periodsRepository->findByYearsPassed( $this->settings['semesterYearsPassed'] );
        $this->view->assign('periods', $aPeriods );
        
		$period = $this->getUserChoosenPeriod($aPeriods);
        $this->view->assign('period', $period );
        
        // read stundenplan imported by extenion sfgz_plan from IS2 and assign
        $rawQueryResult = $this->d_getCourses( $period );

	    // extract Kurzklassen out of that
	    $aKurzklassen = $this->d_coursesToShortclass( $rawQueryResult );
	    
	    // d_handleClasstemplates
	    //  reads classtemplateRepository, if input from request->getArgument('remoteSurvey')[userTpSurvey]
	    //  add or remove template from class in tx_mfflsb_domain_model_classtemplate ( classtemplateRepository ), write a message
        $aClassTemplates = $this->d_handleClasstemplates( $aKurzklassen );
        $this->view->assign('kurzklassen', $aClassTemplates );
        
        // mark if some class still hase no template assign string
        $emptyTemplate = 0;
        foreach( $aClassTemplates as $classTemplate ) if(empty($classTemplate['template_uid'])) ++$emptyTemplate;
        $this->view->assign('hasEmptyTemplates', $emptyTemplate ? 1 : 0 );
        
        // if manual template is choosen take that. assign choise 
        // ( even if no checkbox is marked )
        if($this->request->hasArgument('manuelleVorlage')){
                $manuelleVorlageWahl = $this->request->getArgument('manuelleVorlage');
        }else{
                $manuelleVorlageWahl = 0;
        }
        $this->view->assign('manuelleVorlageWahl', $manuelleVorlageWahl );
        
        // if checkbox is marked AND button 'create' is pressed, create new survey out of a course!
        $checkBoxChecked = 0;
        if( $this->request->hasArgument('createRemoteSurvey') && ( $this->request->hasArgument('create_change') || $this->request->hasArgument('create') ) ){
            $aCreateSurvey = $this->request->getArgument('createRemoteSurvey');
            if( isset($aCreateSurvey['chk']) && array_sum($aCreateSurvey['chk']) ){
                $checkBoxChecked = array_sum($aCreateSurvey['chk']);
            }
        }
        
        //  Enrich table with fields 'template_uid' and 'checked'.
        //  Assign sum of courses 
        $courseSum = 0;
        $enrichedQueryResult = [];
        foreach( $rawQueryResult as $ix => $courseRow ){
            $enrichedQueryResult[$ix] = $courseRow;
            
            //  decide wether the template_uid is taken : rom user-choise or from classtemplates?
            $enrichedQueryResult[$ix]['template_uid'] = !empty($manuelleVorlageWahl) ? $manuelleVorlageWahl : $aClassTemplates[ $courseRow['shortclass'] ]['template_uid'];
            
            //  collect checkboxes to evaluate the courses to add from tx_sfgzplan_domain_model_timetable to tx_mfflsb_domain_model_usersurvey
            $enrichedQueryResult[$ix]['checked'] = $aCreateSurvey['chk'][ $ix ];
            
            //  count new records with a valid template_uid and assign
            $courseSum += empty($enrichedQueryResult[$ix]['template_uid']) ? 0 : 1;
        }
        
        $this->view->assign('courseSum', $courseSum );
        
        // create surveys if specific button 'create' pressed and checkboxes are selected
        if( $checkBoxChecked ){
            // loop throug each record given by input
            $newUids = [];
            foreach( $aCreateSurvey['chk'] as $ix => $isCheched ){
                if( empty( $isCheched ) ) continue; //  browsers with strange behviour by checkbox-handling ends here
                if( empty( $enrichedQueryResult[$ix]['template_uid'] ) ) continue; // no valid template_uid
                
                // create new survey and append the new uid to the array newUids
                $newUids[] = $this->d_createSurvey($enrichedQueryResult[$ix] , $period );
            }
            $this->addFlashMessage( count($newUids) . ' Objekt'.( count($newUids) != 1 ? 'e' : '' ).' erstellt. ' , 'Erstellt', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
            if( $this->request->hasArgument('create_change') ) $this->forward('list' , null , null , [] );
        }

		// load full surveys list 
		$addedSurveys = [];
        $userSurveys = $this->getSurveysList($period);
        foreach($userSurveys as $ix => $oSurvey) {
//             $dbEnquirerUid = $oSurvey->getEnquirerUid();
//             $dbFachUid = $oSurvey->getSubject();
//             $dbCourseName = $oSurvey->getCourseName();
//             $dbPeriod = $oSurvey->getSemesterUid();
//             $addedSurveys[ $dbCourseName .'_'. $dbFachUid .'_'. $dbEnquirerUid .'_'. $dbPeriod ][$ix] = $oSurvey;
            $addedSurveys[ $oSurvey->getRemotePlan() ][$ix] = $oSurvey;
        }
        // add old courses to $enrichedQueryResult (the new ones we have got already)
        foreach( $enrichedQueryResult as $ix=>$courseRow){
//            $sIdx = $courseRow['txt_class'].'_'.$courseRow['txt_subjectlong'].'_'.$courseRow['rel_teacher'].'_'.$period;
            $sIdx = $courseRow['import_index'];
            if( isset( $addedSurveys[$sIdx] ) ) $enrichedQueryResult[$ix]['surveys'] = $addedSurveys[$sIdx];
        }
        // assign surveys list as courses
        $this->view->assign('courses', $enrichedQueryResult );
        
        $this->view->assign('debug', ['courses'=>$enrichedQueryResult ] );
        
        // assign array for template_label
        $tpSurveys = $this->tpSurveyRepository->findByPidS( $this->contentObj->data['pages'] , true, false );
        foreach( $tpSurveys as $ix => $template ){
            $surveyTemplates[ $template['uid'] ] = $template['template_label'];
        }
        $this->view->assign( 'Surveytemplates' , $surveyTemplates );
	   
	}

	/**
	* d_createSurvey
	*
	* @param array $aRemoteSurvey
	* @param int $period
	* @return void
	*/
	Private function d_createSurvey($aRemoteSurvey , $period ){
		  // Append flexform values
		  $this->configurationManager->getContentObject()->readFlexformIntoConf($data['pi_flexform'], $data);
			  
		  $data['user_uid'] = $GLOBALS['TSFE']->fe_user->user['uid'];
		  $userUid = empty($data['user_uid']) ? 0 : $data['user_uid'];
	    
		  $templateObj = $this->tpSurveyRepository->findByUid($aRemoteSurvey['template_uid']);
	    
		  $templateDataUtility = new \Mff\MffLsb\Utility\TemplateDataUtility();
		  $xmlDb = $templateDataUtility->showObjectData( $aRemoteSurvey['template_uid'] );

		  $newUserSurvey = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\UserSurvey');
		  $newUserSurvey->setPid( $this->settings['storagePid'] );
		  $newUserSurvey->setCruserId( $userUid );
		  $newUserSurvey->setUserUid( $userUid );
		  $newUserSurvey->setRemoteKey( md5( $userUid . '-' . microtime(true) ) );
		  
		  $newUserSurvey->setUserTpSurvey( $templateObj );
		  $newUserSurvey->setTemplateName( $templateObj->getTemplateName() );
		  $newUserSurvey->setTemplateLabel( $templateObj->getTemplateLabel() );
		  $newUserSurvey->setConfirmFile( $templateObj->getConfirmFile() );
		  $newUserSurvey->setTemplateXml( json_encode( $xmlDb['survey'] ) );
		  $newUserSurvey->setTemplateGroupOptions( json_encode( $xmlDb['question'] ) );
		  
		  $newUserSurvey->setParticipType( 0 ); // anonyme | email
		  $newUserSurvey->setParticipCount( 99 ); // anonyme | email
		  $newUserSurvey->setEnquirerType( 1 ); // user | remote
		  $newUserSurvey->setCourseName( $aRemoteSurvey['txt_class'] );
		  $newUserSurvey->setRemotePlan( $aRemoteSurvey['import_index'] );
		  $newUserSurvey->setSubject( $aRemoteSurvey['txt_subjectlong'] );
		  
		  $newUserSurvey->setFachUid( $aRemoteSurvey['subject_id'] );
		  $newUserSurvey->setSemesterUid( $period );
		  $newUserSurvey->setRemoteDays( $this->settings['remote_days'] );
		  $newUserSurvey->setMailState( 1 ); // none | wait | process | done
		  $newUserSurvey->setSurveyState( 1 ); // none | wait | active
		  $newUserSurvey->setEnquirerUid( $aRemoteSurvey['rel_teacher'] );
		  $newUserSurvey->setEnquirerEmail( $aRemoteSurvey['eml_teacher'] );
            if( $aRemoteSurvey['txt_teacher'] ){
                    $aUsersFullname = explode( ' ' , $aRemoteSurvey['txt_teacher'] );
                    if( $this->settings['firstname_lastname'] ){
                             $enquirerName =  $aRemoteSurvey['txt_teacher'];
                    }elseif( count($aUsersFullname) == 2 ){
                                $enquirerName =  $aUsersFullname[1] . ' ' . $aUsersFullname[0];
                    }elseif( count($aUsersFullname) == 3 ){
                                $enquirerName =  $aUsersFullname[2] . ' ' . $aUsersFullname[0] . ' ' . $aUsersFullname[1];
                    }else{
							$enquirerName = $aRemoteSurvey['txt_teacher'];
                    }
            }else{
                    $enquirerName = $aRemoteSurvey['user'];
            }        
		  $newUserSurvey->setEnquirerName( $enquirerName );
		  if( filter_var($aRemoteSurvey['email'], FILTER_VALIDATE_EMAIL) ) $newUserSurvey->setEnquirerEmail( $aRemoteSurvey['email'] );

		  
		  $dtStart = new \DateTime(  $aRemoteSurvey['date_start'] . 'T05:00:00' , $this->timeZone );
		  if( $this->settings['days_before_start'] ) $dtStart->sub(new \DateInterval('P' . $this->settings['days_before_start'] . 'D'));
		  $dtEnd = new \DateTime( $aRemoteSurvey['date_end'] .  'T05:00:00'  , $this->timeZone );
		  if( $this->settings['expire_days'] ) $dtEnd->add(new \DateInterval('P' . $this->settings['expire_days'] . 'D'));

		  $interval = date_diff($dtStart, $dtEnd)->format('%a');
		  $newUserSurvey->setExpireDays( $interval );
		  $newUserSurvey->setStartDate( $dtStart );
		  $newUserSurvey->setDeletionDate( $dtEnd );
		  $delDate = $newUserSurvey->getDeletionDate();
		  $delDate->add(new \DateInterval('P1Y'));
		  $delDate->add(new \DateInterval('P1D'));
		  
		  $this->userSurveyRepository->add($newUserSurvey);
		  
		  $this->persistenceManager->persistAll();
		  $uid = $newUserSurvey->getUid();
		  $enqMail = $newUserSurvey->getEnquirerEmail();
		  if( filter_var($enqMail, FILTER_VALIDATE_EMAIL) ){
			// CREATE  LimeSurvey
			$this->createDistantLimeSurvey($newUserSurvey);
			$this->userSurveyRepository->update($newUserSurvey);
			$this->persistenceManager->persistAll();
			$this->addFlashMessage('LimeSurvey Umfrage aktiviert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		  }
 		  $msg = $newUserSurvey->getStartDate()->format('d.m.Y') . ' ' . date( 'Y-m-d' , $aRemoteSurvey['date_start'] ) . ' | ' . $aRemoteSurvey['template_uid'] . ' | ' . $aRemoteSurvey['txt_class'] . ' | ' . $aRemoteSurvey['txt_subject']  . ' | ' . $aRemoteSurvey['user']  . ' ('.$aRemoteSurvey['txt_teacher'].')';
 		  return $uid;
	}

	/**
	* d_coursesToShortclass
	*
	* @param array $rawQueryResult
	* @return void
	*/
	Private function d_coursesToShortclass( $rawQueryResult ){
	    $aKurzklassen = array();
	    if($this->request->hasArgument('remoteSurvey')){
            // create new: templateNr is known
		  $remoteSurvey = $this->request->getArgument('remoteSurvey');
		  $userTpSurvey = $remoteSurvey['userTpSurvey'];
		  foreach( $rawQueryResult as $row ){
			$aKurzklassen[$row['shortclass']] = array( 'shortclass' => $row['shortclass'] , 'template_uid' => $userTpSurvey[ $row['shortclass'] ] );
		  }
	    }else{
            // templateNr not known
		  foreach( $rawQueryResult as $row ){
 			$aKurzklassen[$row['shortclass']] = array( 'shortclass' => $row['shortclass'] , 'template_uid' => '' );
		  }
	    }
	    @ksort($aKurzklassen);
	    return $aKurzklassen;
	}

	/**
	* d_getCourses
	*
	* @param int $period
	* @return void $outResult[ idx ][ sql_fieldname ] = value
	*/
	Private function d_getCourses( $period ){
	    $aAnonymous = array_flip( $this->settings['anonymous_accounts']); // .nn=>0 , ref=>1 ... 
	    $aiFb = explode( ',' , $this->settings['fachbereich'] ); // 12,15 changes to 0=>12 1=>15
        $aFachbereiche = array_flip($aiFb); // changes to 12=>0 , 15=>1 ...
        $outResult = [];
        $dateIndex = [];
        $rawQueryResult = ['klasse'=>[] , 'kurs'=>[]] ;
        
        $rawQueryResKlasse = $this->timetableRepository->findBySemesterGroupByKlasseTeacherFiltered( $period );
        $rawQueryResKurs   = $this->timetableRepository->findBySemesterGroupByKursregelTeacherFiltered( $period  );
        $aOkurzklasse = $this->kurzklasseRepository->findAll();

        // array for Kurzklasse with kurzbezeichnung as key and uid as value
        foreach( $aOkurzklasse as $i => $objKk ){
            $kurzklasseKurzbezeichnung = $objKk->getKurzbezeichnung();
            $aoKkFachbereiche = $objKk->getKrzFachbereich();
            $aKuzeklasseFbUid[ $kurzklasseKurzbezeichnung ] = $aoKkFachbereiche->getUid();
        }
        // klasse-timetable
        foreach( $rawQueryResKlasse as $i => $objTt ) {
            $fullClassShortname = $objTt->getTxtClass();
            $aClassname = explode( ' ' , $fullClassShortname );
            $trSshortclass = substr( $fullClassShortname , 0 , strlen( $aClassname[0] )-2 ); // last two chars are the year-digits
            $objTt->setShortclass( $trSshortclass );
            $rawQueryResult['klasse'][$i] = $objTt;
        }
        // kurs-timetable
        foreach( $rawQueryResKurs as $i => $objTt ) {
            $strSubject = $objTt->getTxtSubject();
            $objTt->setTxtClass( $strSubject );
            $objTt->setShortclass( 'KURS' );
            $rawQueryResult['kurs'][$i] = $objTt;
        }
        
        // combine klasse and kurs, group by teacher-class-subject, then group by date, flatenate and and transform Objects to sql-fileds
        // create the group indizes teacher-class-subject and dates
        foreach($rawQueryResult as $tableType => $queryResult ) {
            foreach( $queryResult as $i => $objTt ){
                // only if Fachbereich for this class is choosen
                $trSshortclass = $objTt->getShortclass();
                $kkFbUid = $aKuzeklasseFbUid[ $trSshortclass ];
                if( !isset( $aFachbereiche[ $kkFbUid ] ) ) continue;
            
                // cancel  anonyme accounts like .nn 
                $teachertext = $objTt->getTxtTeacher();
                if( isset( $aAnonymous[ trim($teachertext) ] ) ) continue;
                
                // set index for group by teacher-class-subject (outer index)
                $strGoupIndex = '.' . $objTt->getTxtClass();
                $strGoupIndex .= $objTt->getRelTeacher();
                $strGoupIndex .= '.' . $objTt->getTxtSubject(); // in kurs the same as txtClass
                
                // set index for date groups (inner index)
                $datStartDate = $objTt->getDateStart();
                $datEndDate = $objTt->getDateEnd();
                $dateIndex[$tableType][$strGoupIndex]['start'][ $datStartDate->format('Ymd') ][ $i ] = $objTt;
                $dateIndex[$tableType][$strGoupIndex]['end'][ $datEndDate->format('Ymd') ][$i] = $objTt;
            }
        }
       
        // flatenate the table by combining first and last event, and transform Objects to sql-fileds
        foreach($dateIndex as $tableType => $aTablesGroup ) {
            ksort($aTablesGroup);
            foreach( $aTablesGroup as $grpd => $grpObjs ){
                
                // detect latest enddate
                ksort($grpObjs['start']);
                krsort($grpObjs['end']);
                $aKs = array_keys( $grpObjs['start'] );
                $aKe = array_keys( $grpObjs['end'] );
                $aFirstStart = $grpObjs['start'][ $aKs[0] ];
                $aLastEnd   = $grpObjs['end'][ $aKe[0] ];
                foreach( $aLastEnd as $i => $objLastEnd ) $datDateEnd = $objLastEnd->getDateEnd();
                
                // detect earliest startdate, choose first recordset an insert latest enddate
                foreach( $aFirstStart as $i => $objFirstStart ) {
                    $idx = $objFirstStart->getUid() ;
                    $outResult[$idx]['date_start'] = $objFirstStart->getDateStart()->format('Y-m-d');
                    $outResult[$idx]['date_end'] = $datDateEnd->format('Y-m-d');
                    
                    // transform to sql-fileds
                    $aProperties = $objFirstStart->_getProperties();
                    foreach( $aProperties  as $key => $value ){
                        $sqlName = $sql_format = GeneralUtility::camelCaseToLowerCaseUnderscored( $key );
                        if( !isset($outResult[$idx][$sqlName]) ) $outResult[$idx][$sqlName] = $value ;
                    }
                    break; // $aFirstStart anyway contains only 1 row
                }
            }
        }
        return $outResult;
        $aSorted = [];
        ksort($outResult);
        foreach( $outResult as $objList ){
                foreach( $objList as $obj ) $aSorted[$obj['uid']] = $obj;
        }
        return $aSorted;
    }


	
	
	
	/**
	* d_handleClasstemplates
	*
	* @param array $classList
	* @return void
	*/
	Private function d_handleClasstemplates( $classList ){
	    // get stored values from Database
	    $clsTemplates = $this->classtemplateRepository->findAll();
	    foreach( $clsTemplates as $clsRow ){
		  $shortclass = $clsRow->getShortclass();
		  $tpsurvey = $clsRow->getTpsurvey();
		  $dbClasses[$shortclass] = $clsRow;
	    }
	    // edit or create new
	    $changes = 0;
	    foreach( $classList as $template ){
            $shortclass = $template['shortclass'];
            if(isset( $dbClasses[ $shortclass ] )){
                    if( empty($template['template_uid']) ){
                            $userTpSurvey='';
                            if($this->request->hasArgument('remoteSurvey')){
                                    $inFromForm = $this->request->getArgument('remoteSurvey');
                                    $userTpSurvey = $inFromForm['userTpSurvey'];
                            }
                            $shortclassFromDb = $dbClasses[ $shortclass ]->getShortclass();
                            if(isset($userTpSurvey[ $shortclassFromDb ])){
                                    $this->classtemplateRepository->remove($dbClasses[ $shortclass ]);
                                    $changes +=1;
                            }else{
                                    $classList[$shortclass]['template_uid'] = $dbClasses[ $shortclass ]->getTpsurvey();
                                    $classList[$shortclass]['shortclass'] = $shortclassFromDb;
                            }
                    }elseif( $template['template_uid'] != $dbClasses[ $shortclass ]->getTpsurvey() ){
                        $dbClasses[ $shortclass ]->setTpsurvey($template['template_uid']);
                        $this->classtemplateRepository->update($dbClasses[ $shortclass ]);
                        $changes +=1;
                    }
            }else{
                    if($template['template_uid']){
                            $newClasstemplate = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\Classtemplate');
                            $newClasstemplate->setShortclass($template['shortclass']);
                            $newClasstemplate->setTpsurvey($template['template_uid']);
                            $this->classtemplateRepository->add( $newClasstemplate );
                            $changes +=1;
                    }
            }
	    }
	    
	    // create message
	    if( $changes ){
		  $notCreate = !$this->request->hasArgument('create') || !$this->request->hasArgument('create_change');
		  $this->persistenceManager->persistAll();
		  if( $notCreate ) $this->addFlashMessage('Gespeichert, '.$changes.' Änderung(en).', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
	    }elseif($this->request->hasArgument('remoteSurvey') && $notCreate ){
		  $this->addFlashMessage('Keine Änderungen.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
	    }
	    
	    return $classList;
	}

	/**
	* action delete
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function deleteAction(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey) {
	    $this->deleteDistantLimeSurvey($userSurvey);
	    $this->addFlashMessage('Die Umfrage wurde geloescht. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
	    $this->userSurveyRepository->remove($userSurvey);
        $this->persistenceManager->persistAll();
        $GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
 	    $this->forward('list' , null , null , [ 'delete'=>1] );
	}
    
    /**
     * createDistantLimeSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
     * @return void
     */
    Private function createDistantLimeSurvey($userSurvey){
	    $lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
	    $result = $lsObjUtility->createLsFromUserSurvey( $userSurvey );
	    $userSurvey->setSurveyState(2);
	    $userSurvey->setSurveyUid($result['survey_uid']);
	    $userSurvey->setResponsesField( '' ); // delete old answers, if existing
    }
    
    /**
     * deleteDistantLimeSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
     * @return void
     */
    Private function deleteDistantLimeSurvey($userSurvey){
	    $lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
	    $result = $lsObjUtility->deactivateLsFromUserSurvey( $userSurvey );
	    $userSurvey->setSurveyState(0);
	    $userSurvey->setSurveyUid(0);
	    $userSurvey->setResponsesCount( '' );
	    return $result;
    }
    
    /**
     * updateDistantLimeSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
     * @return void
     */
    Private function updateDistantLimeSurvey($userSurvey){
	    $lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
	    $isExpired = $this->isSurveyExpiredByDate( $userSurvey );
	    if($isExpired){
		  $lastUpDate = $userSurvey->getResponsesUpdated();
		  $expireDays = 1+$userSurvey->getExpireDays();
		  $startDate = $userSurvey->getStartDate();
		  $enddate = new \DateTime( $startDate->format('Y-m-d H:i:s') );
		  $enddate->add(new \DateInterval('P'.$expireDays.'D'));
		  $enddate->setTimeZone($this->timeZone);
		  if( $lastUpDate && $lastUpDate->format('U') < $enddate->format('U') ) {$isExpired=0;}
	    }
	    $result = $lsObjUtility->updateLsFromUserSurvey( $userSurvey , $isExpired );
	    return $result;
    }
	      

}
	      

	
