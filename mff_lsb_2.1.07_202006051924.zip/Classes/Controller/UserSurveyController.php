<?php
namespace Mff\MffLsb\Controller;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * UserSurveyController
 */
class UserSurveyController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
	/**
	* userSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\UserSurveyRepository
	* @inject
	*/
	protected $userSurveyRepository = null;

	/**
	* tpSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\TpSurveyRepository
	* @inject
	*/
	protected $tpSurveyRepository = null;
	
	/**
	 * frontendUserRepository
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository
	 * @inject
	 */
	protected $frontendUserRepository = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;
	
	/**
	 * @var string 
	 */
	protected $noextKey = 'mfflsb_survey';

	/**
	  * initializeAction
	  *
	  */
	public function initializeAction() {
	      $this->initialize_basics();
	      $this->initialize_useroptions();
	}
	
	public function initialize_basics() {
 	      date_default_timezone_set( 'Europe/Zurich' );
	      $this->GmtZone = new \DateTimeZone('GMT');
 	      $this->timeZone = new \DateTimeZone('Europe/Zurich');
	      
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
 	      $this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $this->contentObj = $this->configurationManager->getContentObject();
	      $fullsettings = $this->configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      
	      $storagePidSurvey = $fullsettings['plugin.']['tx_mfflsb_survey.']['persistence.']['storagePid'];
// 	      $storage = empty($this->contentObj->data['pages']) ? array( 'storagePid'=>$storagePidSurvey ) : explode( ',' , $this->contentObj->data['pages'] );
	      $storage =  array( 'storagePid'=>$storagePidSurvey ) ;
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setRespectStoragePage(FALSE);
	      $querySettings->setStoragePageIds( $storage );
	      $this->userSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\UserSurveyRepository');
	      $this->userSurveyRepository->setDefaultQuerySettings( $querySettings );
	      
	      $teacherStorage['teacherPid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
	      $this->frontendUserRepository = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Domain\\Repository\\FrontendUserRepository');
	      $querySettings->setStoragePageIds( $teacherStorage );
	      $this->frontendUserRepository->setDefaultQuerySettings( $querySettings );
	      $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
// 	      $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_' . $this->contentObj->data['list_type'] . '.']['settings.']);
 	      $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_mfflsb_survey.']['settings.']);
	      $this->settings['teacherPid'] =$teacherStorage['teacherPid'];
	      $this->settings['baseUrl'] = $fullsettings['config.']['baseURL'];
	      $this->settings['storagePid'] = $storage['storagePid'];
	}
	
	public function initialize_useroptions() {
			$userObj = $GLOBALS['TSFE']->fe_user;
			if( !$userObj ) return;
			$settings_useroptions = $userObj->getKey('user', 'useroptions');
			if ($this->request->hasArgument('useroptions')) {
					$useroptions = $this->request->getArgument('useroptions');
					if(  is_array($useroptions) ){
							foreach($useroptions as $field => $value){
								$settings_useroptions[$field] = $value;
							}
							$userObj->setKey("user","useroptions", $settings_useroptions);
							$userObj->sesData_change = true;
							$userObj->storeSessionData();
					}
			}
			if( is_array($settings_useroptions) && count($settings_useroptions)){
					foreach($settings_useroptions as $field => $value){
						$this->settings['useroptions'][$field] = $value;
					}
			}
	}
	
	public function getSettings() {
	      return $this->settings;
	}


	/**
	* action list
	*
	* @return void
	*/
	public function listAction() {
	    $userSurveys = $this->getSurveysList();
	    $enrichedUserSurveys = $this->enrichSurveysWithState($userSurveys);
	    $this->view->assign('userSurveys', $enrichedUserSurveys);
	    
	    $data = $this->getFlexformData();
	    $this->view->assign('data', $data);
	    
	    $this->view->assign('contentUid', $this->contentObj->data['uid'] );
	    
	    $periods = null;
	    if ($this->request->hasArgument('periods')) {
            $periods = $this->request->getArgument('periods');
            $calendarService = new \Mff\MffLsb\Service\CalendarService();
            $aCalendarData = $calendarService->addPeriodToRepository(); // use default values -3y and total 7 jears
            
            $this->view->assign('log', $calendarService->log );
            $this->view->assign('calendar', $aCalendarData );
	    }
        $this->view->assign('periods', $periods );

	}

	/**
	* action new
	*
	* @return void
	*/
	public function newAction() {
	    $tpSurveys = $this->tpSurveyRepository->findByPidS( $this->contentObj->data['pages'] , false, false );
	    $this->view->assign('Surveytemplates', $tpSurveys);

	    // Get the data from content-object (contains the tt_content fields)
	    $data = $this->configurationManager->getContentObject()->data;

	    // Append flexform values
	    $this->configurationManager->getContentObject()->readFlexformIntoConf($data['pi_flexform'], $data);
		    
	    $data['user_uid'] = $GLOBALS['TSFE']->fe_user->user['uid'];
	    $data['user_name'] = trim($GLOBALS['TSFE']->fe_user->user['first_name'] .' ' . $GLOBALS['TSFE']->fe_user->user['last_name']);

	    // select last template as default [ 0 (none) | 1 (first) | 2 (last) ]
	    if( $data['default_template'] == 2 ){
		  foreach( $tpSurveys as $obj ){ $aObjList[] = $obj->getUid(); }
		  $data['default_template'] = end( $aObjList );
	    }
	    
	    // Assign to template
	    $this->view->assign('data', $data);
	    $this->view->assign('bearbeiter' , $this->frontendUserRepository->findAll() );
	    $this->view->assign('contentUid', $this->contentObj->data['uid'] );

	}

	/**
	  * Initialize  create
	  *
	  * @return void
	  */
	public function initializeCreateAction() {
	      if($this->request->hasArgument('newUserSurvey')) {
		      $args = $this->arguments['newUserSurvey']->getPropertyMappingConfiguration();
		      $args->forProperty('startDate')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		      $args->forProperty('deletionDate')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		      $bel = $this->request->getArgument('newUserSurvey');
		      if(empty($bel['userTpSurvey'])) {
			    $this->arguments->getArgument('newUserSurvey')->getPropertyMappingConfiguration()->skipProperties('userTpSurvey');
		      }
		      if(empty($bel['startDate'])) {
			    $this->arguments->getArgument('newUserSurvey')->getPropertyMappingConfiguration()->skipProperties('startDate');
		      }
		      if(empty($bel['deletionDate'])) {
			    $this->arguments->getArgument('newUserSurvey')->getPropertyMappingConfiguration()->skipProperties('deletionDate');
		      }
	      }
	}

	/**
	* action create
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $newUserSurvey
	* @return void
	*/
	public function createAction(\Mff\MffLsb\Domain\Model\UserSurvey $newUserSurvey)
	{
	    $templateObj = $newUserSurvey->getUserTpSurvey();
	    $templateUid = $templateObj->getUid();
	    $templateName = $templateObj->getTemplateName();
	    $confirmFile = $templateObj->getConfirmFile();
	    $templateDataUtility = new \Mff\MffLsb\Utility\TemplateDataUtility();
	    $xmlDb = $templateDataUtility->showObjectData( $templateUid );
	    $newUserSurvey->setPid( $this->settings['storagePid'] );
	    $newUserSurvey->setTemplateName( $templateName );
	    $newUserSurvey->setConfirmFile( $confirmFile );
	    $newUserSurvey->setTemplateXml( json_encode( $xmlDb['survey'] ) );
	    $newUserSurvey->setTemplateGroupOptions( json_encode( $xmlDb['question'] ) );
	    
	    $this->repairDate( $newUserSurvey );
	    
	    $this->userSurveyRepository->add($newUserSurvey);
	    $this->addFlashMessage('Die Umfrage wurde erfasst mit Vorlage Nr: '.$templateUid.'.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
	    
	    $this->persistenceManager->persistAll();
	    $uid = $newUserSurvey->getUid();
	    $rep['userSurvey'] = $this->userSurveyRepository->findByUid($uid);
	    $rep['oldact'] = 'create';
	    
	    // if no spider (self-assessment) and no editable questions in survey, create LimeSurvey
	    $count = array( 'spiders'=>0 , 'editable'=>0 );
	    foreach($xmlDb['question'] as $gid=>$grRows){
		  $partialArr = $templateDataUtility->deflateOptionGroupValue( $grRows['groups']['report_partials'] , 4 );
		  $count['spiders'] += ($partialArr[4]==4) ? 1 : 0;
		  foreach($grRows['questions'] as $qKey=>$qRows){
			if( is_array($grRows['subquestions'][$qKey]) ){
			      foreach($grRows['subquestions'][$qKey] as $sqKey=>$sqRows){
				    $count['editable'] += $sqRows['editable'] ? 1 : 0;
			      }
			}
		  }
	    }
	    if( $count['editable'] == 0 && $count['spiders'] == 0 && empty($rep['userSurvey']->getSurveyUid())){
		  $lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
		  $result = $lsObjUtility->createLsFromUserSurvey( $rep['userSurvey'] );
		  $rep['userSurvey']->setSurveyState(2);
		  $rep['userSurvey']->setSurveyUid($result['survey_uid']);
		  $rep['userSurvey']->setResponsesField( '' ); // delete old answers, if existing
		  if( $rep['userSurvey'] ) $this->userSurveyRepository->update( $rep['userSurvey'] );
		  $this->addFlashMessage('LimeSurvey Umfrage aktiviert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		  $rep['oldact'] = 'update';
	    }else{
		  $this->addFlashMessage('Bitte Fragen bearbeiten, und dann die Umfrage aktivieren.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
	    }
	    
	    $this->forward('edit', NULL, NULL, $rep );
	}

	/**
	* action edit
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @ignorevalidation $userSurvey
	* @return void
	*/
	public function editAction(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){
 	    
 	    $this->view->assign('contentUid', $this->contentObj->data['uid'] );
	    
	    $tpSurveytemplates = $this->tpSurveyRepository->findByPidS( $this->contentObj->data['pages'] , false, false );
	    $this->view->assign('Surveytemplates', $tpSurveytemplates);
	    
	    $reportUtility = new \Mff\MffLsb\Utility\ReportDataUtility( $this->settings );
	    $userObj = $GLOBALS['TSFE']->fe_user;
	    if($userObj){
			$this->settings['useroptions'] = $userObj->getKey('user', 'useroptions');
			$this->settings['useroptions']['sumTypesArray'] = $reportUtility->deflateOptionGroupValue( $this->settings['useroptions']['sumtypes'] , 4 );
			$this->view->assign('settings', $this->settings);
			$reportUtility->settings['useroptions'] = $this->settings['useroptions'];
	    }
	    
	    if ($this->request->hasArgument('download')) {
			$downAct = $this->request->getArgument('download');
			if( $downAct == 'Herunterladen' ) $this->downloadResponses( $userSurvey );
			if( $downAct == 'confirmation' ) $this->downloadConfirmation( $userSurvey );
			if( $downAct == 'vorlage_leer' ) $this->downloadUmfragenvorlage( $userSurvey , TRUE );
			if( $downAct == 'vorlage' ) $this->downloadUmfragenvorlage( $userSurvey , FALSE );
	    }
	    
	    $isExpired = $this->isSurveyExpiredByDate( $userSurvey );
	    $isActive = $this->isSurveyActive( $userSurvey , true );
	    if( $isActive ){
		  if( $this->isUpdateAffored( $userSurvey , false ) ){
			$this->updateSurveyFromApi($userSurvey);
			$this->addFlashMessage('LimeSurvey '.$userSurvey->getResponsesCount().' Antworten abgerufen. ' . $dt->format('d.m.y H:i'), '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);			
		  }
	    }
	    if( $isActive && $isExpired ) $isActive = false;
	    
	    $this->view->assign('userSurvey', $userSurvey);
	    $oldact = $this->request->hasArgument('oldact') ? $this->request->getArgument('oldact') : 'list';
	    $this->view->assign('oldact', $oldact );
	    
	    $answers = json_decode( $userSurvey->getResponsesField() , true );
	    $templateGroupOptions = $reportUtility->repairMacCharset( $userSurvey->getTemplateGroupOptions() );
	    $aQst = $reportUtility->questionsFieldToArray( $templateGroupOptions );
	    if( $this->isSurveyActive( $userSurvey , true ) ){
		  $aReportValues = $reportUtility->getReportValues( $aQst , $answers );
	    }else{
		  $aReportValues = array('groups'=>$aQst);
	    }
	    $aQuestiongroups = $reportUtility->appendSurveyOptions( $userSurvey , $aReportValues );
	    $this->view->assign('questiongroups',  $aQuestiongroups   );
	    
	    $userSurveys = $this->getSurveysList();
	    $enrichedUserSurveys = $this->enrichSurveysWithState($userSurveys);
	    $this->view->assign('userSurveys', $enrichedUserSurveys);
	    
	    if( $this->request->hasArgument('abrufen') ){
		  $abrufen = $this->request->getArgument('abrufen');
	    }else{
		  $abrufen = 0;
	    }
	    $this->view->assign('abrufen',  !empty($abrufen) ? 1: 0  );
	    
	    // fill array $data with options from flexForm and Input
	    $data = $this->getFlexformData();
	    
	    $data['isActive'] = $isActive ;
	    $data['isExpired'] = $isExpired ;
	    $data['isResponses'] = $userSurvey->getResponsesCount() > 0 ? 1 : 0 ;
	    
	    $data['surveyState'] = $userSurvey->getSurveyState();
	    if( $isExpired ) {
		if( $data['surveyState'] ) {
		    $data['surveyState'] = 3;
		}else{
		    $data['surveyState'] = '';
		}
	    }
	    
	    if( $oldact == 'create' ) {
		  // soeben erstellt
		  $data['views']['editform'] = 1; 
	    }elseif( $abrufen ){ 
		  // abrufen und anzeigen = nicht bearbeiten
		  $data['views']['editform'] = 0; 
	    }elseif( $isExpired  && !$aQuestiongroups['survey']['iseditable'] ){ 
		  // abgelaufen und keine bearbeitbaren Fragen
		  $data['views']['editform'] = 1; 
//	    }elseif( $isExpired && empty($data['isResponses']) && !$abrufen ){ 
		  // abgelaufen und keine Antworten
//		  $data['views']['editform'] = 1; 
//	    }elseif( !$aQuestiongroups['survey']['iseditable'] && !$isActive && ( empty($data['isResponses']) || empty($data['mainPartials']['2']) ) ){ 
		  // keine bearbeitbare Fragen UND nicht aktiv und ( keine Antworten ODER Auswertung versteckt)
	    }elseif( !$aQuestiongroups['survey']['iseditable'] && !$isActive ){ 
		  $data['views']['editform'] = 1; 
	    }elseif( $aQuestiongroups['survey']['iseditable'] && $isExpired ){ 
		  $data['views']['editform'] = 1; 
	    }else{ 
		  // editform ausgeblendet anzeigen
		  $data['views']['editform'] = 0; 
	    }
	    $this->view->assign('data', $data);
	    
	}
	
	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeUpdateAction() {
		$args = $this->arguments['userSurvey']->getPropertyMappingConfiguration();
		$args->forProperty('startDate')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		$args->forProperty('deletionDate')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		if($this->request->hasArgument('userSurvey')) {
			$userSurvey = $this->request->getArgument('userSurvey');
			if(empty($userSurvey['deletionDate'])) { // date
			      $this->arguments->getArgument('userSurvey')->getPropertyMappingConfiguration()->skipProperties('deletionDate');
			}else{
			      $args->forProperty('deletionDate')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			if(!empty($userSurvey['responsesUpdated'])) { // datetime
				$args->forProperty('responsesUpdated')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			if(empty($userSurvey['startDate'])) { // date
			      $this->arguments->getArgument('userSurvey')->getPropertyMappingConfiguration()->skipProperties('startDate');
			}else{
			      $args->forProperty('startDate')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
		}
	}

	/**
	* action update
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function updateAction(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey)
	{
	    if ($this->request->hasArgument('delete')) {
		  $this->forward('delete', NULL, NULL, array('userSurvey'=>$userSurvey) );
	    }elseif($this->request->hasArgument('liste')){
		  $this->redirect('list');
	    }
	    
	    // handle templateGroupOptions: array from field-stored json
	    if ($this->request->hasArgument('ownQuestion')) {
		$questionInput = $this->request->getArgument('ownQuestion');
	    }else{ $questionInput = array();}
	    
	    if ($this->request->hasArgument('chkbox')) {
		$ownCheckbox = $this->request->getArgument('chkbox');
	    }else{ $ownCheckbox = array();}
	    
	    $this->updateQuestionsField( $userSurvey , $questionInput , $ownCheckbox );
	    
	    if ($this->request->hasArgument('selfAssessment')) {
		$selfAssessmentInput = $this->request->getArgument('selfAssessment');
		$this->updateSelfAssessmentField( $userSurvey , $selfAssessmentInput );
	    }
	    
	    // handle dialogue with LimeSurvey and get state
	    // $survey_state: 0=no survey created , 1=create now , 2=created+activated , 5=deactivateNow
	    $lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
	    // DEACTIVATE  LimeSurvey
	    if ($this->request->hasArgument('surveyState')) {
				$reqSurvey_state = $this->request->getArgument('surveyState');
				$stateReqNam = array_keys($reqSurvey_state);
				$survey_state = $stateReqNam[0];
				if($survey_state == 5){
					$result = $lsObjUtility->deactivateLsFromUserSurvey( $userSurvey );
					$userSurvey->setSurveyState(0);
					$userSurvey->setSurveyUid(0);
					$userSurvey->setResponsesCount( '' );
					$this->addFlashMessage('LimeSurvey Umfrage deaktiviert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
				}elseif($survey_state == 1 && empty($userSurvey->getSurveyUid()) ){
				// CREATE  LimeSurvey
					$result = $lsObjUtility->createLsFromUserSurvey( $userSurvey );
					$userSurvey->setSurveyState(2);
					$userSurvey->setSurveyUid($result['survey_uid']);
					$userSurvey->setResponsesField( '' ); // delete old answers, if existing
					$this->addFlashMessage('LimeSurvey Umfrage aktiviert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
				}
	    }else{
		  $survey_state = $userSurvey->getSurveyState();
	    }
	    $survey_uid = $userSurvey->getSurveyUid();
	    // CLONE (duplicate)
	    if( $this->request->hasArgument('dupliz') ){
		  $newSurvey = $this->duplicateSurvey( $userSurvey );
		  $this->forward('edit', NULL, NULL, array('oldact'=>'create' ,'userSurvey'=>$newSurvey ) );
		  
	    }elseif( $survey_uid && $survey_state == 2 ){
	    // UPDATE LimeSurvey
		  // and/or get Answers from LimeSurvey
		  if ($this->request->hasArgument('speichern')) {
			$isExpired = $this->isSurveyExpiredByDate( $userSurvey );
			if($isExpired){
			      $lastUpDate = $userSurvey->getResponsesUpdated();
			      $expireDays = 1+$userSurvey->getExpireDays();
			      $startDate = $userSurvey->getStartDate();
			      $enddate = new \DateTime( $startDate->format('Y-m-d H:i:s') );
			      $enddate->add(new \DateInterval('P'.$expireDays.'D'));
			      $enddate->setTimeZone($this->timeZone);
			      if( $lastUpDate && $enddate ){
					if( $lastUpDate->format('U') < $enddate->format('U') ) {$isExpired=0;}
			      }else{$isExpired=1;}
			}
			$result = $lsObjUtility->updateLsFromUserSurvey( $userSurvey , $isExpired );
			$this->addFlashMessage('LimeSurvey '.$result['action'].'d.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		  }else{
			$result = $lsObjUtility->getAnswersFromLs( $survey_uid );
		  }
		  if( isset($result['responsesField']['responses']) ){
			if( count($result['responsesField']['responses']) ){
			      $textValOfJson = json_encode( $result['responsesField'] );
			      if( $textValOfJson == '[]' ){
				    $userSurvey->setResponsesField( '' );
				    $userSurvey->setResponsesCount( 0 );
			      }else{
				    $userSurvey->setResponsesField( $textValOfJson );
				    $userSurvey->setResponsesCount( count( $result['responsesField']['responses'] ) );
			      }
			}else{ 
			      $userSurvey->setResponsesField( '' );
			      $userSurvey->setResponsesCount( 0 ) ;
			}
			$dt = new \DateTime("@".time());
			$dt->setTimeZone( $this->timeZone );
			$userSurvey->setResponsesUpdated($dt);
			if (!$this->request->hasArgument('download')) $this->addFlashMessage('Antworten abgefragt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		  }
	    }
	    if( $userSurvey ) $this->userSurveyRepository->update( $userSurvey );
	    $this->persistenceManager->persistAll();
	    if (!$this->request->hasArgument('download')) $this->addFlashMessage('Die Umfrage wurde gespeichert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
	    
	    if ($this->request->hasArgument('download')) {
		  $downAct = $this->request->getArgument('download');
		  if( $downAct == 'Herunterladen' ) $this->downloadResponses( $userSurvey );
		  if( $downAct == 'vorlage_leer' ) $this->downloadUmfragenvorlage( $userSurvey , TRUE );
		  if( $downAct == 'vorlage' ) $this->downloadUmfragenvorlage( $userSurvey , FALSE );
		  if( $downAct == 'confirmation' ) $this->downloadConfirmation( $userSurvey );
	    }
	    
	    if( $this->request->hasArgument('abrufen') ){
		  $abrufInput = $this->request->getArgument('abrufen');
		  $abrufen = !empty($abrufInput) ? 1: 0;
	    }else{
		  $abrufen = 0;
	    }
	    $this->forward('edit', NULL, NULL, array('oldact'=>'update' ,'userSurvey'=>$userSurvey , 'ownQuestion'=>$questionInput , 'chkbox'=>$ownCheckbox , 'abrufen'=>$abrufen) );
	}
	
	/**
	 * duplicateSurvey
	 *
	 * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	 * @return int
	 */
	public function duplicateSurvey($userSurvey) {
 		  $newSurvey = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\UserSurvey');
		  $properties = $userSurvey->_getProperties() ;
		  $oldUid = $properties['uid'];
		  unset($properties['uid']) ;
		  unset($properties['surveyUid']) ;
		  unset($properties['surveyState']) ;
		  $properties['mailState'] = 1;
		  $properties['crdate'] = time();
		  $properties['timestamp'] = time();
		  unset($properties['responsesCount']) ;
		  unset($properties['responsesField']) ;
		  unset($properties['responsesUpdated']) ;
		  unset($properties['remote_key']) ;
		  foreach ($properties as $key => $value ) $newSurvey->_setProperty( $key , $value );
		  $this->userSurveyRepository->add( $newSurvey );
		  $this->persistenceManager->persistAll();
		  $newUid = $newSurvey->getUid();
		  $this->addFlashMessage('Die Umfrage #' . $oldUid . ' wurde dupliziert zu #'.$newUid.'.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		  return $newSurvey;
	}

      /**
	* action delete
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @ignorevalidation $userSurvey
	* @return void
	*/
	public function deleteAction(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey) {
	    $lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
	    $result = $lsObjUtility->deactivateLsFromUserSurvey( $userSurvey );
	    $this->addFlashMessage('Die Umfrage wurde gelöscht.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
	    $this->userSurveyRepository->remove($userSurvey);
	    $this->redirect('list');
	}

	/**
	* enrichSurveysWithState
	*
	* @return void
	*/
	public function enrichSurveysWithState($userSurveys) {
	    $enrichedUserSurveys = array();
	    foreach($userSurveys as $usrSurvey){
 		  $newSurvey = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\UserSurvey');
		  $properties = $usrSurvey->_getProperties() ;
		  foreach ($properties as $key => $value ) $newSurvey->_setProperty( $key , $value );
		  $actualState = $newSurvey->getSurveyState();
		  $expired = $this->isSurveyExpiredByDate($usrSurvey);
		  if( $expired ) {
		      if( $actualState ) {
			  	  $newSurvey->setSurveyState( 3 );
		      }else{
			  	  $newSurvey->setSurveyState( '' );
		      }
		  }
		  $enrichedUserSurveys[] = $newSurvey;
	    }
	    return $enrichedUserSurveys;
	}

	/**
	* getSurveysList
	*
	* @return void
	*/
	public function getSurveysList() {
	    $user_uid = $GLOBALS['TSFE']->fe_user->user['uid'];
	    return $this->userSurveyRepository->findByPidS( $this->settings['storagePid'], $user_uid );
	}

      /**
	* downloadConfirmation
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function downloadConfirmation(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){
	      $uploadDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( ltrim($this->settings['upload_dir'] , '/') ) , '/' ) . '/';

	      $dateiname = $userSurvey->getConfirmFile();	      
	      if( !file_exists($uploadDir.$dateiname) ) $dateiname = 'confirmation.pdf';
	      if( !file_exists($uploadDir.$dateiname) ) return;
	      
	      $downloadFileName = 'Vorgehen_Durchfuehrungsbestaetigung.pdf';
	      
	      if($this->settings['fill_confirmation_data'] != 1){
	      // PHP 5.6 Problem - in PHP 5.5 only use this
		    $file_url = $uploadDir.$dateiname;
		    if( file_exists($file_url) && !empty($dateiname) && is_file($file_url) ){
			  header('Content-Type: application/force-download');
			  header('Content-Type: application/pdf');
			  header("Content-Transfer-Encoding: Binary");
			  header("Content-disposition: attachment; filename=".$downloadFileName);
			  readfile($file_url);
			  exit();
		    }
	      }else{
	      // FIXME: Dont use this with PHP 5.5! If there is a PHP 5.6 Problem, dont use this and set fill_confirmation_data=0
		    $reportUtility = new \Mff\MffLsb\Utility\ReportPdfDataUtility( $this->settings );
		    $fields = $reportUtility->PDFDataForConfirmations( $userSurvey );
		    $extDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName('typo3conf/ext/mff_contrib/Resources/Private/PHP/fpdm/');
		    require($extDir.'FPDM.php');
		    $pdf = new \FPDM\FPDM($uploadDir.$dateiname);
		    $pdf->Load($fields, false); // second parameter: false if field values are in ISO-8859-1, true if UTF-8
		    $pdf->Merge();
		    echo $pdf->Output($downloadFileName,'D');
		    exit();
	      }
	}

      /**
	* downloadUmfragenvorlage
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @param bool $noData
	* @return void
	*/
	public function downloadUmfragenvorlage(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey , $noData = false){
	//print_r( $this->settings['pdf_basics'][0] );
// 	$this->settings['pdf_basics'][0]['HeadLine']['method'] = 'grundbildungHeader';
		// load variables
		$reportUtility = new \Mff\MffLsb\Utility\ReportPdfDataUtility( $this->settings );
		$reportData = $reportUtility->PDFDataForPrintouts( $userSurvey , $noData );
		// create and output PDF
		$pdfUtility = new \Mff\MffLsb\Utility\PdfPrintoutUtility( $this->settings );
  		$pdfUtility->pdfTemplate( $reportData ); // causes exit();
	}

      /**
	* downloadResponses
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function downloadResponses(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){
		// get user-options to evaluate wich summa-fields should be displayed
		$userObj = $GLOBALS['TSFE']->fe_user;
		if($userObj) $this->settings['useroptions'] = $userObj->getKey('user', 'useroptions');
		// get responses if affored
		if( $this->isUpdateAffored($userSurvey, true) ){
			$this->updateSurveyFromApi($userSurvey);
			$this->addFlashMessage('LimeSurvey '.$userSurvey->getResponsesCount().' Antworten abgerufen. ' . $dt->format('d.m.y H:i'), '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}
		// load variables
		$reportUtility = new \Mff\MffLsb\Utility\ReportPdfDataUtility( $this->settings );
		$reportData = $reportUtility->PDFDataForReports( $userSurvey );
		// create and output PDF
		$pdfUtility = new \Mff\MffLsb\Utility\PdfReportUtility( $this->settings );
		$pdfUtility->pdfReport( $reportData ); // causes exit();
	}

	/**
	* updateSurveyFromApi
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @ignorevalidation $userSurvey
	* @return void
	*/
	public function updateSurveyFromApi(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){
			$survey_uid = $userSurvey->getSurveyUid();
			$lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
			$result = $lsObjUtility->getAnswersFromLs( $survey_uid );
			$textValueOfJson = json_encode( $result['responsesField'] );
			if(count($result['responsesField']['responses']) && '[]' != $textValueOfJson ) {
				$userSurvey->setResponsesField( $textValueOfJson );
				$userSurvey->setResponsesCount( count( $result['responsesField']['responses'] ) );
			}else{
				$userSurvey->setResponsesField( '' );
				$userSurvey->setResponsesCount( 0 );
			}
			$dt = new \DateTime("@".time());
			$dt->setTimeZone( $this->timeZone );
			$userSurvey->setResponsesUpdated($dt);
			if( $userSurvey ) $this->userSurveyRepository->update( $userSurvey );
	}

	/**
	* updateSelfAssessmentField
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @param array $selfAssessmentInput
	* @return int
	*/
	public function updateSelfAssessmentField(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey , $selfAssessmentInput )
	{
		if( !count( $selfAssessmentInput ) ) return false;
		$templateDataUtility = new \Mff\MffLsb\Utility\TemplateDataUtility();
		$updateCounter = 0;
		$questionsFieldValue = $templateDataUtility->repairMacCharset( $userSurvey->getTemplateGroupOptions() );
		$xmlDb = json_decode( $questionsFieldValue , true);
		if(!count($xmlDb)) return false;
		
		foreach($xmlDb as $gid=>$grp){
		      foreach($xmlDb[$gid]['questions'] as $qid=>$quest){
			    if( !count($xmlDb[$gid]['subquestions'][$qid]) ) continue;
			    foreach($xmlDb[$gid]['subquestions'][$qid] as $sqid=>$subquest){
				    if(isset($selfAssessmentInput[$gid][$subquest['parent_qid']][$subquest['qid']])){
					$xmlDb[$gid]['subquestions'][$qid][$sqid]['self_assessment'] = $selfAssessmentInput[$gid][$subquest['parent_qid']][$subquest['qid']];
					++$updateCounter;
				    }
			    }
		      }
		}
		if($updateCounter){ 
		      $updatedTemplateGroupOptions =  json_encode( $xmlDb ) ;
		      $userSurvey->setTemplateGroupOptions( $updatedTemplateGroupOptions );
		}
		return $updateCounter;
	}

	/**
	* updateQuestionsField
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @param array $questionInput
	* @param array $ownCheckbox
	* @return int
	*/
	public function updateQuestionsField(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey , $questionInput , $ownCheckbox ) {
		if( !count( $questionInput ) && !count( $ownCheckbox ) ) return false;
		$updateCounter = 0;
		$templateDataUtility = new \Mff\MffLsb\Utility\TemplateDataUtility();
		$questionsFieldValue = $templateDataUtility->repairMacCharset( $userSurvey->getTemplateGroupOptions() );
		$xmlDb = json_decode( $questionsFieldValue , true);
		if(!count($xmlDb)) return false;

		foreach($xmlDb as $gid=>$grp){
		      foreach($xmlDb[$gid]['questions'] as $qid=>$quest){
			    if( !count($xmlDb[$gid]['subquestions'][$qid]) ) continue;
			    foreach($xmlDb[$gid]['subquestions'][$qid] as $sqid=>$subquest){
				    $valChk = $ownCheckbox[$gid][$subquest['parent_qid']][$subquest['qid']];
				    if(empty($valChk) && isset($ownCheckbox[$gid][$subquest['parent_qid']][$subquest['qid']])){
                            $xmlDb[$gid]['subquestions'][$qid][$sqid]['question'] ='';
                            ++$updateCounter;
				    }elseif(!isset($ownCheckbox[$gid][$subquest['parent_qid']][$subquest['qid']]) && '' !=trim($questionInput[$gid][$subquest['parent_qid']][$subquest['qid']])){
                            $xmlDb[$gid]['subquestions'][$qid][$sqid]['question'] = $questionInput[$gid][$subquest['parent_qid']][$subquest['qid']];
                            ++$updateCounter;
				    }elseif($valChk){
                            $xmlDb[$gid]['subquestions'][$qid][$sqid]['question'] = $questionInput[$gid][$subquest['parent_qid']][$subquest['qid']];
                            ++$updateCounter;
				    }
			    }
		      }
		}
		if($updateCounter){ 
		      $updatedTemplateGroupOptions =  json_encode( $xmlDb ) ;
		      $userSurvey->setTemplateGroupOptions( $updatedTemplateGroupOptions );
		}
		return $updateCounter;
	}

	/**
	* isSurveyExpiredByDate
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return boolean
	*/
	public function isSurveyExpiredByDate(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey ){
	    $startDate = $userSurvey->getStartDate();
	    $expireDays = 1+$userSurvey->getExpireDays();

	    $startDate->setTimeZone($this->timeZone); 
	    
	    $enddate = new \DateTime( $startDate->format('Y-m-d H:i:s') , $this->timeZone );
	    $enddate->add(new \DateInterval('P'.$expireDays.'D'));
// 	    $enddate->setTimeZone($this->timeZone);
		  
	    $expired = time() > $enddate->format('U') ? 1 : 0;
	    return $expired;
	}

	/**
	* isSurveyActive
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @param boolean $ignoreExpired
	* @return boolean
	*/
	public function isSurveyActive(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey , $ignoreExpired=false ){
	    $survey_state = $userSurvey->getSurveyState();
	    $survey_uid = $userSurvey->getSurveyUid();
	    
	    if($ignoreExpired) return ( !empty($survey_uid) && $survey_state == 2 ) ? 1 : 0;
	    
	    $expiredByDate = $this->isSurveyExpiredByDate($userSurvey);
	    
	    return ( empty($expiredByDate) && !empty($survey_uid) && $survey_state == 2 ) ? 1 : 0;
	}

	/**
	* isUpdateAffored
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @param boolean $lookUpIfActive
	* @ignorevalidation $userSurvey
	* @return boolean
	*/
	public function isUpdateAffored(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey , $lookUpIfActive = true){
	    $participCount = $userSurvey->getParticipCount();
	    $answersCount = $userSurvey->getResponsesCount();
	    
	    $isSurveyActive = $lookUpIfActive ? $this->isSurveyActive($userSurvey) : 1;
	    // dont update if last update younger than 1 minute
	    $dtLast = $userSurvey->getResponsesUpdated();
	    if( $this->settings['autoupdate_after_minutes'] > 0 ){
		  if($dtLast){
			$dtLast->setTimeZone( $this->timeZone );
			$dtNow = new \DateTime("@".time() , $this->timeZone );
// 			$dtNow->setTimeZone( $this->timeZone );
			$overdue = ( $dtNow->format('U') > ( 60 * $this->settings['autoupdate_after_minutes'] ) + $dtLast->format('U') ) ? 1:0;
		  }else{
			$overdue = 1;
		  }
	    }else{
		  $overdue = 0;// not 0?
	    }
	    if( 1 == $userSurvey->getEnquirerType() && $answersCount >= $participCount ) $participCount = 1+$answersCount;
	    $affored = ( $overdue && $isSurveyActive && $answersCount < $participCount ) ? 1 : 0;
	    return  $affored;
	}

	/**
	  * repairDate
	  *
	  * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	  * @return void
	  */
	public function repairDate(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){
	    $startdt = $this->repairDateTime($userSurvey->getStartDate());
	    $userSurvey->setStartDate( $startdt ); 
	}
	
	/**
	  * repairDateTime
	  *
	  * @param DateTime $startdt
	  * @return void
	  */
	public function repairDateTime($startdt){
	    $startdt->setTimeZone( $this->timeZone );
	    return $startdt;
	    $hower = $startdt->format('H');
	    if( 0 + $hower < 6 ){
		  $startdt->add(new \DateInterval('PT'.$startdt->getOffset().'S'));
   	    }
	    return $startdt;
	}
	
	/**
	  * getUSformattedDateString
	  * transforms CH date d.m.yy an dd.mm.yyyy to USA-formatted Date YYYY-MM-DD
	  *
	  * @param string $dateString
	  * @return void
	  */
	public function getUSformattedDateString( $dateString ){
		$aDate = explode( '.' , $dateString );
		if( strlen($aDate[2]) <= 2 ) $aDate[2]+=2000;
		$niceUSAdate = $aDate[2] . '-' . sprintf('%02d',$aDate[1]) . '-' . sprintf('%02d',$aDate[0]);
		return $niceUSAdate;
	}
	
	/**
	  * getFlexformData
	  *
	  * @return array
	  */
	public function getFlexformData() {
	    // Get the data from content-object (contains the tt_content fields)
	    $data = $this->configurationManager->getContentObject()->data;

	    // Append flexform values
	    $this->configurationManager->getContentObject()->readFlexformIntoConf($data['pi_flexform'], $data);
		    
	    $data['mainPartials'] = array_flip(explode( ',' , trim( trim( $data['elemente'] , ',' ) ) ));
	    //asort($data['mainPartials']);
	    return $data;
	}
}
