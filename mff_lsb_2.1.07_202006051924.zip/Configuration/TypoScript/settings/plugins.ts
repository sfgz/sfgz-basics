plugin.tx_mfflsb_template = USER_INT
plugin.tx_mfflsb_template {
	view {
		templateRootPaths.0 = EXT:mff_lsb/Resources/Private/Templates/
		partialRootPaths.0 = EXT:mff_lsb/Resources/Private/Partials/
		layoutRootPaths.0 = EXT:mff_lsb/Resources/Private/Layouts/
	}
	persistence {
		storagePid = {$plugin.tx_mfflsb_template.persistence.storagePid}
		#recursive = 1
	}
	settings {
		storagePid = {$plugin.tx_mfflsb_template.persistence.storagePid}
        calendar {
            ## url inclusive format and tag-query
            url =  {$plugin.tx_mfflsb_template.settings.url}

            ## mark as period border if subject matches to one of the words in list (case insensitive)
            period_keywords {
                    Sportferien = FS
                    Sommerferien = HS
            }

            ## exclude: exclude from import if calendar-item matches one of the following conditions
            ## as operands use AND(&&), OR(||), EQUAL(==), and NOT(!=) or the german pendants UND ODER NICHT/UNGLEICH and GLEICH
            ## for date values use jahr_ab(Y), monat_ab(m), tag_ab, datum_ab(Ymd), stunde_ab(H), minute_ab(i) and pendant with *_bis
            exclude {
                schulTerminMorgen = stunde_ab >= 8 UND stunde_bis <= 12
                schulTerminAbMorgen = stunde_ab >= 8 UND stunde_ab <= 12
                Sportwoche = strpos( anlass , 'portwoche' ) > 0
                Weiterbildung = strpos( anlass , 'eiterbildung' ) > 0
                ## ohneFerien = strpos( anlass , 'ferien' ) < 1
                ## mehrereTage = datum_ab UNGLEICH datum_bis
            }
        }
		keymap {
				mandatory {
					0 = N
					1 = Y
				}
				format {
					0 = A
					1 = G
					2 = S
				}
				type {
					1 = T
					2 = Q
					3 = F
					4 = X
				}
		}
		limesurvey_maxlength_question_title = 20
		upload_dir = uploads/tx_mfflsb/documents/
		fill_confirmation_data = 0
		show_questiontype_in_preview = 1
		# map Typo3 Properties to LimeSurvey Xml Fields 
		# lsXmlGroup.lsXmlField = typo3dbTable.dbField
		defaultPropertiesLimeSurveyXml {
				surveys.language = de
				surveys.assessments = Y
				surveys.showwelcome = N
				surveys.anonymized = N
				surveys.showprogress = N
				surveys.template = mff_default
				surveys.adminemail = ##ADMINEMAIL##
				surveys.admin = ##ADMIN##
				surveys_languagesettings.surveyls_language = de
		}
		mapPropertiesToLimeSurveyXml {
				surveys.sid = uid
				surveys.format = page_format
				surveys.printanswers = printanswers
				surveys_languagesettings.surveyls_survey_id = uid
				surveys_languagesettings.surveyls_title = raw_title
				surveys_languagesettings.surveyls_description = description
				surveys_languagesettings.surveyls_welcometext = welcome_text
				surveys_languagesettings.surveyls_endtext = end_text
		}
		specchars {
				laquo = 171
				raquo = 187
				copy = 169
				registered = 174
				at = 64
		}
		empty_subquests {
				1 = 1
				2 = 0
				3 = 0
				4 = 1
		}
		lsFieldKeywords {
				set_as_blank  = SET_BLANK
				set_as_title_only = NOT_SET
		}
		lsBaseFields {
				LimeSurveyDocType = Survey
				DBVersion = 178
				languages {
						language = de
				}
		}
		lsFields {
			answers {
				qid =
				code =
				answer =
				sortorder =
				assessment_value =
				language = de
				scale_id = 0
			}
			groups {
				gid = 
				sid = 998
				group_name = 
				group_order =
				description = SET_BLANK
				language = de
				randomization_group = SET_BLANK
				grelevance = SET_BLANK
			}
			questions {
				qid =
				parent_qid = 0
				sid = 998
				gid =
				type =
				title =
				question =
				preg = SET_BLANK
				help = SET_BLANK
				other = N
				mandatory = 
				question_order =
				language = de
				scale_id = 0
				same_default = 0
				relevance = 1
				label_input_columns = 5
				text_input_columns = 7
			}
			subquestions {
				qid = 
				parent_qid = 
				sid = 998
				gid = 
				type = T
				title = 
				question = 
				preg = NOT_SET
				help = NOT_SET
				other = N
				mandatory = 
				question_order = 
				language = de
				scale_id = 0
				same_default = 0
				relevance = NOT_SET
			}
			question_attributes {
				qid = 
				attribute = 
				value = 
				language = NOT_SET
			}
			surveys {
				sid = 314315
				admin = Administrator
				expires = 
				startdate = 
				adminemail = daten@sfgz.ch
				anonymized = N
				faxto = SET_BLANK
				format = A
				savetimings = N
				template = mff_weiterbildung
				language = de
				additional_languages = SET_BLANK
				datestamp = N
				usecookie = N
				allowregister = N
				allowsave = N
				autonumber_start = 0
				autoredirect = N
				allowprev = Y
				printanswers = Y
				ipaddr = N
				refurl = N
				publicstatistics = N
				publicgraphs = N
				listpublic = N
				htmlemail = Y
				sendconfirmation = N
				tokenanswerspersistence = N
				assessments = Y
				usecaptcha = D
				usetokens = N
				bounce_email = umfragen@sfgz.ch
				attributedescriptions = NOT_SET
				emailresponseto = SET_BLANK
				emailnotificationto = SET_BLANK
				tokenlength = 15
				showxquestions = Y
				showgroupinfo = G
				shownoanswer = Y
				showqnumcode = X
				bouncetime = NOT_SET
				bounceprocessing = N
				bounceaccounttype = NOT_SET
				bounceaccounthost = NOT_SET
				bounceaccountpass = NOT_SET
				bounceaccountencryption = NOT_SET
				bounceaccountuser = NOT_SET
				showwelcome = Y
				showprogress = N
				questionindex = NOT_SET
				navigationdelay = 0
				nokeyboard = N
				alloweditaftercompletion = Y
				googleanalyticsstyle = 0
				googleanalyticsapikey = SET_BLANK
			}
			surveys_languagesettings {
				surveyls_survey_id = 998
				surveyls_language = de
				surveyls_title = 
				surveyls_description = 
				surveyls_welcometext = 
				surveyls_endtext = 
				surveyls_url =  = SET_BLANK
				surveyls_urldescription = SET_BLANK
				surveyls_email_invite_subj = 
				surveyls_email_invite = 
				surveyls_email_remind_subj = 
				surveyls_email_remind = 
				surveyls_email_register_subj = 
				surveyls_email_register = 
				surveyls_email_confirm_subj = 
				surveyls_email_confirm = 
				surveyls_dateformat = 1
				surveyls_attributecaptions = NOT_SET
				email_admin_notification_subj = 
				email_admin_notification = 
				email_admin_responses_subj = 
				email_admin_responses = 
				surveyls_numberformat = 1
				attachments = NOT_SET
			}
		}
		spider {
				radius = 288
				text_inset {
					x = -20
					y = -10
				}
				image_position {
					left = 50
					top = 15
				}
		}
		use_pdf_basics = 0
# 
# page-headlines in array HeaderTexts
# 
# options for parts of layout:
# layout.report
# - abstract summary 
# - aggregation analyse:textarea,text,matrix
# - spider
# layout.sinlges
# - intro summaryForSingle
# - Single textarea,text,matrix,label 
# 
# status views options:
# - nodata handout empty: PdfPrintout->pdfTemplate nodata+usersurvey
# - printout handout with data: PdfPrintout->pdfTemplate printout+usersurvey
# - report with data and answers PdfReport->pdfReport pdf_basic+usersurvey
# 
# configuration select:
# - Grundbildung pdf_basics.0.report+printout+nodata+usersurvey
# - Kurse pdf_basics.1.report+printout+nodata+usersurvey
# - Lehrgaenge pdf_basics.2.report+printout+nodata+usersurvey
#
		pdf_basics.0 {
			index = 0
			FilenamePrefix = Auswertung_
			FilenameBody = ##KURS_KLASSE##_##KURS_NAME##_##START_DATUM##
			FilenameReplacing {
				search{
					0 = .
					1 = /
					2 = :
					3 = ,
					4 = +
				}
				replace {
					0 = -
					1 = -
					2 = -
					3 = _
					4 = _
				}
			}
			Creator = http://umfragen.sfgz.ch
			Title = Unterrichtsbeurteilung
			Subject = Online-Version der «Auswertung Unterrichtsbeurteilung Lernende»
			Author = BfGZ, ###USER_NAME###
			TopMargin = 33
			LeftMargin = 21.5
			RightMargin = 9
			BottomMargin = 15
			docuwidth = 210
			cellwidthPoints = 8
			lfeed = 5
			slfeed = 5
			fontFamilyHead = Helvetica
			fontFamilyFoot = Helvetica
			HeaderText = Lernenden-Feedback | Auswertung
			HeadLine.rows = 125.5 , 8 , 8 , 8 , 8 , 22
			HeadLine.method = grundbildungHeader
			FooterTopLeft = Lernenden-Feedback vom ##START_DATUM##
			FooterTopRight = ##KURS_NAME## bei ##LEITUNG_NAME##
			FooterBottomLeft = __C__ Schule für Gestaltung Zürich | Gedruckt am __DATE__
			FooterBottomRight = Seite __PAGE__ | ##KURS_KLASSE##
			matrixTitle = 
			summaColumnLabels {
				2 = Erreicht
				4 = Note
				6 = Erreicht/Note
				7 = Bemerkung
			}
			layout {
				report {
					data = 
					1.0 = Summary
					1.1 = Analyse:Matrix,Text-title,Textarea-title
					2.0 = Spider
					3.0 = Analyse:Text
					4.0 = Analyse:Textarea
				}
				singles {
					data = usersurvey
					4.2 = Singles
				}
			}
			SummaryTitle = Zusammenfassung
			SummaryLineConf {
				width = 0.15
				color = 0,0,0
				dash = 0.15 , 0.6
			}
			SummaryRows {
				0 {
					width = 25,68,5.5,16,65
					0.0 = leitungname,##LEITUNG_NAME##
					0.1 = 
					0.2 = startdate,##START_DATUM##
					1.0 = kursklasse,##KURS_KLASSE##
					1.1 = 
					1.2 = kursname,##KURS_NAME##
				}
				2 {
					width = 25,68
					0.0 = Methode,##TEMPLATE_NAME##
				}
				1 {
					width = 32,7,4,43,7
					align = L,C,e,L,C,e,L,C
					0.0 = participcount,##ANZAHL_TEILNEHMENDE##
					0.1 = 
					0.2 = responsescount,##ANZAHL_ANTWORTEN##
				}
			}
		}

		pdf_basics.1 < plugin.tx_mfflsb_template.settings.pdf_basics.0
		pdf_basics.1 {
			index = 1
			FilenameBody = ##KURS_KLASSE##_##KURS_NAME##_##SEMESTER##
			Title = 3.5.01.02 FO Auswertung Kursbewertung
			Subject = Auswertung der Bewertungen durch Teilnehmende
			TopMargin = 33
			LeftMargin = 18
			RightMargin = 20
			lfeed = 5
			slfeed = 5
			fsize = 9
			fontFamilyHead = Helvetica
			fontFamilyFoot = Helvetica
			HeaderText = Auswertung Kursbewertung
			HeaderTexts {
				3.4 = Unterrichtsentwicklung Kurse evaluieren
				4.3 = 3.5.1.2
				4.4 = Auswertung Kursbewertung
				5.5 = Anzahl Teilnehmende
			}
			HeadLine.rows = 78,7,1,15,71
			HeadLine.method = weiterbildungHeader
			FooterTopLeft = Kursbewertung
			FooterBottomLeft = __C__ Schule für Gestaltung Zürich | Gedruckt am __DATE__
			FooterTopRight = Kurs ##KURS_KLASSE## bei ##LEITUNG_NAME##
			FooterBottomRight = ##ANZAHL_ANTWORTEN## Personen | Seite __PAGE__
			FirstPageFooter.0 = 
			FirstPageFooter.1 = 
			FirstPageFooter.2 = 
			layout.report.1.1 = Analyse:Matrix,Textarea-title
			layout.report.1.2 = Footer
			layout.report.2.0 >
			matrixTitle = A Auswertung
			ReportFooter.fsize = 9.5
			ReportFooter.lines_min = 8
			ReportFooter.lines_max = 20
			ReportFooter.line_conf {
				width = 0.15
				color = 0,0,0
				dash = 0.15 , 0.6
			}
			ReportFooter.spacing = 5
			ReportFooter.cols.0.title = B Analyse
			ReportFooter.cols.1.title = C Interpretation
			ReportFooter.rows.0 = Kopie der Auswertung bitte innerhalb von 14 Tagen nach Abschluss des Kurses an das
			ReportFooter.rows.1 = Sekretariat Weiterbildung. Original an der nächsten Mitarbeiterbeurteilung vorlegen.
			SummaryTitle = 
			SummaryRows {
				0 > 
				1 > 
				2 > 
				5 {
					width = 34,138
					0.0 = kursklasse,##KURS_KLASSE##-##SEMESTER## ##KURS_NAME##
				}
				6 {
					width = 34,66,1,37,34
					0.0 = leitungname,##LEITUNG_NAME##
					0.1 = 
					0.2 = semester_datum,##SEMESTER## / ##START_DATUM##
				}
				7 {
					width = 34,66,1,41,30
					1.0 = responsescount,##ANZAHL_ANTWORTEN##
					1.1 = 
					1.2 >
				}
			}
			
		}
		
		pdf_basics.2 < plugin.tx_mfflsb_template.settings.pdf_basics.1
		pdf_basics.2 {
			index = 2
			Title = 3.5.01.02 FO Auswertung Semesterbewertungen
			fontFamilyHead = Helvetica
			fontFamilyFoot = Helvetica
			lfeed = 5
			slfeed = 5
			fsize = 9
			HeaderText = Auswertung Semesterbewertungen
			HeaderTexts {
				3.3 = 3.5.2
				3.4 = Unterrichtsentwicklung Lehrgänge evaluieren
				4.3 = 3.5.2.2
				4.4 = Auswertung Semesterbewertungen
				5.5 = Anzahl Teilnehmende
			}
			FooterTopLeft = Semesterbewertung
			FooterTopRight = ##KURS_KLASSE## | ##LEITUNG_NAME##
			FooterBottomRight =  Seite __PAGE__
			matrixTitle = A Auswertung
			layout.report.1.1 = Analyse:Matrix,Textarea-title
			layout.report.1.2 = Footer
			layout.report.2.0 >
			SummaryRows.7.1.0 = responsescount,##ANZAHL_ANTWORTEN##
			SummaryRows.7.1.1 >
			SummaryRows.7.1.2 >
			ReportFooter.fsize = 9.5
			ReportFooter.lines_min = 8
			ReportFooter.lines_max = 20
			ReportFooter.line_conf {
				width = 0.15
				color = 0,0,0
				dash = 0.15 , 0.6
			}
			ReportFooter.spacing = 5
			ReportFooter.cols.0.title = B Analyse
			ReportFooter.cols.1.title = C Interpretation
			ReportFooter.rows.0 = Kopie der Auswertung bitte innerhalb von 14 Tagen der Lehrgangsleitung zustellen. Original an der nächs-
			ReportFooter.rows.1 = ten Mitarbeiterbeurteilung vorlegen. In digitaler oder analoger Form sechs Jahre lang aufbewahren.
			FirstPageFooter.0 = 
			FirstPageFooter.1 = 
			FirstPageFooter.2 = 
		}
# pdf_dynamic overrides pdf_basics. 
# For 'printout' and 'nodata' only, 
# The config for 'reports' (with answers) will not be touched.
		pdf_dynamic.0 {
				printout < plugin.tx_mfflsb_template.settings.pdf_basics.0
				nodata < plugin.tx_mfflsb_template.settings.pdf_basics.0
				usersurvey < plugin.tx_mfflsb_template.settings.pdf_basics.0
				printout {
					pdfDynamicIndex = printout
					FilenamePrefix = Vorlage_
					Subject = «Fragebogen Unterrichtsbeurteilung Lernende»
					FooterBottomRight =  ##KURS_KLASSE##
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
				}
				nodata {
					pdfDynamicIndex = nodata
					FilenamePrefix = Vorlage_
					FilenameBody = ##TEMPLATE_NAME##
					FooterTopLeft = 
					FooterTopRight = 
					FooterBottomLeft = __C__ Schule für Gestaltung Zürich
					FooterBottomRight = Gedruckt am __DATE__ | Lernenden-Feedback
					BottomMargin = 10.5
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
				}
				usersurvey {
					pdfDynamicIndex = usersurvey
					HeaderText = Lernenden-Feedback | Fragebogen
					SummaryTitle = ##TEMPLATE_NAME##
					SummaryRows.1 >
					SummaryRows.2 >
					cellwidthPoints = 8
				}
		}
		pdf_dynamic.1 {
				printout < plugin.tx_mfflsb_template.settings.pdf_basics.1
				nodata < plugin.tx_mfflsb_template.settings.pdf_basics.1
				usersurvey < plugin.tx_mfflsb_template.settings.pdf_basics.1
				printout {
					pdfDynamicIndex = printout
					FilenamePrefix = Vorlage_
					SummaryTitle = 
					Subject = «Fragebogen Kursbewertung Teilnehmer/innen»
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
					SummaryRows.6.0.2 = semester_datum,##SEMESTER## / 
				}
				nodata {
					pdfDynamicIndex = nodata
					FilenamePrefix = Vorlage_
					FilenameBody = ##TEMPLATE_NAME##
					FooterTopLeft = 
					FooterTopRight = 
					FooterBottomLeft = __C__ Schule für Gestaltung Zürich
					FooterBottomRight = Gedruckt am __DATE__ | Kursbewertung
					SummaryRows.5.0.0 = kursklasse,
					SummaryRows.6.0.2 = semester_datum,
					BottomMargin = 10.5
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
				}
				usersurvey {
					pdfDynamicIndex = usersurvey
					SummaryTitle = 
					SummaryRows.6.0.2 = semester_datum,##SEMESTER##
					SummaryRows.7.1 >
					HeaderText = Fragebogen Kursbewertung
					cellwidthPoints = 8
					matrixTitle =
				}
		}
		pdf_dynamic.2 {
				printout < plugin.tx_mfflsb_template.settings.pdf_basics.2
				nodata < plugin.tx_mfflsb_template.settings.pdf_basics.2
				usersurvey < plugin.tx_mfflsb_template.settings.pdf_basics.2
				printout {
					pdfDynamicIndex = printout
					FilenamePrefix = Vorlage_
					FilenameBody = ##TEMPLATE_NAME##
					Subject = «Fragebogen Semesterbewertungen Teilnehmer/innen»
					FooterTopLeft = 
					FooterTopRight = 
					FooterBottomLeft = __C__ Schule für Gestaltung Zürich
					FooterBottomRight = Gedruckt am __DATE__ | Semesterbewertung
					BottomMargin = 10.5
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
				}
				nodata {
					pdfDynamicIndex = nodata
					FilenamePrefix = Vorlage_
					FilenameBody = ##TEMPLATE_NAME##
					Subject = «Fragebogen Semesterbewertungen Teilnehmer/innen»
					FooterTopLeft = 
					FooterTopRight = 
					FooterBottomLeft = __C__ Schule für Gestaltung Zürich
					FooterBottomRight = Gedruckt am __DATE__ | Semesterbewertung
					SummaryRows.5.0.0 = kursklasse,
					SummaryRows.6.0.2 = semester_datum,
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
				}
				usersurvey {
					pdfDynamicIndex = usersurvey
					HeaderText = Fragebogen Semesterbewertungen
					SummaryTitle = 
					SummaryRows.6.0.2 = semester_datum,##SEMESTER##
					SummaryRows.7.1 >
					cellwidthPoints = 8
					matrixTitle =
				}
		}
		
		pdf_basics.0.printout < plugin.tx_mfflsb_template.settings.pdf_dynamic.0.printout
		pdf_basics.0.nodata < plugin.tx_mfflsb_template.settings.pdf_dynamic.0.nodata
		pdf_basics.0.usersurvey < plugin.tx_mfflsb_template.settings.pdf_dynamic.0.usersurvey
		
		pdf_basics.1.printout < plugin.tx_mfflsb_template.settings.pdf_dynamic.1.printout
		pdf_basics.1.nodata < plugin.tx_mfflsb_template.settings.pdf_dynamic.1.nodata
		pdf_basics.1.usersurvey < plugin.tx_mfflsb_template.settings.pdf_dynamic.1.usersurvey

		pdf_basics.2.printout < plugin.tx_mfflsb_template.settings.pdf_dynamic.2.printout
		pdf_basics.2.nodata < plugin.tx_mfflsb_template.settings.pdf_dynamic.2.nodata
		pdf_basics.2.usersurvey < plugin.tx_mfflsb_template.settings.pdf_dynamic.2.usersurvey
	}
}


plugin.tx_mfflsb_survey = USER_INT
plugin.tx_mfflsb_survey {
  view {
    templateRootPaths.0 = EXT:mff_lsb/Resources/Private/Templates/
    partialRootPaths.0 = EXT:mff_lsb/Resources/Private/Partials/
    layoutRootPaths.0 = EXT:mff_lsb/Resources/Private/Layouts/
  }
  persistence {
    storagePid = {$plugin.tx_mfflsb_survey.persistence.storagePid}
    periodsStoragePid = {$plugin.tx_mfflsb_survey.persistence.periodsStoragePid}
	classes{
		Mff\MffLsb\Domain\Model\UserSurvey {
			newRecordStoragePid = {$plugin.tx_mfflsb_survey.persistence.storagePid}
		}
	}
  }
    settings < plugin.tx_mfflsb_template.settings
    settings {
        lsBaseUrl = {$plugin.tx_mfflsb_survey.settings.lsBaseUrl}
        lsUsername = {$plugin.tx_mfflsb_survey.settings.lsUsername}
        lsPassword = {$plugin.tx_mfflsb_survey.settings.lsPassword}
        urlpath = /survey/index/sid/
        shortpath = /unterricht/
        # token auch in der Datei .htaccess unterhalb umfragen.xx.ch anpassen!
        token = pin
        anonymous {
                    token = klasse
                    firstname = Anonyma
                    lastname = Nonames
                    email = daten@sfgz.ch
                    usesleft = 100
                    used = 0
        }
        useroptions.sumtypes = 6
        autoupdate_after_minutes = 0
        barcode_size = 7
        particip.examples {
                1 {
                    name = Eva Roth
                    email = eva.roth@blau.ch
                }
                2 {
                    name = Joseph-Marie_Charles Jacquard
                    email = jac@gelb.com
                }
        }
    }
}

plugin.tx_mfflsb_remote = USER_INT
plugin.tx_mfflsb_remote {
	view {
			templateRootPaths.0 = EXT:mff_lsb/Resources/Private/Templates/
			partialRootPaths.0 = EXT:mff_lsb/Resources/Private/Partials/
			layoutRootPaths.0 = EXT:mff_lsb/Resources/Private/Layouts/
	}
	persistence {
			storagePid = {$plugin.tx_mfflsb_survey.persistence.storagePid}
			classes{
				Mff\MffLsb\Domain\Model\UserSurvey {
					newRecordStoragePid = {$plugin.tx_mfflsb_survey.persistence.storagePid}
				}
			}
	}
    settings < plugin.tx_mfflsb_survey.settings
    settings {
            anonymous.token = kurs
            use_pdf_basics = 1
            days_before_start = 0
            semesterYearsPassed = {$plugin.tx_mfflsb_survey.settings.semesterYearsPassed}
            firstname_lastname = {$plugin.tx_mfflsb_survey.settings.firstname_lastname}
            anonymous_accounts {
                    10 = .nn
                    20 = ref
            }
            ## sumtypes: 1=none, 2=nurProzent, 4=nurNote, 6=ProzUndNote
            useroptions.sumtypes = 2
            useroptions.foreignTimetable = 1
            useroptions.listlength = 10
            useroptions.period = 1
            useroptions.manualmailcopy = 2
            useroptions.default_black_copy = 1
            useroptions.default_black_copy_reminder = 0
            mail {
                unlock = 1
                fix_invitation_from = weiterbildung@sfgz.ch
                use_fix_invitation = 0 
                presentation.link_label = Link pr&auml;sentieren
                pdf_request.link_label = Auswertung anfordern
                sender_adress = umfragen@sfgz.ch
                sender_text.subject = Auswertung der Unterrichtsbeurteilung (##KURS## | ##FACH##)
                sender_text.body = Guten Tag ##NAME## <br /> Im Anhang befindet sich die Auswertung der Umfrage  "##KURS## | ##FACH##"
                sender_footer.0 = <p style="font-family:Helvetica,Arial,sans-serif;font-size:85%;font-style:italic;">
                sender_footer.1 = Diese Nachricht wurde &uuml;ber Email angefordert und automatisch generiert. 
                sender_footer.2 = Ignorieren Sie sie, falls Sie diese Auswertung nicht selbst angefordert haben,
                sender_footer.3 = oder kontaktieren Sie die Administration der Umfrage: ##ADMIN_NAME##, ##ADMIN_EMAIL##.
                sender_footer.4 = </p>
                reminder_text.subject = Erinnerung
                reminder_text.body = Diese Erinnerung wurde automatisch erstellt, weil ihre Umfrage noch nicht beantwortet wurde. Bitte denken Sie daran, die Umfrage in den n&auml;chsten Tagen durchzuf&uuml;hren.<br /><br />
                printout_reminder_text.subject = 
                printout_reminder_text.body = 
                logo {
                        path = typo3conf/ext/mff_lsb/Resources/Public/Icons/
                        imagename = logo.svg
                        image_width = 280
                        wrap_image = <br /><p><a href="http://www.sfgz.ch" style="text-decoration:none;color:#333;">|</a></p>
                        wrap_signature_neutral (
                                <br><span style="color:#333;font-size:10pt;font-family:Helvetica,Arial,sans-serif;">
                                <b>Schule für Gestaltung Zürich</b><br>Weiterbildungssekretariat<br>Ausstellungsstrasse 104<br>8090 Zürich
                                #telephone#</span><p><a href="http://www.sfgz.ch" style="text-decoration:none;color:#333;">|</a></p>
                        )
                        wrap_signature (
                                <br><span style="color:#333;font-size:10pt;font-family:Helvetica,Arial,sans-serif;">
                                <b>Schule für Gestaltung Zürich<br>#title##vorname# #nachname#</b><br>#fachbereich##fachbereiche#Ausstellungsstrasse 104<br>8090 Zürich
                                #telephone#</span><p><a href="http://www.sfgz.ch" style="text-decoration:none;color:#333;">|</a></p>
                        )
                }
                notification_subject.0 = Maildämon hat 1 Nachricht gesendet
                notification_subject.1 = Maildämon hat ##EX## Nachrichten gesendet
            }
    }
}
