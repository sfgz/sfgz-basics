<INCLUDE_TYPOSCRIPT: source="FILE:EXT:mff_lsb/Configuration/TypoScript/settings/plugins.ts">

# the file on top file contains the setting for 3 plugins:
#  plugin.tx_mfflsb_template
#  plugin.tx_mfflsb_survey
#  plugin.tx_mfflsb_remote

# dialog pages for direct calls when running remote-survey
distant_survey = PAGE
distant_survey {
    shortcutIcon = typo3conf/ext/sfgz_design/Resources/Public/Img/Web/favicon.ico
    config {
        debug = 0
        no_cache = 1
    }
    typeNum = 43

    headerData.1110 = COA_INT
    headerData.1110 {
        wrap = <title>|</title>
            10 = USER_INT
            10.userFunc = Mff\MffLsb\Utility\DialogUtility->showObjectTitle
    }
    
    5 = COA_INT
    5.wrap = <div id="standalone_main">|</div>
    
    5.10 = COA_INT
    5.10.wrap = <div class="standalone_headline">|</div>
    5.10.10 = IMAGE
    5.10.10.file = typo3conf/ext/mff_lsb/Resources/Public/Icons/logo.svg
    5.10.10.params = alt="sfgz-logo"
    
    5.20 = COA_INT
    5.20.10 = USER_INT
    5.20.wrap = <div class="standalone_content">|</div>
    5.20.10.userFunc = Mff\MffLsb\Utility\DialogUtility->showObjectData

}

## preview from choosen template with questions and options
json_survey = PAGE
json_survey {
    config {
        disableAllHeaderCode = 1
        debug = 0
        no_cache = 1
        additionalHeaders {
            10 {
                header = Content-Type: application/json
                replace = 1
            }
        }
    }
    typeNum = 1489891401
    10 = COA_INT
    10 {
        10 = RECORDS
        10 {
            tables = tt_content
            source = {GP:cnt}
            source.insertData = 1
            source.insertData.intval = 1
        }
    }
}

[globalVar = GP:type=1489891401]
    tt_content.list.20.stdWrap.prefixComment = 
    tt_content.stdWrap.prefixComment =
    tt_content.stdWrap.innerWrap.cObject.default = 
    lib.stdheader >
[global]


# JS  einbinden
# page.includeJSFooter.lsb_helpers = EXT:mff_lsb/Resources/Public/script/mfflsb_helper.js

# js for tx_sfgzkurs_conf
# editConfigUrl
config.removeDefaultJS = external
page.jsInline.13 = TEXT
page.jsInline.13 {
	value (
        function getSurveyFromTemplate( URL ,  uid , insertObj ) {
            if( uid == '' ) {$('#' + insertObj).html('');return false;}
            $.ajax({
                url : URL,
                type : 'GET',
                data : {
                    'uid' : uid 
                },
                dataType:'html',
                success : function(data) {
                    $('#' + insertObj).html(data);
                },
                error : function(request,error)
                {
                    alert("Request " + error + ": "+JSON.stringify(request));
                }
                });
            }

            function backgroundSubmitForm( URL , formId ) {
            $.ajax({
                url : URL,
                type : 'POST',
                data : $('#' + formId).serialize(),
                success : function(data) {
                    window.location = URL;
                },
                error : function(request,error)
                {
                    return false;
                }
                });
            }

            function backgroundUpdateValue( URL , table , selId ) {
            opt = {};
            opt[selId] = $('#' + selId).val();
            usropt = {};
            usropt[table] = opt;
            usropt['table'] = table;
            $.ajax({
                url : URL,
                type : 'POST',
                data: usropt,
                success : function(data) {
                },
                error : function(request,error)
                {
                    alert('error: ' + URL + " Request " + error + ": "+JSON.stringify(request));
                    return false;
                }
                });
        }
		
	)
}

plugin.tx_mfflsb._CSS_DEFAULT_STYLE (
    textarea.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }
    .listbox {
        clear:left;margin:2px 0 15px 0;padding:6px;background-color:#FFF;border-radius:4px;border:1px solid #555;width:auto;float:left;
    }
    input.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }
    .blackhover A:hover {color:#000;text-decoration:none;opacity:0.5;}
    .tx-mff-lsb table {
        border-collapse:separate;
        border-spacing:2px 3px; 
    }

    .tx-mff-lsb table th {
        font-weight:bold;
    }

    .tx-mff-lsb table td {
        /* vertical-align:top; */
    }

    .typo3-messages .message-error {
        color:red;
    }

    .typo3-messages .message-ok {
        color:green;
    }

    
    @font-face {
            font-family: "SFGZSansBlack";
            font-weight: 800;
            font-style: normal;
            src: url("../Fonts/Helvetica/2B6D49_0_0.eot");
            src: url("../Fonts/Helvetica/2B6D49_0_0.eot?#iefix") format("embedded-opentype"), url("../Fonts/Helvetica/2B6D49_0_0.woff") format("woff"), url("../Fonts/Helvetica/2B6D49_0_0.ttf") format("truetype");
    }
    @font-face {
        font-family: Helvetica Neue;
        src: url('../Fonts/Helvetica/HelveticaNeue-Roman.woff') format('woff');
    }

    html, *, ::before, ::after {
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
    }
   
    #standalone_main {margin:30px auto; width:auto;}
    #standalone_main .standalone_headline { text-align: center; }
    #standalone_main .standalone_content { text-align: center;  width:580px;margin:1px auto;}
    
    #standalone_main .chapta  { text-align: center; margin-left:20px; }
    #standalone_main .invitation  {  width:580px; text-align:left;}
    #standalone_main .message  { text-align: center; margin-left:20px; color: #777; }
    
    DIV.tx-mff-lsb .editform input[type=text] {
        width:auto;
    }
    BODY DIV.tx-mff-lsb H1, #content DIV.tx-mff-lsb H1, #content_main DIV.tx-mff-lsb H1 {
            font-size:11pt;
            font-weight:bold;
            background:#ddd;
            color:black;
            padding:4px 3px 1px 3px;
            margin:0;
            border:1px solid #888;
            border-bottom:1px solid #d0d0d0;
            border-right:1px solid #bbb;
            border-radius:3px 0 5px 0px;
            cursor:pointer;
    }
    #content_main DIV.tx-mff-lsb H1:hover {
            color:#888;
    }
    BODY DIV.tx-mff-lsb H1.maintitle, #content DIV.tx-mff-lsb H1.maintitle, #content_main DIV.tx-mff-lsb H1.maintitle {
            background:#ddd;
            color:#000;
            cursor:auto;
    }
    .question_edit { border-bottom:0px solid #aaa;margin:0;padding:0px;}
    BODY DIV.tx-mff-lsb H2 {
        font-size:10pt;border:1px solid #000;font-weight:bold;color:black;background:#ddd;padding:1px 3px 0px 18px;
    }
    BODY DIV.tx-mff-lsb .question_edit H2 { font-size:115%;border:0;background:white;color:black;padding:0.5em 0 0 0;text-decoration:underline;}
    .question_edit H3 { font-size:108%;padding:0.1em 0 0 0;}
    .question_edit H4 { font-size:100%;padding:0.1em 0 0 0;color:#555;}
    SPAN.required {font-style:italic;font-weight:bold;color:#888;padding:2px 3px;}
    DIV.editdatble {padding:5px 0;}
    .tx-mff-lsb TABLE.tx_mfflsb  {
    border: 0px solid #333;
    border-collapse:separate;
        border-spacing:0px; 
    }
    
    TABLE.tx_mfflsb A, TABLE.tx_mfflsb A:visited {color:#333;font-weight:normal;}
    TABLE.tx_mfflsb TR.sel A, TABLE.tx_mfflsb TR.sel A:visited {color:#009ee0;font-weight:normal;}
    .tx-mff-lsb TABLE.tx_mfflsb th {
        background-color:#eee;
        color:#666;
        border-top: 1px #888 solid;
        border-bottom: 1px #bbb solid;
        text-align:left;
        vertical-align:top;
        padding:2px 5px 1px 3px;
        font-style:italic;
    }
    .tx-mff-lsb TABLE.tx_mfflsb th:first-child { border-left:1px solid #e0e0e0; }
    .tx-mff-lsb TABLE.tx_mfflsb th:last-child { border-right:1px solid #f0f0f0; }
    .tx-mff-lsb TABLE.tx_mfflsb td {
        color:#666;
        border-left: 1px #EFEFEF solid;
        border-bottom: 1px #aaa dotted;
        border-top: 0;
        text-align:left;
        vertical-align:top;
        padding:3px 5px;
        font-size:13pt;
    }

    .tx-mff-lsb TABLE.tx_mfflsb td:first-child { border-left:0; }
    DIV.analyse {
    page-break-inside:avoid;
    }
    TABLE.analyse {
        page-break-inside:avoid;
        border: 1px solid #333;
        border-collapse:separate;
        border-spacing:0px;
        margin:0 0 2ex 0;
        background:#fff;
    }
    TABLE.analyse TD { border-left: 1px solid #333; }
    TABLE.analyse TD:first-child { border-left:0; }
    TABLE.analyse TD { border-top:1px dotted #aaa; }
    TABLE.analyse TR:first-child TD { border-top:0; }
    TABLE.analyse TR:nth-child(1) TD { border-top:1px solid #000; }
    TABLE.analyse TR.total TD { border-top:2px solid #000; }
    TABLE.analyse TR.total TD:nth-child(2) { border-left:1px solid #000; }
    TABLE.analyse TD.headrow { vertical-align:bottom; padding:2px 3px; font-size:95%;}
    TABLE.analyse THEAD TD.label { vertical-align:bottom; }
    TABLE.analyse TD.label { padding-left:18px;text-indent:-15px; text-align:left;width:42em; }
    TABLE.analyse TD.label.nth_row { padding-left:18px; text-indent:0px; text-align:left;width:42em; }
    TABLE.analyse TD.fullwidth { padding-left:2px; text-align:left;width:63em; }
    TABLE.analyse TD.rightwidth { width:21em; }
    TABLE.analyse TD.prozent, TABLE.analyse TD.punkte { text-align:center;  width:1px; }
    TABLE.analyse TD.note { text-align:left;padding-left:5px; }
    TABLE.analyse.standard TD.prozent, TABLE.analyse.standard TD.punkte { vertical-align:bottom;  }
    TABLE.analyse.standard TD.note { vertical-align:bottom; }
    TABLE.analyse TR.total TD.label, TABLE.analyse TR.total TD.punkte { font-style:italic; }
    TABLE.analyse TR.total TD.label, TABLE.analyse TR.total TD.prozent { font-style:italic; }
    TABLE.analyse TR.total TD.prozent, TABLE.analyse TR.total TD.note { padding-left:3px;padding-right:3px;font-weight:bold;border-left:1px solid #000; }
    TABLE.analyse TR.total.subtotal TD { border-width:1px;}
    TABLE.analyse TR.total.subtotal TD.punkte,
    TABLE.analyse TR.total.subtotal TD.prozent,
    TABLE.analyse TR.total.subtotal TD.note { font-style:normal; font-weight:normal; }
    TABLE.analyse TR.notalone TD.note, 
    TABLE.analyse TR.notalone TD.punkte, 
    TABLE.analyse TR.notalone TD.prozent { font-size:80%; color:#555;  border-width:1px; vertical-align:bottom; }
    TABLE.analyse TR.blankcell TD { border: 1px olid #CCC; border-width:1px 0 0 0; }
    .tx-mff-lsb TABLE.analyse.grouped TR.isalone TD.prozent, 
    .tx-mff-lsb TABLE.analyse.grouped TR.isalone TD.punkte, 
    .tx-mff-lsb TABLE.analyse.grouped TR.isalone TD.note {
    vertical-align:middle; 
    }
    
    .handwritten {font-family:courier;}
    .isboldX {font-weight:bold;}
    .isbold- {color:#888;}
    DIV.singles {
        page-break-inside:avoid;
        background:#ffc;
        padding:2ex;
        padding-bottom:0;
        margin:5px 2px;
        border:1px dotted #AAA;
    }
    A.black, A:visited.black { color:black; }
    A.black:hover {color:#555;}

    A.button, A:visited.button { border:2px outset #888; border-radius:3px; background:#efefef; margin:0; margin-right:5px; padding:2px 3px; }
    A.button:hover { border:2px inset #888; border-radius:3px; background:#fff; }
    
    A.add_record.black {color:black}
    A.add_record.black:hover {color:#555;}
    
    .page {padding:4px;margin-right:2px;border:1px solid #333;border-radius:3px;}
    TABLE.surveyedit {border-spacing:5px 5px; }
    .preview .obsolete { color:#888; }
    .isvisible_1 {}
    .isvisible_0 {display:none;}
    TABLE.nowrap TD {white-space:nowrap;overflow:visible;}
    TABLE.tx_mfflsb input[type=xxcheckbox]{
    position: relative;
    vertical-align: middle;
    bottom: 1px;
    }
    .tx-mff-lsb TABLE.editform TD:first-child {vertical-align:bottom;font-size:95%;}
    
    .tx-mff-lsb A.anzeigen_ {}    /* new record || deactivated+passed */
    .tx-mff-lsb A.anzeigen_:before, 
    .tx-mff-lsb .anzeigen_:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/clock_disabled.png);}
    .tx-mff-lsb A.anzeigen_0 {}  /* deactivated */
    .tx-mff-lsb A.anzeigen_0:before, 
    .tx-mff-lsb .anzeigen_0:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/bulb_offs.png);}
    .tx-mff-lsb A.anzeigen_1 {}  /* */
    .tx-mff-lsb A.anzeigen_1:before, 
    .tx-mff-lsb .anzeigen_1:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/bulb_ons.png);} 
    .tx-mff-lsb A.anzeigen_2 {} /* running */
    .tx-mff-lsb A.anzeigen_2:before, 
    .tx-mff-lsb .anzeigen_2:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/bulb_ons.png);} 
    .tx-mff-lsb A.anzeigen_3 {}  /* activated+passed */
    
    .tx-mff-lsb A.anzeigen_3:before, .tx-mff-lsb .anzeigen_3:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/clock_yellow.png);} 
    
    .tx-mff-lsb .send_:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/send_empty.png) ; }
    .tx-mff-lsb .send_0:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/send_none.png) ; }
    .tx-mff-lsb .send_1:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/send_dot.png) ; }
    /* sendend */
    .tx-mff-lsb .send_2:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/send_dot.png) ; }
    .tx-mff-lsb A.send_2:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/pdf.png) ; }
    
    .tx-mff-lsb .send_3:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/send_empty.png) ; }
    .tx-mff-lsb .send_5:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/send_alert.png) ; } /* link senden */
    .tx-mff-lsb .send_6:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/pdf_dot.png) ; }
    .tx-mff-lsb A.send_6:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/pdf.png) ; }
    .tx-mff-lsb .send_8:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/pdf.png) ; }
    .tx-mff-lsb .send_9:before { content:url(/typo3conf/ext/mff_lsb/Resources/Public/Buttons/send_none.png) ; }
    
)
