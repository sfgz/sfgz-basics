# customsubcategory=0limeSurvey=LimeSurvey: Einstellungen in Limesurvey unter https://umfragen.sfgz.ch/admin
# customsubcategory=4calendar=Fremdverwaltete Umfragen. URL zum erstellen der Perioden, Darstellung.
# customsubcategory=3persistence=Speicher Ordner.

plugin.tx_mfflsb_template {
  persistence {
    # cat=plugin.tx_mfflsb_template//a; type=string; label=Default storage PID
    storagePid =
  }
}

plugin.tx_mfflsb_survey {
  persistence {
    # cat=plugin.tx_mfflsb_survey/3persistence/a; type=integer; label=Default storage PID
    storagePid =
    # cat=plugin.tx_mfflsb_survey/3persistence/b; type=string; label=Storage PID of period records: Could be eg. the parent folder of storagePid.
    periodsStoragePid =
  }
  settings {
    # cat=plugin.tx_mfflsb_survey/0limeSurvey/a; type=string; label=URL of LimeSurvey Server
    lsBaseUrl = http://umfragen.verarbeitung.ch
    # cat=plugin.tx_mfflsb_survey/0limeSurvey/b; type=string; label=LimeSurvey users Username
    lsUsername = admin
    # cat=plugin.tx_mfflsb_survey/0limeSurvey/c; type=string; label=LimeSurvey users Password
    lsPassword = parameter
    # cat=plugin.tx_mfflsb_survey/4calendar/a; type=string; label=Kalender URL:Vollständige uri mit parametern
    url = ttps://tcs.tam.ch/home/termine@sfgz.ch/4calendar?fmt=json&query=tag:urlaub
    # cat=plugin.tx_mfflsb_survey/4calendar/d; type=int+; label=Anzahl Jahre in Auswahlliste:Wie viele zurückliegende Jahre sollen in der Semesterliste angezeigt werden?
    semesterYearsPassed = 3
    # cat=plugin.tx_mfflsb_survey/4calendar/e; type=options[Nachname Vorname=0,Vorname Nachname=1]; label=Dozent Namen Anzeige: Reihenfolge Nach- Vorname oder Vor- Nachname.
    firstname_lastname = 1
    
  }
}
