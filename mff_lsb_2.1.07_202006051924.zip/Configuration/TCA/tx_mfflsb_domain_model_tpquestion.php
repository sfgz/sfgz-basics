<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpquestion',
        'label' => 'question',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
		'enablecolumns' => [
		'sorting' => 'sorting'
        ],
		'searchFields' => 'question,hide_title,mandatory,question_type,question_width,  answers,tp_question_subquestion',
        'iconfile' => 'EXT:mff_lsb/Resources/Public/Icons/tx_mfflsb_domain_model_tpquestion.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'question, hide_title, mandatory, question_type, question_width, answers, tp_question_subquestion',
    ],
    'types' => [
		'1' => ['showitem' => 'question, hide_title, mandatory, question_type, question_width, answers, tp_question_subquestion'],
    ],
    'columns' => [
        'question' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpquestion.question',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'hide_title' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpquestion.hide_title',
	        'config' => [
			    'type' => 'check',
			    'items' => [
			        '1' => [
			            '0' => 'LLL:EXT:lang/locallang_core.xlf:labels.enabled'
			        ]
			    ],
			    'default' => 0
			]
	    ],
	    'mandatory' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpquestion.mandatory',
	        'config' => [
			    'type' => 'check',
			    'items' => [
			        '1' => [
			            '0' => 'LLL:EXT:lang/locallang_core.xlf:labels.enabled'
			        ]
			    ],
			    'default' => 0
			]
	    ],
	    'question_type' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpquestion.question_type',
	        'config' => [
			    'type' => 'select',
			    'renderType' => 'selectSingle',
			    'items' => [
			        ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpquestion.question_type.selopt.1', 1],
			        ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpquestion.question_type.selopt.2', 2],
			        ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpquestion.question_type.selopt.3', 3],
			        ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpquestion.question_type.selopt.4', 4]
			    ],
			    'size' => 1,
			    'maxitems' => 1,
			    'eval' => ''
			],
	    ],
	    'question_width' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpquestion.question_width',
	        'config' => [
			    'type' => 'input',
			    'size' => 4,
			    'eval' => 'int'
			]
	    ],
	    'answers' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpquestion.answers',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'user_copies' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpquestion.user_copies',
	        'config' => [
			    'type' => 'input',
			    'size' => 4,
			    'eval' => 'int'
			]
	    ],
	    'tp_question_subquestion' => [
	        'exclude' => true,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpquestion.tp_question_subquestion',
	        'config' => [
			    'type' => 'inline',
			    'foreign_table' => 'tx_mfflsb_domain_model_tpsubquestion',
			    'foreign_field' => 'tpquestion',
			    'foreign_sortby' => 'sorting',
			    'maxitems' => 9999,
			    'appearance' => [
			        'collapseAll' => 1,
			        'levelLinksPosition' => 'top',
			        'showSynchronizationLink' => 1,
			        'showPossibleLocalizationRecords' => 1,
			        'useSortable' => 1,
			        'showAllLocalizationLink' => 1
			    ],
			],
	    ],
        'tpgroup' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
        'sorting' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];
