<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_classtemplate',
        'label' => 'shortclass',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'searchFields' => 'shortclass,tpsurvey',
        'iconfile' => 'EXT:mff_lsb/Resources/Public/Icons/tx_mfflsb_domain_model_classtemplate.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'shortclass,tpsurvey',
    ],
    'types' => [
		'1' => ['showitem' => 'shortclass,tpsurvey'],
    ],
    'columns' => [
        'shortclass' => [
	        'exclude' => false,
	        'label' => 'shortclass',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	'tpsurvey' => [
	    'exclude' => false,
	    'label' => 'tpsurvey',
	    'config' => [
			'type' => 'select',
			'items' => array( array('keine', 0)),
			'renderType' => 'selectSingle',
			'foreign_table' => 'tx_mfflsb_domain_model_tpsurvey',
			'minitems' => 0,
			'maxitems' => 1,
		    ],
	],
    ],
];
