<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Mff.MffLsb',
            'Template',
            'Vorlagen für Umfragen verwalten'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Mff.MffLsb',
            'Survey',
            'Umfragen verwalten'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Mff.MffLsb',
            'Remote',
            'Umfragen fremdverwalten'
        );

	$pluginSignature = str_replace('_','',$extKey) . '_survey';
	$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
	\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:' . $extKey . '/Configuration/FlexForms/flexform_survey.xml');

	$pluginSignature = str_replace('_','',$extKey) . '_template';
	$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
	\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:' . $extKey . '/Configuration/FlexForms/flexform_template.xml');

	$pluginSignature = str_replace('_','',$extKey) . '_remote';
	$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
	\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:' . $extKey . '/Configuration/FlexForms/flexform_remote.xml');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($extKey, 'Configuration/TypoScript', 'LimeSurvey Baker');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_tpsurvey', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_tpsurvey.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_tpgroup', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_tpgroup.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_tpquestion', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_tpquestion.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_tpsubquestion', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_tpsubquestion.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_usersurvey', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_usersurvey.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_classtemplate', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_classtemplate.xlf');

    },
    $_EXTKEY
);

$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['ctrl']['external'] = array(
    0 => array(
        'connector' => 'sql',
        'parameters' => array(
            'driver' => 'mysqli',
            'server' => 'db01.metanet.ch',
            'user' => 'daten_mysql_user',
            'password' => 'P4r4m373r',
            'database' => 'sfgz_daten_my_bck',
            'query' => 'SELECT * FROM tx_mfflsb_domain_model_usersurvey ORDER BY uid',
            'init' => 'SET NAMES utf8',
            'fetchMode' => '4',
        ),
        'data' => 'array',
        'referenceUid' => 'uid',
        'enforcePid' => TRUE,
        'priority' => 110,
        'disabledOperations' => '',
        'description' => 'Nur zu Installation: Importiert Belegungen ab der alten Seite daten.sfgz.ch.',
    )
);

$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['pid']['external'] = [ 0 => [ 'field' => 'pid'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['template_name']['external'] = [ 0 => ['field' => 'template_name'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['template_label']['external'] = [ 0 => ['field' => 'template_label'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['template_label']['external'] = [ 0 => ['field' => 'template_label'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['template_xml']['external'] = [ 0 => ['field' => 'template_xml'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['course_name']['external'] = [ 0 => ['field' => 'course_name'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['subject']['external'] = [ 0 => ['field' => 'subject'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['start_date']['external'] = [ 0 => ['field' => 'start_date'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['expire_days']['external'] = [ 0 => ['field' => 'expire_days'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['remote_days']['external'] = [ 0 => ['field' => 'remote_days'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['deletion_date']['external'] = [ 0 => ['field' => 'deletion_date'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['user_uid']['external'] = [ 0 => ['field' => 'user_uid'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['enquirer_type']['external'] = [ 0 => ['field' => 'enquirer_type'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['semester_uid']['external'] = [ 0 => ['field' => 'semester_uid'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['klasse_uid']['external'] = [ 0 => ['field' => 'klasse_uid'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['fach_uid']['external'] = [ 0 => ['field' => 'fach_uid'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['remote_key']['external'] = [ 0 => ['field' => 'remote_key'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['enquirer_uid']['external'] = [ 0 => ['field' => 'enquirer_uid'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['enquirer_email']['external'] = [ 0 => ['field' => 'enquirer_email'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['enquirer_name']['external'] = [ 0 => ['field' => 'enquirer_name'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['mail_state']['external'] = [ 0 => ['field' => 'mail_state'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['particip_type']['external'] = [ 0 => ['field' => 'particip_type'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['particip_count']['external'] = [ 0 => ['field' => 'particip_count'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['particip_mails']['external'] = [ 0 => ['field' => 'particip_mails'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['template_group_options']['external'] = [ 0 => ['field' => 'template_group_options'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['responses_updated']['external'] = [ 0 => ['field' => 'responses_updated'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['responses_field']['external'] = [ 0 => ['field' => 'responses_field'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['responses_count']['external'] = [ 0 => ['field' => 'responses_count'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['survey_uid']['external'] = [ 0 => ['field' => 'survey_uid'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['survey_state']['external'] = [ 0 => ['field' => 'survey_state'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['user_tp_survey']['external'] = [ 0 => ['field' => 'user_tp_survey'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['tstamp']['external'] = [ 0 => ['field' => 'tstamp'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['crdate']['external'] = [ 0 => ['field' => 'crdate'] ];
$GLOBALS['TCA']['tx_mfflsb_domain_model_usersurvey']['columns']['cruser_id']['external'] = [ 0 => ['field' => 'cruser_id'] ];

