<?php

	/** Copyright (C) 2010 by Dominik Dzienia **/
	/** http://sourceforge.net/projects/phpqrcode/ **/

	$rootPath = dirname(dirname(dirname(dirname(dirname(__FILE__)))));
	$libFilePath = $rootPath . '/sfgz_fetools/Resources/Private/PHP/phpqrcode/qrlib.php';

	$msg = isset($_GET['msg']) ? $_GET['msg'] : '';
	if (!$msg) die('parameter "msg" fehlt. <br />' . $libFilePath ); //$msg = "http://spipu.net/";

	$size = isset($_GET['s']) ? $_GET['s'] : 6;

	$border = isset($_GET['b']) ? $_GET['b'] : 5;

	$err = isset($_GET['err']) ? $_GET['err'] : '';
	if (!in_array($err, array('L', 'M', 'Q', 'H'))) $err = 'L';
	
	include( $libFilePath );
	QRcode::png(utf8_encode($msg), false, $err, $size, $border);
	// sizes: 5,0 = 145 px
	//        5,4 = 185 px ... 4 border = 40 px
