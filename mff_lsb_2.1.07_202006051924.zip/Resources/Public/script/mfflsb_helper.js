function getSurveyFromTemplate( URL ,  uid , insertObj ) {
  if( uid == '' ) {$('#' + insertObj).html('');return false;}
  $.ajax({
	  url : URL,
	  type : 'GET',
	  data : {
	      'uid' : uid 
	  },
	  dataType:'html',
	  success : function(data) {
	      $('#' + insertObj).html(data);
	  },
	  error : function(request,error)
	  {
	      alert("Request " + error + ": "+JSON.stringify(request));
	  }
      });
}

function backgroundSubmitForm( URL , formId ) {
  $.ajax({
	  url : URL,
	  type : 'POST',
	  data : $('#' + formId).serialize(),
	  success : function(data) {
	     window.location = URL;
	  },
	  error : function(request,error)
	  {
	      return false;
	  }
      });
}

function backgroundUpdateValue( URL , table , selId ) {
  opt = {};
  opt[selId] = $('#' + selId).val();
  usropt = {};
  usropt[table] = opt;
  usropt['table'] = table;
  $.ajax({
	  url : URL,
	  type : 'POST',
	  data: usropt,
	  success : function(data) {
	  },
	  error : function(request,error)
	  {
	     alert('error: ' + URL + " Request " + error + ": "+JSON.stringify(request));
	      return false;
	  }
      });
}
