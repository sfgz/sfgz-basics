<?php
namespace Sfgz\SfgzCsvconvert\Controller;

/***
 *
 * This file is part of the "Table Converter" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * ConvController
 */
class ConvController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
	
	/**
	* extKey
	*
	* @var string
	*/
	Private $extKey = '';
    
    /**
     * initializeAction
     *
     * @return void
     */
    public function initializeAction() {
			$this->fileHandlerUtility = new \Sfgz\SfgzCsvconvert\Utility\FileHandlerUtility;
			$this->shrinkTimetableUtility = new \Sfgz\SfgzCsvconvert\Utility\ShrinkTimetableUtility;
			$rawExtKey = \TYPO3\CMS\Core\Utility\GeneralUtility::camelCaseToLowerCaseUnderscored($this->extensionName);
			$this->extKey = str_replace( '_' , '' , $rawExtKey );
    }

    /**
     * helper getSubmitKey
     *
     * @return string
     */
    public function getSubmitKey()
    {
 		$submitKey = '';
 		if( $this->request->hasArgument('submit') ){
			$aSubmit = $this->request->getArgument('submit');
			reset( $aSubmit ) ;
			$submitKey = key( $aSubmit ) ;
		}
		return $submitKey;
    }

    /**
     * action show
     *
     * @return void
     */
    public function showAction()
    {
		
		$uploadDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( 'uploads/tx_' . $this->extKey  ) . '/';
		
		$submitKey = $this->getSubmitKey();
 		
 		if( $submitKey == 'upload' ){
				$freshUploadedFile = $this->handleUpload();
				if( $freshUploadedFile ){
					$hint = 'Datei erfolgreich hochgeladen.';
				}else{
					$hint = 'Aktion zum hochladen ausgelöst, aber keine Datei vorhanden.';
				}
				$this->view->assign('aktion',  $hint);
 		}
 		
 		$file_list = $this->fileHandlerUtility->show_file_list( $uploadDir );
		
		if( $file_list && $submitKey == 'delete' ) {
			foreach( $file_list as $file => $attribut ) {
				unlink( $uploadDir . $file );
			}
			$file_list = $this->fileHandlerUtility->show_file_list( $uploadDir . 'export/' );
			if( $file_list ) {
				foreach( $file_list as $file => $attribut ) {
					unlink( $uploadDir  . 'export/' . $file );
				}
			}
			unset($file_list);
			return;
		}
		
 		if( !count( $file_list ) ) return;
		
		$attributes = $this->getOutputAttributes();
		$this->view->assign('out_attributes', $attributes );
 		
		$hintForLb = [ 'rn' => ' (Windows)' , 'r' => ' ' , 'n' => ' (Linux)' ];
		foreach( $file_list as $file => $attribut ){
			$KB = ( $attribut['size'] * 1.044 );
			$this->fileHandlerUtility->analyse_file( $uploadDir . $file , $KB );
			$file_list[$file]['filename'] = $file;
			$file_list[$file]['charset'] = $this->fileHandlerUtility->fileAttributes['charset']['value'];
			$file_list[$file]['delimiterKey'] = $this->fileHandlerUtility->fileAttributes['delimiter']['key'];
			$file_list[$file]['delimiter'] = $this->fileHandlerUtility->fileAttributes['delimiter']['value'];
			$file_list[$file]['linebreakKey'] = $this->fileHandlerUtility->fileAttributes['linebreak']['key'];
			if( $hintForLb[$file_list[$file]['linebreakKey']] ) $file_list[$file]['linebreakSys'] = $hintForLb[$file_list[$file]['linebreakKey']];
		}
		$flatArr = array_shift($file_list);
		
		$downloadBasename = 'zus_' . $flatArr['filename'] ;
		$flatArr['downloadBasename'] = $downloadBasename;
		$flatArr['urlPath'] ='uploads/tx_' . $this->extKey . '/' ;
		$downloadFile = $uploadDir . 'export/' .  $downloadBasename ;
		if( file_exists($downloadFile) ){ 
			$flatArr['downloadFile'] = $flatArr['urlPath'] . 'export/zus_' . $flatArr['filename'];
		}
		$this->view->assign('file_list', $flatArr );

    }

    /**
     * getOutputAttributes
     *
     * @return void
     */
    public function getOutputAttributes()
    {
				$linebreaks = array(
					'rn'         => "\r\n",
					'n'         => "\n",
					'r'         => "\r",
					'nr'         => "\n\r"
				);
				$enclosure = $this->settings['csv_attributes']['enclosure'][ $this->settings['output']['enclosure'] ];
				$delimiter = $this->settings['csv_attributes']['delimiter'][ $this->settings['output']['delimiter'] ];
				$charset = $this->settings['csv_attributes']['charset'][ $this->settings['output']['charset'] ];
				$linebreak = $linebreaks[ $this->settings['csv_attributes']['linebreak'][ $this->settings['output']['linebreak'] ]];
				$datumblocks = $this->settings['output']['group_by_date'];
				$zeitblocks = $this->settings['output']['group_if_time_less'];
				return [
					'enclosure' =>$enclosure ,
					'linebreakKey' =>$this->settings['csv_attributes']['linebreak'][ $this->settings['output']['linebreak'] ] , 
					'linebreak' =>$linebreak , 
					'delimiter' => $delimiter , 
					'charset' => $charset , 
					'datumblocks' => $datumblocks  , 
					'zeitblocks' => $zeitblocks 
				];
    }

    /**
     * handleUpload
     *
     * @return void
     */
    public function handleUpload()
    {
		$pluginName = \TYPO3\CMS\Core\Utility\GeneralUtility::camelCaseToLowerCaseUnderscored($this->request->getPluginName());
		$freshUploadedFile =  $this->fileHandlerUtility->fileUpload( 'dateiname' , $this->extKey , $pluginName );
 		
 		if($freshUploadedFile) {
				$uploadDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( 'uploads/tx_' . $this->extKey  ) . '/';
				$downloadDir = $uploadDir . 'export/';
				$file_list = $this->fileHandlerUtility->show_file_list( $uploadDir );
				$attributes = $this->getOutputAttributes();
				
				foreach( $file_list as $file => $attribut ){
					if( $file != $freshUploadedFile ){
							unset( $file_list[$file] );
							unlink( $uploadDir . $file );
					}else{
							$KB = ( $attribut['size'] * 1.044 );
							$this->fileHandlerUtility->analyse_file( $uploadDir . $file , $KB );
							$attr = $this->fileHandlerUtility->fileAttributes;
							$fileAttributes['charset'] = $attr['charset']['value'];
							$fileAttributes['delimiter'] = $attr['delimiter']['value'];
							$fileAttributes['linebreak'] = $attr['linebreak']['value'];
							$aTimetable = $this->shrinkTimetableUtility->shrinkTimetable( $uploadDir . $file , $attributes , $fileAttributes );
							$strContent = $this->shrinkTimetableUtility->content_string;
							@unlink( $downloadDir . 'zus_' . $file );
							file_put_contents( $downloadDir . 'zus_' . $file ,$strContent );
					}
				}
 		}
		return $freshUploadedFile;
    }
}
