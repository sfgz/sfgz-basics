<?php
namespace Sfgz\SfgzKurs\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/**
 * JsonController
 */
class JsonController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	* @var string
	*/
	protected $defaultViewObjectName = 'TYPO3\CMS\Extbase\Mvc\View\JsonView';

	/**
	  * initializeAction
	  *
	  */
	public function initializeAction() {
	    $this->configUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ConfigUtility');
		$this->importUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ImportUtility');
	}

	/**
	* Action edconffield
	* stores values in table conf, the global configuration table
	* returns 'ok' if successfull, otherwise a errormessage
	*
	* @return void
	*/
	public function edconffieldAction()
	{
        $options = GeneralUtility::_GET('options');
		
		$response = $this->configUtility->updateConfTypeField( $options['tab'] , strtolower( $options['fld'] ) , $options['val'] );
		
		$settings_useroptions = $options;
		$settings_useroptions['responseText'] = 'ok edconffield->' . $response;
	    $this->view->assign( 'value' , $settings_useroptions );
	}

	/**
	* Action edconftable
	* stores values in table conf, the global configuration table
	* returns 'ok' if successfull, otherwise a errormessage
	*
	* @return void
	*/
	public function edconftableAction()
	{
	    $options = GeneralUtility::_GET('options');
		$response = $this->configUtility->updateConfTypeTable( $options['tab'] , $options['fld'] , $options['val'] );
		
		$settings_useroptions = $options;
		$settings_useroptions['responseText'] = 'ok-edconftable->' . $response ;
		
	    $this->view->assign( 'value' , $settings_useroptions );
	}

	/**
	* Action update
	* stores values in users session variable
	* returns 'ok' if successfull, otherwise a errormessage
	*
	* @return void
	*/
	public function updateAction(){
	    $updateTable = GeneralUtility::_GET('table');
	    
	    if(empty($updateTable)){ 
			$this->view->assign( 'value' ,  'Json->updateAction no table' );
			return;
	    }
	    $useroptions = GeneralUtility::_GET($updateTable);
	    
	    switch($updateTable){
	    
			case 'SfgzKurs':
				$userObj = $GLOBALS['TSFE']->fe_user;
				if( $userObj ){
					$settings_useroptions = $userObj->getKey('user', 'SfgzKurs');
					foreach($useroptions as $field => $value){
						$settings_useroptions[$field] = $value;
					}
					$userObj->setKey("user","SfgzKurs", $settings_useroptions);
					$userObj->sesData_change = true;
					$userObj->storeSessionData();
				}
				$settings_useroptions['responseText'] = 'ok';
				$this->view->assign( 'value' , $settings_useroptions );
			break;
			
			case 'tableKursHide':
				$aInk = array_keys($useroptions);
				$sNamInkey = array_shift($aInk);
				$aNamKey = explode( '_' , $sNamInkey );
				$inkey = $aNamKey[1];
				$sNamVal= array_shift($useroptions);
				$bNewVal = ($sNamVal-1) * (-1);
				
				$objKurs = $this->importUtility->kursRepository->findByUid($inkey);
				if( $objKurs ){
					$objKurs->setAusblenden( $bNewVal );
					$this->importUtility->kursRepository->update($objKurs);
				}
				
				$settings_useroptions['responseText'] =  'css' ;
				$aCss = [ 1=>'bulboff' , 0=>'bulbon' ];
				$settings_useroptions['css'] = $aCss[$bNewVal];
				$settings_useroptions['nocss'] = $aCss[$sNamVal];
				$settings_useroptions['debug'] = $bNewVal;
				$this->view->assign( 'value' , $settings_useroptions );
			break;
			
			case 'reihenfolge':
                $selId = GeneralUtility::_GET('selId');
                $direction = GeneralUtility::_GET('direction');
                $otherUid = $this->resortKategorien( $selId , $direction );
				$settings_useroptions['responseText'] = $otherUid ;
				$this->view->assign( 'value' , $settings_useroptions );
			break;
			
			case 'importSelection':
				$table = $useroptions['table'];
				$index = $useroptions['index'];
				$value = $useroptions['value'];
				$aKeyValuePairs[$index][$table] = $value == 'true' || $value == 1 ? 1 : 0 ;
				// returns "ok, table:lektion index:2735-HS18 value:false"
				$answer = $this->importUtility->setImportSelection( $aKeyValuePairs );
				$settings_useroptions['responseText'] = "ok";
				$this->view->assign( 'value' , $settings_useroptions );
			break;
			default:
				$settings_useroptions['responseText'] = 'not ok';
				$this->view->assign( 'value' , $settings_useroptions );
	    }
	    
	}

    /**
     * resortKategorien
     *  let records stay in their group - dont move out of group
     *  reihenfolge = ( group-id * 1000 ) + (sort-index * 10 )
     *
     * @param int $selId content-uid to move
     * @param str $direction [ up | down ] default is 'up' or empty
     * @return boolean
     */
    Public function resortKategorien( int $selId , string $direction )
    {
            $objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
            $persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
            $querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $repository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\KategorieRepository');
            
            $aKategories = $repository->findAll();
            $table = [];
            foreach( $aKategories as $ix => $objKategorie ){
                $index = isset($table[$objKategorie->getKategorieGruppe()]) ? 1 + count($table[$objKategorie->getKategorieGruppe()]) : 1 ;
                $table[$objKategorie->getKategorieGruppe()][$index] = $objKategorie;
            }
                
			if( !count( $table ) ) return false;

			$posOtherIx = $direction == 'up' || empty($direction) ? -1 : +1;
			
			$otherIx = 0;
            $otherUid = 0;
			foreach( $table as $gid => $aGrpKategories ){
                foreach( $aGrpKategories as $ix => $objKategorie ){
                    
                    if( $selId == $objKategorie->getUid() ){
                        // detect the other item to flip with: add or substract 1 to actual position (ix)
                        $otherIx = $ix + $posOtherIx;
                        if( !isset($table[$gid][$otherIx]) || $table[$gid][$otherIx]->getKategorieGruppe() != $table[$gid][$ix]->getKategorieGruppe() ){
                            // should not be possible: move down the last in group or move up the first in group
                            $table[$gid][$ix]->setReihenfolge( ( 1000 * $gid ) + ( 10 * $ix ) );
                            
                        }else{
                            // detect last or next uid, depending on move down or up
                            $otherUid = $table[$gid][$otherIx]->getUid();
                            // set the sortnumber of the moving item to sortnumber of targeting item
                            $table[$gid][$ix]->setReihenfolge( ( 1000 * $gid ) + ( 10 * $otherIx ) );
                            // set the sortnumber of the targeting item to sortnumber of moving item
                            $table[$gid][$otherIx]->setReihenfolge( ( 1000 * $gid ) + ( 10 * $ix ) );
                            // update the targeting item (the one to flip with)
                            $repository->update($table[$gid][$otherIx]);
                        }

                    }elseif( empty($otherIx) || $ix != $otherIx ){
                        // not one of the two moving items: add 1
                        $table[$gid][$ix]->setReihenfolge( ( 1000 * $gid ) + ( 10 * $ix ) );
                        
                    }
                    
                    // update the moving item
                    $repository->update($table[$gid][$ix]);
                    
                }
			}
			
			$persistenceManager->persistAll();
			return $otherUid;
    }

}
