<?php
namespace Sfgz\SfgzKurs\Command;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \DateTime;

 /** 
 * Class CalendarimportCommandController
 * 
 * 
 */
 
class CalendarimportCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {

	/**
	 * reads the calendar file from distant ftp-directory
	 * 
	 * returns true
	 *
	 * @return void
	 */
	public function execute()
	{
		$filetransferUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\FiletransferUtility');
		$filename = $filetransferUtility->getFtpFile('calendar');
		return $filename ? true : false;
	}
}
