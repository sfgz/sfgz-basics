<?php
namespace Sfgz\SfgzKurs\View\Kurs;
use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class ExportXML
 * Exports todays data from json-file as XML-Document
 * 
 * 
 */
 
class ExportXML extends \TYPO3\CMS\Extbase\Mvc\View\AbstractView {
   public function render() {
		
		$this->xmlUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\XmlUtility');
		
		// return todays XML-Document from json-file 
		$document = $this->xmlUtility->ViewActualExportFile( date('Y-m-d') , 'xml' );
		return $document;
		
   }
}
