<?php
namespace Sfgz\SfgzKurs\Domain\Model;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Config
 */
class Config extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * fieldname
     *
     * @var string
	 * @validate NotEmpty
     */
    protected $fieldname = '';

    /**
     * fieldvalue
     *
     * @var string
     */
    protected $fieldvalue = '';

    /**
     * option1
     *
     * @var string
     */
    protected $option1 = '';

    /**
     * option2
     *
     * @var string
     */
    protected $option2 = '';

    /**
     * description
     *
     * @var string
     */
    protected $description = '';

    /**
     * sorting
     *
     * @var int
     */
    protected $sorting = 10;

    /**
     * __construct
     */
    public function __construct()
    {
    }

    /**
     * Returns the fieldname
     *
     * @return string $fieldname
     */
    public function getFieldname()
    {
        return $this->fieldname;
    }

    /**
     * Sets the fieldname
     *
     * @param string $fieldname
     * @return void
     */
    public function setFieldname($fieldname)
    {
        $this->fieldname = $fieldname;
    }

    /**
     * Returns the fieldvalue
     *
     * @return string $fieldvalue
     */
    public function getFieldvalue()
    {
        return $this->fieldvalue;
    }

    /**
     * Sets the fieldvalue
     *
     * @param string $fieldvalue
     * @return void
     */
    public function setFieldvalue($fieldvalue)
    {
        $this->fieldvalue = $fieldvalue;
    }

    /**
     * Returns the option1
     *
     * @return string $option1
     */
    public function getOption1()
    {
        return $this->option1;
    }

    /**
     * Sets the option1
     *
     * @param string $option1
     * @return void
     */
    public function setOption1($option1)
    {
        $this->option1 = $option1;
    }

    /**
     * Returns the option2
     *
     * @return string $option2
     */
    public function getOption2()
    {
        return $this->option2;
    }

    /**
     * Sets the option2
     *
     * @param string $option2
     * @return void
     */
    public function setOption2($option2)
    {
        $this->option2 = $option2;
    }

    /**
     * Returns the description
     *
     * @return string $description
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Sets the description
     *
     * @param string $description
     * @return void
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * Returns the sorting
     *
     * @return string $sorting
     */
    public function getSorting()
    {
        return $this->sorting;
    }

    /**
     * Sets the sorting
     *
     * @param string $sorting
     * @return void
     */
    public function setSorting($sorting)
    {
        $this->sorting = $sorting;
    }

}
