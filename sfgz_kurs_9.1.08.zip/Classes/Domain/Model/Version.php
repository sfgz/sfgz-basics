<?php
namespace Sfgz\SfgzKurs\Domain\Model;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Version
 */
class Version extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * kurs
     *
     * @var int
     */
    protected $kurs = 0;

    /**
     * tstamp
     *
     * @var int
     */
    protected $tstamp = 0;
    
    /**
     * versionStart
     *
     * @var \DateTime
     */
    protected $versionStart = null;

    /**
     * versionEnde
     *
     * @var \DateTime
     */
    protected $versionEnde = null;

    /**
     * neuBis
     *
     * @var \DateTime
     */
    protected $neuBis = null;

    /**
     * titel
     *
     * @var string
     */
    protected $titel = '';

    /**
     * subTitel
     *
     * @var string
     */
    protected $subTitel = '';

    /**
     * kursBezeichnungLang
     *
     * @var string
     */
    protected $kursBezeichnungLang = '';

    /**
     * voraussetzungen
     *
     * @var string
     */
    protected $voraussetzungen = '';

    /**
     * Abschluss
     *
     * @var string
     */
    protected $zertifikat = '';

    /**
     * ziel
     *
     * @var string
     */
    protected $ziel = '';

    /**
     * textLead
     *
     * @var string
     */
    protected $textLead = '';

    /**
     * zielgruppe
     *
     * @var string
     */
    protected $zielgruppe = '';

    /**
     * inhalt
     *
     * @var string
     */
    protected $inhalt = '';

    /**
     * Kursmittel
     *
     * @var string
     */
    protected $kursunterlagen = '';

    /**
     * Arbeitsweise
     *
     * @var string
     */
    protected $methode = '';

    /**
     * hinweis
     *
     * @var string
     */
    protected $hinweis = '';

    /**
     * weitereInfos
     *
     * @var string
     */
    protected $weitereInfos = '';

    /**
     * kostenMaterial
     *
     * @var string
     */
    protected $kostenMaterial = '';

    /**
     * vDurchfuehrungen
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung>
     * @cascade remove
     */
    protected $vDurchfuehrungen = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->vDurchfuehrungen = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the kurs
     *
     * @return int $kurs
     */
    public function getKurs()
    {
        return $this->kurs;
    }

    /**
     * Sets the kurs
     *
     * @param int $kurs
     * @return void
     */
    public function setKurs($kurs)
    {
        $this->kurs = $kurs;
    }

    /**
     * Returns the tstamp
     *
     * @return int $tstamp
     */
    public function getTstamp()
    {
        return $this->tstamp;
    }

    /**
     * Sets the tstamp
     *
     * @param int $tstamp
     * @return void
     */
    public function setTstamp($tstamp)
    {
        $this->tstamp = $tstamp;
    }

    /**
     * Returns the versionStart
     *
     * @return \DateTime $versionStart
     */
    public function getVersionStart()
    {
        return $this->versionStart;
    }

    /**
     * Sets the versionStart
     *
     * @param \DateTime $versionStart
     * @return void
     */
    public function setVersionStart($versionStart)
    {
        $this->versionStart = $versionStart;
    }

    /**
     * Returns the versionEnde
     *
     * @return \DateTime $versionEnde
     */
    public function getVersionEnde()
    {
        return $this->versionEnde;
    }

    /**
     * Sets the versionEnde
     *
     * @param \DateTime $versionEnde
     * @return void
     */
    public function setVersionEnde($versionEnde)
    {
        $this->versionEnde = $versionEnde;
    }

    /**
     * Returns the neuBis
     *
     * @return \DateTime $neuBis
     */
    public function getNeuBis()
    {
        return $this->neuBis;
    }

    /**
     * Sets the neuBis
     *
     * @param \DateTime $neuBis
     * @return void
     */
    public function setNeuBis( $neuBis )
    {
        $this->neuBis = $neuBis;
    }

    /**
     * Returns the titel
     *
     * @return string $titel
     */
    public function getTitel()
    {
        return $this->titel;
    }

    /**
     * Sets the titel
     *
     * @param string $titel
     * @return void
     */
    public function setTitel($titel)
    {
        $this->titel = $titel;
    }

    /**
     * Returns the subTitel
     *
     * @return string $subTitel
     */
    public function getSubTitel()
    {
        return $this->subTitel;
    }

    /**
     * Sets the subTitel
     *
     * @param string $subTitel
     * @return void
     */
    public function setSubTitel($subTitel)
    {
        $this->subTitel = $subTitel;
    }

    /**
     * Returns the kursBezeichnungLang
     *
     * @return string $kursBezeichnungLang
     */
    public function getKursBezeichnungLang()
    {
        return $this->kursBezeichnungLang;
    }

    /**
     * Sets the kursBezeichnungLang
     *
     * @param string $kursBezeichnungLang
     * @return void
     */
    public function setKursBezeichnungLang($kursBezeichnungLang)
    {
        $this->kursBezeichnungLang = $kursBezeichnungLang;
    }

    /**
     * Returns the voraussetzungen
     *
     * @return string $voraussetzungen
     */
    public function getVoraussetzungen()
    {
        return $this->voraussetzungen;
    }

    /**
     * Sets the voraussetzungen
     *
     * @param string $voraussetzungen
     * @return void
     */
    public function setVoraussetzungen($voraussetzungen)
    {
        $this->voraussetzungen = $voraussetzungen;
    }

    /**
     * Returns the zertifikat
     *
     * @return string $zertifikat
     */
    public function getZertifikat()
    {
        return $this->zertifikat;
    }

    /**
     * Sets the zertifikat
     *
     * @param string $zertifikat
     * @return void
     */
    public function setZertifikat($zertifikat)
    {
        $this->zertifikat = $zertifikat;
    }

    /**
     * Returns the ziel
     *
     * @return string $ziel
     */
    public function getZiel()
    {
        return $this->ziel;
    }

    /**
     * Sets the ziel
     *
     * @param string $ziel
     * @return void
     */
    public function setZiel($ziel)
    {
        $this->ziel = $ziel;
    }

    /**
     * Returns the textLead
     *
     * @return string $textLead
     */
    public function getTextLead()
    {
        return $this->textLead;
    }

    /**
     * Sets the textLead
     *
     * @param string $textLead
     * @return void
     */
    public function setTextLead($textLead)
    {
        $this->textLead = $textLead;
    }

    /**
     * Returns the zielgruppe
     *
     * @return string $zielgruppe
     */
    public function getZielgruppe()
    {
        return $this->zielgruppe;
    }

    /**
     * Sets the zielgruppe
     *
     * @param string $zielgruppe
     * @return void
     */
    public function setZielgruppe($zielgruppe)
    {
        $this->zielgruppe = $zielgruppe;
    }

    /**
     * Returns the inhalt
     *
     * @return string $inhalt
     */
    public function getInhalt()
    {
        return $this->inhalt;
    }

    /**
     * Sets the inhalt
     *
     * @param string $inhalt
     * @return void
     */
    public function setInhalt($inhalt)
    {
        $this->inhalt = $inhalt;
    }

    /**
     * Returns the kursunterlagen
     *
     * @return string $kursunterlagen
     */
    public function getKursunterlagen()
    {
        return $this->kursunterlagen;
    }

    /**
     * Sets the kursunterlagen
     *
     * @param string $kursunterlagen
     * @return void
     */
    public function setKursunterlagen($kursunterlagen)
    {
        $this->kursunterlagen = $kursunterlagen;
    }

    /**
     * Returns the methode
     *
     * @return string $methode
     */
    public function getMethode()
    {
        return $this->methode;
    }

    /**
     * Sets the methode
     *
     * @param string $methode
     * @return void
     */
    public function setMethode($methode)
    {
        $this->methode = $methode;
    }

    /**
     * Returns the hinweis
     *
     * @return string $hinweis
     */
    public function getHinweis()
    {
        return $this->hinweis;
    }

    /**
     * Sets the hinweis
     *
     * @param string $hinweis
     * @return void
     */
    public function setHinweis($hinweis)
    {
        $this->hinweis = $hinweis;
    }

    /**
     * Returns the weitereInfos
     *
     * @return string $weitereInfos
     */
    public function getWeitereInfos()
    {
        return $this->weitereInfos;
    }

    /**
     * Sets the weitereInfos
     *
     * @param string $weitereInfos
     * @return void
     */
    public function setWeitereInfos($weitereInfos)
    {
        $this->weitereInfos = $weitereInfos;
    }

    /**
     * Returns the kostenMaterial
     *
     * @return int $kostenMaterial
     */
    public function getKostenMaterial()
    {
        return $this->kostenMaterial;
    }

    /**
     * Sets the kostenMaterial
     *
     * @param int $kostenMaterial
     * @return void
     */
    public function setKostenMaterial($kostenMaterial)
    {
        $this->kostenMaterial = $kostenMaterial;
    }

    /**
     * Adds a Durchfuehrung
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $vDurchfuehrungen
     * @return void
     */
    public function addVDurchfuehrungen(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $vDurchfuehrungen)
    {
        $this->vDurchfuehrungen->attach($vDurchfuehrungen);
    }

    /**
     * Removes a Durchfuehrung
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $vDurchfuehrungenToRemove The Durchfuehrung to be removed
     * @return void
     */
    public function removeVDurchfuehrungen(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $vDurchfuehrungenToRemove)
    {
        $this->vDurchfuehrungen->detach($vDurchfuehrungenToRemove);
    }

    /**
     * Returns the vDurchfuehrungen
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung> $vDurchfuehrungen
     */
    public function getVDurchfuehrungen()
    {
        return $this->vDurchfuehrungen;
    }

    /**
     * Sets the vDurchfuehrungen
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung> $vDurchfuehrungen
     * @return void
     */
    public function setVDurchfuehrungen(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $vDurchfuehrungen)
    {
        $this->vDurchfuehrungen = $vDurchfuehrungen;
    }
}
