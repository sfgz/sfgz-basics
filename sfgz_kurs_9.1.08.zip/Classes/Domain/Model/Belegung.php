<?php
namespace Sfgz\SfgzKurs\Domain\Model;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Belegung
 */
class Belegung extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * info
     *
     * @var int
     */
    protected $info = 0;

    /**
     * belegungstext
     *
     * @var string
     */
    protected $belegungstext = '';

    /**
     * zeitVon
     *
     * @var string
     */
    protected $zeitVon = '';

    /**
     * zeitBis
     *
     * @var string
     */
    protected $zeitBis = '';

    /**
     * raum
     *
     * @var string
     */
    protected $raum = '';

    /**
     * person
     *
     * @var string
     */
    protected $person = '';

    /**
     * Returns the info
     *
     * @return int $info
     */
    public function getInfo()
    {
        return $this->info;
    }

    /**
     * Sets the info
     *
     * @param int $info
     * @return void
     */
    public function setInfo($info)
    {
        $this->info = $info;
    }

    /**
     * Returns the belegungstext
     *
     * @return string $belegungstext
     */
    public function getBelegungstext()
    {
        return $this->belegungstext;
    }

    /**
     * Sets the belegungstext
     *
     * @param string $belegungstext
     * @return void
     */
    public function setBelegungstext($belegungstext)
    {
        $this->belegungstext = $belegungstext;
    }

    /**
     * Returns the zeitVon
     *
     * @return string $zeitVon
     */
    public function getZeitVon()
    {
        return $this->zeitVon;
    }

    /**
     * Sets the zeitVon
     *
     * @param string $zeitVon
     * @return void
     */
    public function setZeitVon($zeitVon)
    {
        $this->zeitVon = str_replace( '.' , ':' , $zeitVon );
    }

    /**
     * Returns the zeitBis
     *
     * @return string $zeitBis
     */
    public function getZeitBis()
    {
        return $this->zeitBis;
    }

    /**
     * Sets the zeitBis
     *
     * @param string $zeitBis
     * @return void
     */
    public function setZeitBis($zeitBis)
    {
        $this->zeitBis = str_replace( '.' , ':' , $zeitBis );
    }

    /**
     * Returns the raum
     *
     * @return string $raum
     */
    public function getRaum()
    {
        return $this->raum;
    }

    /**
     * Sets the raum
     *
     * @param string $raum
     * @return void
     */
    public function setRaum($raum)
    {
        $this->raum = $raum;
    }

    /**
     * Returns the person
     *
     * @return string $person
     */
    public function getPerson()
    {
        return $this->person;
    }

    /**
     * Sets the person
     *
     * @param string $person
     * @return void
     */
    public function setPerson($person)
    {
        $this->person = $person;
    }
}
