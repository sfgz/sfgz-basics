<?php
namespace Sfgz\SfgzKurs\Domain\Model;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Kurs
 */
class Kurs extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * titel
     *
     * @var string
     */
    protected $titel = '';

    /**
     * kursCode
     *
     * @var string
	 * @validate NotEmpty
     */
    protected $kursCode = '';

    /**
     * stufeWb
     * used as Kursniveau
     *
     * @var string
     */
    protected $stufeWb = '';

    /**
     * sorting
     *
     * @var int
     */
    protected $sorting = 0;

    /**
     * ausblenden
     *
     * @var int
     */
    protected $ausblenden = 0;

    /**
     * tstamp
     *
     * @var int
     */
    protected $tstamp = 0;

    /**
     * kKategorien
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Kategorie>
     */
    protected $kKategorien = null;

    /**
     * kVersionen
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Version>
     * @cascade remove
     */
    protected $kVersionen = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->kKategorien = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->kVersionen = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the titel
     *
     * @return string $titel
     */
    public function getTitel()
    {
        return $this->titel;
    }

    /**
     * Sets the titel
     *
     * @param string $titel
     * @return void
     */
    public function setTitel($titel)
    {
        $this->titel = $titel;
    }

    /**
     * Returns the kursCode
     *
     * @return string $kursCode
     */
    public function getKursCode()
    {
        return $this->kursCode;
    }

    /**
     * Sets the kursCode
     *
     * @param string $kursCode
     * @return void
     */
    public function setKursCode($kursCode)
    {
        $this->kursCode = $kursCode;
    }

    /**
     * Returns the stufeWb
     *
     * @return string $stufeWb
     */
    public function getStufeWb()
    {
        return $this->stufeWb;
    }

    /**
     * Sets the stufeWb
     *
     * @param string $stufeWb
     * @return void
     */
    public function setStufeWb($stufeWb)
    {
        $this->stufeWb = $stufeWb;
    }

    /**
     * Returns the sorting
     *
     * @return int $sorting
     */
    public function getSorting()
    {
        return $this->sorting;
    }

    /**
     * Sets the sorting
     *
     * @param string $sorting
     * @return void
     */
    public function setSorting($sorting)
    {
        $this->sorting = $sorting;
    }


    /**
     * Returns the ausblenden
     *
     * @return int $ausblenden
     */
    public function getAusblenden()
    {
        return $this->ausblenden;
    }

    /**
     * Sets the ausblenden
     *
     * @param string $ausblenden
     * @return void
     */
    public function setAusblenden($ausblenden)
    {
        $this->ausblenden = $ausblenden;
    }

    /**
     * Returns the tstamp
     *
     * @return int $tstamp
     */
    public function getTstamp()
    {
        return $this->tstamp;
    }

    /**
     * Sets the tstamp
     *
     * @param int $tstamp
     * @return void
     */
    public function setTstamp($tstamp)
    {
        $this->tstamp = $tstamp;
    }

    /**
     * Adds a Kategorie
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Kategorie $kKategorien
     * @return void
     */
    public function addKKategorien(\Sfgz\SfgzKurs\Domain\Model\Kategorie $kKategorien)
    {
        $this->kKategorien->attach($kKategorien);
    }

    /**
     * Removes a Kategorie
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Kategorie $kKategorienToRemove The Kategorie to be removed
     * @return void
     */
    public function removeKKategorien(\Sfgz\SfgzKurs\Domain\Model\Kategorie $kKategorienToRemove)
    {
        $this->kKategorien->detach($kKategorienToRemove);
    }

    /**
     * Returns the kKategorien
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Kategorie> $kKategorien
     */
    public function getKKategorien()
    {
        return $this->kKategorien;
    }

    /**
     * Sets the kKategorien
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Kategorie> $kKategorien
     * @return void
     */
    public function setKKategorien(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $kKategorien)
    {
        $this->kKategorien = $kKategorien;
    }

    /**
     * Adds a Version
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Version $kVersionen
     * @return void
     */
    public function addKVersionen(\Sfgz\SfgzKurs\Domain\Model\Version $kVersionen)
    {
        $this->kVersionen->attach($kVersionen);
    }

    /**
     * Removes a Version
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Version $kVersionenToRemove The Version to be removed
     * @return void
     */
    public function removeKVersionen(\Sfgz\SfgzKurs\Domain\Model\Version $kVersionenToRemove)
    {
        $this->kVersionen->detach($kVersionenToRemove);
    }

    /**
     * Returns the kVersionen
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Version> $kVersionen
     */
    public function getKVersionen()
    {
        return $this->kVersionen;
    }

    /**
     * Sets the kVersionen
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Version> $kVersionen
     * @return void
     */
    public function setKVersionen(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $kVersionen)
    {
        $this->kVersionen = $kVersionen;
    }
}
