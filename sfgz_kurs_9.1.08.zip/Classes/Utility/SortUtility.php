<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class SortUtility
 * used by exportUtility()
 * to sort the records 
 * based on configuration in ts
 * 
 */
 
class SortUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * array sortFields
	 */
	protected $sortFields = null;

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
	    $this->settings = $this->settingsUtility->getSettings( 'tx_sfgzkurs_lst' );
		$this->setSortConfig( $this->getSortConfig( 'export' ) );
	}
	
	/**
	 * resortArrayCourses
     * 
	 * @param array $db
	 * @return array
	 */
	Public function resortArray( $db )
	{
		
		$this->cleanSortConfigLoop( $db );

		$dbIndex = $this->getSortIndexLoop( $db );

		$dbSorted = $this->resortArrayLoop( $dbIndex , [] , $db );

		return $dbSorted;
	}


	/**
	 * getSortIndexLoop
	 * helper for resortArrayCourses()
     * 
	 * @param array $db
	 * @return array
	 */
	Private function getSortIndexLoop( $db )
	{
		$subDbIndex = [];
		foreach( $db as $mainTabnam => $dbKurse ){
			if( !is_array($dbKurse) ) continue; // skip normal fields
			
			// collect recordsets
			foreach( $dbKurse as $idKurs => $rowKurs ){
				$idx = [];
				// build sort-index for a specific kurs-row
				if( isset( $this->sortFields[$mainTabnam] ) ){
					foreach( $this->sortFields[$mainTabnam] as $ix => $fld ) {
						$idx[ $fld['field'] ] = $rowKurs[ $fld['field'] ];
					}
				}else{
					$idx['uid'] = $idKurs;
				}
				// zb dbIndex['kurse'][ kurs_code + kurs_uid ]['uid'] = kurs_uid;
				$row['uid'] = $idKurs;
				$row['tab'] = $this->getSortIndexLoop( $rowKurs );
 				$aIndizes = $idx;
 				
				$kursIndex = array_shift( $aIndizes );
				if( !count($aIndizes) ){
					// assign recordset as a 1-dimensional array
					$subDbIndex[$mainTabnam][ $kursIndex ] = $row;
				}else{
					// assign recordset as a multi-dimensional array with unknown deepness
					$subDbIndex[$mainTabnam][ $kursIndex.'.'.implode('.',$aIndizes) ] = $this->redimLoop( $aIndizes , $row );
				}
				
			}
			
			// sort and then re-assign as a 1-dimensional array
			if( isset($subDbIndex[$mainTabnam]) && count($subDbIndex[$mainTabnam]) ) {
				// build sort-order-index valid for all kurs-rows
				$srt = [];
				if( isset( $this->sortFields[$mainTabnam] ) ){
					foreach( $this->sortFields[$mainTabnam] as $fldName=>$fldCnf ) {
							$srt[ $fldName ] = $fldCnf['srtdir'];
					}
				}else{
					$srt['uid'] = 'ASC';
				}
				
				$order = [];
				$concatenatedIndex = [];
				foreach( $srt as $aSrt ) $order[] = $aSrt;

				$subDbIndex[$mainTabnam] = $this->sortRedimedLoop( $subDbIndex[$mainTabnam] , $concatenatedIndex , $order , 0 );
			}
			
		}
		return $subDbIndex;
	}

	/**
	 * redimLoop
     * 
	 * @param array $aIndizes
	 * @param array $aRow
	 * @return array
	 */
	Private function redimLoop( $aIndizes , $aRow )
	{
			
			$aNewData = [];
			$sub1kursIndex = array_shift( $aIndizes );
			
			if( !count($aIndizes) ){
				$aNewData[$sub1kursIndex] = $aRow;
			}else{
				$aNewData[$sub1kursIndex] = $this->redimLoop( $aIndizes , $aRow );
			}
			return $aNewData;
	}

	/**
	 * sortRedimedLoop
     * 
	 * @param array $db
	 * @param array $concatenatedIndex
	 * @param array $order
	 * @param int $counter
	 * @return array
	 */
	Private function sortRedimedLoop( $db , $concatenatedIndex , $order , $counter )
	{
			if( $order[$counter] == 'DESC' ) {
				krsort($db);
			}else{
				ksort($db);
			}
			
			$aData = [];
			foreach( $db as $sub1kursIndex => $cntsub1kurs ){
				$concatenatedIndex[$counter] = isset($concatenatedIndex[$counter-1]) ? $concatenatedIndex[$counter-1] . '-' . $sub1kursIndex : $sub1kursIndex;
				if( !isset($order[$counter+1]) ){
					$aData[ $concatenatedIndex[$counter] ] = $cntsub1kurs;
					
				}else{
					$aResult = $this->sortRedimedLoop( $cntsub1kurs , $concatenatedIndex , $order , $counter+1 );
					foreach($aResult as $i => $c ){
						$aData[ $i ] = $c;
					}
				}
			}
			return $aData;
	}

	
	/**
	 * resortArrayLoop
     * 
	 * @param array $dbIndex
	 * @param array $dbSorted
	 * @param array $db
	 * @return array
	 */
	Private function resortArrayLoop( $dbIndex , $dbSorted = [] , $db)
	{
		foreach( $dbIndex as $mainTab => $mainRow ){
			if( !is_array($mainRow) ) continue;
			foreach( $mainRow as $kursIndex => $rowKurs ){
				// Kurs start
				$idKurs = $rowKurs['uid'];
				$dbSorted[$idKurs] = $db[$mainTab][$idKurs];// copy table kurse 
				
				if( !isset($rowKurs['tab']) || !count($rowKurs['tab']) ) continue;
				
				$dbSorted[$idKurs] = $this->resortArrayLoop( $rowKurs , $dbSorted[$idKurs] , $db );
			}
		}
		return $dbSorted;
	}


	/**
	 * cleanSortConfigLoop
	 * skip fields in sort-config when there are empty in db
     * 
	 * @param str $tablename
	 * @param array $row
	 * @return array
	 */
	Private function cleanSortConfigLoop( $db  )
	{
		if( !is_array($db) )return;
		foreach( $db as $mainTabnam => $dbKurse ){
			if( !is_array($dbKurse) ) continue; // skip if no sub-rows
			foreach( $dbKurse as $idKurs => $rowKurs ){
				if( !is_array($rowKurs) ) continue; // skip normal fields
				if( isset( $this->sortFields[$tablename] ) ){
					foreach( $this->sortFields[$tablename] as $ix => $fld ) {
						if( !isset( $row[ $fld['field'] ] ) ) {
							unset($this->sortFields[$tablename][$ix]);
						}
					}
				}
				$this->cleanSortConfigLoop( $rowKurs );
			}
		}
	}

	/**
	 * setSortConfig
     * 
	 * @param array $aIndizes
	 * @return void
	 */
	Public function setSortConfig( $aIndizes )
	{
		$this->sortFields = $aIndizes;
	}

	/**
	 * getSortConfig
     * 
	 * @param str $tsKey default is 'export'
	 * @return array
	 */
	Private function getSortConfig( $tsKey = 'export' )
	{
		$expDef = $this->settings[$tsKey];
		foreach( $expDef['recordSortOrder'] as $xmlTable => $strIndizesFields ){
				$domTable = !isset( $expDef['mapXmlToDbTablenames'][$xmlTable] ) ? $xmlTable : $expDef['mapXmlToDbTablenames'][$xmlTable] ;
				$fldDefLst = explode( ',' , $strIndizesFields );
				foreach( $fldDefLst as $fldDef ){
					$aFldDirection = explode( ' ' , trim($fldDef) );
					$field = trim($aFldDirection[0]);
					$sortDirection = trim($aFldDirection[1]);
					
					$aIndizes[$domTable][$field]['field'] = $field;
					$aIndizes[$domTable][$field]['srtdir'] = $sortDirection ? $sortDirection : 'ASC';
				}
				// append default sort-settings at the end of sort-fields
				$aIndizes[$domTable]['uid']['field'] = 'uid'; 
				$aIndizes[$domTable]['uid']['srtdir'] = 'ASC'; 
		}
		return $aIndizes;
	}

}
