<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/** 
 * Class TableMapperUtility
 * 
 * 
 */
 
class TableMapperUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * array settings
	 */
	protected $settings = null;

	/**
	 * array aCleanChars
	 */
	protected $aCleanChars = [
		'search' => [ 0 => "'" , 1 => ',' , 2 => "`" ] ,
		'replace' => [ 0 => '' , 1 => '.' , 2 => '' ]
	];

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_lst';

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
	

	    $this->dateUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\DateUtility');
		$this->importfunctionsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ImportfunctionsUtility');
		$this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
	    $this->settings = $this->settingsUtility->getSettings( $this->pluginKey );
		
	}

	/**
	 * helper getContentFromFile
	 *
	 * @param string $pathFileName
	 * @return array 
	 */
	Public function getContentFromFile( $pathFileName )
	{
			if( !file_exists($pathFileName) ) return ['no file ' . $pathFileName ];

			$tableType = pathinfo( dirname( $pathFileName ) , PATHINFO_FILENAME );

			$aLines = file($pathFileName);

			if( !is_array($aLines) ) return ['no array'];
			return $this->getContentFromArray( $aLines , $tableType );
	}

	/**
	 * helper getContentFromArray
	 *
	 * @param array $aLines
	 * @param string $tableType
	 * @return array 
	 */
	Public function getContentFromArray( $aLines , $tableType )
	{
			$mappedDb = $this->mapArrayToTableFields( $aLines , $tableType );
			$indexedDb = $this->rebuildIndex( $mappedDb , $tableType );
			$cleanFieldsDb = $this->postImportFunction( $indexedDb , $tableType );
			return $cleanFieldsDb;
	}

	/**
	 * helper mapArrayToTableFields
	 *
	 * @param array $aLines
	 * @param string $tableType
	 * @return array 
	 */
	Public function mapArrayToTableFields( $aLines , $tableType )
	{
			// get import options from ts-config
			$mapCsvField = $this->getSettingsToMapFields( $tableType );
			// $mapCsvField[ $From_Field ][ $tablename ][ $sql_fieldname ]
			
			// detect delimiter and line-break
			$fileAttributes = $this->settings['csv_options'];
			
			// cut headline
			// map inColumn-Nr to outColumn-Name
			$rawHeadline = array_shift( $aLines );
			
			$aHeadLine = explode( $fileAttributes['delimiter'] , $rawHeadline );
			foreach( $aHeadLine as $colNr => $rawFromField ) {
					$trimmedRawFromField = trim( trim( trim($rawFromField) , $fileAttributes['enclosure'] ) );
					$fromField = str_replace( ' ' , '_' , $trimmedRawFromField );
					if( isset( $mapCsvField[$fromField] ) ) $aFieldmappingForColNr[$colNr] = $mapCsvField[$fromField];
			}

			// create output-array
			$mappedDb = [];
			foreach( $aLines as $ix => $strLine ){
					$aSingleLine = explode( $fileAttributes['delimiter'] , $strLine );
					foreach( $aSingleLine as $colNr => $rawCellContent ) {
						
						$cellContent = trim( $rawCellContent , $fileAttributes['enclosure'] );
						
						// if there is a definition for the field
						if( isset( $aFieldmappingForColNr[$colNr] ) ){
							foreach( $aFieldmappingForColNr[$colNr] as $tablename => $tabConfigs ){
								foreach( $tabConfigs as $sqlFieldname => $objName ){
									$fldConf = $this->settings['tables'][$tablename]['mapFields'][$sqlFieldname];
									$mappedDb[$ix][$tablename][$objName] = $this->renderField( $fldConf , $cellContent );
								}
							}
						}else{
							// No complete definition found. Append the cell to default-table. 
							// Be aware there will be no file to store this value.
							$mappedDb[$ix][$tableType][$colNr] = $colNr . ' ['.$cellContent . ']';
						}
					}
				
			}
			return $mappedDb;
    }
    
	/**
	 * helper renderField
	 * renders defined special fields
	 * hint: the field-type is related to the targeting t3db field
	 * 
	 * @param array $tabConfigs
	 * @param string $cellContent
	 * @return array 
	 */
	Public function renderField( $tabConfigs , $cellContent )
	{
			if( empty( $cellContent) ) return $cellContent;
			if( isset($tabConfigs['postImportFunction']) ) return $cellContent;

			$unMaskedContent = '';
			$fieldType = isset($tabConfigs['fieldType']) ? $tabConfigs['fieldType']: 'default';
			
			switch( $fieldType ){
				case 'int':
				case 'integer':
					$cleanedChars = str_replace( $this->aCleanChars['search'] , $this->aCleanChars['replace'] , $cellContent );
					$unMaskedContent = is_numeric($cleanedChars) ? round( $cleanedChars ) : $cleanedChars ;
				break;
				case 'dec':
				case 'decimal':
					$cleanedChars = str_replace( $this->aCleanChars['search'] , $this->aCleanChars['replace'] , $cellContent );
// 					$unMaskedContent = number_format( trim($cleanedChars)+0 , 2 , '.' , "'" );
					$unMaskedContent = is_numeric($cleanedChars) ? round( round( 20 * $cleanedChars ) / 20 , 2 ): $cleanedChars ;
				break;
				case 'date':
					// remove trailing time-string: '00:00'
					$fullDateTime = $this->dateUtility->sanitizeDateTimeStringToEnglish($cellContent);
					$aDateTime = explode( ' ' , trim($fullDateTime) );
					$unMaskedContent = $aDateTime[0];
				break;
				case 'datetime':
					// translate German to English Date including time-string
					$fullDateTime = $this->dateUtility->sanitizeDateTimeStringToEnglish($cellContent);
					$unMaskedContent = $fullDateTime;
				break;
				case 'date_de':
					// unused: translate English to German Date and remove trailing time-string: '00:00'
					$fullDateTime = $this->dateUtility->sanitizeDateTimeStringToGerman($cellContent);
					$aDateTime = explode( ' ' , $fullDateTime );
					$unMaskedContent = $aDateTime[0];
				break;
				case 'timestring':
					$timestring = str_replace( '.' , ':' , $cellContent );
					$aTimeSplit = explode( ':' , $timestring );
					$unMaskedContent = sprintf( '%02s' , $aTimeSplit[0] ) . ':' . sprintf( '%02s' , $aTimeSplit[1] );
				break;
				case 'default':
				default:
					// replace _semicolon_with char ; (replaced with placeholder in sanitizeLinebreaksInCsvString() by replacement between enclosures)
					$unMaskedContent = str_replace( '_' . $this->settings['csv_options']['delimiter_key'] . '_' , $this->settings['csv_options']['delimiter'] , $cellContent );
			}
			return $unMaskedContent;
    }
	
	/**
	 * helper getSettingsToMapFields
	 *
	 * @param string $tableType
	 * @return array 
	 */
	Public function getSettingsToMapFields( $tableType )
	{
			// get import options from ts-config
			$mapCsvField = array();
			foreach( $this->settings['tables']  as $tablename => $tableDefs ){
				if( $tableDefs['sourceFile'] != $tableType ) continue;
				if( !is_array( $tableDefs['mapFields'] ) ) continue;
				foreach( $tableDefs['mapFields']  as $sqlFieldname => $fieldDefs ){
					if( !isset( $fieldDefs['source'] ) ) continue;
					$fromField = str_replace( ' ' , '_' , trim($fieldDefs['source']));
					$objName = GeneralUtility::underscoredToLowerCamelCase( $sqlFieldname );
					$mapCsvField[$fromField][$tablename][$sqlFieldname] = $objName ;
				}
			}
			return $mapCsvField;
    }
     
	/**
	 * helper getSettingsToRebuildIndex
	 *
	 * @param string $tableType
	 * @return array 
	 */
	Public function getSettingsToRebuildIndex( $tableType )
	{
			$aFldDef = explode( ',' , $this->settings['sourceFiles'][$tableType]['rebuildIndex'] );
			
			$aConcatFields = [];
			foreach( $aFldDef as $tabFld ) {
				$aTf = explode( '.' , trim($tabFld) );
				$aConcatFields[$aTf[1]] = $aTf[0];
			}
			return $aConcatFields;
    }
     
	/**
	 * helper rebuildIndex
	 *
	 * @param array $aTables
	 * @param string $tableType
	 * @return array 
	 */
	Public function rebuildIndex( $aTables , $tableType )
	{
			$aConcatFields = $this->getSettingsToRebuildIndex( $tableType );
			if( !count($aConcatFields) ) return $aTables;
			
			$naOut = [];
			foreach( $aTables as $ix => $aRow ){
					$aAtom = [];
					foreach( $aConcatFields as $fld => $tab ){
						if( !empty($aRow[$tab][$fld]) ) $aAtom[$fld] = $aRow[$tab][$fld];
					}
 					$newIndex = count($aAtom) ? implode( '-' , $aAtom ) : $ix;
					$naOut[$newIndex] = $aRow;
			}
			if( !count($naOut) ) return $aTables;
			return $naOut;
    }
   
	/**
	 * helper postImportFunction
	 * this method calculates values with default-methods based on one ore more fields in the same row of csv-table
	 * 
	 * @param array $aOut
	 * @param string $tableType
	 * @return array 
	 */
	Public function postImportFunction( $aOut , $tableType )
	{
			$aCalcFuncts = $this->getSettingsForPostFunction( $tableType );
			foreach( $aOut as $ix => $recordTable ) {
				foreach( $recordTable as $tablename => $recordSet ) {
						// are there calc-functions for the table?
						if( !isset( $aCalcFuncts[$tablename] ) ) continue;
						foreach( $aCalcFuncts[$tablename] as $domFieldName => $fldDef ){
							if( !isset($fldDef['postImportFunction']) || !isset($fldDef['postImportFunction']['function']) ) continue;
							$impDef = $fldDef['postImportFunction'];
							 
							 // if value is already set and override = 0 do nothing
							if( empty($impDef['override']) && !empty($aOut[$ix][$tablename][$domFieldName]) ) continue;
							
							if( isset($impDef['parameterFields']) && isset($impDef['parameters']) ) {
								// get values from parameter-fields $aParamVal[ paramField ] = $recordSet[ paramField ]
								$aParamValue = array();
								$fieldsToMap = explode( ',' , $impDef['parameterFields'] );
								foreach($fieldsToMap as $z => $sqlFieldname){
										$parameterField = GeneralUtility::underscoredToLowerCamelCase( trim($sqlFieldname) );
										$aParamValue[ '%' . ($z+1) ] = $recordSet[$parameterField];
								}
								$functionParameters = str_replace( array_keys($aParamValue) , $aParamValue , $impDef['parameters'] );
							}elseif( isset($impDef['parameters']) ){
								$functionParameters = trim($impDef['parameters']);
							}else{
								$functionParameters = '';
							}
							
							$method = 'import_' . $impDef['function'];
							$calculatedCellContent = '';
							if( method_exists( $this->importfunctionsUtility , $method ) ){
									$calculatedCellContent = $this->importfunctionsUtility->$method( $functionParameters ) ;
							}
							if( !empty($calculatedCellContent) || $impDef['override'] >1 ) $aOut[$ix][$tablename][$domFieldName] = $calculatedCellContent;
						}
				}
			}
			return $aOut;
    }
    
	/**
	 * helper getSettingsForPostFunction
	 * this method calculates values with import_-methods based on one ore more fields in the same row of csv-table
	 * 
	 * @param string $tableType
	 * @return array 
	 */
	Public function getSettingsForPostFunction( $tableType )
	{
			// get import options from ts-config
			// create $fieldsToMap $dom2sql $solved-0 
			// - $solved[ table ][ 0 ][ solvedField ] = solvedBecauseOf_sourceFieldName
			// - $fieldsToMap[ table ][ unsolvedField ][0-listlength] = unsolvedBecaseDependentOn_sql_field_name
			
			$fieldsToMap = array();
			$dom2sql = array();
			$solved = array();
			$grade = 0;
			foreach( $this->settings['tables']  as $tablename => $tableDefs ){
				if( $tableDefs['sourceFile'] != $tableType ) continue;
				if( !is_array( $tableDefs['mapFields'] ) ) continue;
				foreach( $tableDefs['mapFields']  as $sqlFieldname => $fieldDefs ){
						$calcObjName = GeneralUtility::underscoredToLowerCamelCase( $sqlFieldname );
						$dom2sql[$calcObjName] = trim($sqlFieldname);
						// at first register as solved-0 if source exists
						if( isset($fieldDefs['source']) ) {
							$solved[ $tablename ][ $grade ][ $calcObjName ] = str_replace( ' ' , '_' , trim($fieldDefs['source']));
							
						}elseif( isset( $fieldDefs['postImportFunction']['parameterFields'] ) ){
							$fieldsToMap[$tablename][$calcObjName] = explode( ',' , $fieldDefs['postImportFunction']['parameterFields'] );
							
						}elseif( isset( $fieldDefs['postImportFunction'] ) && !isset( $fieldDefs['postImportFunction']['parameterFields'] ) ){
							$solved[ $tablename ][ $grade ][ $calcObjName ] = $fieldDefs['postImportFunction']['function'];
						}
				}
			}
			
			// need $fieldsToMap, $dom2sql, $solved-0
			// enrich $dom2sql $solved-1 ... 10
			// destroy $fieldsToMap
			++$grade; // 1
			foreach( $fieldsToMap as $tablename => $tableDefs ){
			
				for( $actualGrade = $grade ; $actualGrade < 10 ; ++$actualGrade ){
								
					foreach( $tableDefs  as $calcObjName => $aParameterFields ){
						
							foreach($aParameterFields as $ix => $sql_fieldname ) {
									$objNameUsedField = GeneralUtility::underscoredToLowerCamelCase( trim($sql_fieldname) );
									$dom2sql[$objNameUsedField] = trim($sql_fieldname);
									// register this parameterField as solved if dependent field has a solved-registering with lower grade 
									// if equal then register later with a higher grade.
									//
									// $calcObjName is dependent on $sql_fieldname!
									//
									for( $lastGrade = 0 ; $lastGrade < $actualGrade ; ++$lastGrade ){
									
										if( isset($solved[ $tablename ][ $lastGrade ]) && isset($solved[ $tablename ][ $lastGrade ][ $objNameUsedField ]) ){
											// solved because the parent field on whitch it was dependent is solved. first solved fieldname is first calculated
											if( !isset($solved[ $tablename ][$actualGrade][ $calcObjName ]) ) {
												$solved[ $tablename ][$actualGrade][ $calcObjName ] = $solved[ $tablename ][ $lastGrade ][ $objNameUsedField ]; 
											}
											unset( $fieldsToMap[$tablename][$calcObjName][$ix] );
											if( !is_array($fieldsToMap[$tablename][$calcObjName]) || !count($fieldsToMap[$tablename][$calcObjName]) ) {
												unset($fieldsToMap[$tablename][$calcObjName]) ;
												break;
											}
										}
										// else field could not be registered as solved-$actualGrade
									}
							}
							
					}
				}
			}
			// go ahead with $solved. if there still remaining $dependsOn then ignore them. 
			
			// need $solved $dom2sql
			// create $aCalcFuncts
			$aCalcFuncts = array();
			foreach( $solved as $tablename => $skaledSolved ){
					
					ksort($skaledSolved); //  upper-graded needs lower-graded
					
					foreach( $skaledSolved as $grade => $aUsedFields ){
							foreach( $aUsedFields as $objNameSolvedField => $solvingFieldName ){
								// set config[ inTable ][ objNameUsedField ][ ... ]
								if( !isset( $aCalcFuncts[$tablename][$objNameSolvedField] ) ) {
									$sqlFieldname = $dom2sql[ $objNameSolvedField ];
									$aCalcFuncts[$tablename][$objNameSolvedField] = $this->settings['tables'][$tablename]['mapFields'][$sqlFieldname];
								}
							}
					}
			}
			return $aCalcFuncts;
    }

	/**
	 * helper sanitizeLinebreaksInCsvString
	 * substitutes linebreaks within enclosures
	 * exspects and returns a string
	 *
	 * @param string $strCsvTable
	 * @return string 
	 */
	Public function sanitizeLinebreaksInCsvString( $strCsvTable )
	{
			// detect charset
			$fileAttributes = $this->settings['csv_options'];
			
			$lb = array(  "\n\r" => '<br />' ,"\r\n" => '<br />' , "\n" => '<br />' ,"\r" => '<br />' );
			// detect rows with hugetext
			// replace delimiters between enclosures with placeholder __delimiter_key__  and  linebreaks with <br />
			
			$strFilecontent = iconv( $fileAttributes['charset'] , 'utf-8' ,$strCsvTable );
			$newString = '';
			for( $pos = 0 ; $pos < strlen($strFilecontent) ; ++ $pos ){
				// prepend space and subtr 1 to set on -1 if empty
				$firstPos = strpos( ' ' . $strFilecontent , $fileAttributes['enclosure'] , $pos+1 )-1;
				$secondPos = $firstPos == -1 ? -1 : strpos(  $strFilecontent , $fileAttributes['enclosure'] , 1+$firstPos);
				if( $firstPos == -1 || $secondPos <= $firstPos ){
					// end. no more enclosure-pairs, dispatch rest of text an quit
					$newString .= substr( $strFilecontent , $pos ); // epilogue
					break;
				}
				// prologue: append leading text (or string between last second-enclosure and new first-enclosure) to newString
				if( $firstPos > $pos) {
					$newString .= substr( $strFilecontent , $pos , $firstPos - $pos );
				}
				// replacement between enclosures
				$blankContent = substr( $strFilecontent , $firstPos+1 , $secondPos-($firstPos+1) ); // content
				$maskedContent = str_replace( $fileAttributes['delimiter'] , '_' . $fileAttributes['delimiter_key'] . '_' , $blankContent );
				$htmlContent = str_replace( array_keys($lb) , $lb , $maskedContent );
				// append replaced content to new string
				$newString .= $htmlContent;
				// reset the new position.
				$pos = $secondPos;
			}
			return $newString;
    }
    
	
}
