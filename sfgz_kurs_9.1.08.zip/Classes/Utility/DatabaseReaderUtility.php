<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class DatabaseReaderUtility
 * 
 * 
 */
 
class DatabaseReaderUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
     * disablingField
     *
     * @var string
     */
    Public $disablingField = 'ausblenden';

    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     */
    protected $kursRepository = null;

    /**
     * versionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\VersionRepository
     */
    protected $versionRepository = null;
    
    /**
     * durchfuehrungRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\DurchfuehrungRepository
     */
    protected $durchfuehrungRepository = null;

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
	
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$this->typoScriptService =  $objectManager->get('TYPO3\\CMS\\Extbase\\Service\\TypoScriptService');
        $persistence = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_sfgzkurs_vw.']['persistence.']);
        $settings =  $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_sfgzkurs_vw.']['settings.']);
        array_unshift($persistence , ['pageUid'=> $settings['pageUid']['storagePid'] ] );
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
        $querySettings->setIgnoreEnableFields(TRUE);
		$querySettings->setRespectStoragePage(FALSE);
        $querySettings->setStoragePageIds( $persistence );
		
		$this->kursRepository = $objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\KursRepository');
	    $this->kursRepository->setDefaultQuerySettings($querySettings);
		
		$this->versionRepository = $objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\VersionRepository');
	    $this->versionRepository->setDefaultQuerySettings($querySettings);
		
		$this->kategorieRepository = $objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\KategorieRepository');
	    $this->kategorieRepository->setDefaultQuerySettings($querySettings);
		
		$this->durchfuehrungRepository = $objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\DurchfuehrungRepository');
	    $this->durchfuehrungRepository->setDefaultQuerySettings($querySettings);
		
		$this->dateUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\DateUtility');
	}


	/**
	 * enrichFiletablesWithDbRecords
	 * enriches the incoming csv-array with objects from database and returns it
	 * returns array
	 * with domFormattedFieldNames: array[$index][$tablename][durchfuehrungsCode | codeSuffix];
	 * and  objects: object[$index]['db'][$tablename]->getDurchfuehrungsCode() | ...->getCodeSuffix();
	 * 
	 * the method maps the values from:
	 * - file filetransferUtility->concatFileTables('course') 
	 * - database getCourses( now, filtered )
	 * 
     * @param array $aFileContents  
	 * @return array
	 */
	Public function enrichFiletablesWithDbRecords( $aFileContents )
	{

        if( !count($aFileContents) ) return [];

        // find matching records if already stored
		$englishStartDate = $this->dateUtility->getStichtag();

		$dbKurse = $this->getCourses( 1 , $englishStartDate );
		
        if( !is_array($dbKurse) || !count($dbKurse) ) return $aFileContents;
        
        $abstractArr = [ 'lektion'=>[] , 'durchfuehrung'=>[] , 'version'=>[] , 'kurs'=>[]  ];
        
        $aCourseBox = [];
        foreach( $aFileContents as $index => $aFileContent){
			$kursCode = trim( $aFileContent['kurs']['kursCode'] );
			if( $kursCode ) $oKurse = $this->kursRepository->findByKursCode( $kursCode );
			if( $oKurse ){// only one object expected, but we have to loop anyway through the objects
				foreach($oKurse as $kurs){if( !$kurs ) continue;
					$kursUid = $kurs->getUid();
					if( !isset( $dbKurse[ $kursUid ] ) ) continue;
					// matching Kurs found
 					$aCourseBox[$index] = $abstractArr;
					$aCourseBox[$index]['kurs'] = $kurs;
					break;
				}
			}
        }
        
        // if no recordset found then return the incomed array from import-file
        if( !count($aCourseBox) ) return $aFileContents;
        
        // append the 'db' branch from stored recordsets to incomed array
        foreach( $aCourseBox as $index => $assemblerArr){
				$aFileContents[$index]['db']['kurs'] = $assemblerArr['kurs'];
				$kursUid = $assemblerArr['kurs']->getUid();
				if( !isset( $dbKurse[ $kursUid ][ 'kVersionen' ] ) || !count( $dbKurse[ $kursUid ][ 'kVersionen' ] ) ) continue;
 				if( empty( $dbKurse[ $kursUid ]['aktuell'] ) ) continue;
				$tempDb = $dbKurse[ $kursUid ][ 'kVersionen' ];
				$objVers = array_shift($tempDb); 
				if( !$objVers ) continue;
				// matching Version found
				$aFileContents[$index]['db']['version'] = $objVers;
				$drchList = $objVers->getVDurchfuehrungen();
				if( !$drchList ) continue;
				foreach( $drchList as $objDurchfuehrung ){
					$durchfuehrungCode = $objDurchfuehrung->getDurchfuehrungsCode();
					$codeSuffix = $objDurchfuehrung->getCodeSuffix();
					if(
						trim($durchfuehrungCode) == trim($aFileContents[$index]['durchfuehrung']['durchfuehrungsCode']) &&
						trim($codeSuffix) == trim($aFileContents[$index]['durchfuehrung']['codeSuffix'])
					){
						// matching Durchfuehrung found
						$aFileContents[$index]['db']['durchfuehrung'] = $objDurchfuehrung;
						$aFileContents[$index]['db']['lektion'] = $objDurchfuehrung->getDLektionen();
					}
				}
        }
        return $aFileContents;
	}


	/**
	 * getCourses
	 * creates a array containing objects from database
	 * if date is given and ($istStichtag == 1 || $istStichtag == 3) then this method returns all courses with one version only each: the active version.
	 * 
     * no_param string $datum optional string yyyy.mm.dd or empty for all versions
     * no_param bool $filterOutput optional [ default is true: list only specified by date | false: mark specific as 'aktuell' but list all ]
     * $istStichtag 0 = all | 1 filtered version | 2 all but only kurse with valid version | 3 filtered version + kurse 
     * if $istStichtag 2 or 3 then $filterOutEmptyCourses = true
     * 
	 * @param int $istStichtag default 1
	 * @param string $datum optional d.m.Y german or Y-m-d english-date
	 * @return array
	 */
	Public function getCourses( $istStichtag = 1 , $datum = '' )
	{
		$englDate = $datum ? $this->dateUtility->sanitizeDateTimeStringToEnglish( $datum ) : date( 'Y-m-d' );
		
		$filterOutEmptyCourses = $istStichtag > 1;
		if( $filterOutEmptyCourses ) $istStichtag -= 2;
			
		$dbKurse = $this->getCourses_createArrayCourses();
		if( !$dbKurse ) return;
		
        // find the version that matces to the given date and append it to kurs
		$dbNewst = [];
		foreach( $dbKurse as $kUid => $arrKurs ){
			$dbNewst[ $kUid ] = $arrKurs;
			$aVersion = $this->versionRepository->findNewest( $kUid , $englDate );
			foreach( $aVersion as $version ) { // there should be only one records, anyway break at the end - just in case of.
 				$dbNewst[ $kUid ][ 'aktuell' ] = $version['uid'];
				$dbNewst[ $kUid ][ 'kVersionen' ][$version['uid']] = $this->versionRepository->findByUid( $version['uid'] );
				break;
			}
		}
		
		 // list only specified by date
		if( $istStichtag == true ){
			foreach( $dbNewst as $kUid => $arrKurs ){
				if( $filterOutEmptyCourses && !isset($arrKurs['kVersionen']) ) unset($dbNewst[$kUid]);
			}
			return $dbNewst;
		}

		// list all BUT mark specific as aktuell = version.uid
		foreach( $dbKurse as $kUid => $arrKurs ){
			$aVersionen = $this->versionRepository->findByKurs( $kUid );
			$dbKurse[ $kUid ][ 'aktuell' ] = isset($dbNewst[ $kUid ][ 'aktuell' ]) ? $dbNewst[ $kUid ][ 'aktuell' ] : 0;
			foreach( $aVersionen as $version ) {
				$vUid = $version->getUid();
				if( !$vUid ) continue; // error!? otherwise: append also the 'aktuell' one, even if it has been done for $dbNewst
				$dbKurse[ $kUid ][ 'kVersionen' ][$vUid] = $this->versionRepository->findByUid( $vUid );
			}
			if( $filterOutEmptyCourses && ( !isset($dbKurse[ $kUid ][ 'kVersionen' ]) || !count($dbKurse[ $kUid ][ 'kVersionen' ]) ) ) unset($dbKurse[ $kUid ]);
		}
		return $dbKurse;
	}

	/**
	 * helper getCourses_createArrayCourses
	 * used by getCourses()
	 * - creates a array containing objects
	 * 
	 * @return array
	 */
	Private function getCourses_createArrayCourses()
	{
		$dbKurse = array();
		
 		$oKurse = $this->kursRepository->findAll();
		$asArray = false;
//		$oKurse = $this->kursRepository->callSqlStatement('SELECT * FROM tx_sfgzkurs_domain_model_kurs;' , $asArray );
		
		if( !$oKurse ) return $dbKurse;
		if( !$asArray && !is_object($oKurse) ) return $dbKurse;
		if( $asArray && !is_array($oKurse) ) return $dbKurse;
		if( !count($oKurse) ) return $dbKurse;
  		foreach( $oKurse as $objKurs ){
  			$kUid = $objKurs->getUid();
// 			// exclude disabled records
  			$method = 'get' . ucFirst( $this->disablingField );
  			if( method_exists( $objKurs , $method ) && $objKurs->$method() == 1 ) continue;
			// get all properties of record
 			$properties = $objKurs->_getProperties() ;
 			foreach ( $properties as $key => $value ) $dbKurse[ $kUid ][ $key ] =  $value ;
 			unset($dbKurse[ $kUid ][ 'kVersionen' ]);
  		}
		return $dbKurse;
	}


	/**
	 * getArrayCourses
	 * creates a array with arrays from database
     * 
	 * @param int $istStichtag default 1
	 * @param string $englDate optional Y-m-d english-date
	 * @return array
	 */
	Public function getArrayCourses( $istStichtag = true , $englDate = '' )
	{
 			$dbKurse = $this->getCourses( $istStichtag , $englDate );
 			
 			$aKurse = $this->objToArrayLoop( $dbKurse );
 			
 			return $aKurse;
 			
	}

	/**
	 * objToArrayLoop
	 * returns a array containing arrays 
	 * converts database objects in a array to arrays
	 * transforms domFormattedObjectNames to sql_field_names
     * 
	 * @param string $aObjDb a array or object containing mixed values, arrays and objects.
	 * @return array
	 */
	Private function objToArrayLoop( $aObjDb )
	{
 			
 			if (is_a($aObjDb, 'DateTime')){
				return $aObjDb->format('Y-m-d');

 			}elseif( !is_array($aObjDb) && !is_object($aObjDb) ) {
				// String or numeric value
				return $aObjDb;
				
 			}
 			
			// A bunch of database objects OR a array
 			$aOut = [];
			foreach( $aObjDb as $index => $varContent ){
				
				if( is_object($varContent) && method_exists( $varContent , 'getUid' ) ){
					// database object. The uid gives the nicer index than $index from object whitch is not consistent
					$uid = $varContent->getUid();
					$properties = $varContent->_getProperties() ;
					foreach ( $properties as $key => $value ) {
						$sql_fieldname = is_numeric($key) ? $key : GeneralUtility::camelCaseToLowerCaseUnderscored($key);
						$aOut[$uid][$sql_fieldname] = $this->objToArrayLoop( $value );
					}
				}else{
					// Array OR A bunch of objects OR DateTime object OR String or Numeric values
					$sql_fieldname = is_numeric($index)  ? $index : GeneralUtility::camelCaseToLowerCaseUnderscored($index);
					$aOut[$sql_fieldname] = $this->objToArrayLoop( $varContent );
				}
			
			}
 			return $aOut;
	}

	/**
	 * getKategorien
     * 
	 * @return array
	 */
	Public function getKategorien()
	{
		$kategorien = $this->kategorieRepository->findAll();
		return $this->objToArrayLoop($kategorien);
	}

}
