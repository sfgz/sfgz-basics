<?php
namespace Sfgz\SfgzKurs\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

$extDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName('typo3conf/ext/sfgz_fetools/Resources/Private/PHP/fpdf/');
define( 'FPDF_FONTPATH' , $extDir .  'font/' ); 
set_include_path($extDir);
include $extDir.'PdfRotatePagegroup.php';

class PdfUtility extends \PdfRotatePagegroup {

	protected $FontSpacingPt;      // current font spacing in points
	protected $FontSpacing;        // current font spacing in user units

	/**
	* pdf_charset
	*
	* @var string
	*/
	Public $pdf_charset = 'ISO-8859-15';

	/**
	* headerText
	*
	* @var array
	*/
	Public $headerText = array();

	/**
	* pageConf
	*
	* @var array
	*/
	Public $pageConf = array(
		'imagePath' => '' , 
		'keywords' => '' , 
		'subject' => '' , 
		'title' => '' , 
		'fontfamily' => 'Helvetica' , 
		'own_fonts' => 1 , 
		'fsize' => 11 , 
		'fsize_title' => 22 , 
		'fsize_subtitle' => 14 , 
		'fsize_header' => 8.5 , 
		'lfeed' => 6.5 , 
		'lfeed_header' => 3.5 , 
		'fontSpacing' => 0 , 
		'lineSmall' => 0.15 , 
		'lineBold' => 1.55 , 
		'topMargin' => 20.5 , 
		'rightMargin' => 15 , 
		'bottomMargin' => 12 , 
		'leftMargin' => 59.5 , 
		'leftMargin_header' => 151.7 , 
		'docuwidth' => 210 , 
		'imageLeft' => 10 , 
		'imageTop' => 6 , 
		'imageWidth' => 100 , 
		'specchars' => array( '-g-' => 150 , 'laquo' => 171 , 'raquo' => 187 , 'copy' => 169 , 'copyright' => 169 , 'C' => 169 , 'registered' => 174 , 'at' => 64 ) , 
	  );
	
	public function initializePdf( $pageConf = array() ) {
		
		if(count($pageConf)){
		      foreach($pageConf as $key=>$value) {
					if(isset($this->pageConf[$key] )) $this->pageConf[$key] = $value;
		      }
		}
		
//		if( $this->pageConf['own_fonts'] ) $this->AddFont('HelveticaBlack','','helveticaneueblack.php'); /* broken!
//  		if( $this->pageConf['own_fonts'] ) $this->AddFont('HelveticaNeueBlack','','helveticaneuecondensedblack.php');
		if( $this->pageConf['own_fonts'] ) $this->AddFont('HelveticaBlack','','helveticablack.php');
		
		$this->SetTopMargin( $this->pageConf['topMargin'] );
		$this->SetLeftMargin( $this->pageConf['leftMargin'] );
		$this->SetRightMargin( $this->pageConf['rightMargin'] );
	 	$this->SetAutoPageBreak( TRUE , $this->pageConf['bottomMargin'] );
		$this->SetTextColor(0,0,0);
		$this->SetDrawColor(0,0,0);
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		$this->SetLineWidth(  $this->pageConf['lineWidth'] );
		$this->SetKeywords(  $this->pageConf['keywords'] );
		$this->SetSubject(  $this->pageConf['subject'] );
		$this->SetTitle(  $this->pageConf['title'] );
		if( $this->pageConf['fontSpacing'] ) $this->SetFontSpacing( $this->pageConf['fontSpacing'] );
		
	}
	
	function Header() {
		$this->TopY = $this->getY();
		
		if( file_exists( $this->pageConf['imagePath'] ) && is_file($this->pageConf['imagePath']) ){
				$this->image( $this->pageConf['imagePath'] , $this->pageConf['imageLeft'] , $this->pageConf['imageTop'] , $this->pageConf['imageWidth'] );
		}
		
		$leftTab = $this->pageConf['leftMargin_header'];
		$lh = $this->pageConf['lfeed_header'];
		$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize_header'] );
		
		$w = $this->pageConf['docuwidth'] - $leftTab;
		
		if( count( $this->headerText ) ){
			foreach( $this->headerText as $txt ){
				$this->SetX( $leftTab );
				$this->Cell( $w , $lh , $txt , '' , 1 , 'L' );
			}
		}
	    
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
	}
	
	function Footer() {
	}
	
	function drawLinesTillBottom( $maxLn ) {
		$lh = $this->pageConf['lfeed'];
		$ponr = 297 - ($lh + $this->pageConf['bottomMargin']);
 		$y = $this->getY();
 		$lns = ( $y >= $ponr ) ? 0 : floor( ( $ponr - $y ) / $lh );
 		if( $lns ) $this->Ln( ( $lh * ( $lns > $maxLn ? $maxLn : $lns ) ) );
	}
	
	function encode( $value ) {
		$sr = [
			'<ul>'=>'' , 
			'</ul>'=>" .\n\n\n" , 
			'<li>'=> "" , 
			'</li>'=>'; ' , 
			'<p>'=>'' , 
			'</p>'=>"\n" , 
			'<br />'=>"\n" , 
			'<br/>'=>"\n" , 
			'<br>'=>"\n"  , 
			'&nbsp;'=>' ' , 
			';  .'=>".",  
			' .'=>""  
		];

		$value = trim( str_replace( "\n\r" , "\n" , $value ) );
		$value = trim( str_replace( "\n" , '' , $value ) );
		$brkChar = trim( str_replace( array_keys($sr) , $sr , $value ) );
		$brkChar = trim( str_replace( "\n\r" , "\n" , $brkChar ) );
		$brkChar = trim( str_replace( "\n\n" , "\n" , $brkChar ) );
		
		$localizedChar = iconv("UTF-8", $this->pdf_charset, $brkChar ) ;
		
		$localizedChar = str_replace( '_datum_' , date('d.m.Y') , $localizedChar );
		$localizedChar = str_replace( '_jahr_' , date('Y') , $localizedChar );
		
		foreach( $this->pageConf['specchars'] as $vNam => $chr ) 
		$localizedChar = str_replace( '_'.$vNam.'_' , chr($chr) , $localizedChar );
		
		return trim( trim( $localizedChar ) , '.' );
	}
	
	function mkTitle( $value ){
		$lh = 8;
		
		if( $this->pageConf['own_fonts'] ){
			$this->SetFont( 'HelveticaBlack','' , $this->pageConf['fsize_title'] );
		//	$this->SetFontSpacing( -0.5 );
		}else{
			$this->SetFont( 'Helvetica' , 'B' , $this->pageConf['fsize_title'] );
			//$this->SetFontSpacing( 0.6 );
		}
		$x = $this->GetX();
		$this->SetX( $x-0.25 );
		$this->MultiCell( 0 , $lh , $value , '' , 'L' );
		
		$this->SetFontSpacing( $this->pageConf['fontSpacing'] );
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
	}
	
	function mkSubTitle( $value ){
		$lh = 6;
		
		if( $this->pageConf['own_fonts'] ){
			$this->SetFont( 'HelveticaBlack','' , $this->pageConf['fsize_subtitle'] );
		}else{
			$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize_subtitle'] );
		}
		$this->SetFontSpacing( -0.4 );
		
		$this->MultiCell( 0 , $lh , $value , '' , 'L' );
		
		$this->SetFontSpacing( $this->pageConf['fontSpacing'] );
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
	}
	
	function SetFontSpacing($size)
	{
		if($this->FontSpacingPt==$size)
			return;
		$this->FontSpacingPt = $size;
		$this->FontSpacing = $size/$this->k;
		if ($this->page>0)
			$this->_out(sprintf('BT %.3f Tc ET', $size));
	}

	public function _dounderline($x, $y, $txt)
	{
		// Underline text
		$up = $this->CurrentFont['up'];
		$ut = $this->CurrentFont['ut'];
		$w = $this->GetStringWidth($txt)+$this->ws*substr_count($txt,' ')+(strlen($txt)-1)*$this->FontSpacing;
		return sprintf('%.2F %.2F %.2F %.2F re f',$x*$this->k,($this->h-($y-$up/1000*$this->FontSize))*$this->k,$w*$this->k,-$ut/1000*$this->FontSizePt);
	}	
}
// Handle special IE contype request
if(isset($_SERVER['HTTP_USER_AGENT']) && $_SERVER['HTTP_USER_AGENT']=='contype')
{
	header('Content-Type: application/pdf');
	exit;
}

?>
