<?php
namespace Sfgz\SfgzKurs\Utility;
 
	use Box\Spout\Reader\ReaderFactory;
	use Box\Spout\Writer\WriterFactory;
	use Box\Spout\Common\Type;
	
 /** 
 * Class SpreadsheetUtility
 * 
 * 
 */
 
class SpreadsheetUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * Property config
	 *
	 * @var array
	 */
	Public $config = array(
		'spoutFilpath' => 'typo3conf/ext/sfgz_fetools/Resources/Private/PHP/Spout/',
		'excelReaderFile' => 'typo3conf/ext/sfgz_fetools/Resources/Private/PHP/excel_reader/excel_reader27.php',
	);

	/**
	 * __construct
	 *
     * @param array $config
	 * @return void
	 */
	public function __construct( $config = array() ){
			if( count($config) ) {
				foreach( $config as $key => $var ) if( isset($this->config[$key]) ) $this->config[$key] = $var;
			}
			$this->config['excelReaderFile'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->config['excelReaderFile'] );

			$this->config['spoutFilpath'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->config['spoutFilpath'] );
			if( file_exists($this->config['spoutFilpath'].'Autoloader/autoload.php') ) require_once( $this->config['spoutFilpath'].'Autoloader/autoload.php' ); 
	}
	
	/**
	* fileToArray
	* 
	* @param string $filePathName
	* @return array
	*/
	public function fileToArray( $filePathName ) {
	
		$aSpreadsheet = [];
		$suffix = pathinfo( $filePathName , PATHINFO_EXTENSION );
		
		if( 'csv' == strtolower($suffix) ){
			$aSpreadsheet = $this->csv_to_array( $filePathName );
		
		}elseif( 'xls' == strtolower($suffix) ){
			$aSheetsInFile = $this->xlsFile2Arrays( $filePathName );
			if( is_array($aSheetsInFile) ){
                $aSpreadsheet = array_shift( $aSheetsInFile );
			}else{
                return $aSheetsInFile;
			}
		
		}elseif( 'xlsx' == strtolower($suffix) || 'ods' == strtolower($suffix) ){  
			$aSheetsInFile = $this->spreadsheetToArrays( $filePathName );
			if( is_array($aSheetsInFile) ){
                $aSpreadsheet = array_shift( $aSheetsInFile );
			}else{
                return $aSheetsInFile;
			}
			
		}
		return $aSpreadsheet;
	}
	
	
	/**
	* arrayToSpreadSheet
	* 
	* @param array $spoutRs
	* @param string $filePathname 
	* @return void
	*/
	public function arraysToSpreadSheet( $spoutRs, $filePathname ) {
			if( !file_exists($this->config['spoutFilpath']) ) return false;
			$type = pathinfo( $filePathname , PATHINFO_EXTENSION );
			
			switch( $type ){
				case 'ods' : $writer = WriterFactory::create(Type::ODS); break;
				case 'xlsx' : $writer = WriterFactory::create(Type::XLSX); break;
				default : return false; break;
			}
			$writer->setShouldCreateNewSheetsAutomatically(false);

			$writer->openToBrowser( pathinfo( $filePathname , PATHINFO_FILENAME ).'.'. $type); // stream data directly to the browser
			
			if( !is_array($spoutRs) ) return false;
			$testTab = $spoutRs;
			$testRow = array_shift($testTab);
			if( !is_array($testRow) ) return false;
			$testField = array_shift($testRow);
			if( is_array($testField) ){
				foreach( $spoutRs as $sheet => $shtRs ){
					$writer->addRows( $shtRs ); // add multiple rows at a time
					$writer->getCurrentSheet()->setName( $sheet );
					$writer->addNewSheetAndMakeItCurrent();
				}
			}else{
				$writer->addRows( $spoutRs ); // add multiple rows at a time
				$writer->getCurrentSheet()->setName(pathinfo( $filePathname , PATHINFO_FILENAME ));
			}
			
			$writer->close();
			exit();
	}
	
	/**
	* spreasheetToArrays
	* 
	* @param string $filePathName
	* @param boolean $prependHeadrow
	* @return array
	*/
	public function spreadsheetToArrays( $filePathName , $prependHeadrow = FALSE ) {
			if( !file_exists($this->config['spoutFilpath']) ) return 'Datei fehlt: ' . $this->config['spoutFilpath'];

			$uploadedFileExtension = strtolower( pathinfo( $filePathName , PATHINFO_EXTENSION ) );
			switch( $uploadedFileExtension ){
				case 'ods' : $reader = ReaderFactory::create(Type::ODS); break;
				case 'xlsx' : $reader = ReaderFactory::create(Type::XLSX); break;
				case 'xls' : return $this->xlsFile2Arrays( $filePathName , $prependHeadrow ); break;
				default : return false; break;
			}
			
			$spoutRs = array();
			$reader->open($filePathName);
			foreach ($reader->getSheetIterator() as $sNr => $sheet) {
				$sheetname = urlencode( str_replace( '.csv' , '' , $sheet->getName() ) );
				foreach ($sheet->getRowIterator() as $rNr => $row) {
					if( !isset($fieldnames[$sNr]) ) {$fieldnames[$sNr] = $row; if(!$prependHeadrow) continue;}
					foreach($fieldnames[$sNr] as $fix=>$fld) $spoutRs[$sheetname][$rNr][$fld] = $row[$fix];
				}
			}
			$reader->close();
			return $spoutRs;
	}
	
	/**
	 * xlsFile2Arrays
	 * 
	 * @param string $filePathName
	 * @param boolean $prependHeadrow
	 * @return array
	 */
	public function xlsFile2Arrays( $filePathName , $prependHeadrow = FALSE ) {
	
			if( !file_exists( $this->config['excelReaderFile'] ) ) return false;
			require_once( $this->config['excelReaderFile'] );
			$data = new \Spreadsheet_Excel_Reader($filePathName);
			
			$excelReaderRs = array();
			foreach( $data->sheets as $sNr => $objSheet){
				$sheetname = urlencode( str_replace( '.csv' , '' , $data->boundsheets[$sNr]['name'] ) );
				foreach( $objSheet['cells'] as $rNr => $row){
					if( !isset($fieldnames[$sNr]) ) {// first row (titles)
						$fieldnames[$sNr] = $row;
						if( count($row) < $objSheet['numCols'] ){
							for( $emptyCols = count($row) ; $emptyCols <= $objSheet['numCols'] ; ++$emptyCols) { 
									$name = strtolower(( (($emptyCols-1)/26>=1)?chr(($emptyCols-1)/26+64):'') . chr(($emptyCols-1)%26+65));
									$fieldnames[$sNr][$emptyCols . '_' . $name] = $name; 
							}
						}
						 // default is not to insert the first row with the column-headers. But until here we need this row to get fieldnames
						if(!$prependHeadrow) continue;
					}
					foreach($fieldnames[$sNr] as $fix=>$fld) $excelReaderRs[$sheetname][$rNr][$fld] = isset($row[$fix]) ? utf8_encode($row[$fix]) : '';
				}
			}
			return $excelReaderRs;
	}
	
	/**
	* @link http://gist.github.com/385876
	 * 
	 * @param string $filePathName
	 * @param boolean $prependHeadrow
	 * @return array
	*/
	function csv_to_array($filePathName='' , $prependHeadrow = FALSE )
	{
		if(!file_exists($filePathName) || !is_readable($filePathName))
			return FALSE;
			
		$aFileInfo = $this->analyse_file($filePathName );
		$delimiter = $aFileInfo['delimiter'];

		$header = NULL;
		$data = array();
		if (($handle = fopen($filePathName, 'r')) !== FALSE)
		{
			while (($row = fgetcsv($handle, 1000, $delimiter)) !== FALSE)
			{
				if(!$header)
					$header = $row;
				else
					$data[] = array_combine($header, $row);
			}
			fclose($handle);
		}
		if( !$prependHeadrow ) array_shift($data);
		return $data;
	}

	/**
	* analyse_file
	* 
	* from Ashley, http://php.net/manual/de/function.fgetcsv.php
	* 
	* Example Usage:
    * $Array = analyse_file('/www/files/file.csv', 10);
    *
    * example usable parts
    * $Array['charset']['value'] => ISO-8859-15
    * $Array['delimiter']['value'] => ,
    * $Array['linebreak']['value'] => \r\n
    * 
	* @param string $file 
	* @param integer $capture_limit_in_kb
	* @return array 
	*/
	function analyse_file($file, $capture_limit_in_kb = 10) {
		// capture starting memory usage
		$output['peak_mem']['start']    = memory_get_peak_usage(true);

		// log the limit how much of the file was sampled (in Kb)
		$output['read_kb']                 = $capture_limit_in_kb;
	
		// read in file
		$fh = fopen($file, 'r');
			$contents = fread($fh, ($capture_limit_in_kb * 1024)); // in KB
		fclose($fh);
	
		// specify allowed field delimiters
		$delimiters = array(
			'comma'     => ',',
			'semicolon' => ';',
			'tab'         => "\t",
			'pipe'         => '|',
			'colon'     => ':'
		);
	
		// specify allowed line endings
		$linebreaks = array(
			'rn'         => "\r\n",
			'n'         => "\n",
			'r'         => "\r",
			'nr'         => "\n\r"
		);
	
		// loop and count each line ending instance
		foreach ($linebreaks as $key => $value) {
			$line_result[$key] = substr_count($contents, $value);
		}
	
		// sort by largest array value
		asort($line_result);
	
		// log to output array
		$output['linebreak']['results']     = $line_result;
		$output['linebreak']['count']     = end($line_result);
		$output['linebreak']['key']         = key($line_result);
		$output['linebreak']['value']     = $linebreaks[$output['linebreak']['key']];
		$lines = explode($output['linebreak']['value'], $contents);
	
		// remove last line of array, as this maybe incomplete?
		array_pop($lines);
	
		// create a string from the legal lines
		$complete_lines = implode(' ', $lines);
	
		// log statistics to output array
		$output['lines']['count']     = count($lines);
		$output['lines']['length']     = strlen($complete_lines);
	
		// loop and count each delimiter instance
		foreach ($delimiters as $delimiter_key => $delimiter) {
			$delimiter_result[$delimiter_key] = substr_count($complete_lines, $delimiter);
		}
	
		// sort by largest array value
		asort($delimiter_result);
	
		// log statistics to output array with largest counts as the value
		$output['delimiter']['results']     = $delimiter_result;
		$output['delimiter']['count']         = end($delimiter_result);
		$output['delimiter']['key']         = key($delimiter_result);
		$output['delimiter']['value']         = $delimiters[$output['delimiter']['key']];

		$output['charset']['list'] = 'utf-8,utf-16,ucs2,iso-10646-ucs-2,iso-8859-15,iso-8859-1,windows-1251';
		$charsetlist = explode( ',' , $output['charset']['list'] );
		foreach ($charsetlist as $item) {
			if( strtolower(mb_detect_encoding( $complete_lines , $item , true)) == strtolower($item) ){ // first test ok
				$sample = iconv($item, $item, $complete_lines);
				if (md5($sample) == md5($complete_lines)) { // second test ok
					$output['charset']['value'] =  $item;
					break;
				}
			}
		}
	
		// capture ending memory usage
		$output['peak_mem']['end'] = memory_get_peak_usage(true);
		
		
		return array( 'charset'=>$output['charset']['value'] , 'delimiter'=>$output['delimiter']['value'] , 'linebreak'=>$output['linebreak']['value'] , 'delimiter_key'=>$output['delimiter']['key'] , 'linebreak_key'=>$output['linebreak']['key'] );
	}
}
