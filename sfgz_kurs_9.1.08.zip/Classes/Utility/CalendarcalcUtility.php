<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class CalendarcalcUtility
 * 
 * 
 */
 
class CalendarcalcUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * array aDurchfuehrung
	 */
	Public $aDurchfuehrung = [ 
			'terminStart' => '2018-01-31',
			'terminEnde' => '2018-02-07',
			'zeitBis' => '18:00',
			'veranstaltungen' => '2',
			'periodika' => 1 
		];

	/**
	 * array skippedDates
	 */
	Public $skippedDates = null;

	/**
	 * array calendarDB
	 */
	protected $calendarDB = null;

	/**
	 * array settings
	 */
	protected $settings = null;

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_vw';

    /**
     * timeZoneString
     *
     * @var string
     */
    protected $timeZoneString = 'Europe/Zurich';

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->timeZone = new \DateTimeZone( $this->timeZoneString );

		$this->filetransferUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\FiletransferUtility');
		$this->calendarDB = $this->filetransferUtility->getCalendarsFtpFile();
    }

    /**
     * calcVeranstaltungen
     *
     * @param int $daysteps
     * @param int $startUxTime
     * @param int $endUxTime
     * @param string $zeitBis
     * @return int
     */
    public function calcVeranstaltungen( $daysteps , $startUxTime , $endUxTime , $zeitBis )
    {
			$jumps = $daysteps * 24 * 3600;
			$stundeBis = substr( $zeitBis , 0 , 2 );
			$calcEvents = 0;
			$this->skippedDates = [];
			for( $start = $startUxTime ; $start <= $endUxTime ; $start+= $jumps ){
				$engDate = date('Y-m-d',$start);
				$adjustDateToNoon = new \DateTime( $engDate . ' 12:00' , $this->timeZone ); 
				$start = $adjustDateToNoon->format('U');
				if(
					$daysteps == 1 || 
					!isset( $this->calendarDB[$engDate] ) || 
					substr( $this->calendarDB[$engDate]['zeitAb'] , 0 , 2 ) > $stundeBis
				){
					$calcEvents+=1;
				}
				if( isset( $this->calendarDB[$engDate] ) ) $this->skippedDates[date('d.m.Y',$start)] = $this->calendarDB[$engDate]['typ'];
			}
			return $calcEvents;
	}

    /**
     * calcDateEnd
     *
     * @param int $daysteps
     * @param int $veranstaltungen
     * @param int $startUxTime
     * @param string $zeitBis
     * @return \DateTime
     */
    public function calcDateEnd( $daysteps , $veranstaltungen , $startUxTime , $zeitBis )
    {
			$jumps = $daysteps * 24 * 3600;
			$stundeBis = substr( $zeitBis , 0 , 2 );
			
			$start = $startUxTime;
			$this->skippedDates = [];
			for( $dayDiff = 0 , $calcEvents = 1; $calcEvents < $veranstaltungen ; $dayDiff+=1 ){
				$start += $jumps;
				$engDate = date('Y-m-d',$start);
				if(
					$daysteps == 1 || 
					!isset( $this->calendarDB[$engDate] ) || 
					substr( $this->calendarDB[$engDate]['zeitAb'] , 0 , 2 ) > $stundeBis
				){
					$calcEvents += 1;
				}
				if( isset( $this->calendarDB[$engDate] ) ) $this->skippedDates[date('d.m.Y',$start)] = $this->calendarDB[$engDate]['typ'];
				
				$adjustDateToNoon = new \DateTime( $engDate . ' 12:00' , $this->timeZone ); 
				$start = $adjustDateToNoon->format('U');
			}
			$calcDatetime = new \DateTime( date('Y-m-d 12:00' , $startUxTime) ,$this->timeZone);
			$calcDatetime->add(new \DateInterval('P' . ( $daysteps * $dayDiff ) . 'D')); // P1D means a period of 1 day
			return $calcDatetime;
	}

    /**
     * calcDateStart
     *
     * @param int $daysteps
     * @param int $veranstaltungen
     * @param int $endUxTime
     * @param string $zeitBis
     * @return \DateTime
     */
    public function calcDateStart( $daysteps , $veranstaltungen , $endUxTime , $zeitBis )
    {
			$jumps = $daysteps * 24 * 3600;
			$stundeBis = substr( $zeitBis , 0 , 2 );
			
			$endeUx = $endUxTime;
			$this->skippedDates = [];
			for( $dayDiff = 0 , $calcEvents = 1; $calcEvents < $veranstaltungen ; $dayDiff+=1 ){
				$endeUx -= $jumps;
				$engDate = date('Y-m-d',$endeUx);
				if(
					$daysteps == 1 || 
					!isset( $this->calendarDB[$engDate] ) || 
					substr( $this->calendarDB[$engDate]['zeitAb'] , 0 , 2 ) > $stundeBis
				){
					$calcEvents += 1;
				}
				if( isset( $this->calendarDB[$engDate] ) ) $this->skippedDates[date('d.m.Y',$endeUx)] = $this->calendarDB[$engDate]['typ'];
				
				$adjustDateToNoon = new \DateTime( $engDate . ' 12:00' , $this->timeZone ); 
				$endeUx = $adjustDateToNoon->format('U');
			}
			$calcDatetime = new \DateTime( date('Y-m-d 12:00' , $endUxTime) ,$this->timeZone);
			$calcDatetime->sub(new \DateInterval('P' . ( $daysteps * $dayDiff ) . 'D')); // P1D means a period of 1 day
			return $calcDatetime;
	}
	
    /**
     * helper setDurchfuehrungFromObj
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung
     * @param array $propertiesToSkip
     * @return void
     */
    public function setDurchfuehrungFromObj(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung , $propertiesToSkip )
    {
			$this->aDurchfuehrung = [];
			$this->aDurchfuehrung['zeitBis'] = $durchfuehrung->getZeitBis();
			$this->aDurchfuehrung['periodika'] = $durchfuehrung->getPeriodika(); // 0:daily | 1:weekly | 2:all2weeks
			$this->aDurchfuehrung['daysteps'] = empty($this->aDurchfuehrung['periodika']) ? 1 : $this->aDurchfuehrung['periodika'] * 7;

			$this->aDurchfuehrung['veranstaltungen'] = $durchfuehrung->getVeranstaltungen();
			
			$datetime1 = $propertiesToSkip['terminStart'] ? '' : $durchfuehrung->getTerminStart();
			$this->aDurchfuehrung['terminStart'] = ( empty($datetime1) || 0 == $datetime1->format('U') ) ? '' : $datetime1->format('U');
			
			$datetime2 = $propertiesToSkip['terminEnde'] ? '' : $durchfuehrung->getTerminEnde();
			$this->aDurchfuehrung['terminEnde'] =( empty($datetime2) || 0 == $datetime2->format('U') ) ? '' : $datetime2->format('U');
			
			
			if( !empty($this->aDurchfuehrung['veranstaltungen']) && !empty($this->aDurchfuehrung['terminStart']) && empty($this->aDurchfuehrung['terminEnde']) ){
				$this->aDurchfuehrung['message'] = 'TerminEnde';
				$this->aDurchfuehrung['resultTerminEnde'] = $this->calcDateEnd( $this->aDurchfuehrung['daysteps'] , $this->aDurchfuehrung['veranstaltungen'] , $this->aDurchfuehrung['terminStart'] , $this->aDurchfuehrung['zeitBis'] );
			}elseif( !empty($this->aDurchfuehrung['veranstaltungen']) && empty($this->aDurchfuehrung['terminStart']) && !empty($this->aDurchfuehrung['terminEnde']) ){
				$this->aDurchfuehrung['message'] = 'TerminStart';
				$this->aDurchfuehrung['resultTerminStart'] = $this->calcDateStart( $this->aDurchfuehrung['daysteps'] , $this->aDurchfuehrung['veranstaltungen'] , $this->aDurchfuehrung['terminEnde'] , $this->aDurchfuehrung['zeitBis'] );
			
			}elseif( empty($this->aDurchfuehrung['veranstaltungen']) && !empty($this->aDurchfuehrung['terminStart']) && !empty($this->aDurchfuehrung['terminEnde']) ){
				$this->aDurchfuehrung['message'] = 'Veranstaltungen';
				$this->aDurchfuehrung['resultVeranstaltungen'] = $this->calcVeranstaltungen( $this->aDurchfuehrung['daysteps'] , $this->aDurchfuehrung['terminStart'] , $this->aDurchfuehrung['terminEnde'] , $this->aDurchfuehrung['zeitBis'] );
			}
			$this->aDurchfuehrung['method'] = 'set' . $this->aDurchfuehrung['message'];
			return $this->aDurchfuehrung;
	}
	

}
