<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_info',
        'label' => 'datum_anzeige',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
		'enablecolumns' => [
        ],
		'searchFields' => 'datum_anzeige,infotext,i_belegungen',
        'iconfile' => 'EXT:sfgz_kurs/Resources/Public/Icons/tx_sfgzkurs_domain_model_info.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'datum_anzeige,infotext,i_belegungen',
    ],
    'types' => [
		'1' => ['showitem' => 'datum_anzeige,infotext,i_belegungen'],
    ],
    'columns' => [
        'datum_anzeige' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgzkurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_info.datum_anzeige',
	        'config' => [
			    'dbType' => 'date',
			    'type' => 'input',
			    'size' => 7,
			    'eval' => 'date',
			    'default' => time()
			],
	    ],
	    'infotext' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgzkurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_info.infotext',
	        'config' => [
			    'type' => 'text',
			    'cols' => 40,
			    'rows' => 15,
			    'eval' => 'trim',
			],
	        'defaultExtras' => 'richtext:rte_transform[mode=ts_css]'
	    ],
	    'i_belegungen' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_info.i_belegungen',
	        'config' => [
			    'type' => 'inline',
			    'foreign_table' => 'tx_sfgzkurs_domain_model_belegung',
			    'foreign_field' => 'info',
			    'maxitems' => 9999,
			    'appearance' => [
			        'collapseAll' => 1,
			        'levelLinksPosition' => 'top',
			        'showSynchronizationLink' => 1,
			        'showPossibleLocalizationRecords' => 1,
			        'showAllLocalizationLink' => 1
			    ],
			],
	    ],
    ],
];
