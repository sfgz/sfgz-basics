<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kategorie',
        'label' => 'kategorie_name',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'default_sortby' => 'kategorie_gruppe,reihenfolge',
		'enablecolumns' => [
        ],
		'searchFields' => 'kategorie_gruppe,kategorie_name',
        'iconfile' => 'EXT:sfgz_kurs/Resources/Public/Icons/tx_sfgzkurs_domain_model_kategorie.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'kategorie_gruppe, kategorie_name,reihenfolge',
    ],
    'types' => [
		'1' => ['showitem' => 'kategorie_gruppe, kategorie_name,reihenfolge'],
    ],
    'columns' => [
        'kategorie_gruppe' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kategorie.kategorie_gruppe',
	        'config' => [
			    'type' => 'select',
			    'renderType' => 'selectSingle',
			    'items' => [
			        ['LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kategorie.kategoriegruppe.sel.1', 1],
			        ['LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kategorie.kategoriegruppe.sel.2', 2],
			        ['LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kategorie.kategoriegruppe.sel.3', 3],
			    ],
			    'default' => 1,
			    'size' => 1,
			    'maxitems' => 1,
			    'eval' => ''
			],
	    ],
	    'kategorie_name' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kategorie.kategorie_name',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim,required'
			],
	    ],
        'reihenfolge' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kategorie.reihenfolge',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim,required'
			],
        ],
    ],
];
