# customcategory=sfgz_kursverwaltung=SfGZ Kursverwaltung
# customsubcategory=a10categorien=Kategorien Gruppen
# customsubcategory=a10ftp=FTP-Server
# customsubcategory=b10export=Export
# customsubcategory=c10persistence=Speicher-Ordner
# customsubcategory=c15pages=Seiten
# customsubcategory=c20display=Display-Anzeige
# customsubcategory=d10file=Template-Grundeinstellung

plugin.tx_sfgzkurs_vw {
  view {
    # cat=sfgz_kursverwaltung/d10file; type=string; label=Path to template root (FE)
    templateRootPath = EXT:sfgz_kurs/Resources/Private/Templates/
    # cat=sfgz_kursverwaltung/d10file; type=string; label=Path to template partials (FE)
    partialRootPath = EXT:sfgz_kurs/Resources/Private/Partials/
    # cat=sfgz_kursverwaltung/d10file; type=string; label=Path to template layouts (FE)
    layoutRootPath = EXT:sfgz_kurs/Resources/Private/Layouts/
  }
  persistence {
    # cat=sfgz_kursverwaltung/c10persistence/a; type=string; label=Default storage PID
    storagePid =
  }
  settings {
	    # cat=sfgz_kursverwaltung/a10categorien/a; type=text; label=Kategorien Gruppen:Die Hauptkategorien, duch Komma getrennt.
		kategoriegruppen = Angebotsbereiche, Berufe, WBZH Abschluss
	    # cat=sfgz_kursverwaltung/a10ftp/a; type=text; label=FTP URL:URL des FTP-Kontos.
		url = ftp.myserver.net
	    # cat=sfgz_kursverwaltung/a10ftp/b; type=text; label=FTP Username:Benutzername des FTP-Kontos.
	    username = zb_kurs
	    # cat=sfgz_kursverwaltung/a10ftp/c; type=text; label=FTP Passwort:Passwort des FTP-Kontos.
		password = zb_Aa1£
	    # cat=sfgz_kursverwaltung/c15pages/boptions;  label= Page-uid of config page:Page uid where the config-plugin is stored.
		konfiguration = 44
		# cat=sfgz_kursverwaltung/b10export/aremoteurl; type=text; label=Import URL des Remotes:URL der Seite, welche die Exportdatei importiert.
		remote_url = https://sfgz.ch/signalwerk/course/import
		# cat=sfgz_kursverwaltung/c20display/10; type=int; label= Alte Lektionen ausblenden:Anzahl Minuten nach Lektionsende, ab welchen die Lektion ausgeblendet wird. Bei negativem Wert vor Lektionsende ausblenden.
		infodisplay_hideLessonsAfterMinutes = 15
		# cat=sfgz_kursverwaltung/c20display/30; type=boolean; label=Display Clock Zeitquelle:Verwende genauere Javascript Zeit des Display-PCs anstelle von Serverseitiger PHP Zeit. Bei alten Displays ausschalten.
		use_js_time_in_clock = 1
		# cat=sfgz_kursverwaltung/c20display/50; type=boolean; label=Display Clock Design:Bahnhofsuhr statt mit Zahlen
		station_design = 1
		# cat=sfgz_kursverwaltung/c20display/70; type=int+; label=Reload Display Page:Seite nach so vielen Sekunden neu laden. Bei 0 findet kein automatisches neu-laden statt. Voreingestellt sind 300 (5 Minuten)
		reload_page = 300
  }
}

plugin.tx_sfgzkurs_conf {
  persistence {
    # cat=sfgz_kursverwaltung/c10persistence/b; type=string; label=Configuration storage PID:Leave empty if the same as in tx_sfgzkurs_vw.storagePid above
    storagePid =
  }
}


