<?php
namespace Sfgz\SfgzFoyer\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;

/** 
 * Class RecordsUtility
 * 
 * 
 */
 
class RecordsUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
     * msg
     * 
     * @var array
     */
    Public $msg = [];
	
    /**
     * infoRepository
     *
     * @var \Sfgz\SfgzFoyer\Domain\Repository\InfoRepository
     * @inject
     */
    protected $infoRepository = null;


    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     */
    protected $kursRepository = null;

    /**
     * versionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\VersionRepository
     */
    protected $versionRepository = null;

    /**
     * durchfuehrungRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\DurchfuehrungRepository
     */
    protected $durchfuehrungRepository = null;

    /**
     * lektionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\LektionRepository
     */
    protected $lektionRepository = null;
    
    /**
     * rpsMieterRepository
     *
     * @var \Mff\Mffrps\Domain\Repository\MieterRepository
     */
    protected $rpsMieterRepository = null;

    /**
     * rpsAnlassRepository
     *
     * @var \Mff\Mffrps\Domain\Repository\AnlassRepository
     */
    protected $rpsAnlassRepository = null;

    /**
     * rpsBelegungRepository
     *
     * @var \Mff\Mffrps\Domain\Repository\BelegungRepository
     */
    protected $rpsBelegungRepository = null;

    /**
     * settings
     *
     * @var array
     */
    protected $settings = null;

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->objectManager = GeneralUtility::makeInstance('TYPO3\CMS\Extbase\Object\ObjectManager');

		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);

	    $this->infoRepository = $this->objectManager->get('Sfgz\SfgzFoyer\Domain\Repository\InfoRepository');
	    $this->infoRepository->setDefaultQuerySettings($querySettings);
		
        $extensionConfig = GeneralUtility::makeInstance( \TYPO3\CMS\Core\Configuration\ExtensionConfiguration::class ); 
        $this->extConf = $extensionConfig->get('sfgz_foyer');

        $this->calendarService = GeneralUtility::makeInstance('Sfgz\\SfgzFoyer\\Service\\CalendarService');
	}

	/**
	 * setSettings
	 * settings are used for findLektionenByDatumAnzeige()
     * 
     * @param array $settings
	 * @return void
	 */
	Public function setSettings( $settings )
	{
		$this->settings = $settings;
	}
	
	
	/**
	 * getMessages
	 *  prepend index to message, put the message out and unset it
	 *
	 * @return void
	 */
	Private function returnMessage( $msg , $returnValue ) {
            $this->msg[] = $msg;
            return $returnValue;
	}
	
	
	/**
	 * getMessages
	 *  prepend index to message, put the message out and unset it
	 *
	 * @return void
	 */
	public function getMessages( $object , $targetObject ) {
	
        if( !count($object->msg) ) return $targetObject->msg;
        
        foreach( $object->msg as $i => $msg ){
            $targetObject->msg[ $i ] = $msg;
        }
        unset( $object->msg );
        return $targetObject->msg;
    }

	/**
	 * deleteInfoAndBelegungOlderThanDate
     * 
     * @param int $engDateNow
	 * @return array
	 */

	/**
	 * findInfoByDatumAnzeige
     * 
     * @param string $sEnglDate
     * @param string $calledBy optional
	 * @return array
	 */
	Public function findInfoByDatumAnzeige( $sEnglDate , $calledBy = '' )
	{

		$aObjInfo = $this->infoRepository->findHiddenByDatumAnzeige( $sEnglDate );
        $index = substr( hrtime(true) , -12); 
        if( count($aObjInfo) ){
            $this->msg[ $index ] = 'info found for ' . $sEnglDate . ': (' . count($aObjInfo) . '). (calledBy ' . $calledBy . ')';
            foreach($aObjInfo as $objInfo) break;
        }else{
            $this->msg[ $index ] = 'no info found for ' . $sEnglDate . '. (calledBy ' . $calledBy . ')';
        }
        return $objInfo;
	}

	/**
	 * findPermaInfoByDatumAnzeige
     * 
     * @param string $sEnglDate selected day
	 * @return array
	 */
	Public function findPermaInfoByDatumAnzeige( $sEnglDate )
	{
		
		$aPermaInfo = [];
		$bHideRecords = false;
		
		$aObjInfo = $this->infoRepository->findHiddenAll();
		if( !$aObjInfo || !count($aObjInfo) ){
            return $this->returnMessage( 'findPermaInfoByDatumAnzeige: no Records' , [] );
		}
		
		foreach( $aObjInfo as $i => $objInfo ){
            $dtEndtime = $objInfo->getDatumPerma();
            // this is no permacontent or endtime is in past, do nothing
            if( empty($dtEndtime) || $dtEndtime->format('Y-m-d') < $sEnglDate ) continue;
            // starttime is in future, do nothing. 
            $startPermacont = $objInfo->getDatumAnzeige()->format('Y-m-d');
            if( $startPermacont > $sEnglDate ) continue;
            // if starttime is today then do not add to contents!
            if( $startPermacont == $sEnglDate ) continue;

            if( $startPermacont < $sEnglDate ){
                // starttime is in past
                // this element has to be shown for permanent
                $sHidePerma = $objInfo->getHidePerma();
                $bHideRecords = true;
                $aHideType[ $sHidePerma ] += 1;
                $aPermaInfo[$objInfo->getUid()] = $objInfo;
            }
		}
		
		return [ 'hideType'=> $aHideType , 'hideRecords'=> $bHideRecords , 'content' =>$aPermaInfo ];
    }


	/**
	 * findBelegungenAndLektionenByDatumAnzeige
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Public function findBelegungenAndLektionenByDatumAnzeige( $sEnglDate )
	{
		$objsBelegungen = $this->findBelegungenByDatumAnzeige( $sEnglDate );
        $aLektionen = $this->findLektionenByDatumAnzeige( $sEnglDate );
        
        if( !count($objsBelegungen) && !count($aLektionen) ) return [];
        if( !count($objsBelegungen) ) return $aLektionen;
        
        $aMerged = [];
        $aNumIndex = [];
        
        $sortBy = [ 'zeitVon' , 'zeitBis' , 'zimmer' , 'uid']; // lehrperson , titel
        
        foreach($aLektionen as $ix => $aLektion) {
				$aIx = [];
				foreach( $sortBy as $sortFieldname ) $aIx[ $sortFieldname ] = $aLektion[ $sortFieldname ];
				$sortIndex = implode( '' , $aIx );
				if( empty($sortIndex) ) continue;

				$aMerged[ $sortIndex ] = [
					'uid'=> $aLektion['uid'],
					'titel' => $aLektion['titel'],
					'code' => '',
					'zeitVon' => $aLektion['zeitVon'],
					'zeitBis' => $aLektion['zeitBis'],
					'zimmer' => $aLektion['zimmer'],
					'lehrperson' => $aLektion['lehrperson'],
					'source' => 'lektion',
				];
        }
        
        foreach($objsBelegungen as $ix => $oBelegung) {
				$aBelegung = [];
				$aBelegung['uid'] = trim($oBelegung->getUid());
				$aBelegung['titel'] = trim($oBelegung->getBelegungstext());
				$aBelegung['code'] = '';
				$aBelegung['zeitVon'] = trim($oBelegung->getZeitVon());
				$aBelegung['zeitBis'] = trim($oBelegung->getZeitBis());
				$aBelegung['zimmer'] = trim($oBelegung->getRaum());
				$aBelegung['lehrperson'] = trim($oBelegung->getPerson());
				$aBelegung['source'] = 'belegung';

				$aIx = [];
				foreach( $sortBy as $sortFieldname ) $aIx[ $sortFieldname ] = $aBelegung[ $sortFieldname ];
				$sortIndex = implode( '' , $aIx );
				if( empty($sortIndex) ) continue;

				$aMerged[ $sortIndex ] = $aBelegung;
		}
		
		if( !count($aMerged) ) return [];
		ksort($aMerged);
		return $aMerged;
	}

	/**
	 * getRaumplanungExample
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Public function getRaumplanungExample( $sEnglDate )
	{
        $dateObject = new \DateTime( $sEnglDate );
        $row[] = "datum;zeitVon;zeitBis;zimmer;titel;mieter";
        $row[] = $dateObject->format('Ymd') . ";08:00;09:50;Lp 101;Erstes Beispiel mit yyyymmdd formatiertem Datum;SfGH";
        $row[] = $dateObject->format('d.m.Y') . ";10:05;10:50;Lp 101;Zweites Beispiel mit deutschem Datum;SfGH";
        $row[] = $dateObject->format('Y-m-d') . ";10:55;11:30;Lp 101;Drittes Beispiel mit englischem Datum;SfGH";
        return implode( "\n" , $row );
	}

	/**
	 * findRaumplanungByDatumAnzeige
	 *  if MffRps exists
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Public function findRaumplanungByDatumAnzeige( $sEnglDate )
	{
            $aBelegungVorschlag = [];
            
            // from repository
            $aBelegungVorschlagListe = [];
            if( ExtensionManagementUtility::isLoaded('mffrps') ){
                $aBv = $this->findRaumplanungByDatumAnzeige_fromMffrps( $sEnglDate );
                $aBelegungVorschlag = [];
                foreach( $aBv as $recordset ){
                        $uid = $recordset['titel'] . '.' . $recordset['zeitVon'] . '.' . $recordset['zeitBis'] . '.' . $recordset['zimmer'] . '.' . $recordset['lehrperson'] ;
                        $aBelegungVorschlag[$uid] = $recordset;
                }
                $aBelegungVorschlagListe['mffrps'] = $aBelegungVorschlag;
            }

            // from calendar
            $vorschlagAbKalender = $this->findRaumplanungByDatumAnzeige_fromCalendar( $sEnglDate );
            if( $vorschlagAbKalender ){
                $aBelegungVorschlag = [];
                foreach( $vorschlagAbKalender as $recordset ){
                        $uid = $recordset['titel'] . '.' . $recordset['zeitVon'] . '.' . $recordset['zeitBis'] . '.' . $recordset['zimmer'] . '.' . $recordset['lehrperson'] ;
                        $aBelegungVorschlag[$uid] = $recordset;
                }
                $aBelegungVorschlagListe['cal'] = $aBelegungVorschlag;
            }
            
            // from file
           $aRaumplanung = $this->findRaumplanungByDatumAnzeige_fromFile( $sEnglDate );
           if($aRaumplanung) {
                $aBelegungVorschlag = [];
                foreach( $aRaumplanung as $recordset ){
                        $uid = $recordset['titel'] . '.' . $recordset['zeitVon'] . '.' . $recordset['zeitBis'] . '.' . $recordset['zimmer'] . '.' . $recordset['lehrperson'] ;
                        $aBelegungVorschlag[$uid] = $recordset;
                }
                $aBelegungVorschlagListe['file'] = $aBelegungVorschlag;
           }

            // merge records
            $aBelVors = [];
            foreach( $aBelegungVorschlagListe as $list ){
                foreach( $list as $recordset ){
                        if( !isset($recordset['uid']) ) continue;
                        $uid = $recordset['zeitVon'] . '.' . $recordset['zeitBis'] . '.' . $recordset['zimmer'] . '.' . $recordset['uid'] ;
                        $aBelVors[$uid] = $recordset;
                }
            }
            ksort($aBelVors);
            return $aBelVors;
	}

	/**
	 * findBelegungenByDatumAnzeige
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Protected function findBelegungenByDatumAnzeige( $sEnglDate )
	{
        $objInfo = $this->findInfoByDatumAnzeige( $sEnglDate , 'recordsUtility->findBelegungenByDatumAnzeige' );
        if( !$objInfo ) return [];
        $objsBelegungen = $objInfo->getIBelegungen() ;
        if( !$objsBelegungen ) return [];
        return $objsBelegungen;
	}

	/**
	 * findLektionenByDatumAnzeige_fromSfgzKurs
	 *  if SfgzKurs exists
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Protected function findLektionenByDatumAnzeige( $sEnglDate )
	{
            $aLektionen = [];

            // from repository
            $aLektionenListe = [];
            if( ExtensionManagementUtility::isLoaded('sfgz_kurs') ){
                $aLektionenListe[] = $this->findLektionenByDatumAnzeige_fromSfgzkurs( $sEnglDate );
            }
            
            // merge records
            foreach( $aLektionenListe as $list ){
                foreach( $list as $recordset ){
                        $uid = $recordset['zeitVon'] . '.' . $recordset['zeitBis'] . '.' . $recordset['zimmer'] . '.' . $recordset['uid'] ;
                        $aLektionen[$uid] = $recordset;
                }
            }
            
            return $aLektionen;
    }

	/**
	 * findLektionenByDatumAnzeige_fromSfgzkurs
	 *  if SfgzKurs exists
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Protected function findLektionenByDatumAnzeige_fromSfgzkurs( $sEnglDate )
	{
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		
		$this->kursRepository = $this->objectManager->get('Sfgz\SfgzKurs\Domain\Repository\KursRepository');
	    $this->kursRepository->setDefaultQuerySettings($querySettings);
		
		$this->versionRepository = $this->objectManager->get('Sfgz\SfgzKurs\Domain\Repository\VersionRepository');
	    $this->versionRepository->setDefaultQuerySettings($querySettings);
		
		$this->durchfuehrungRepository = $this->objectManager->get('Sfgz\SfgzKurs\Domain\Repository\DurchfuehrungRepository');
	    $this->durchfuehrungRepository->setDefaultQuerySettings($querySettings);
		
		$this->lektionRepository = $this->objectManager->get('Sfgz\SfgzKurs\Domain\Repository\LektionRepository');
	    $this->lektionRepository->setDefaultQuerySettings($querySettings);

	    $aLektionen = $this->lektionRepository->findByLektionDatum( $sEnglDate );
		$lekt = [];
		foreach( $aLektionen as $ix => $objLektion ){
			$objDurchfuehrung = $this->durchfuehrungRepository->findByUid($objLektion->getDurchfuehrung());
			if( !$objDurchfuehrung ) continue;
			$objVersion = $this->versionRepository->findByUid($objDurchfuehrung->getVersion());
			if( !$objVersion ) continue;
			$objKurs = $this->kursRepository->findByUid($objVersion->getKurs());
			if( !$objKurs ) continue;
			
			$durchfuehrungStatus = $objDurchfuehrung->getStatus();
			$testStatus = 1;
			if( $this->settings['infodisplay_hideStatus_list'] ){
				$statesToRefuse = explode( ',' , $this->settings['infodisplay_hideStatus_list'] );
				foreach($statesToRefuse as $refStat ) {
					if( trim($refStat) ==  $durchfuehrungStatus){
						$testStatus = 0;
						break;
					}
				}
			}
			if( !$testStatus ) continue;

			$suffix = $objDurchfuehrung->getCodeSuffix();
			if( $suffix ) $suffix = '-' . $suffix;
			$code = $objKurs->getKursCode().$suffix.' '.$objDurchfuehrung->getDurchfuehrungsCode();
			
			$aLp = explode( ' ' , $objLektion->getLehrpersonText() );
			$vorname = array_shift( $aLp );
			$lehrperson = substr( $vorname , 0 , 1 ) . '. ' . implode( ' ' , $aLp );
			
			$zeitVon = $objLektion->getZeitVon();
			$zeitBis = $objLektion->getZeitBis();
			$zimmer = $objLektion->getZimmer();
			
			$lekt[ $zeitVon . '.' . $zeitBis . '.' . $zimmer . '.' . $ix] = [
				'uid' => $objLektion->getUid(),
				'titel' => $objVersion->getTitel(),
				'code' => $code,
				'zeitVon' => $zeitVon,
				'zeitBis' => $zeitBis,
				'zimmer' => $zimmer,
				'lehrperson' => $lehrperson,
				'source' => 'lektion'
			];
		}
		if( count($lekt) ) ksort($lekt);
		return $lekt;
	}

	
	/**
	 * findRaumplanungByDatumAnzeige
	 *  if MffRps exists
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Protected function findRaumplanungByDatumAnzeige_fromMffrps( $sEnglDate )
	{
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		
		$this->rpsMieterRepository = $this->objectManager->get('Mff\Mffrps\Domain\Repository\MieterRepository');
	    $this->rpsMieterRepository->setDefaultQuerySettings($querySettings);
		
		$this->rpsAnlassRepository = $this->objectManager->get('Mff\Mffrps\Domain\Repository\AnlassRepository');
	    $this->rpsAnlassRepository->setDefaultQuerySettings($querySettings);
		
		$this->rpsBelegungRepository = $this->objectManager->get('Mff\Mffrps\Domain\Repository\BelegungRepository');
	    $this->rpsBelegungRepository->setDefaultQuerySettings($querySettings);
	    
			$aRaumplanung = [];
			$rpBelegungen = $this->rpsBelegungRepository->findByDatum($sEnglDate);

			if( !count($rpBelegungen) ) return $aRaumplanung;
			
			foreach($rpBelegungen as $objBelegung ){
				$uid = $objBelegung->getUid();
				$uidAnlass = $objBelegung->getAnlass();
				$objAnlass = $this->rpsAnlassRepository->findByUid($uidAnlass);
				$uidMieter = $objAnlass->getMieter();
				$objMieter = $this->rpsMieterRepository->findByUid($uidMieter);
				$codeMieter = $objMieter->getKurz();
				$objZimmer = $objBelegung->getBelZimmer();
				if($objZimmer) $zimmer = trim( $objZimmer->getHaus() . ' ' . $objZimmer->getZimmer() );
				$aRaumplanung[$uid]['uid']=$uid;
				$aRaumplanung[$uid]['titel'] = $objBelegung->getBelegungstext();;
				$aRaumplanung[$uid]['code'] = '';
				$aRaumplanung[$uid]['zeitVon'] = $objBelegung->getAb();
				$aRaumplanung[$uid]['zeitBis'] = $objBelegung->getBis();
				$aRaumplanung[$uid]['zimmer'] = $zimmer;
				$aRaumplanung[$uid]['mieter'] = $codeMieter;
			}
			return $aRaumplanung;
	}
	
	/**
	 * findRaumplanungByDatumAnzeige_fromFile
	 *  if MffRps exists on distant server
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Protected function findRaumplanungByDatumAnzeige_fromFile( $sEnglDate )
	{
        
        $this->spreadsheetUtility = GeneralUtility::makeInstance('Sfgz\\SfgzFoyer\\Utility\\SpreadsheetUtility');
        
        $aAllowedSuffix = [ 'csv'=>'csv' , 'xls'=>'xls' , 'xlsx'=>'xlsx' , 'ods'=>'ods' ];
        $uploadDir = $this->settings['uploadFolder'] . 'suggest/';
        if( !is_dir($uploadDir) ) return false;
        
        $aContent = [];
        $d = dir( $uploadDir );
        $aFieldnames = [ 'datum'=>'datum' , 'zeit_von'=>'zeitVon' , 'zeit_bis'=>'zeitBis' , 'raum'=>'zimmer' ,'text'=>'titel' , 'mieter'=>'mieter'  ];
        $aRs = [];
        $newRow = [];
        while (false !== ($entry = $d->read())) {
            $filename = $uploadDir.'/'.$entry;
            if( !isset($aAllowedSuffix[ pathinfo( $entry , PATHINFO_EXTENSION) ]) ) continue; 
            $table = $this->spreadsheetUtility->fileToArray($filename);
            foreach( $table as $row ) {
                $rs = [];
                $rs[ 'uid' ] = count($newRow) + 1000;
                foreach( $row as $fldName => $cnt ){
                    if( isset($aFieldnames[$fldName] ) ) {
                        $rs[ $aFieldnames[$fldName] ] = $cnt;
                    }else{
                        $rs[ $fldName ] = $cnt;
                    }
                }
                $rs[ 'datum' ] = $this->mixedToEnglishDate(  $rs[ 'datum' ]);
                // filter by date
                if( $sEnglDate == $rs[ 'datum' ] ) $newRow[] = $rs;
            }
        }
        return $newRow;
	}
	
	/**
	 * findRaumplanungByDatumAnzeige_fromCalendar
	 *  if MffRps exists on distant server
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Protected function findRaumplanungByDatumAnzeige_fromCalendar( $sEnglDate )
	{
		$aTable = [];
        $db = $this->calendarService->calendarsReadData() ;
        // filter records by date
        foreach( $db as $i => $calRow ) {
            if( date( 'Y-m-d' , $calRow['datum'] ) == $sEnglDate ){
                $aTable[] = $calRow;
            }
        }
        return $aTable;
    }
	
	/**
	 * mixedToEnglishDate
	 *  YYYYMMDD or d.m.Y or Y-m-d
     * 
     * @param string $sMixedDate
	 * @return string english date
	 */
	Protected function mixedToEnglishDate( $sMixedDate )
	{
            $sMixedDate = trim($sMixedDate);
            
            // separed by divis (-) Y-m-d or d-m-Y
            $aLn = explode( '-' , $sMixedDate );
            if( count($aLn) == 3 ){
                //  4 digits on start is english date, return the incomed value
                if( strlen($aLn[0]) == 4 ) return $sMixedDate;
                //  4 digits on end is german date, change the order
                if( strlen($aLn[2]) == 4 ) return $aLn[2] . '-' . $aLn[1] . '-' . $aLn[0];
            }

            // separed by dot (.) d.m.Y or Y.m.d
            $aPt = explode( '.' , $sMixedDate );
            if( count($aPt) == 3 ){
                //  4 digits on start is english date, replace the dots with english separer 
                if( strlen($aPt[0]) == 4 ) return str_replace( '.' , '-' , $sMixedDate );
                // 4 digits on end is german date
                if( strlen($aPt[2]) == 4 ) return $aPt[2] . '-' . $aPt[1] . '-' . $aPt[0];
            }
            
            // YYYYMMDD
            if( strlen($sMixedDate) == 8 && is_numeric( $sMixedDate+1 ) ){
                return substr($sMixedDate , 0 , 4 ) . '-' . substr($sMixedDate , 4 , 2 ) . '-' . substr($sMixedDate , 6 , 2 );
            }
            // error exit
            return $sMixedDate;
	}

}
