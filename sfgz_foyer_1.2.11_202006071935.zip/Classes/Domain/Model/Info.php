<?php
namespace Sfgz\SfgzFoyer\Domain\Model;


/***
 *
 * This file is part of the "Foyer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Daniel Rueegg <daten@verarbeitung.ch>
 *
 ***/
/**
 * Zusätzliche Tages-Informatinen auf Foyer
 */
class Info extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * datumAnzeige
     *  should be unique together with pid
     * 
     * @var \DateTime
     */
    protected $datumAnzeige = null;

    /**
     * datumPerma
     *  should be unique together with pid
     * 
     * @var \DateTime
     */
    protected $datumPerma = null;

    /**
     * hidePerma
     * 
     * @var int
     */
    protected $hidePerma = 0;

    /**
     * infotext
     * 
     * @var string
     */
    protected $infotext = '';

    /**
     * iBelegungen
     * 
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzFoyer\Domain\Model\Belegung>
     * @TYPO3\CMS\Extbase\Annotation\ORM\Cascade("remove")
     */
    protected $iBelegungen = null;

    /**
     * __construct
     */
    public function __construct()
    {

        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     * 
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->iBelegungen = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the datumAnzeige
     * 
     * @return \DateTime $datumAnzeige
     */
    public function getDatumAnzeige()
    {
        return $this->datumAnzeige;
    }

    /**
     * Sets the datumAnzeige
     * 
     * @param \DateTime $datumAnzeige
     * @return void
     */
    public function setDatumAnzeige(\DateTime $datumAnzeige)
    {
        $this->datumAnzeige = $datumAnzeige;
    }

    /**
     * Returns the datumPerma
     * 
     * @return \DateTime $datumPerma
     */
    public function getDatumPerma()
    {
        return $this->datumPerma;
    }

    /**
     * Sets the datumPerma
     * 
     * @param \DateTime $datumPerma
     * @return void
     */
    public function setDatumPerma($datumPerma)
    {
        $this->datumPerma = $datumPerma;
    }

    /**
     * Returns the infotext
     * 
     * @return string $infotext
     */
    public function getInfotext()
    {
        return $this->infotext;
    }

    /**
     * Sets the infotext
     * 
     * @param string $infotext
     * @return void
     */
    public function setInfotext($infotext)
    {
        $this->infotext = $infotext;
    }

    /**
     * Returns the hidePerma
     * 
     * @return int $hidePerma
     */
    public function getHidePerma()
    {
        return $this->hidePerma;
    }

    /**
     * Sets the hidePerma
     * 
     * @param int $hidePerma
     * @return void
     */
    public function setHidePerma($hidePerma)
    {
        $this->hidePerma = $hidePerma;
    }

 
    /**
     * Adds a Belegung
     * 
     * @param \Sfgz\SfgzFoyer\Domain\Model\Belegung $iBelegungen
     * @return void
     */
    public function addIBelegungen(\Sfgz\SfgzFoyer\Domain\Model\Belegung $iBelegungen)
    {
        $this->iBelegungen->attach($iBelegungen);
    }

    /**
     * Removes a Belegung
     * 
     * @param \Sfgz\SfgzFoyer\Domain\Model\Belegung $iBelegungenToRemove The Belegung to be removed
     * @return void
     */
    public function removeIBelegungen(\Sfgz\SfgzFoyer\Domain\Model\Belegung $iBelegungenToRemove)
    {
        $this->iBelegungen->detach($iBelegungenToRemove);
    }

    /**
     * Returns the iBelegungen
     * 
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzFoyer\Domain\Model\Belegung> $iBelegungen
     */
    public function getIBelegungen()
    {
        return $this->iBelegungen;
    }

    /**
     * Sets the iBelegungen
     * 
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzFoyer\Domain\Model\Belegung> $iBelegungen
     * @return void
     */
    public function setIBelegungen(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $iBelegungen)
    {
        $this->iBelegungen = $iBelegungen;
    }
}
