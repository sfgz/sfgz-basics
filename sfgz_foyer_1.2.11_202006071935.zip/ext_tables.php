<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SfgzFoyer',
            'Main',
            'Info Foyer'
        );

        $pluginSignature = str_replace('_', '', 'sfgz_foyer') . '_main';
        $GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:sfgz_foyer/Configuration/FlexForms/flexform_main.xml');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('sfgz_foyer', 'Configuration/TypoScript', 'Foyer');

    }
);
