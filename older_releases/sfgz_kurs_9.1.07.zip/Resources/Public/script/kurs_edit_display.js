		// extension sfgzkurs_inf: functions for Info->editorAction
		function appendRaumplanungRow( planUid ) {

			var added = localStorage.getItem( 'belegungen' );
			if( added == 0 ){
				added = 1;
			}else{
				added++;
			}
			localStorage.setItem('belegungen' , added );
			
			if( planUid ){
				var zeit_von  = $( '#raum_' + planUid + '_zeit_von' ).html();
				var zeit_bis  = $( '#raum_' + planUid + '_zeit_bis' ).html();
				var titel = $( '#raum_' + planUid + '_titel' ).html();
				var zimmer = $( '#raum_' + planUid + '_zimmer' ).html();
				var lehrperson = $( '#raum_' + planUid + '_lehrperson' ).html();
			}else{
				var zeit_von  = '';
				var zeit_bis  = '';
				var titel = '';
				var zimmer = '';
				var lehrperson = '';
			}

			var buttonCell = '<td class="delete" onClick="$(\'#pln_' +  added + '\').remove();"> </td>';
			var raumCell = '<td><input type="text" value="' +  zimmer + '" name="tx_sfgzkurs_inf[belegung][pln_' +  added + '][raum]" size="6" /></td>';
			var timeCells = '<td>';
			timeCells = timeCells + '<input type="text" value="' +  zeit_von + '" name="tx_sfgzkurs_inf[belegung][pln_' +  added + '][zeitVon]" size="3" /> ';
			timeCells = timeCells + '</td><td>';
			timeCells = timeCells + '<input type="text" value="' +  zeit_bis + '" name="tx_sfgzkurs_inf[belegung][pln_' +  added + '][zeitBis]" size="3" />';
			timeCells = timeCells + '</td>';
			var textCell = '<td><input type="text" value="' +  titel + '" name="tx_sfgzkurs_inf[belegung][pln_' +  added + '][belegungstext]" size="30" /></td>';
			var personCell = '<td><input type="text" value="' +  lehrperson + '" name="tx_sfgzkurs_inf[belegung][pln_' +  added + '][person]" size="12" /></td>';
			
			$(".belegungen tbody").append('<tr id="pln_' + added + '">' + buttonCell + timeCells + raumCell + textCell + personCell + "</tr>");
		}
		
