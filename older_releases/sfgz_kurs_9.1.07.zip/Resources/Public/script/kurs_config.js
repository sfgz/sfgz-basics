// extension sfgzkurs_conf: functions for Config->displayAction
function getSelectText( idSuffix ) {
    return $( '#sel_' + idSuffix ).find('option:selected').text();
}

function confTableSelect( tablename ) {
    $('#' + tablename  + ' span.add_record ' ).html( getSelectText( tablename ) );
    console.log('ok confTableSelect... change ' + tablename + '; '  + '#' + tablename  + ' span.add_record ' + '');
    updateConfigTable( tablename );
}

function updateConfigTable( tablename ) {
    var value = $( '#sel_' + tablename ).val();
    jsUpdateConfigTable( editConfigUrl( 'edconftable' ) , tablename , 'fieldvalue' , value );
}

function confTableCheck( tablename ) {
    isChecked = $( '#chk_' + tablename ).prop('checked')
    jsUpdateConfigTable( editConfigUrl( 'edconftable' ) , tablename , 'fieldname' , isChecked );
}

function confFieldSelect( tablename , fieldname ) {
    var value = $( '#sel_' + tablename + '_' + fieldname ).val();
    if( value == 4 ){
        $('#span_' + tablename + '_' + fieldname ).removeClass('edit');
        $('#span_' + tablename + '_' + fieldname ).addClass('add_record');
        $('#span_' + tablename + '_' + fieldname ).html( getSelectText( tablename ) );
    }else{
        $('#span_' + tablename + '_' + fieldname ).removeClass('add_record');
        $('#span_' + tablename + '_' + fieldname ).addClass('edit');
        $('#span_' + tablename + '_' + fieldname ).html( getSelectText( tablename + '_' + fieldname ) );
    }
    updateConfigField( tablename , fieldname );
}

function updateConfigField( tablename , fieldname ) {
    var value = $( '#sel_' + tablename + '_' + fieldname ).val();
    jsUpdateConfigTable( editConfigUrl( 'edconffield' ) , tablename , fieldname , value );
}

function updateAllConfigFields( tablename ) {
    var newValue = $( '#multifield_changer' ).val();
    if( newValue == 4 ){return;}
    $( '.lektion_edits_durchfuehrung' ).each(function(){
        $(this).val( newValue ).change();
    });
}

// extension sfgz_kurs: Config->editAction change formfields in relation to choosen select-field value 
function vievHide( selectorid , targetid ) {
    if( $("#" + selectorid ).val() == 1 ){
        // radiobuttons on, hide textfield
        $("[class^='box_txt_" + targetid + "']").hide(); 
        $("[class^='txt_" + targetid + "']").prop('disabled', true);
        $("[class^='box_rad_" + targetid + "']").show(); 
        $("[class^='rad_" + targetid + "']").prop('disabled', false);
    }else{
        // textfield on, hide radiobuttons
        $("[class^='box_txt_" + targetid + "']").show(); 
        $("[class^='txt_" + targetid + "']").prop('disabled', false);
        $("[class^='box_rad_" + targetid + "']").hide(); 
        $("[class^='rad_" + targetid + "']").prop('disabled', true);
    }
}
$(document).ready(function(){
	// extension sfgz_kurs: Config-Controller editAction
		vievHide( 'option2' , 'fieldname' );

});
