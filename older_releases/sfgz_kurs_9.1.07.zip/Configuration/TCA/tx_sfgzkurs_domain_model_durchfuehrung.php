<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung',
        'label' => 'durchfuehrungs_code',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
		'searchFields' => 'durchfuehrungs_code,code_suffix,publikation_start,publikation_ende,anmerkung,termin_ausblenden,kurskosten,kosten_lernende,kosten_extern,status,lektionen,maxteilnehmer,anmeldeschluss,anmeldung,anmeldung_link,eco_mandant,eco_angebotid,eco_fachid,d_lektionen,veranstaltungen,periodika,termin_start,termin_ende,zeit_von,zeit_bis,ort,zimmer,lehrer_eco_id,lehrperson_textlehrperson_nachname,lehrperson_vorname',
        'iconfile' => 'EXT:sfgz_kurs/Resources/Public/Icons/tx_sfgzkurs_domain_model_durchfuehrung.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'durchfuehrungs_code, code_suffix,  publikation_start, publikation_ende, anmerkung, termin_ausblenden ,kurskosten, kosten_lernende, kosten_extern,  status, lektionen, maxteilnehmer, anmeldeschluss, anmeldung, anmeldung_link, eco_mandant, eco_angebotid, eco_fachid, d_lektionen, veranstaltungen, periodika, termin_start, termin_ende, zeit_von, zeit_bis, ort, zimmer, lehrer_eco_id, lehrperson_textlehrperson_nachname, lehrperson_vorname',
    ],
    'types' => [
		'1' => ['showitem' => 'durchfuehrungs_code, code_suffix, status, maxteilnehmer, kurskosten, kosten_lernende, kosten_extern,  eco_mandant, eco_angebotid, eco_fachid, --div--;Datum, publikation_start, publikation_ende, --div--;Anmeldung,anmeldeschluss, anmeldung, anmeldung_link, --div--;Lektionen, lektionen, veranstaltungen, periodika, termin_start, termin_ende, zeit_von, zeit_bis, ort, zimmer, lehrer_eco_id, lehrperson_text, lehrperson_nachname, lehrperson_vorname, d_lektionen, anmerkung, termin_ausblenden'],
    ],
    'columns' => [
	    'durchfuehrungs_code' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.durchfuehrungs_code',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'code_suffix' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.code_suffix',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
		'publikation_start' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.publikation_start',
	        'config' => [
			    'dbType' => 'date',
			    'type' => 'input',
			    'size' => 7,
			    'eval' => 'date',
			    'default' => '0000-00-00'
			]
        ],
        'publikation_ende' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.publikation_ende',
            'config' => [
			    'dbType' => 'date',
                'type' => 'input',
                'size' => 7,
                'eval' => 'date',
                'default' => '0000-00-00',
                'range' => [
                    'upper' => mktime(0, 0, 0, 1, 1, 2238)
                ]
            ],
        ],
	    'anmerkung' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.anmerkung',
	        'config' => [
			    'type' => 'text',
			    'cols' => 40,
			    'rows' => 15,
			    'eval' => 'trim',
			],
	        'defaultExtras' => 'richtext:rte_transform[mode=ts_css]'
	    ],
		'termin_ausblenden' => [
				'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.disable',
				'exclude' => 1,
				'config' => [
						'type' => 'check',
						'default' => '0'
				]
		],    
	    'kurskosten' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.kurskosten',
	        'config' => [
			    'type' => 'input',
			    'size' => 4,
			    'eval' => 'int'
			]
	    ],
	    'kosten_lernende' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.kosten_lernende',
	        'config' => [
			    'type' => 'input',
			    'size' => 4,
			    'eval' => 'int'
			]
	    ],
	    'kosten_extern' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.kosten_extern',
	        'config' => [
			    'type' => 'input',
			    'size' => 4,
			    'eval' => 'int'
			]
	    ],
	    'status' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.status',
	        'config' => [
			    'type' => 'select',
			    'renderType' => 'selectSingle',
			    'items' => [
			        ['LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.statusse.sel.0', 0],
			        ['LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.statusse.sel.1', 1],
			        ['LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.statusse.sel.2', 2],
			        ['LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.statusse.sel.3', 3],
			        ['LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.statusse.sel.4', 4],
			    ],
			    'size' => 1,
			    'maxitems' => 1,
			    'eval' => ''
			],
	    ],
	    'lektionen' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.lektionen',
	        'config' => [
			    'type' => 'input',
			    'size' => 2,
			    'eval' => 'int'
			]
	    ],
	    'maxteilnehmer' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.maxteilnehmer',
	        'config' => [
			    'type' => 'input',
			    'size' => 2,
			    'eval' => 'int'
			]
	    ],
	    'anmeldeschluss' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.anmeldeschluss',
	        'config' => [
			    'dbType' => 'date',
			    'type' => 'input',
			    'size' => 7,
			    'eval' => 'date',
			    'default' => '0000-00-00'
			]
	    ],
	    'eco_mandant' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.eco_mandant',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'eco_angebotid' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.eco_angebotid',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'eco_fachid' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.eco_fachid',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
        'veranstaltungen' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.veranstaltungen',
	        'config' => [
			    'type' => 'input',
			    'size' => 2,
			    'eval' => 'int'
			]
	    ],
	    'periodika' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.periodika',
	        'config' => [
			    'type' => 'select',
			    'renderType' => 'selectSingle',
			    'items' => [
			        ['LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.periodika.sel.0', 0],
			        ['LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.periodika.sel.1', 1],
			    ],
			    'size' => 1,
			    'maxitems' => 1,
			    'eval' => ''
			],
	    ],
	    'termin_start' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.termin_start',
	        'config' => [
			    'dbType' => 'date',
			    'type' => 'input',
			    'size' => 7,
			    'eval' => 'date',
			    'default' => '0000-00-00'
			]
	    ],
	    'termin_ende' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.termin_ende',
	        'config' => [
			    'dbType' => 'date',
			    'type' => 'input',
			    'size' => 7,
			    'eval' => 'date',
			    'default' => '0000-00-00'
			]
	    ],
	    'zeit_von' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.zeit_von',
	        'config' => [
			    'type' => 'input',
			    'size' => 5,
			    'eval' => 'trim'
			],
	    ],
	    'zeit_bis' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.zeit_bis',
	        'config' => [
			    'type' => 'input',
			    'size' => 5,
			    'eval' => 'trim'
			],
	    ],
	    'ort' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.ort',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'zimmer' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.zimmer',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'lehrer_eco_id' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.lehrer_eco_id',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'lehrperson_text' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.lehrperson_text',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'lehrperson_vorname' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.lehrperson_vorname',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'lehrperson_nachname' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.lehrperson_nachname',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'd_lektionen' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_durchfuehrung.d_lektionen',
	        'config' => [
			    'type' => 'inline',
			    'foreign_table' => 'tx_sfgzkurs_domain_model_lektion',
			    'foreign_field' => 'durchfuehrung',
			    'foreign_sortby' => 'lektion_datum',
			    'maxitems' => 9999,
			    'appearance' => [
			        'collapseAll' => 1,
			        'levelLinksPosition' => 'top',
			        'showSynchronizationLink' => 1,
			        'showPossibleLocalizationRecords' => 1,
			        'showAllLocalizationLink' => 1
			    ],
			],
	    ],
        'tstamp' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
        'version' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];
