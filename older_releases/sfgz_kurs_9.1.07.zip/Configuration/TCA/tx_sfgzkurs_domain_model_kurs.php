<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kurs',
        'label' => 'titel',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
		'enablecolumns' => [
        ],
		'searchFields' => 'titel,ausblenden,kurs_code,stufe_wb,k_kategorien,k_versionen',
        'iconfile' => 'EXT:sfgz_kurs/Resources/Public/Icons/tx_sfgzkurs_domain_model_kurs.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'titel, ausblenden, kurs_code, stufe_wb, k_kategorien, k_versionen, sorting',
    ],
    'types' => [
		'1' => ['showitem' => 'titel, ausblenden, kurs_code, stufe_wb, k_kategorien, k_versionen, sorting'],
    ],
    'columns' => [
		'ausblenden' => [
				'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.disable',
				'exclude' => 1,
				'config' => [
						'type' => 'check',
						'default' => '0'
				]
		],    
        'titel' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kurs.titel',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'kurs_code' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kurs.kurs_code',
	        'config' => [
			    'type' => 'input',
			    'size' => 8,
			    'eval' => 'trim'
			],
	    ],
	    'stufe_wb' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kurs.stufe_wb',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'k_kategorien' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kurs.k_kategorien',
	        'config' => [
			    'type' => 'select',
			    'renderType' => 'selectMultipleSideBySide',
			    'foreign_table' => 'tx_sfgzkurs_domain_model_kategorie',
			    'foreign_sortby' => 'kategorie_gruppe,kategorie_name',
			    'MM' => 'tx_sfgzkurs_kurs_kategorie_mm',
			    'size' => 10,
			    'autoSizeMax' => 30,
			    'maxitems' => 9999,
			    'multiple' => 0,
			    'wizards' => [
			        '_PADDING' => 1,
			        '_VERTICAL' => 1,
			        'edit' => [
			            'module' => [
			                'name' => 'wizard_edit',
			            ],
			            'type' => 'popup',
			            'title' => 'Edit', // todo define label: LLL:EXT:.../Resources/Private/Language/locallang_tca.xlf:wizard.edit
			            'icon' => 'EXT:backend/Resources/Public/Images/FormFieldWizard/wizard_edit.gif',
			            'popup_onlyOpenIfSelected' => 1,
			            'JSopenParams' => 'height=350,width=580,status=0,menubar=0,scrollbars=1',
			        ],
			        'add' => [
			            'module' => [
			                'name' => 'wizard_add',
			            ],
			            'type' => 'script',
			            'title' => 'Create new', // todo define label: LLL:EXT:.../Resources/Private/Language/locallang_tca.xlf:wizard.add
			            'icon' => 'EXT:backend/Resources/Public/Images/FormFieldWizard/wizard_add.gif',
			            'params' => [
			                'table' => 'tx_sfgzkurs_domain_model_kategorie',
			                'pid' => '###CURRENT_PID###',
			                'setValue' => 'prepend'
			            ],
			        ],
			    ],
			],
	    ],
	    'k_versionen' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_kurs.k_versionen',
	        'config' => [
			    'type' => 'inline',
			    'foreign_table' => 'tx_sfgzkurs_domain_model_version',
			    'foreign_field' => 'kurs',
			    'foreign_sortby' => 'version_start',
			    'maxitems' => 9999,
			    'appearance' => [
			        'collapseAll' => 0,
			        'levelLinksPosition' => 'top',
			        'showSynchronizationLink' => 1,
			        'showPossibleLocalizationRecords' => 1,
			        'showAllLocalizationLink' => 1
			    ],
			],
	    ],
        'sorting' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
        'tstamp' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];
