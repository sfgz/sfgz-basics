<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SfgzKurs',
            'Conf',
            [
                'Config' => 'display, template,migrate, list, new, create, edit, update, delete',
                'Json' => 'update,edconftable,edconffield'
            ],
            // non-cacheable actions
            [
                'Config' => 'template, migrate,list, create, edit, update, delete',
                'Json' => 'update,edconftable,edconffield'
            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SfgzKurs',
            'Lst',
            [
                'Kurs' => 'overview',
                'Json' => 'update',
                'Kategorie' => 'list, new, create, edit, update, delete'
            ],
            // non-cacheable actions
            [
                'Kurs' => 'overview',
                'Json' => 'update',
                'Kategorie' => 'list, create, edit, update'
            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SfgzKurs',
            'Vw',
            [
                'Kurs' => 'list, new, create, edit, update, delete, import, export',
                'Kategorie' => 'list, new, create, edit, update, delete',
                'Version' => 'list, new, create, edit, update, delete',
                'Durchfuehrung' => 'list, new, create, edit, update, delete, storeLektionen',
                'Termin' => 'list, new, create, edit, update, delete',
                'Json' => 'update'
            ],
            // non-cacheable actions
            [
                'Kurs' => 'list, create, edit, update, delete, import, export',
                'Kategorie' => 'list,create, edit, update, delete',
                'Version' => 'new, create, edit, update, delete',
                'Durchfuehrung' => 'create, edit, update, delete, storeLektionen',
                'Termin' => 'create, edit, update, delete',
                'Json' => 'update',
            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SfgzKurs',
            'Inf',
            [
                'Info' => 'editor, update, display, list',
                'Json' => 'update'
            ],
            // non-cacheable actions
            [
                'Info' => 'editor, update, display, list',
                'Json' => 'update',
            ]
        );

        // wizards
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
            'mod {
                wizards.newContentElement.wizardItems.plugins {
                    elements {
                        vw {
                            icon = ' . \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($extKey) . 'Resources/Public/Icons/user_plugin_vw.svg
                            title = LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgz_kurs_domain_model_vw
                            description = LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgz_kurs_domain_model_vw.description
                            tt_content_defValues {
                                CType = list
                                list_type = sfgzkurs_vw
                            }
                        }
                        lst {
                            icon = ' . \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($extKey) . 'Resources/Public/Icons/user_plugin_kat.svg
                            title = Liste
                            description = LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgz_kurs_domain_model_kat.description
                            tt_content_defValues {
                                CType = list
                                list_type = sfgzkurs_lst
                            }
                        }
                        conf {
                            icon = ' . \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($extKey) . 'Resources/Public/Icons/user_plugin_conf.svg
                            title = LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgz_kurs_domain_model_conf
                            description = LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgz_kurs_domain_model_conf.description
                            tt_content_defValues {
                                CType = list
                                list_type = sfgzkurs_conf
                            }
                        }
                        inf {
                            icon = ' . \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($extKey) . 'Resources/Public/Icons/user_plugin_inf.svg
                            title = LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgz_kurs_domain_model_inf
                            description = LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgz_kurs_domain_model_inf.description
                            tt_content_defValues {
                                CType = list
                                list_type = sfgzkurs_inf
                            }
                        }
                    }
                    show = *
                }
            }'
        );
        // Register scheduler-Tasks
        if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('scheduler')) {
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Sfgz\\SfgzKurs\\Command\\CalendarimportCommandController'] = array(
                'extension'			=> 'sfgz_kurs',
                'title'				=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang.xlf:scheduler.calendarimport.title',
                'description'		=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang.xlf:scheduler.calendarimport.description',
                'additionalFields'	=> ''
            );
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Sfgz\\SfgzKurs\\Command\\BackupDbCommandController'] = array(
                'extension'			=> 'sfgz_kurs',
                'title'				=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang.xlf:scheduler.backup_db.title',
                'description'		=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang.xlf:scheduler.backup_db.description',
                'additionalFields'	=> 'Sfgz\\SfgzKurs\\Command\\BackupDbCommandControllerAdditionalFieldProvider'
            );
        }
    },
    $_EXTKEY
);
