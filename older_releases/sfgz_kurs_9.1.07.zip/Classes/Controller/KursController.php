<?php
namespace Sfgz\SfgzKurs\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * KursController
 */
class KursController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     * @inject
     */
    protected $kursRepository = null;

    /**
     * versionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\VersionRepository
     * @inject
     */
    protected $versionRepository = null;
    
    /**
     * durchfuehrungRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\DurchfuehrungRepository
     * @inject
     */
    protected $durchfuehrungRepository = null;

    /**
     * filetransferUtility
     *
     * @var \Sfgz\SfgzKurs\Utility\FiletransferUtility
     */
    protected $filetransferUtility = null;

	/**
	 * initializeAction
	 *
	 */
	public function initializeAction()
	{
	      
		$this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

		$this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$this->contentObj = $this->configurationManager->getContentObject();
		
		$this->dateUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\DateUtility');
		$this->filetransferUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\FiletransferUtility');
		$this->importUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ImportUtility');
		$this->configUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ConfigUtility');
		$this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
		$this->exportUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ExportUtility');
		$this->xmlUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\XmlUtility');

		$this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		
		$this->versionRepository = $this->objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\VersionRepository');
	    $this->versionRepository->setDefaultQuerySettings($querySettings);
		
		$this->durchfuehrungRepository = $this->objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\DurchfuehrungRepository');
	    $this->durchfuehrungRepository->setDefaultQuerySettings($querySettings);
	    
    }

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        // delete kurse from list
        if( $this->request->hasArgument('delete_selection') &&
			$this->request->hasArgument('selection_nr')
		){
				$kursListe = $this->request->getArgument('selection_nr') ;
				$z = 0;
				foreach( $kursListe as $kursNr => $isChecked) {
					if( empty( $isChecked ) ) continue;
					$objLektion = $this->kursRepository->findByUid( $kursNr );
					$this->kursRepository->remove( $objLektion );
					++$z;
				}
				if( $z ){
					$this->addFlashMessage(  ( $z == 1 ? 'Markierter Kurs' : $z . ' markierte Kurse' ) . ' gelöscht.' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
				}
				$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
				$this->persistenceManager->persistAll();
        }
        
        // searchResults
        $aSearchOption = $this->getSessionDataSearch();
        $this->view->assign('search', $aSearchOption );
        $this->view->assign('settings', $this->settings );
        
        // default action list kurse
        $kurse = $this->getFilteredKurse( $aSearchOption );
        $this->view->assign('kurse', $kurse);
    }

    /**
     * helper getFilteredKurse
     *
     * @param array $aSearchOption
     * @return array
     */
    public function getFilteredKurse( $aSearchOption )
    {
        switch( $aSearchOption['hidden'] ){
			case 0:
				$kurse = $this->kursRepository->findAll();
			break;
			case 1:
				$kurse = $this->kursRepository->findByAusblenden( 1 );
			break;
			case 2:
				$kurse = $this->kursRepository->findByAusblenden( 0 );
			break;
        }
        
        
        if( empty($aSearchOption['chars']) ) return $kurse;
        
        $caseSensitive = $this->settings['searchCaseSensitive'];
        foreach( $this->settings['searchFields'] as $table => $fldLst ){
			foreach( $fldLst as $fieldname => $isset ){
				if($isset) {
					$searchFields[$table.'.'.$fieldname] = ['field' => $fieldname , 'table' => $table ];
				}
			}
        }

        $needle = $caseSensitive ? $aSearchOption['chars'] : strtolower( $aSearchOption['chars'] );
        
        $markedKurs = [];
		foreach( $kurse as $objKurs ){
			$hasFound = 0;
			$kUid = $objKurs->getUid();
			foreach( $searchFields as $aFld ){
				if( 'kurs' != $aFld['table'] ) continue;
				$objName = GeneralUtility::underscoredToLowerCamelCase( $aFld['field'] );
				$method = 'get' . ucFirst( $objName );
				if( method_exists( $objKurs , $method ) ){
					$haystack = $objKurs->$method();
					if( !$caseSensitive ) $haystack = strtolower($haystack);
					$hasFound = strpos( ' ' . $haystack , $needle );
				}
				if( $hasFound ) break;
			}
			
			$aVersionen = $objKurs->getKVersionen();
			if(count($aVersionen)){
				foreach( $aVersionen as $oVersion ){
					foreach( $searchFields as $aFld ){
						if( 'version' != $aFld['table'] ) continue;
						$objName = GeneralUtility::underscoredToLowerCamelCase( $aFld['field'] );
						$method = 'get' . ucFirst( $objName );
						if( method_exists( $oVersion , $method ) ){
							$haystack = $oVersion->$method();
							if( !$caseSensitive ) $haystack = strtolower($haystack);
							$hasFound = strpos( ' ' . $haystack , $needle );
						}
						if( $hasFound ) break;
					}
					if( $hasFound ) break;
				}
			}
			if( $hasFound ) $markedKurs[$kUid] = $objKurs;
		}
        return $markedKurs;
    }

    /**
     * helper getSessionDataSearch
     *
     * @return array
     */
    public function getSessionDataSearch()
    {
		// set default values for search array
		$aSearchOption = ['hidden'=>0 , 'chars'=>'' ];
		
		// read from session-data
		$userObj = $GLOBALS['TSFE']->fe_user;
        if( $userObj ){
            $usrSess = $userObj->getKey( "user" , "SfgzKurs" );
        }
        
        if( $this->request->hasArgument('search') ){
            $aSearchOption = $this->request->getArgument('search');
			if( $userObj ){
				$usrSess['search'] = $aSearchOption;
				$userObj->setKey("user","SfgzKurs", $usrSess);
				$userObj->sesData_change = true;
				$userObj->storeSessionData();
            }
		}else{
			if( $usrSess['search'] ){
				$aSearchOption = $usrSess['search'];
			}
		}
		return $aSearchOption;
	}

    /**
     * action overview
     *
     * @return void
     */
    public function overviewAction()
    {
        $usrSess = $this->getSessionDataStichtag();
		$Stichdatum = $usrSess['ist_stichtag'] ? $usrSess['stichtag'] : date( 'Y-m-d' );
// 		return;
        // IMPORT
        // pre-import: clear upload folder
		$checkAllImports = false;
        if( $this->request->hasArgument('clearfolder_timetable') ){
			$this->filetransferUtility->clearFolder( 'course' );
			$this->filetransferUtility->clearFolder( 'timetable' );
			
		}elseif( $this->request->hasArgument('getfile_course') ) {
			// pre-import: copy files from ftp-folder to upload folder
			$this->filetransferUtility->getFtpFiles();
			
		}elseif( $this->request->hasArgument('delete_selection') ) {
			$this->importUtility->resetImportSelection();
			
		}elseif( $this->request->hasArgument('checkall_selection') ) {
			$checkAllImports = true;
			
		}elseif( $this->request->hasArgument('delete_exportfile') ) {
			$this->exportUtility->RemoveExportFile($this->request->getArgument('delete_exportfile'));
			
        }else{
			// pre-import: upload csv-file and convert to json-file
			$this->filetransferUtility->uploadFile();
        }
        
        // look up for newer files on ftp-Server
		$aFtpFolderContent = $this->filetransferUtility->getFtpFolderContent();
		if( isset($aFtpFolderContent['WB_Ferien.csv']) ) unset($aFtpFolderContent['WB_Ferien.csv']);
		$firstFile  = count($aFtpFolderContent) ? array_pop($aFtpFolderContent): [];
		$Y = substr( $firstFile['modify'] , 0 , 4 );
		$M =  substr( $firstFile['modify'] , 4 , 2 );
		$T =  substr( $firstFile['modify'] , 6 , 2 );
		$H =  substr( $firstFile['modify'] , 8 , 2 );
		$i =  substr( $firstFile['modify'] , 10 , 2 );
		$firstFile['datum'] = $T . '.' . $M . '.' . $Y . ' ' . $H . ':' . $i;
		$this->view->assign('ftpFiles', $firstFile );

        // list import: read from json-file and assign to array mapCsvField
        // FIXME ERROR 1 START END
        // $this->importUtility->getImportList()->databaseReaderUtility->enrichFiletablesWithDbRecords()->
        // databaseReaderUtility->getCourses()->getCourses_createArrayCourses() !!
        
        
        $aFileDbConfigCheckedContents = $this->importUtility->getImportList();
		
        // trigger import: register the trigger to start import-routine.
        $import = $this->request->hasArgument('import') ? $this->request->getArgument('import') : null;

        // import: start import from files in upload folder to t3db (database)
		if( $import ) {
			$this->importUtility->RunImport($aFileDbConfigCheckedContents);
			$this->persistenceManager->persistAll();
			$this->filetransferUtility->clearFolder( 'course' );
			$this->filetransferUtility->clearFolder( 'timetable' );
			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
			$aFileDbConfigCheckedContents = [];//$this->importUtility->getImportList();
		}
		
		if( $usrSess['ist_stichtag'] ){
			$dbKurse = $this->importUtility->databaseReaderUtility->getCourses( 3 , $usrSess['stichtag'] );
		}else{
			$dbKurse = $this->importUtility->databaseReaderUtility->getCourses( 2 , '' );
		}

		$this->importUtility->dispatchFlashMessages( $this );

		// anyway: assign trigger and json-file
		$this->view->assign('import', $import );
		
		$postFromList = GeneralUtility::_POST('tx_sfgzkurs_vw');
        if( $postFromList['delete_selection'] ) $aFileDbConfigCheckedContents = [];
        $this->view->assign('mapCsvField', $aFileDbConfigCheckedContents );
		
        // OVERVIEW
		// overview: plugin-uid needed by stichtag
		$this->view->assign('contentUid', $this->contentObj->data['uid'] );
		
		// overview: checkbox for stichtag
		$this->view->assign('user_options', $usrSess  );
        
		// overview: list depending on stichtag
        $this->view->assign( 'kurse', $dbKurse );
        
		// link to config-page
		$this->settings['pageUid']['liste'] = $this->configurationManager->getContentObject()->data['pid'];
        $this->view->assign( 'pageUid', $this->settings['pageUid'] );

        // EXPORT files-list
		if( $this->request->hasArgument('doexport') ){
			$this->exportUtility->CreateExportFile( $Stichdatum );
		}elseif( $this->request->hasArgument('clear_exportfolder') ){
			$deletedFiled = $this->exportUtility->ClearOldExportFiles();
            $msg = ( $deletedFiled > 0 ? $deletedFiled : 'Keine') . ' ' . ( $deletedFiled ==1 ? 'Datei' : 'Dateien') . ' gelöscht. ' . $this->settings['export']['keepOldExportFiles'] . ' alte Dateien werden behalten.';
            $this->addFlashMessage( $msg , 'Ordner bereinigt!', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}
		$reqFromList = GeneralUtility::_GET('tx_sfgzkurs_vw');
        $exportfiles = $this->exportUtility->GetExportFiles( $Stichdatum , $reqFromList['view_exportfile'] );
		$this->view->assign('exportfiles', $exportfiles  );
        $this->view->assign( 'remote_url', $this->settings['remote_url'] );
    }

    /**
     * helper getSessionDataStichtag
     *
     * @return array
     */
    public function getSessionDataStichtag()
    {
			// read useroptions with stichtag
			$userObj = $GLOBALS['TSFE']->fe_user;
			if( $userObj ){
				$usrSess = $userObj->getKey( "user" , "SfgzKurs" );
				$usrSess['ist_stichtag'] = $usrSess['ist_stichtag'] ? 1 : 0;
				$usrSess['keep_stichtag'] = $usrSess['keep_stichtag'] ? 1 : 0;
			}

			// get date and checkbox from input if button or checkbox is klicked
			if( $this->request->hasArgument('user_options') ){
				$user_options = $this->request->getArgument('user_options');
				
				if( isset($user_options['ist_stichtag']) ){ // checkbox
					$usrSess['ist_stichtag'] = $user_options['ist_stichtag'] ;
				}
				
				if( isset($user_options['stichtag']) ){ // date
					
					if( empty($usrSess['ist_stichtag']) ){ // checkbox IS NOT checked
						// dont care about incomed date
						if( !$usrSess['keep_stichtag'] ) { // keep-stichtag IS NOT set
							// only store a empty stichtag if 
							// - checkbox IS NOT checked AND keep-stichtag IS NOT set
							// - or checkbox IS checked and a empty date was submitted
							// delete outgoing Stichtag also if keep-stichtag IS set
							$usrSess['stichtag'] = '';
						}
					}else{ // checkbox IS checked. Set incoming date, regardless if its empty or not.
						$todaysDate = $this->dateUtility->sanitizeDateTimestamp( );
						$incomedDate = empty($user_options['stichtag']) ? '' : $this->dateUtility->sanitizeGermanDateTimeString( $user_options['stichtag'] );
						$usrSess['stichtag'] = $todaysDate->format('d.m.Y') == $incomedDate ? '' : $incomedDate;
					}
				}
			}

			
			if( isset($user_options) ) {
				// store stichtag + useroptions
				$userObj->setKey("user","SfgzKurs", $usrSess);
				$userObj->sesData_change = true;
				$userObj->storeSessionData();
			}
			
			return $usrSess;
    }

    /**
     * action export
     *
     * @return void
     */
    public function exportAction()
    {
			$usrSess = $this->getSessionDataStichtag();
			$this->view->assign('user_options', $usrSess  );
			
			$pluginKey = 'tx_sfgzkurs_lst';
			$reqFromList = GeneralUtility::_POST( $pluginKey );
			
			// display title and data for user-called actions
			if( $reqFromList['import'] ) $this->view->assign( 'aktion', 'import' );
			
			if( isset($reqFromList['doexport']) ) {
				$datum = $this->dateUtility->getStichtag();
				$fileName = str_replace( '-' , '' , $datum ) . '.json';
				$debug = $this->exportUtility->ReadExportFile( $fileName );
				$this->view->assign( 'data', $debug );
				$this->view->assign( 'aktion', 'export' );

			}elseif( $this->request->hasArgument('view_exportfile') ){
				$fileName = $this->request->getArgument('view_exportfile');
				$debug = $this->xmlUtility->DebugActualExportFile( $fileName );
				$this->view->assign( 'data', $debug );
				$this->view->assign( 'aktion', 'preview' );
			}elseif( $reqFromList['clear_exportfolder'] ){
				$this->view->assign( 'aktion', 'preview' );
				if( $usrSess['ist_debug'] ){
 					$this->view->assign( 'data', [ 'Ordner bereinigt' => $this->settings['export']['keepOldExportFiles'] . ' alte Dateien werden behalten.']  );
				}
			}
    }

    /**
     * action import
     *
     * @return void
     */
    public function importAction()
    {
			$usrSess = $this->getSessionDataStichtag();
			$this->view->assign('user_options', $usrSess  );
        
			$index = $this->request->hasArgument('index') ? $this->request->getArgument( 'index' ) : -1;
			$this->view->assign('index', $index );
			
			$this->persistenceManager->persistAll();
			$aFileDbConfigCheckedContents = $this->importUtility->getImportList();
			
			$pluginKey = 'tx_sfgzkurs_lst';
			$reqFromList = GeneralUtility::_POST( $pluginKey);
			
			$strAktion = 'back' ;
			$out = [];
			if( $this->request->hasArgument('index') ){
				$strAktion = 'preview' ;
				$out = $aFileDbConfigCheckedContents;
				
			}else{
				foreach($aFileDbConfigCheckedContents as $loopIx => $aCourse ){
					if( $aCourse['general']['checkImport'] ) $out[$loopIx] = $aCourse;
				}
				
				if( $reqFromList['import'] ){
					$strAktion = 'import' ;
					
				}elseif( $_FILES[$pluginKey]['tmp_name']['dateiname'] ){ // UPLOAD
					$strAktion = 'upload' ;
					$out = $aFileDbConfigCheckedContents;
					
				}elseif( $reqFromList['getfile_course'] ){ // FILE-IMPORT
					$strAktion = 'getfile' ;
					$out = $aFileDbConfigCheckedContents;
					
				}elseif( $reqFromList['clearfolder_timetable'] ){ // FILE DELETE
					$strAktion = 'clearfolder' ;
					
				}elseif( $reqFromList['delete_selection'] ){ // SELECTION DELETE
					$strAktion = 'reload' ;
					
				}elseif( !count($aFileDbConfigCheckedContents) ){
					$strAktion = 'nodata' ;
					$out = [];
					
				}
			}
			$this->view->assign( 'aktion', $strAktion );
			
			$aSingleDataIfPossible = isset($out[$index]) ? $out[$index] : $out;
			$this->view->assign('data', $aSingleDataIfPossible );
        
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {
        $objKategorie = $this->objectManager->get( 'Sfgz\\SfgzKurs\Domain\\Repository\\KategorieRepository' )->findAll();
        $this->view->assign('kategorien', $objKategorie);
        $this->view->assign('kategoriegruppen', $this->getKategorienGruppen() );

    }

    /**
     * action create
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Kurs $newKurs
     * @return void
     */
    public function createAction(\Sfgz\SfgzKurs\Domain\Model\Kurs $newKurs)
    {
        if( $this->request->hasArgument('abort') ) $this->redirect('list');
        $this->addFlashMessage('Der Kurs wurde erstellt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->kursRepository->add($newKurs);
// 		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        $this->redirect('list');
    }
    
    /**
     * action edit
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Kurs $kurs
     * @ignorevalidation $kurs
     * @return void
     */
    public function editAction(\Sfgz\SfgzKurs\Domain\Model\Kurs $kurs)
    {
        $objKategorie = $this->objectManager->get( 'Sfgz\\SfgzKurs\Domain\\Repository\\KategorieRepository' )->findAll();
        $this->view->assign('kategorien', $objKategorie);
        $this->view->assign('kurs', $kurs);

        $this->view->assign('kategoriegruppen', $this->getKategorienGruppen() );
    }

    /**
     * getKategorienGruppen
     *
     * @return void
     */
    Private function getKategorienGruppen()
    {
        $aKategoriegruppen = [];
        $aCatGrp = explode( ',' ,  $this->settings['kategoriegruppen'] );
        foreach( $aCatGrp as $i => $cat ) $aKategoriegruppen[$i+1] = trim($cat);
        return $aKategoriegruppen;
    }

    /**
     * action update
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Kurs $kurs
     * @return void
     */
    public function updateAction(\Sfgz\SfgzKurs\Domain\Model\Kurs $kurs)
    {
        if( $this->request->hasArgument('abort') ) $this->redirect('list');
        
        $this->addFlashMessage('Der Kurs wurde gespeichert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        $this->kursRepository->update($kurs);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        $this->redirect('edit', NULL, NULL, array('kurs' => $kurs));
    }

    /**
     * action delete
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Kurs $kurs
     * @ignorevalidation $kurs
     * @return void
     */
    public function deleteAction(\Sfgz\SfgzKurs\Domain\Model\Kurs $kurs)
    {
        $this->addFlashMessage('Der Kurs wurde entfernt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->kursRepository->remove($kurs);
// 		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        $this->redirect('list');
    }
}
