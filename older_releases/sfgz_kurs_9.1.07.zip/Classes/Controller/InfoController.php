<?php
    namespace Sfgz\SfgzKurs\Controller;

    use \TYPO3\CMS\Core\Utility\GeneralUtility;

    /***
    *
    * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
    *
    * For the full copyright and license information, please read the
    * LICENSE.txt file that was distributed with this source code.
    *
    *  (c) 2018
    *
    ***/

    /**
    * InfoController
    */
    class InfoController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
    {
    /**
        * infoRepository
        *
        * @var \Sfgz\SfgzKurs\Domain\Repository\InfoRepository
        * @inject
        */
    protected $infoRepository = null;

    /**
        * belegungRepository
        *
        * @var \Sfgz\SfgzKurs\Domain\Repository\BelegungRepository
        */
    protected $belegungRepository = null;

    /**
        * initializeAction
        *
        */
    public function initializeAction()
    {
        $this->dateUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\DateUtility');
        $this->belegungenUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\BelegungenUtility');
        $this->belegungenUtility->setSettings( $this->settings );

        $objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
        $this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');

        $querySettings = $objectManager->get('TYPO3\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
        $querySettings->setRespectStoragePage(FALSE);
        $this->infoRepository = $objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\InfoRepository');
        $this->infoRepository->setDefaultQuerySettings($querySettings);
        
        $this->belegungRepository = $objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\BelegungRepository');
        $this->belegungRepository->setDefaultQuerySettings($querySettings);
    }

    /**
        * action editor
        *
        * @return void
        */
    public function editorAction()
    {
        $origStichday = $this->dateUtility->getStichtag();
        $stichday = ( $origStichday == date( 'Y-m-d' ) ) ?  '' : $origStichday;
        $stichtag = $stichday ? $this->dateUtility->sanitizeDateTimeStringToGerman($stichday) : '';
        
        $objDate = $this->dateUtility->sanitizeDateTimestringToObject( $origStichday );
        $objDate->add( new \DateInterval( 'PT12H' ) );
        
        $aLektionen = $this->belegungenUtility->findBelegungenAndLektionenByDatumAnzeige( $objDate->format( 'Y-m-d' ) );
        $aLektionen = $this->enrichLektionenWithCss( $aLektionen );
        
        $aObjInfo = $this->infoRepository->findByDatumAnzeige( $objDate->format( 'Y-m-d' ) );
        if( !count($aObjInfo) ){
            $newObject = GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\Info');
            $newObject->setDatumAnzeige( $objDate );
            $this->infoRepository->add($newObject);
        }else{
            foreach( $aObjInfo as $newObject ) break;
        }
        $this->persistenceManager->persistAll();

        $this->view->assign('stichtag', $stichtag);
        $this->view->assign('lektionen', $aLektionen);
        $this->view->assign('info', $newObject);
        
        $settings = $this->settings;
        $settings['infodisplay_hideLessonsAfterMinutesSigned'] = $settings['infodisplay_hideLessonsAfterMinutes'];
        if ( $settings['infodisplay_hideLessonsAfterMinutes'] < 0 ) $settings['infodisplay_hideLessonsAfterMinutes'] = $settings['infodisplay_hideLessonsAfterMinutes']*-1;
        $this->view->assign('settings', $settings );
//         $rpBelegungen = $this->belegungenUtility->findRaumplanungByDatumAnzeige( $objDate->format( 'Y-m-d' ) );
//         $this->view->assign('raumplanung', $rpBelegungen);
        
    }

    /**
        * action update
        *
        * @param \Sfgz\SfgzKurs\Domain\Model\Info $info
        * @return void
        */
    public function updateAction(\Sfgz\SfgzKurs\Domain\Model\Info $info=NULL)
    {
        if( $this->request->hasArgument('but_stichtag') ) {
                $incomedStichtag = $this->request->hasArgument('stichtag') ? $this->request->getArgument('stichtag') : '';
                $this->storeStichtag($incomedStichtag);
        }
        
        if ( $this->request->hasArgument('but_store') && $info ){
            $aBelegungen = $this->request->hasArgument('belegung') ? $this->request->getArgument('belegung'): [];
            $this->updateBelegungen( $aBelegungen , $info );
            $this->infoRepository->update($info);
            $this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
            $GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        }
        
        $this->redirect('editor');
    }

    /**
        * action display
        *
        * @return void
        */
    public function displayAction()
    {
        
        $zeitFromExtern = GeneralUtility::_GET('zeit');
        $datumFromExtern = GeneralUtility::_GET('datum');
        if($datumFromExtern){
            $strStichtag = $datumFromExtern;
            if( empty($zeitFromExtern) ) $zeitFromExtern = '00:00' ;
            
        }elseif( $this->request->hasArgument('stichtag') ){
            $strStichtag = $this->request->getArgument('stichtag');
            
        }else{
            $strStichtag = '';
        }
        
        if( $strStichtag ){
            $objDate = $this->dateUtility->sanitizeDateTimestringToObject( $strStichtag );
        }else{
            $objDate = $this->dateUtility->sanitizeDateTimestamp();
        }

        $objInfo = $this->belegungenUtility->findInfoByDatumAnzeige( $objDate->format('Y-m-d') );
        $aLektionen = $this->belegungenUtility->findBelegungenAndLektionenByDatumAnzeige( $objDate->format('Y-m-d') );
        
        $aLektionen = $this->enrichLektionenWithCss( $aLektionen , $zeitFromExtern );
        
        $aCallState = [ 
                'standalone' => $this->request->hasArgument('action') ? 0 : 1 , 
                'preview'    => $this->request->hasArgument('stichtag') || $datumFromExtern || $zeitFromExtern ? 1 : 0,
                'zeit'       => $zeitFromExtern ? $zeitFromExtern : ''
        ];
        
        $this->view->assign('stichtag', $objDate);
        $this->view->assign('info', $objInfo);
        $this->view->assign('lektionen', $aLektionen );
        $this->view->assign('callstate', $aCallState );
    }

    /**
        * enrichLektionenWithCss
        *
        * @param array $aLektionen
        * @param string $zeit optional, default is now
        * @return array
        */
    public function enrichLektionenWithCss( $aLektionen , $zeit ='' )
    {
        if( !count( $aLektionen ) ) return $aLektionen;
        
        if( $zeit ){
            $aTime = explode( ':' , str_replace( '.' , ':' , $zeit ) );
            if( empty($aTime[0]) ) $aTime[0] = 0;
            if( empty($aTime[1]) ) $aTime[1] = 0;
            $nowMinutesFromMidnight = ( $aTime[0] * 60 ) + $aTime[1];
            
        }else{
            $objDateNow = $this->dateUtility->sanitizeDateTimestamp();
            $nowMinutesFromMidnight = ( $objDateNow->format('H') * 60 ) + $objDateNow->format('i');
        }
        $isPassed = [];
        foreach( $aLektionen as $ix => $lektion ){
            $aLektionen[$ix]['zeitBis'] = str_replace(':','.',$aLektionen[$ix]['zeitBis']);
            
            if( empty($this->settings['infodisplay_hideLessonsAfterMinutes']) ){
                // if 0 = infodisplay_hideLessonsAfterMinutes then leave the loop and display the lesson
                 continue;
            }
            
            $aBis = explode( ':' , str_replace( '.' , ':' , $lektion['zeitBis'] ) );
            $std = is_numeric($aBis[0]) ? ( $aBis[0] * 60 ) : 0;
            $min = is_numeric($aBis[1]) ?  $aBis[1]: 0;
            $lessonMinutesFromMidnight = $min + $std;
            $isPassed[$ix] = $lessonMinutesFromMidnight + $this->settings['infodisplay_hideLessonsAfterMinutes'] < $nowMinutesFromMidnight ? 1 : 0;
            $aLektionen[$ix]['css'] = $isPassed[$ix] ? 'passed' : '';
        }
        $countVisible = count($aLektionen) - array_sum($isPassed);
        return [ 'daten' => $aLektionen , 'count' => $countVisible ];
    }

    /**
        * action list
        *
        * @return void
        */
    public function listAction()
    {
        $info = $this->infoRepository->findAll();
        $this->view->assign('info', $info );
    }

    /**
        * updateBelegungen
        *
        * @param array $aBelegungen
        * @param \Sfgz\SfgzKurs\Domain\Model\Info $info
        * @return \Sfgz\SfgzKurs\Domain\Model\Info
        */
    public function updateBelegungen( array $aBelegungen , $info )
    {
        
        $this->deleteBelegungen( $aBelegungen , $info );
        
        // add or store belegungen
        if( !count($aBelegungen) ) return false;
        
        $uidInfo = $info->getUid();
        foreach( $aBelegungen as $ix => $aBelegung ){
            
            $isNew = substr( $ix , 3 , 1 ) == '_' ? 1 : 0;
            
            if( $isNew ){
                // create recordset
                $objBelegung = GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\Belegung');
            }else{
                // select recordset to update
                $objBelegung = $this->belegungRepository->findByUid($ix);
                if( !$objBelegung ) continue;
            }
            
            $objBelegung->setInfo( $uidInfo );
            $objBelegung->setZeitVon( $aBelegung['zeitVon'] );
            $objBelegung->setZeitBis( $aBelegung['zeitBis'] );
            $objBelegung->setRaum( $aBelegung['raum'] );
            $objBelegung->setBelegungstext( $aBelegung['belegungstext'] );
            $objBelegung->setPerson( $aBelegung['person'] );
            
            if( $isNew ){
                //  add created recordset to belegungRepository
                $this->belegungRepository->add($objBelegung);
                $this->persistenceManager->persistAll();
            }else{
                // update existing recordset
                $this->belegungRepository->update($objBelegung);
                $this->persistenceManager->persistAll();
            }
        }

        return true;
    }

    /**
        * deleteBelegungen
        *
        * @param array $aBelegungen
        * @param \Sfgz\SfgzKurs\Domain\Model\Info $info
        * @return \Sfgz\SfgzKurs\Domain\Model\Info
        */
    public function deleteBelegungen( array $aBelegungen , \Sfgz\SfgzKurs\Domain\Model\Info $info )
    {
        // remove existing belegungen if missed in the array $aBelegungen
        $objsBelegungen = $info->getIBelegungen() ;
        if( !count($objsBelegungen) ) return false;
        
        foreach( $objsBelegungen as $ix => $objBelToDel ){
            if( isset( $aBelegungen[$objBelToDel->getUid()] ) )  continue;
            $this->belegungRepository->remove($objBelToDel);
            $this->persistenceManager->persistAll();
        }

        return true;
    }

    /**
        * storeStichtag
        *
        * @param string $stichdatum optional, empty for todays date
        * @return void
        */
    public function storeStichtag( $stichdatum = '' )
    {
        $userObj = $GLOBALS['TSFE']->fe_user;
        if( !$userObj ) return false;
        
        // get the incomed date-value
        $reqStichdatum = '';
        if( $stichdatum ){
            $reqStichdatum = $this->dateUtility->sanitizeGermanDateTimeString( $stichdatum );
            // store empty value if the incomed date corresponds todays date
            if( $reqStichdatum == date( 'd.m.Y' ) ) $reqStichdatum = '';
        }
        
        // get stored array
        $usrSess = $userObj->getKey( "user" , "SfgzKurs" );
        
        // change stichtag value in array. 
        $usrSess['stichtag'] = $reqStichdatum;
        // if date is empty then set stichtag-checkbox in array to unchecked.
        $usrSess['ist_stichtag'] = $reqStichdatum ? 1 : 0;
        
        // store array again
        $userObj->setKey("user","SfgzKurs", $usrSess);
        $userObj->sesData_change = true;
        $userObj->storeSessionData();

        return true;
    }

    }
