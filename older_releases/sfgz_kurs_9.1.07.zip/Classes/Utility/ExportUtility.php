<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/** 
 * Class ExportUtility
 * 
 * 
 */
 
class ExportUtility extends \Sfgz\SfgzKurs\Utility\ExportfunctionsUtility {

	/**
	 * array metadaten
	 */
	protected $metadaten = null;

	/**
	 * array kategorien
	 */
	protected $kategorien = null;

	/**
	 * array kurse
	 */
	protected $kurse = null;

	/**
	 * array progress
	 */
	protected $progress = null;

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_lst';

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
			$this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
			$this->databaseReaderUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\DatabaseReaderUtility');
			$this->filetransferUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\FiletransferUtility');
			$this->sortUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SortUtility');
		    $this->settings = $this->settingsUtility->getSettings( $this->pluginKey );

	}
	
    /**
     *  CreateExportFile
     *  main function
     *
     * @param string $datum
     * @return array
     */
	Public function CreateExportFile( $datum )
	{
		    $this->englStichtag = $this->databaseReaderUtility->dateUtility->sanitizeDateTimeStringToEnglish( $datum );
		    
			$this->BuildXmlMetadaten();
			
 			$this->BuildXmlKategorie();
 			
 			$this->BuildXmlKurs();
			
			$jsonData = [ 'enumeratoren' => $this->metadaten['enumeratoren'] , 'kategorien' => $this->kategorien , 'kurse' => $this->kurse ];
		
			return $this->writeExportFile($jsonData);
			
			// examples of array-structures:
			// metadaten['komplexe-typen']['typ'][0]['attr']['attr-feld1']
			// metadaten['komplexe-typen']['typ'][0]['node']['feld']['0']
			// kategorien[0]['attr']['id']
			// kategorien[0]['node']['0']['attr']['id']
			// kategorien[0]['node']['0']['data']
			// kurse[222]['node']['versionen'][327]['node']['durchfuehrungen'][360]['node']['data-feld1']
			// kurse[3]['node']['versionen'][17]['node']['durchfuehrungen'][3]['attr']['attr-feld1']
	}

    /**
     *  writeExportFile
     *
     * @param string $jsonData
     * @return array
     */
	Private function writeExportFile( $jsonData )
	{
			$uploadDir = rtrim(PATH_site, '/') . '/' . trim($this->settings['filePaths']['subfolder'], '/')  . '/' ;
			$this->uploadFolder =  GeneralUtility::getFileAbsFileName($uploadDir);
			$this->filetransferUtility->createDirectory( $this->uploadFolder );

			$exportfolder = rtrim($this->uploadFolder, '/') . '/' . trim($this->settings['filePaths']['exportfolder'], '/')  . '/' ;
			$this->filetransferUtility->createDirectory( $exportfolder );

			$dateObject = new \DateTime( $this->englStichtag . 'T'.date('H:i:s') );
			$localDate = $this->databaseReaderUtility->dateUtility->sanitizeDateTime( $dateObject );
			$d = $localDate->format('U');
			$rp = array( '%Y' => date('Y',$d) , '%m' => date('m',$d) , '%d' => date('d',$d) , '%H' => date('H',$d) , '%i' => date('i',$d) , '%s' => date('s',$d) );
			$filename = str_replace( array_keys($rp) , $rp , trim($this->settings['export']['file_datepattern']) );
			file_put_contents( $exportfolder . $filename . '.json' , json_encode( $jsonData ) );

			return  $jsonData;
	}
	
    /**
     * GetExportFiles
     * - $stichtag sets css class to 'bulbon' for actual file - for all others to bulboff
     * - $selectedFilename appends css class 'selected' to choosen file
     *
     * @param string $stichtag german date dd.mm.yyyy
     * @param string $selectedFilename optional
     * @param boolean $sortDescending optional, default = true
     * @return array
     */
	Public function GetExportFiles( $stichtag , $selectedFilename = '' , $sortDescending = true )
	{
			$fileList = $this->filetransferUtility->getFileList( $this->settings['filePaths']['exportfolder'] );
			if( !is_array($fileList) ) return;
			
			$strEnglDate = $this->filetransferUtility->dateUtility->sanitizeDateTimeStringToEnglish( $stichtag );
			$dateObject = new \DateTime( $strEnglDate );
			
			$this->englStichtag = $dateObject->format('Y-m-d');

			$uxTime = $dateObject->format('U');
			$todaysFilename = $this->uxTimeToExportFilename( $uxTime );
			
			$aSortList = [];
			ksort($fileList); // ksort by filename = date ASC - oldest first
			foreach($fileList as $fix  => $fileInfo ){
				$y = substr( $fix , 0 , 4);
				$m = substr( $fix , 4 , 2);
				$d = substr( $fix , 6 , 2);
				$activetime = mktime( 12,0,0, $m ,$d , $y );
				$cetActveDate = $this->filetransferUtility->dateUtility->sanitizeDateTimestamp($activetime);
				$cetDate = $this->filetransferUtility->dateUtility->sanitizeDateTimestamp($fileInfo['time']);
				$fileInfo['selected'] = $selectedFilename == $fix ? 'selected':'';
				$fileInfo['css'] = 'bulboff';
				$fileInfo['hint'] = 'Inaktiv';
// 				$fileInfo['date'] =  $cetDate->format('d.m.Y H:i:s');
// 				$fileInfo['start'] =  $cetActveDate->format('d.m.Y');
				$fileInfo['date'] =  $cetDate;
				$fileInfo['start'] =  $cetActveDate;
				// set to active if the filename-date is not in future ( today >= file ). The next file is the younger, could be the more actual and overwrite the variable $lastActiveFile
				if( $todaysFilename >= substr($fileInfo['shortfilename'] , 0 , 8 ) ) $lastActiveFile = $fix . '.' . $cetDate->format('YmdHis');
				$aSortList[ $fix . '.' . $cetDate->format('YmdHis') ] = $fileInfo;
			}
			
			if( $sortDescending ) krsort($aSortList);
			
			if( isset( $lastActiveFile ) ) {
				$aSortList[$lastActiveFile]['css'] = 'bulbon';
				$aSortList[$lastActiveFile]['hint'] = 'Aktiv';
			}
			return $aSortList;
	}
	
    /**
     * uxTimeToExportFilename
     *
     * @param int $uxTime
     * @return string
     */
	private function uxTimeToExportFilename( $uxTime )
	{
			$rp = array(
				'%Y' => date('Y', $uxTime ) , 
				'%m' => date('m', $uxTime ) , 
				'%d' => date('d', $uxTime ) , 
				'%H' => date('H', $uxTime ) , 
				'%i' => date('i', $uxTime ) , 
				'%s' => date('s', $uxTime ) 
			);
			$datepattern = trim($this->settings['export']['file_datepattern']);
			
			$todaysFilename = str_replace( array_keys($rp) , $rp , $datepattern );
			return $todaysFilename;
	}
	
    /**
     * ClearOldExportFiles
     * deletes old files in export folder
     *
     * @return void
     */
	Public function ClearOldExportFiles()
	{
			if( empty($this->settings['export']['keepOldExportFiles']) ) return;
			
			$fileList = $this->filetransferUtility->getFileList( $this->settings['filePaths']['exportfolder'] );
			if( !is_array($fileList) ) return;
			
			krsort($fileList); // krsort by filename = date DESC newest first
			$uxTime = time(); // now unix timestamp
			$todaysFilename = $this->uxTimeToExportFilename( $uxTime );
			
			$exportDir = $this->filetransferUtility->uploadFolder . $this->settings['filePaths']['exportfolder'] . '/';
			$activeFiles = 0;
			foreach($fileList as $fix  => $fileInfo ){
				// mark as active if the filename-date is not in future ( today >= file ). 
				if( $todaysFilename >= substr($fileInfo['shortfilename'] , 0 , 8 ) ) {
					$activeFiles += 1 ;
					// we increase 1+keepOldExportFiles because we keep 1 filemore than old
					if( $activeFiles > 1+$this->settings['export']['keepOldExportFiles'] ){
						@unlink( $exportDir . $fileInfo['filename'] );
					}
				}
			}

			return ( $activeFiles - (1+$this->settings['export']['keepOldExportFiles']) );

	}
	
    /**
     *  RemoveExportFile
     *  called from  kursController->overviewAction()
     *
     * @param string $fileName
     * @return array
     */
	Public function RemoveExportFile( $fileName )
	{
			$uploadDirFile = rtrim(PATH_site, '/') . '/';
			$uploadDirFile .= trim($this->settings['filePaths']['subfolder'], '/')  . '/';
			$uploadDirFile .= trim($this->settings['filePaths']['exportfolder'], '/')  . '/';
			$uploadDirFile .= $fileName ;
			
			$exportfolder = GeneralUtility::getFileAbsFileName($uploadDirFile);
			
			@unlink( $exportfolder );
	}
	
    /**
     *  ReadExportFile
     *
     * @param string $fileName
     * @return array
     */
	Public function ReadExportFile( $fileName )
	{
			$uploadDir = rtrim(PATH_site, '/') . '/';
			$uploadDir .= trim($this->settings['filePaths']['subfolder'], '/')  . '/';
			$uploadDir .= trim($this->settings['filePaths']['exportfolder'], '/')  . '/' ;
			
			$exportfolder = GeneralUtility::getFileAbsFileName($uploadDir);
			
			if( !file_exists($exportfolder . $fileName) ) return false;
			$jsonText = file_get_contents( $exportfolder . $fileName );
			return json_decode( $jsonText , true );
	}

    /**
     *  BuildXmlLists
     *  standalone method
     *
     * @return array
     */
	Protected function BuildXmlMetadaten()
	{
			
			$this->records = [];
			// build records['enumeratoren']
			$this->part_metadaten_buildDataForLists();
			
// 			// build records['komplexe-typen']
// 			$xmlFieldcontent = $this->getExportTsCleanEmptyFields();
// 			$this->part_metadaten_buildDataForFields($xmlFieldcontent);
			
			$this->metadaten = $this->part_renderDataWithConfig( $this->settings['export']['mapFieldStructure']['metadaten'] );
			return true;
	}
	
    /**
     *  part_metadaten_buildDataForLists
     *  used by BuildXmlMetadaten()
     *
     * @return array
     */
	Protected function part_metadaten_buildDataForLists()
	{
			$languageKeys = $this->settings['export']['optionListsLanguageKeys'] ;
			foreach( $languageKeys as $enumeratorenName => $maskedLlKey ){
				$z1 = isset($this->records['enumeratoren']['typ']) ? count($this->records['enumeratoren']['typ']) : 0;
				for( $n = 0; $n<=99 ; ++$n ){
					$llString = str_replace( '%n' , $n , $maskedLlKey );
					$strTranslated = LocalizationUtility::translate( $llString , 'SfgzKurs' );
					if( !strlen( $strTranslated ) ) continue;
					//$this->records['enumeratoren'][$enumeratorenName][$n] = $strTranslated ;
					$this->records['enumeratoren']['typ'][$z1]['name'] = $enumeratorenName ;
					$this->records['enumeratoren']['typ'][$z1]['element'][$n]['wert'] = $n ;
					$this->records['enumeratoren']['typ'][$z1]['element'][$n]['data'] = $strTranslated ;
				}
			}
			return true;
	}
	
    /**
     *  part_metadaten_buildDataForFields
     *  used by BuildXmlMetadaten()
     *
     * @param array $xmlFieldcontent
     * @return array
     */
	Protected function part_metadaten_buildDataForFields($xmlFieldcontent)
	{
			
			if( !is_array($xmlFieldcontent) ) return;
			
			// earn data
			// $cNodeName is 'typ' (only one element)
			foreach( $xmlFieldcontent as $sub1tablename => $sub1Row  ){
				if( !isset( $sub1Row['node'] ) ) continue; 
				$z1 = count($this->records['komplexe-typen']['typ']);
 				$this->records['komplexe-typen']['typ'][$z1]['name'] = $sub1tablename;
				$z2 = 0;
				foreach($sub1Row['node'] as $sub1XmlFieldName => $sub1XmlContent  ){
					if( is_array( $sub1XmlContent ) ){
						$this->part_metadaten_buildDataForFields($sub1XmlContent);
						
					}else{
						$aFieldAttributes = $this->extractFieldAttributesFromString( $sub1XmlContent , $sub1XmlFieldName , $sub1tablename );
						
						if( empty($aFieldAttributes['datatype']) ){
							
							$aFieldAttributes['datatype'] = $this->settingsUtility->getDbFieldType( $sub1tablename , $sub1XmlFieldName );
							
							// if still empty
							if( empty($aFieldAttributes['datatype']) ){
								// if $sub1XmlContent like isNewGetScript | version.neu_bis | TRUE | FALSE 
								// then there is no field 'neu' ( $sub1XmlFieldName) in database, the fields db-name is neu_bis
								$atoms = explode( '.' , $sub1XmlContent );
								if( trim($atoms[0]) == 'functions') {
									$aFunct = explode( '|' , trim($sub1XmlContent) );
									// get last parameter
									$lastParameter = trim($aFunct[ count($aFunct)-1 ]);
									if( is_numeric( $lastParameter ) ){
										$aFieldAttributes['datatype'] = 'int'; // Int32
									}elseif( strtolower($lastParameter) == 'true' || strtolower($lastParameter) == 'false' ){
										$aFieldAttributes['datatype'] = 'tinyint'; // Boolean
									}else{
										// $aFieldAttributes['datatype'] = '';
									}
								}
							}
							
						}
						
						if( $sub1XmlFieldName == 'id' && $aFieldAttributes['datatype'] == 'int' ) $aFieldAttributes['datatype'] .= '_uid';
						
						// map with ts-settings
						$aInfo = $this->settings['export']['mapDataTypes']['fieldtypes'][ $aFieldAttributes['datatype'] ];
						// append to all fields a description from local-language-file - or a empty string.
						$aInfo['beschreibung'] = LocalizationUtility::translate( 'tx_sfgzkurs_domain_model_'.$aFieldAttributes['tablename'] . '.' . $aFieldAttributes['fieldname'] , 'SfgzKurs' );;

						if( !is_array($aInfo) ) continue;
						$this->records['komplexe-typen']['typ'][$z1]['feld'][$z2] = $aInfo;
						$this->records['komplexe-typen']['typ'][$z1]['feld'][$z2]['name'] = $sub1XmlFieldName;
						++$z2;
					}
				}
			}
			return true;
	}
	
    /**
     *  extractFieldAttributesFromString
     *  used by BuildXmlMetadaten()
     *
     * @param string $strTableFieldNames
     * @return array
     */
	Protected function extractFieldAttributesFromString( $strTableFieldNames , $fieldName , $tablename )
	{
			if( $strTableFieldNames == 'EMPTY' ) return;
			
			$atoms = explode( '.' , $strTableFieldNames );
			
			if( trim($atoms[0]) == 'functions') {
				// detect datatype via function-name 
				$table = $tablename;
				$field = $fieldName;
				$aFunct = explode( '|' , trim($atoms[1]) );
				$function = trim($aFunct[0]);
				$dbDataType = $this->settings['export']['mapDataTypes']['functionsFieldtype'][ $function ];
				
			}elseif( count($atoms) == 2 ){ // is it a table/field-pair or simple text
				// detect datatype via database-info
				$table = trim($atoms[0]);
				$field = trim($atoms[1]);
				$dbDataType = $this->settingsUtility->getDbFieldType( $table , $field );
				if( $field == 'uid' && $dbDataType == 'int' ) $dbDataType .= '_uid';
			}else{
				return [  ];
			}
			
			return [ 'tablename' => $table ,'fieldname' => $field , 'datatype' => $dbDataType ];
	}
	
    /**
     *  BuildXmlKategorie
     *  standalone method
     *
     * @return array
     */
	Protected function BuildXmlKategorie()
	{
				$this->records = [];
				$kategorien = $this->databaseReaderUtility->getKategorien();
				foreach($kategorien as $n => $row ){
					$gUid = $row['kategorie_gruppe'];
					$this->records['kategorien']['kategorie'][$gUid]['id'] = $row['kategorie_gruppe'];
					$this->records['kategorien']['kategorie'][$gUid]['name'] = '';
					foreach( $this->settings['export']['mapFieldStructure']['kategorien']['kategorie']['node']['kategorie']['attr'] as $attNam => $attSource ){
                        $aSrc = explode( '.' , $attSource );
                        if( $aSrc[0] == 'kategorie' && isset($row[$aSrc[1]]) ){
                            $this->records['kategorien']['kategorie'][$gUid]['kategorie'][$n][$attNam] = $row[$aSrc[1]];
                        }
					}
					// override special attributes
					$this->records['kategorien']['kategorie'][$gUid]['kategorie'][$n]['id'] = $n;
					$this->records['kategorien']['kategorie'][$gUid]['kategorie'][$n]['parent-id'] = $gUid;
					// set data
					$this->records['kategorien']['kategorie'][$gUid]['kategorie'][$n]['data'] = $row['kategorie_name'];
				}
				// add a dimension to the array in order to get over the first loop.
				$config = ['kategorien' => $this->settings['export']['mapFieldStructure']['kategorien'] ];
 				$begleitdaten = $this->part_renderDataWithConfig( $config );
 				// remove a dimension from array and assign to class-variable 
				$this->kategorien = $begleitdaten['kategorien'];
				
				return true;
	}
	
    /**
     *  part_renderDataWithConfig
     *  used by BuildXmlMetadaten()
     *  used by BuildXmlKategorie()
     *
     * @param array $config
     * @return array
     */
	Protected function part_renderDataWithConfig($config)
	{
			// durchlaufe erste Instanz der Config 
			//  fuer jeden Eintrag in der ersten ConfigInstanz (typ,beispiel) durchlaufe die erste Instanz der Datenbank
			//      wende daten auf attr konfiguration an
			//      durchlaufe node (zweite Instanz) der Config
			//        fuer jeden Eintrag in der zweiten ConfigInstanz (feld,beispiel) durchlaufe die zweite Instanz der Datenbank
			//        	 wende daten auf attr konfiguration an
			//        	 durchlaufe node (dritte Instanz) der Config
			//             fuer jeden Eintrag in der dritten ConfigInstanz (datatyp,format) 
			//        	   wende daten auf konfiguration an
			//           -ende config 3
			//        -ende db 2 (sub-record) 
			//      -ende config 2
			//  -ende db 1 (main-record) 
			// -ende config 1
			
			$this->dbStatic = [];
			$begleitdaten = [];
			foreach( $config as $metaTyp => $cMetaConf) {
				foreach( $cMetaConf as $cNodeName => $cNodeConf) {
					// for each tables-config (typ) run through all main-records $cNodeName = typ!
					if( !isset($this->records[$metaTyp][$cNodeName]) || !count($this->records[$metaTyp][$cNodeName]) ) continue;
					foreach( $this->records[$metaTyp][$cNodeName] as $z1 => $DB ){
						foreach( $cNodeConf['attr'] as $name => $value ){
 							if( isset( $DB[ $name ] ) ) {
								$this->dbStatic[ $cNodeName ][ $name ] = $DB[ $name ];
								$begleitdaten[$metaTyp][$z1]['attr'][$name] = $this->renderDataField( $value );
 							}
						}
						$begleitdaten[$metaTyp][$z1]['attr']['nodename'] = $cNodeName;
						
						if( isset($cNodeConf['data']) ) {
							$this->dbStatic[ $cNodeName ][ 'data' ] = $DB[ 'data' ];
							$begleitdaten[$metaTyp][$z1]['data'] = $this->renderDataField( $cNodeConf['data'] );
						}
						
						foreach( $cNodeConf['node'] as $cSubNodeName => $cSubNodeConf ){
								if( !count($DB[$cSubNodeName]) ) continue;
								// for each fields-config (element) run through all sub-records
								foreach( $DB[$cSubNodeName] as $z2 =>  $dbFieldRows ){
									foreach( $cSubNodeConf['attr'] as $name => $value ){
										// typ .node. element .attr. name = fieldname
										if( isset( $DB[$cSubNodeName][$z2][ $name ] ) ) {
											$this->dbStatic[ $cSubNodeName ][ $name ] = $DB[$cSubNodeName][$z2][ $name ];
											$begleitdaten[$metaTyp][$z1]['node'][$z2]['attr'][$name] = $this->renderDataField( $value );
										}
									}
									$begleitdaten[$metaTyp][$z1]['node'][$z2]['attr']['nodename'] = $cSubNodeName;
									
									if( isset($cSubNodeConf['data']) ) {
										$this->dbStatic[ $cSubNodeName ][ 'data' ] = $DB[$cSubNodeName][$z2][ 'data' ];
										$begleitdaten[$metaTyp][$z1]['node'][$z2]['data'] = $this->renderDataField( $cSubNodeConf['data'] );
									}
									
									if( !is_array($cSubNodeConf['node']) ) continue;
									foreach( $cSubNodeConf['node'] as $cSubSubNodeName => $cSubSubNodeConf ){
										// typ .node. element .node. datatyp = datatyp
 										if( isset( $DB[$cSubNodeName][$z2][$cSubSubNodeName] ) ) {
											$this->dbStatic[ $cSubNodeName ][ $cSubSubNodeName ] = $DB[$cSubNodeName][$z2][$cSubSubNodeName];
											$begleitdaten[$metaTyp][$z1]['node'][$z2]['node'][$cSubSubNodeName]= $this->renderDataField($cSubSubNodeConf);
 										}
									}
								}// for each sub-record
							
						}
					}// for each main-record 
				}
			}
			return $begleitdaten;
	}
	
    /**
     *  getExportTsCleanEmptyFields
     *  used by BuildXmlKurs()
     *  used by BuildXmlMetadaten()
     *  
     *  unsets empty arrays and fields with EMPTY as content
     *  
     *  The value EMPTY was inserted in this field because 
     *   - there is no corresponding field in db 
     *   - nor is there a function defined for it
     *  
     *  applies settings from
     *  $this->settings['export']['recordRestrictions']['keepEmpyFields']
     *  $this->settings['export']['recordRestrictions']['keepEmpySubrecords']
     *
     * @param array $aSettings
     * @return array
     */
	Protected function getExportTsCleanEmptyFields( $aSettings = [] )
	{
			if( !count($aSettings) ) $aSettings = $this->settings['export']['mapFieldStructure']['kurse'];

			$keepEmpyFields = $this->settings['export']['recordRestrictions']['keepEmpyFields'];
			$keepEmpySubrecords = $this->settings['export']['recordRestrictions']['keepEmpySubrecords'];
			
			if(	$keepEmpyFields && $keepEmpySubrecords ) {
				// keep everything, return all recordsets without any restrictions.
				return $aSettings;
			}
			
			foreach( $aSettings as $key => $aValu ){
				if( !is_array($aValu) ){ // field with value (string)
					if( $keepEmpyFields ) continue;
					if( 'EMPTY' == trim($aValu) ) unset($aSettings[ $key ]);
					
				}elseif( !count($aValu) ){ // empty array: no subrecords
						if( $keepEmpySubrecords ) continue;
						unset($aSettings[ $key ]);
						
				}else{ // not empty array with subrecords
					$aSettings[ $key ] = $this->getExportTsCleanEmptyFields( $aValu );
				}
			}
			return $aSettings;
	}
	
    /**
     *  BuildXmlKurs
     *  standalone method
     *
     * @return array
     */
	Protected function BuildXmlKurs()
	{
 			
			$conf = $this->getExportTsCleanEmptyFields();
			
			$unsortRecords = $this->databaseReaderUtility->getArrayCourses( 0 , $this->englStichtag );
			
 			$this->records = $this->sortUtility->resortArray( [ 'kurse' => $unsortRecords ] );
			
			
			$this->kurse = [];
			$this->dbStatic = [];
			foreach( $this->records as $index => $dbKurs ) {
				// MOVED DB to spec kurs
				
				// DB Kurs
				$this->dbStatic['kurs'] = $dbKurs;
				
				if( $this->part_kurs_selectWhere('kurs') != true ) continue;
				
				if( isset($conf['kurs']['attr']) ) {
					foreach($conf['kurs']['attr'] as $name => $value ){
						$this->kurse[$index]['attr'][$name] = $this->renderDataField($value);
					}
				}
				$this->kurse[$index]['attr']['nodename'] = 'kurs';
				
				foreach( $conf['kurs']['node'] as $cProp => $cCont ){
					// MOVE config through kurs fields
					if( !is_array($cCont) ) {
						$this->kurse[$index]['node'][$cProp] = $this->postRenderDataField( $this->renderDataField($cCont) );
					}
				}
				
				foreach( $conf['kurs']['node'] as $cSubTabF_name => $cSubTabConf ){
					// MOVED config to spec kurs.k_subtable
					
					// do arrays now: $cSubTabF_name kurs.k_versionen OR kurs.k_kategorien
					if( !is_array($cSubTabConf) ) continue;
			
					$dbTabNam = $this->part_kurs_x2dbNam($cSubTabF_name) ;
					// could be a simple field, rendered bevore
					if( !is_array($dbKurs[ $dbTabNam ]) ) continue;
					
					foreach( $dbKurs[ $dbTabNam ] as $dbKursSubArrIx => $dbKursSubRow ){
						// MOVED DB  to spec kurs.k_subrow.X like kurs.kategorie.2. DB is ready for fieldnames in row
						// $dbKursSubArrIx is a integer  like 1.

						foreach( $cSubTabConf as $cCsubTablename => $cCsubTabRow ){
							// DB version and kategorie
							$this->dbStatic[$this->part_kurs_x2dbNam($cCsubTablename)] = $dbKursSubRow;
							// MOVED config to spec kurs.k_kategorien.kategorie OR kurs.k_versionen.version
							// $cCsubTablename is like version or kategorie: $cCsubTabRow = $conf['kurs']['node']['k_versionen']['version']
							
							if( $this->part_kurs_selectWhere($cCsubTablename) != true ) continue;
							
							if( isset($cCsubTabRow['attr']) ) {
								foreach($cCsubTabRow['attr'] as $name => $value ){
									$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['attr'][$name] = $this->renderDataField($value);
								}
							}
							$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['attr']['nodename'] = $cCsubTablename;
							
							if( isset($cCsubTabRow['data']) ) {
								$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['data'] = $this->renderDataField($cCsubTabRow['data']);
							}
								
							if( !isset($cCsubTabRow['node']) ) continue;
							foreach( $cCsubTabRow['node'] as $cCsubTabFieldname => $cCsubTabContent ){ 
								// version fields: $cCsubTabFieldname: titel, start, ende ...
								if( is_array($cCsubTabContent) ) continue;
								$strFieldContent = $this->postRenderDataField( $this->renderDataField($cCsubTabContent) );
								$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['node'][$cCsubTabFieldname] = $strFieldContent; // $this->renderDataField($cCsubTabContent);
							}
							foreach( $cCsubTabRow['node'] as $cCsubTabFieldname => $cCsubTabContent ){
								// MOVED config to $cCsubTabFieldname = kurs.k_subtable.v_durchfuehrungen
								// version subtables, $cCsubTabFieldname = durchfuehrung
								if( !is_array($cCsubTabContent) ) continue;
								
								$dbSubTabNam = $this->part_kurs_x2dbNam($cCsubTabFieldname) ;
								if( !is_array($dbKursSubRow[$dbSubTabNam]) ) continue;
								foreach( $dbKursSubRow[$dbSubTabNam] as $dbDuchfuehrungArrIx => $dbDuchfuehrungRows ){
									// MOVED DB  to spec DuchfuehrungRow
									foreach( $cCsubTabContent as $cCsubTabTablename => $cCsubTabledef ){
										// DB durchfuehrung
										$durchfTabNam = $this->part_kurs_x2dbNam($cCsubTabTablename);
										$this->dbStatic[$durchfTabNam] = $dbDuchfuehrungRows;
										// $cCsubTabTablename = durchfuehrung
										
										if( $this->part_kurs_selectWhere($cCsubTabTablename) != true ) continue;
										
										if( isset($cCsubTabledef['attr']) ) {
											foreach($cCsubTabledef['attr'] as $name=>$value ){
												$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['node'][$cCsubTabFieldname][ $dbDuchfuehrungArrIx ]['attr'][$name] = $this->renderDataField($value);
											}
										}
										$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['node'][$cCsubTabFieldname][ $dbDuchfuehrungArrIx ]['attr']['nodename'] = $cCsubTabTablename;
										if( isset($cCsubTabledef['data']) ) {
											$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['node'][$cCsubTabFieldname][ $dbDuchfuehrungArrIx ]['data'] = $this->renderDataField($cCsubTabledef['data']);
										}
										if( !isset($cCsubTabledef['node']) ) continue;
										foreach( $cCsubTabledef['node'] as $cCsubSubTabFieldname => $cCsubSubTabContent ){ 
											// fields in durchfuehrung
											if( is_array($cCsubSubTabContent) ) continue;
											if( is_array($this->settings['export']['fieldRestrictions'][$durchfTabNam]) ){
												$testStop = 0;
												foreach( $this->settings['export']['fieldRestrictions'][$durchfTabNam] as $testField => $testRow ){
													if( 
														isset($testRow[$cCsubSubTabFieldname]) && 
														$testRow[$cCsubSubTabFieldname] != $this->dbStatic[$durchfTabNam][$testField]
													) {
														$testStop += 1;
													}
												}
												if( $testStop ) continue;
											}
											$strFieldContent = $this->postRenderDataField( $this->renderDataField($cCsubSubTabContent) );
											$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['node'][$cCsubTabFieldname][ $dbDuchfuehrungArrIx ]['node'][$cCsubSubTabFieldname] = $strFieldContent;// $this->renderDataField($cCsubSubTabContent);
										}
										foreach( $cCsubTabledef['node'] as $cCsubSubTabFieldname => $cCsubSubTabContent ){
											// subrows of durchfuehrung: $cCsubSubTabFieldname = d_termine
											if( !is_array($cCsubSubTabContent) ) continue;
											
											$dbSubSubTabNam =  $this->part_kurs_x2dbNam($cCsubSubTabFieldname) ;
											if( !is_array($dbDuchfuehrungRows[$dbSubSubTabNam]) ) continue;
											foreach( $dbDuchfuehrungRows[$dbSubSubTabNam] as $dbLektionenArrIx => $dbLektionenRows ){
												// MOVED DB  to spec lektionRow
												foreach( $cCsubSubTabContent as $cCsubSubTabTablename => $cCsubSubTabledef ){
													// $cCsubSubTabTablename = termin
													// DB termin (xml:lektion)
													$this->dbStatic[ $this->part_kurs_x2dbNam($cCsubSubTabTablename) ] = $dbLektionenRows;
													
													if( $this->part_kurs_selectWhere($cCsubSubTabTablename) != true ) continue;
													
													if( isset($cCsubSubTabledef['attr']) ) {
														foreach($cCsubSubTabledef['attr'] as $name=>$value ){
															$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['node'][$cCsubTabFieldname][ $dbDuchfuehrungArrIx ]['node'][$cCsubSubTabFieldname][$dbLektionenArrIx]['attr'][$name] = $this->renderDataField($value);
														}
													}
													$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['node'][$cCsubTabFieldname][ $dbDuchfuehrungArrIx ]['node'][$cCsubSubTabFieldname][$dbLektionenArrIx]['attr']['nodename'] = $cCsubSubTabTablename;
													if( isset($cCsubSubTabledef['data']) ) {
														$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['node'][$cCsubTabFieldname][ $dbDuchfuehrungArrIx ]['node'][$cCsubSubTabFieldname][$dbLektionenArrIx]['data'] = $this->renderDataField($cCsubSubTabledef['data']);
													}
													if( !isset($cCsubSubTabledef['node']) ) continue;
													foreach( $cCsubSubTabledef['node'] as $cCsubSubSubTabFieldname => $cCsubSubSubTabContent ){ 
														if( is_array($cCsubSubSubTabContent) ) continue;
														$strFieldContent = $this->postRenderDataField( $this->renderDataField($cCsubSubSubTabContent) );
														$this->kurse[$index]['node'][$cSubTabF_name][$dbKursSubArrIx]['node'][$cCsubTabFieldname][ $dbDuchfuehrungArrIx ]['node'][$cCsubSubTabFieldname][$dbLektionenArrIx]['node'][$cCsubSubSubTabFieldname] = $strFieldContent;
													}
												}
												break; // ONE IS ENOUGH FIXME
											} // $dbDuchfuehrungRows[$dbSubSubTabNam] as $dbLektionenArrIx => $dbLektionenRows
										}
									}
								} // $dbKursSubRow[$dbSubTabNam] as $dbDuchfuehrungArrIx => $dbDuchfuehrungRows
							} 
						}
					} // $dbKurs[ $dbTabNam ] as $dbKursSubArrIx => $dbKursSubRow
				}
			} // $this->records as $index => $dbKurs
			
			return true;
	}
	
    /**
     *  part_kurs_selectWhere
     *  used by BuildXmlKurs()
     *
     *  filter records depending on ts-settings
     *  settings['export']['recordRestrictions']['tablesSelectWhere']
     *
     * @param string $xmlTablename
     * @return string
     */
	Protected function part_kurs_selectWhere( $xmlTablename )
	{
		$bTotalResult = true;
		$cnf = $this->settings['export']['recordRestrictions']['tablesSelectWhere'];
		
		if( !isset( $cnf[$xmlTablename] ) ) return $bTotalResult;
		$strParam = trim( trim( trim($cnf[$xmlTablename]) , '|' ) );
		
		// could be AND / OR chain-words
		$aChainWords = [ 'AND' , 'OR' ];
		$pChainWrd = [];
		foreach( $aChainWords as $glue ){
			for( $offset = 0 ; $offset < strlen($strParam) ; ++$offset ){
				$fPos = strpos( $strParam , $glue , $offset );
				if( !$fPos ) break; // can not find this chain-word anymore
				// store positions of chain-words found in the fully raw string $strParam
				$pChainWrd[$fPos] = $glue;
				// set offset to the end of this chain-word
				$offset = $fPos + strlen($glue) ;
			}
		}
		
		if( !count($pChainWrd) ) {
			// no AND / OR chain-words
			$bTotalResult = $this->part_kurs_selectWhereTestSingle( $strParam );
			return $bTotalResult;
		}
		
		// clean out string to extract the conditions as array [ (str)condition ] = (bool)result
		$rp = [ 'OR'=>'AndOr' , 'AND'=>'AndOr' , '('=>'' , ')'=>'' ];
		$cleandedParam = str_replace( array_keys($rp) , $rp , $strParam );
		$aConditions = explode( 'AndOr' , $cleandedParam );
		foreach( $aConditions as $pCondIndex => $fullCondition ){
			$bResult = $this->part_kurs_selectWhereTestSingle( trim($fullCondition) );
			$aPartlyResult[trim($fullCondition)] = $bResult ? $bResult : 0;
		}
		
		// replace condition-textes in raw fullstring with corresponding boolean results
		$strCalculatdParam = str_replace( array_keys($aPartlyResult) , $aPartlyResult , $strParam );
		
		// replace SQL-sytled chainwords with PHP-styled
		$oRp = [ 'OR'=>' || ' , 'AND'=>' && '  ];
		$strPhpOperandParam = str_replace( array_keys($oRp) , $oRp , $strCalculatdParam );
		// execute full condition string eg: $bTotalResult = 1 && ( 0 || 1 ); 
		// ... $bTotalResult = datum_bis > getStichtag() AND ( termin NOT EMPTY OR text NOT EMPTY )
		$execstring = '$bTotalResult = ' . $strPhpOperandParam . ';';
		eval($execstring);
		return $bTotalResult;
	}
	
    /**
     *  part_kurs_selectWhereTestSingle
     *  used by BuildXmlKurs()
     *
     * @param string $strParam
     * @return boolean
     */
	Protected function part_kurs_selectWhereTestSingle( $strParam )
	{
		
		// operator could be anywere
		// detect operator by chars =, < or >
		// 6 possibilitys: [ != | <= | >= | == | < | > ]
		// 
		$aOperators = [ '!=' , '<=' , '>=' , '==' , '>' , '<' , 'NOT' , 'IS' ];
		
		foreach( $aOperators as $op ){
			if( strpos( $strParam , $op ) ){
				$actualOperator = $op;
				break;
			}
		}
		if( !isset($actualOperator) ) return true;
		
		// split string with operator
		$aFullOperation = explode( $actualOperator , $strParam );
		if( count($aFullOperation) != 2 ) return true;
		
		// special handling if a operand contains keyword like EMPTY
		$hasKeyword = false;
		$aKeywords = [ 'empty' , 'null' , 'leer' , 'numeric' ]; // 0, 1, 2 same function empty()
		foreach( $aKeywords as $ixKeyword => $keyword ){
			$hasKeyword = $keyword == strtolower(trim($aFullOperation[0])) ? 2 : 0;
			$hasKeyword = $keyword == strtolower(trim($aFullOperation[1])) ? 1 : $hasKeyword;
			if($hasKeyword) break;
		}
		
		if( !$hasKeyword ){
			$operand1 = $this->renderDataField( trim($aFullOperation[0]) );
			$operand2 = $this->renderDataField( trim($aFullOperation[1]) );
			
			if( !strlen($operand1) ) $operand1 = 0;
			if( !strlen($operand2) ) $operand2 = 0;
			$execstring = '$res = ( "' . $operand1 . '" ' . $actualOperator . ' "' . $operand2 . '" );';
			eval($execstring);
			return $res ? true : false;
		}
		
		
		$pos = $hasKeyword-1;
		$operand1 = $this->renderDataField( trim($aFullOperation[$pos]) );
		$bResult = true;
		
		if( $ixKeyword <= 2 ){ // EMPTY?
				
				$isEmpty = empty($operand1);
				
				if( $actualOperator == '!=' || $actualOperator == 'NOT' ){ 
					$bResult = $isEmpty ? false : true;
				
				}elseif( $actualOperator == '==' || $actualOperator == 'IS' ){
					// n IS EMPTY
					$bResult = $isEmpty;
				
				}elseif( $actualOperator == '<=' ){
					// NULL <= 13 ... always true! ( pos == 1 )
					// 13 <= NULL ... false or true if empty ( pos == 0 )
					$bResult = $pos == 1 ? true : $isEmpty;
				
				}elseif( $actualOperator == '<' ){ 	
					// NULL < 13 ... always true! ( pos == 1 )
					// 13 < NULL ...  always false! ( pos == 0 )
					$bResult = $pos;
				
				}elseif( $actualOperator == '>' ){
					// NULL > 13 ... always false! ( pos == 1 )
					// 13 > NULL ...  true or false if empty ( pos == 0 )
					$bResult = $pos == 1 ? false : $isEmpty==false ;
				}
				
		}elseif( $ixKeyword == 3 ){ // NUMERIC?
				
				$isNumeric = is_numeric($operand1);
				
				if( $actualOperator == '==' || $actualOperator == 'IS' ){
					// mixVar [ IS | == ] NUMERIC 
					$bResult = $isNumeric ;
					
				}elseif( $actualOperator == '!=' || $actualOperator == 'NOT' ){
					// mixVar [ NOT | != ] NUMERIC 
					$bResult = $isNumeric ? false : true;
				}
		}
		
		return $bResult;
	}
	
    /**
     *  part_kurs_x2dbNam
     *  used by BuildXmlKurs()
     *
     *  unfortunately the tables in db has different names than in xml affored
     *  tranlsate kategorien to k_kategorien and termine to d_lektionen and so on ...
     *
     * @param string $xmlTablename
     * @return string
     */
	Protected function part_kurs_x2dbNam( $xmlTablename )
	{
			$xml2dbName = $this->settings['export']['mapXmlToDbTablenames'];
			return isset($xml2dbName[ $xmlTablename ]) ? $xml2dbName[ $xmlTablename ]: $xmlTablename;
	}
	
    /**
     *  RenderExportMethod
     *  to use as standalone from external
     *  
     *  get value from a specified fieldname OR get the result from a function
     *
     * @param string $strFieldContent
     * @return string
     */
	Public function RenderExportMethod( $strFieldContent )
	{
			$this->progress = [];
			// something went wrong, return incomed value
			if( is_array($strFieldContent) ) return $strFieldContent;
			
			// extract fieldname
			$aTabFld = explode( '.' , $strFieldContent );
			$this->progress['table'] = trim($aTabFld[0]);
			
			if( 'functions' != trim($aTabFld[0]) ) return $strFieldContent;
			
			// value contains the name of a function
			$aMxParam = explode( '|' , $strFieldContent );
			$aFunctName = array_shift( $aMxParam );
			$strMixParam = implode( '|' , $aMxParam );
			$aFunct = explode( '.' , trim( $aFunctName ) );
			$method = 'export_' . trim( $aFunct[1] );
			$this->progress['field'] = $method;
			if( method_exists( $this , $method ) ){
				// execute method and return result
				return $this->$method( $strMixParam );
			}
			// return incomed value
			return $strFieldContent;
			
			// if failed return incomed value
			
	}

	
    /**
     *  renderDataField
     *  used by BuildXmlKurs()
     *  used by BuildXmlMetadaten()
     *  used by BuildXmlKategorie()
     *  
     *  get value from a specified fieldname OR get the result from a function
     *
     * @param string $strFieldContent
     * @return string
     */
	Protected function renderDataField( $strFieldContent )
	{
			$this->progress = [];
			// something went wrong, return incomed value
			if( is_array($strFieldContent) ) return $strFieldContent;
			
			// extract fieldname
			$aTabFld = explode( '.' , $strFieldContent );
			$this->progress['table'] = trim($aTabFld[0]);
			
			if( 'functions' == trim($aTabFld[0]) ){
				// value contains the name of a function
				$aMxParam = explode( '|' , $strFieldContent );
				$aFunctName = array_shift( $aMxParam );
				$strMixParam = implode( '|' , $aMxParam );
				$aFunct = explode( '.' , trim( $aFunctName ) );
				$method = 'export_' . trim( $aFunct[1] );
				$this->progress['field'] = $method;
				if( method_exists( $this , $method ) ){
					// execute method and return result
					$strFromFunct = $this->$method( $strMixParam );
					return strlen($strFromFunct) ? $strFromFunct : '' ;
				}
				// return incomed value
				return strlen($strFieldContent) ? $strFieldContent : '';
				
			}elseif( 2 == count( $aTabFld ) ){
				// get value from database-table
				$this->progress['field'] = trim($aTabFld[1]);
				$strFromDb = $this->dbStatic[ trim($aTabFld[0]) ][ trim($aTabFld[1]) ];
				return strlen($strFromDb) ? $strFromDb : '' ;
			}
			
			// if failed return incomed value
			return strlen($strFieldContent) ? $strFieldContent : '';
	}

	
    /**
     *  postRenderDataField
     *  used by BuildXmlKurs()
     *  
     *  get value from a specified fieldname OR get the result from a function
     *
     * @param string $strFieldContent
     * @return string
     */
	Protected function postRenderDataField( $strFieldContent )
	{
		 
		if( !isset($this->progress['table']) || !isset($this->progress['field']) ) return $strFieldContent;
		
		if( 
			$this->progress['table'] == 'functions' &&
			isset($this->settings['export']['mapDataTypes']['functionsFieldtype'][ $this->progress['field'] ])
		) {
				$dbDataType = $this->settings['export']['mapDataTypes']['functionsFieldtype'][ $this->progress['field'] ];
		}else{
				$dbDataType = $this->settingsUtility->getDbFieldType( $this->progress['table'] , $this->progress['field'] );
		}
		
		if( empty( $dbDataType ) ) return $strFieldContent;
		if( !isset($this->settings['export']['mapDataTypes']['fieldtypes'][ $dbDataType ]) ) return $strFieldContent;
		
		$function = 'postrender_' . $this->settings['export']['mapDataTypes']['fieldtypes'][ $dbDataType ]['renderFunct'];
		
		if( method_exists( $this , $function ) ) return $this->$function( $strFieldContent );
		
		return $strFieldContent;
		
	}
	
}
