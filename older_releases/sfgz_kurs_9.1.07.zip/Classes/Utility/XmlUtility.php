<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/** 
 * Class ExportUtility
 * 
 * 
 */
 
class XmlUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * array settings
	 */
	protected $settings = null;

	/**
	 * array usetags
	 */
	protected $usetags = null;

	/**
	 * array dbData
	 */
	protected $dbData = null;

	/**
	 * array xmlData
	 */
	protected $xmlData = null;

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_lst';
	
	/**
	 * Property aHtmlReplace
	 *
	 * @var array
	 */
	protected $aHtmlReplace = [
		'linebreak' => [
							'<br>'=>"\n" , 
							'<br />'=>"\n" , 
							'<p>'=>'' , 
							'</p>'=>"\n"
					],
		'old_linebreak' => [ 
							'<br>'=>"\n" , 
							'<br />'=>"\n"
					],
		'double_linebreak' => [ 
							'<br></p>'=>'</p>'
					],
		'search'=> [ 
							'&' , 
							'<' , 
							'>' , 
							"'" , 
							'"'
					],
		'replace'=> [ 
							'&amp;', 
							'&lt;', 
							'&gt;', 
							'&apos;', 
							'&quot;'
					]
	];

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
			$this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
			$this->databaseReaderUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\DatabaseReaderUtility');
			$this->filetransferUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\FiletransferUtility');
			$this->exportUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ExportUtility');
		    $this->settings = $this->settingsUtility->getSettings( $this->pluginKey );
	}
	
    /**
     *  ViewActualExportFile
     *  used by View ExportXML with $tagSetting = xml
     *       to export todays data from json-file as XML-Document
     *  used by View ListXML with $tagSetting = html
     *       to display date-specific data from json-file as HTML-formatted xml-document
     *
     * @param string $datestring date Y-m-d
     * @param int $tagSetting optional, [ xml | html ] default = xml
     * @return array
     */
	Public function ViewActualExportFile( $datestring = '' , $tagSetting = 'xml' )
	{
			$this->usetags = $this->settings['export']['tags'][$tagSetting];
			
			if( $this->usetags['tab_space'] == 't' ){
				$this->usetags['tab_space'] = "\t";
			}elseif( is_numeric( $this->usetags['tab_space'] ) ){
				$this->usetags['tab_space'] = str_repeat( ' ' , $this->usetags['tab_space'] );
			}
			
			if( $this->usetags['line_end'] == 'n' ){
				$this->usetags['line_end'] = "\n";
			}elseif( $this->usetags['line_end'] == 'nr' ){
				$this->usetags['line_end'] = "\n\r";
			}elseif( $this->usetags['line_end'] == 'rn' ){
				$this->usetags['line_end'] = "\r\n";
			}elseif( $this->usetags['line_end'] == 'r' ){
				$this->usetags['line_end'] = "\r";
			}

			$aFileInfo = $this->getActualFileInfo( $datestring );
			if( !$aFileInfo['filename'] )  return 'noFileForDate_' . $datestring;
			
			$dbData = $this->exportUtility->ReadExportFile( $aFileInfo['filename'] );
			if( !is_array($dbData) ) return 'noArrayInFile_' . $aFileInfo['filename'];
			
			$strOut = '';
			foreach( $dbData as $ix => $sectRow ){ 
				$strOut .=  $this->loop_node( $dbData , 1 , $ix ); 
			}
			
			$dn = pathinfo( $aFileInfo['filename'] , PATHINFO_BASENAME );
			$dokunameY = substr( $dn , 0 , 4);
			$dokunameM = substr( $dn , 4 , 2);
			$dokunameD = substr( $dn , 6 , 2);
			
			$stichtag = $this->exportUtility->getStichtag();
			
			$rep['_DATE_NOW_'] = $stichtag.' '.date( 'H:i:s' );
			
			$rep['_DATE_DOKU_'] = date( 'Y-m-d H:i:s' , $aFileInfo['time'] );
			$rep['_DATE_DOKUNAME_'] =  $dokunameY . '-' . $dokunameM . '-' . $dokunameD . ' ' . date( 'H:i:s' , $aFileInfo['time'] );
			
			$out = $this->settings['export']['xmlDocuHeader'];
			
			$out .= $this->usetags['line_end'];
			
			$out .= str_replace( array_keys($rep) , $rep , $this->settings['export']['xmlDocuDef']['start'] );
			
			$out .= $this->usetags['line_end'];
			
			$out .= $strOut;
			
			$out .= $this->settings['export']['xmlDocuDef']['end'];
			
			return $out;
	}

	/**
	 * xmlEscape
	 * transform html-tags and special chars to xml-tags
	 * Xml-Documents do not like & and <br> linebreak-tags
	 *
	 * @param string $value
	 * @return string
	 */
	function xmlEscape($string) {
//		$string = str_replace( array_keys($this->aHtmlReplace['linebreak']) , $this->aHtmlReplace['linebreak'] , $string );
 		//$string = rtrim( ltrim( trim($string) , '<p>' ) , '</p>' );
 		$string = str_replace( array_keys($this->aHtmlReplace['double_linebreak']) , $this->aHtmlReplace['double_linebreak'] , $string );
 		$string = str_replace( $this->aHtmlReplace['search'] , $this->aHtmlReplace['replace'] , $string );
 		return $string;
	}
    /**
     *  DebugActualExportFile
     *  used by Controller Kurs->exportAction()
     *
     * @param string $filename
     * @return array
     */
	Public function DebugActualExportFile( $filename )
	{
			$dbData = $this->exportUtility->ReadExportFile( $filename );

			$outData = [];
			foreach( $dbData as $ix => $sectRow ){ 
				$outData[$ix] =  $this->debug_loop_node( $dbData , 1 , $ix ); 
			}
			
			return $outData;
	}
	
    /**
     *  getActualFileInfo
     *
     * @param string $datestring date Y-m-d
     * @return array
     */
	private function getActualFileInfo( $datestring = '' )
	{
			if( !$datestring ) $datestring = date('Y-m-d');
			$dateObject = new \DateTime( $datestring );
			$localDateObject = $this->databaseReaderUtility->dateUtility->sanitizeDateTime( $dateObject );
			$aFiles = $this->exportUtility->GetExportFiles( $localDateObject->format('Y-m-d') );
			if( !is_array($aFiles) )  return false;
			
			// date must be english! Stichtag is used for live-functions
			$this->exportUtility->setStichtag( $localDateObject->format('Y-m-d') );
			
			foreach($aFiles as $fix => $aFileInfo ){
				if( $aFileInfo['css'] == 'bulbon' ){
					return $aFileInfo;
					break;
				}
			}
			return false;
	}
	
    /**
     *  loop_node
     *
     * @param array $aRow
     * @param int $dim
     * @param str $ix
     * @return string
     */
	private function loop_node( $aRow , $dim=0 , $ix )
	{
		$strOut = '';
		
		$tabSpace = $dim ? str_repeat( $this->usetags['tab_space'] , $dim ) : '' ;
		
		if( is_numeric($ix) ){
			// $ix = [0]. detect name and attributes, then write as a tag and  render 'node' if exists, otherwise 'data'
			$strOut .= $this->loop_recordset( $aRow[$ix] , $dim );
		}else{
			// $ix = enumaeratoren. write as a tag. dont look for attributes. Then re-run method with content.
			$strOut .= $tabSpace.$this->usetags['open_starttag'].$ix.$this->usetags['close_tag'] . $this->usetags['line_end'];
			foreach( $aRow[$ix] as $six => $subRow ) {
				$strOut .= $this->loop_node( $aRow[$ix] , $dim+1 , $six );
			}
			$strOut .=  $tabSpace.$this->usetags['open_endtag'].$ix.$this->usetags['close_tag'] . $this->usetags['line_end'];
		}
		return $strOut;
		
	}
	
    /**
     *  loop_recordset
     *
     * @param array $sectRow
     * @param int $dim
     * @return string
     */
	private function loop_recordset( $sectRow , $dim )
	{
		// define tab-spaces
		$tabSpace = $dim ? str_repeat(  $this->usetags['tab_space'] , $dim ) : '' ;
		
		// define DATA from [data] or [node]
		
		
		// return value from a specified fieldname OR the result from a function
		if( isset( $sectRow['data'] ) ) {
			// if there is data, then this is a value-field 
			// and there is no node... but there may be attributes eg. 
			//     <kategorie id="6" parent-id="1">Dominokurse</kategorie> 
			$strOut = $this->exportUtility->RenderExportMethod(trim($sectRow['data']));
			$strOut = $this->xmlEscape($strOut);
		}elseif( !is_array( $sectRow['node'] ) ){
			// eror handling if no data nor node exists
			$strOut = ' typo3-Kursverwaltung: noNodeData? ';
		
		}else{
			// loop through children data, 
			// could be node (deeper table) or field-definition
			$strOut = $this->usetags['line_end'];
			foreach( $sectRow['node'] as $fieldname => $fldCont ){
					if( is_array($fldCont) ){
						$strOut .= $this->loop_node( $sectRow['node'] , $dim+1 , $fieldname );
					}else{
						$subCnt = $this->exportUtility->RenderExportMethod(trim($fldCont));
						if( strlen($subCnt) > 0 ){
							$strOut .= $tabSpace . $this->usetags['tab_space'] . $this->usetags['open_starttag'] . $fieldname . $this->usetags['close_tag'];
							$strOut .= $this->xmlEscape($subCnt);
							$strOut .=  $this->usetags['open_endtag'] . $fieldname . $this->usetags['close_tag']. $this->usetags['line_end'];
						}else{
							$strOut .= $tabSpace . $this->usetags['tab_space'] . $this->usetags['open_starttag'] . $fieldname . ' /' . $this->usetags['close_tag']. $this->usetags['line_end'];
						}
					}
			}
			$strOut .= $tabSpace;
		}
		
		// define TAG
		$tagname = $sectRow['attr']['nodename'];
		
		if( !strlen($strOut) ) return $this->usetags['open_starttag']  . $tagname . ' /' . $this->usetags['close_tag'] . $this->usetags['line_end'];
		
		// open Start tag and append attributes to the part of the tag if defined
		$startTag = $tabSpace . $this->usetags['open_starttag'] . $tagname ;
		foreach($sectRow['attr'] as $attNam => $attVal ) {
			if($attNam != 'nodename' ) $startTag .= ' ' . $attNam . '="'.$attVal.'"';
		}
		// close the Start tag
		$startTag .= $this->usetags['close_tag'];
		
		// open and close the End tag and append line-break to it
		$endTag = $this->usetags['open_endtag']  . $tagname . $this->usetags['close_tag'] . $this->usetags['line_end'];
		
		// return tagged data
		return $startTag . $strOut . $endTag;
	}


    /**
     *  debug_loop_node
     *
     * @param array $aRow
     * @param int $dim
     * @param str $ix
     * @return array
     */
	private function debug_loop_node( $aRow , $dim=0 , $ix )
	{
		$outData = [];
		
		if( is_numeric($ix) ){
			// $ix = [0]. detect name and attributes, then write as a tag and  render 'node' if exists, otherwise 'data'
			$outData = $this->debug_loop_recordset( $aRow[$ix] , $dim , $outData );
		}else{
			// $ix = enumaeratoren. write as a tag. dont look for attributes. Then re-run method with content.
			foreach( $aRow[$ix] as $six => $subRow ) {
				if( is_numeric($six) ){
					$outData = $this->debug_loop_recordset( $subRow , $dim , $outData );
				}else{
					$outData[$six] = $this->debug_loop_node( $aRow[$ix] , $dim+1 , $six );
				}
			}
		}
		return $outData;
		
	}
	
    /**
     *  debug_loop_recordset
     *
     * @param array $sectRow
     * @param int $dim
     * @param array $outData
     * @return array
     */
	private function debug_loop_recordset( $sectRow , $dim , $outData )
	{
		
		$aAttr = $sectRow['attr'];
		$aNode = $sectRow['node'];
		$tagname = $sectRow['attr']['nodename'];
		
		$nodeSuffix = $this->settings['export']['debugNodeSuffix'][ $sectRow['attr']['nodename'] ];
		if( $nodeSuffix ) {
			$tagname = $sectRow['attr']['nodename'] . '_' . $aNode[ $nodeSuffix ];
		}else{
			if( $aAttr['parent-id'] ) $tagname .= '_' . $aAttr['parent-id'];
			if( $aAttr['id'] ) $tagname .= ( $aAttr['parent-id'] ? '.' : '_' ) . $aAttr['id'];
			if( strlen($aAttr['wert']) ) $tagname .= '_' . $aAttr['wert'];
			if( $aAttr['name'] ) $tagname .= '_' . $aAttr['name'];
		}
		
		if( isset( $sectRow['data'] ) ) {
			$outData[$tagname] = $sectRow['data'];
			return $outData;
		}
		
		// eror handling if no data nor node exists
		if( !is_array( $aNode ) ) return $openTag . ' typo3-Kursverwaltung: noNodeData? ' . $closeTag;
		
		
		foreach( $aNode as $fieldname => $fldCont ){
				if( is_array($fldCont) ){
					if( is_numeric($fieldname) ){
						$outData[$tagname] = $this->debug_loop_recordset( $fldCont , $dim , $outData[$tagname] );
					}else{
							$aRes = $this->debug_loop_node( $aNode , $dim+1 , $fieldname );
							foreach( $aRes as $i => $r ) $outData[$tagname][$i] = $r;
					}
				}else{
					$outData[$tagname][$fieldname] = trim($fldCont) ;
				}
		}

		return $outData;
	}
	

}
