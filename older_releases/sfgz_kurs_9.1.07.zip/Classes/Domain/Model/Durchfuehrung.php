<?php
namespace Sfgz\SfgzKurs\Domain\Model;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Durchfuehrung
 */
class Durchfuehrung extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * version
     *
     * @var int
     */
    protected $version = 0;

    /**
     * durchfuehrungsCode
     * zB. HS18
     *
     * @var string
	 * @validate NotEmpty
     */
    protected $durchfuehrungsCode = '';

    /**
     * codeSuffix
     * zB. A
     *
     * @var string
     */
    protected $codeSuffix = '';

    /**
     * durchfuehrungStart
     *
     * @var \DateTime
     */
    protected $durchfuehrungStart = null;

    /**
     * durchfuehrungEnde
     *
     * @var \DateTime
     */
    protected $durchfuehrungEnde = null;

    /**
     * publikationStart
     *
     * @var \DateTime
     */
    protected $publikationStart = null;

    /**
     * publikationEnde
     *
     * @var \DateTime
     */
    protected $publikationEnde = null;

    /**
     * Datumsangaben
     *
     * @var string
     */
    protected $anmerkung = '';

    /**
     * terminAusblenden
     *
     * @var int
     */
    protected $terminAusblenden = 0;

    /**
     * kurskosten
     *
     * @var int
     */
    protected $kurskosten = 0;

    /**
     * kostenLernende
     *
     * @var int
     */
    protected $kostenLernende = 0;

    /**
     * kostenExtern
     *
     * @var int
     */
    protected $kostenExtern = 0;

    /**
     * 0:geplant, 1:FindetStatt, 2:Abgesagt, 3: Ausgebucht
     *
     * @var int
     */
    protected $status = 0;

    /**
     * Lektionenzahl Total
     *
     * @var string
     */
    protected $lektionen = '';

    /**
     * maxteilnehmer
     *
     * @var int
     */
    protected $maxteilnehmer = 0;

    /**
     * anmeldeschluss
     *
     * @var \DateTime
     */
    protected $anmeldeschluss = null;

    /**
     * ecoMandant
     *
     * @var string
     */
    protected $ecoMandant = '';

    /**
     * ecoAngebotid
     *
     * @var string
     */
    protected $ecoAngebotid = '';

    /**
     * ecoFachid
     *
     * @var string
     */
    protected $ecoFachid = '';

    /**
     * veranstaltungen
     *
     * @var int
     */
    protected $veranstaltungen = 0;

    /**
     * periodika
     * 0:Taeglich 1:JedeWoche 2:Jede2Woche
     *
     * @var int
     */
    protected $periodika = 1;

    /**
     * terminStart
     *
     * @var \DateTime
     */
    protected $terminStart = null;

    /**
     * terminEnde
     *
     * @var \DateTime
     */
    protected $terminEnde = null;

    /**
     * zeitVon
     *
     * @var string
     */
    protected $zeitVon = '';

    /**
     * zeitBis
     *
     * @var string
     */
    protected $zeitBis = '';

    /**
     * ort
     *
     * @var string
     */
    protected $ort = '';

    /**
     * zimmer
     *
     * @var string
     */
    protected $zimmer = '';

    /**
     * lehrerEcoId
     *
     * @var string
     */
    protected $lehrerEcoId = '';

    /**
     * lehrpersonText
     *
     * @var string
     */
    protected $lehrpersonText = '';

    /**
     * lehrpersonNachname
     *
     * @var string
     */
    protected $lehrpersonNachname = '';

    /**
     * lehrpersonVorname
     *
     * @var string
     */
    protected $lehrpersonVorname = '';

    /**
     * tstamp
     *
     * @var int
     */
    protected $tstamp = 0;

    /**
     * dLektionen
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Lektion>
     * @cascade remove
     */
    protected $dLektionen = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->dLektionen = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the version
     *
     * @return int $version
     */
    public function getVersion()
    {
        return $this->version;
    }

    /**
     * Sets the version
     *
     * @param int $version
     * @return void
     */
    public function setVersion($version)
    {
        $this->version = $version;
    }

    /**
     * Returns the durchfuehrungsCode
     *
     * @return string $durchfuehrungsCode
     */
    public function getDurchfuehrungsCode()
    {
        return $this->durchfuehrungsCode;
    }

    /**
     * Sets the durchfuehrungsCode
     *
     * @param string $durchfuehrungsCode
     * @return void
     */
    public function setDurchfuehrungsCode($durchfuehrungsCode)
    {
        $this->durchfuehrungsCode = $durchfuehrungsCode;
    }

    /**
     * Returns the codeSuffix
     *
     * @return string $codeSuffix
     */
    public function getCodeSuffix()
    {
        return $this->codeSuffix;
    }

    /**
     * Sets the codeSuffix
     *
     * @param string $codeSuffix
     * @return void
     */
    public function setCodeSuffix($codeSuffix)
    {
        $this->codeSuffix = $codeSuffix;
    }

    /**
     * Returns the durchfuehrungStart
     *
     * @return \DateTime $durchfuehrungStart
     */
    public function getDurchfuehrungStart()
    {
        return $this->durchfuehrungStart;
    }

    /**
     * Sets the durchfuehrungStart
     *
     * @param \DateTime $durchfuehrungStart
     * @return void
     */
    public function setDurchfuehrungStart($durchfuehrungStart)
    {
        $this->durchfuehrungStart = $durchfuehrungStart;
    }

    /**
     * Returns the durchfuehrungEnde
     *
     * @return \DateTime $durchfuehrungEnde
     */
    public function getDurchfuehrungEnde()
    {
        return $this->durchfuehrungEnde;
    }

    /**
     * Sets the durchfuehrungEnde
     *
     * @param \DateTime $durchfuehrungEnde
     * @return void
     */
    public function setDurchfuehrungEnde($durchfuehrungEnde)
    {
        $this->durchfuehrungEnde = $durchfuehrungEnde;
    }

    /**
     * Returns the publikationStart
     *
     * @return \DateTime $publikationStart
     */
    public function getPublikationStart()
    {
        return $this->publikationStart;
    }

    /**
     * Sets the publikationStart
     *
     * @param \DateTime $publikationStart
     * @return void
     */
    public function setPublikationStart($publikationStart)
    {
        $this->publikationStart = $publikationStart;
    }

    /**
     * Returns the publikationEnde
     *
     * @return \DateTime $publikationEnde
     */
    public function getPublikationEnde()
    {
        return $this->publikationEnde;
    }

    /**
     * Sets the publikationEnde
     *
     * @param \DateTime $publikationEnde
     * @return void
     */
    public function setPublikationEnde( $publikationEnde )
    {
        $this->publikationEnde = $publikationEnde;
    }

    /**
     * Returns the anmerkung
     *
     * @return string $anmerkung
     */
    public function getAnmerkung()
    {
        return $this->anmerkung;
    }

    /**
     * Sets the anmerkung
     *
     * @param string $anmerkung
     * @return void
     */
    public function setAnmerkung($anmerkung)
    {
        $this->anmerkung = $anmerkung;
    }

    /**
     * Returns the terminAusblenden
     *
     * @return string $terminAusblenden
     */
    public function getTerminAusblenden()
    {
        return $this->terminAusblenden;
    }

    /**
     * Sets the terminAusblenden
     *
     * @param string $terminAusblenden
     * @return void
     */
    public function setTerminAusblenden($terminAusblenden)
    {
        $this->terminAusblenden = $terminAusblenden;
    }

    /**
     * Returns the kurskosten
     *
     * @return int $kurskosten
     */
    public function getKurskosten()
    {
        return $this->kurskosten;
    }

    /**
     * Sets the kurskosten
     *
     * @param int $kurskosten
     * @return void
     */
    public function setKurskosten($kurskosten)
    {
        $this->kurskosten = $kurskosten;
    }

    /**
     * Returns the kostenLernende
     *
     * @return int $kostenLernende
     */
    public function getKostenLernende()
    {
        return $this->kostenLernende;
    }

    /**
     * Sets the kostenLernende
     *
     * @param int $kostenLernende
     * @return void
     */
    public function setKostenLernende($kostenLernende)
    {
        $this->kostenLernende = $kostenLernende;
    }

    /**
     * Returns the kostenExtern
     *
     * @return int $kostenExtern
     */
    public function getKostenExtern()
    {
        return $this->kostenExtern;
    }

    /**
     * Sets the kostenExtern
     *
     * @param int $kostenExtern
     * @return void
     */
    public function setKostenExtern($kostenExtern)
    {
        $this->kostenExtern = $kostenExtern;
    }

    /**
     * Returns the status
     *
     * @return int $status
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Sets the status
     *
     * @param int $status
     * @return void
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * Returns the lektionen
     *
     * @return int $lektionen
     */
    public function getLektionen()
    {
        return $this->lektionen;
    }

    /**
     * Sets the lektionen
     *
     * @param int $lektionen
     * @return void
     */
    public function setLektionen($lektionen)
    {
        $this->lektionen = $lektionen;
    }

    /**
     * Returns the maxteilnehmer
     *
     * @return int $maxteilnehmer
     */
    public function getMaxteilnehmer()
    {
        return $this->maxteilnehmer;
    }

    /**
     * Sets the maxteilnehmer
     *
     * @param int $maxteilnehmer
     * @return void
     */
    public function setMaxteilnehmer($maxteilnehmer)
    {
        $this->maxteilnehmer = $maxteilnehmer;
    }

    /**
     * Returns the anmeldeschluss
     *
     * @return \DateTime $anmeldeschluss
     */
    public function getAnmeldeschluss()
    {
        return $this->anmeldeschluss;
    }

    /**
     * Sets the anmeldeschluss
     *
     * @param \DateTime $anmeldeschluss
     * @return void
     */
    public function setAnmeldeschluss( $anmeldeschluss )
    {
        $this->anmeldeschluss = $anmeldeschluss;
    }

    /**
     * Returns the ecoMandant
     *
     * @return string $ecoMandant
     */
    public function getEcoMandant()
    {
        return $this->ecoMandant;
    }

    /**
     * Sets the ecoMandant
     *
     * @param string $ecoMandant
     * @return void
     */
    public function setEcoMandant($ecoMandant)
    {
        $this->ecoMandant = $ecoMandant;
    }

    /**
     * Returns the ecoAngebotid
     *
     * @return string $ecoAngebotid
     */
    public function getEcoAngebotid()
    {
        return $this->ecoAngebotid;
    }

    /**
     * Sets the ecoAngebotid
     *
     * @param string $ecoAngebotid
     * @return void
     */
    public function setEcoAngebotid($ecoAngebotid)
    {
        $this->ecoAngebotid = $ecoAngebotid;
    }

    /**
     * Returns the ecoFachid
     *
     * @return string $ecoFachid
     */
    public function getEcoFachid()
    {
        return $this->ecoFachid;
    }

    /**
     * Sets the ecoFachid
     *
     * @param string $ecoFachid
     * @return void
     */
    public function setEcoFachid($ecoFachid)
    {
        $this->ecoFachid = $ecoFachid;
    }

    /**
     * Returns the veranstaltungen
     *
     * @return int $veranstaltungen
     */
    public function getVeranstaltungen()
    {
        return $this->veranstaltungen;
    }

    /**
     * Sets the veranstaltungen
     *
     * @param int $veranstaltungen
     * @return void
     */
    public function setVeranstaltungen($veranstaltungen)
    {
        $this->veranstaltungen = $veranstaltungen;
    }

    /**
     * Returns the periodika
     *
     * @return int $periodika
     */
    public function getPeriodika()
    {
        return $this->periodika;
    }

    /**
     * Sets the periodika
     *
     * @param int $periodika
     * @return void
     */
    public function setPeriodika($periodika)
    {
        $this->periodika = $periodika;
    }

    /**
     * Returns the terminStart
     *
     * @return \DateTime $terminStart
     */
    public function getTerminStart()
    {
        return $this->terminStart;
    }

    /**
     * Sets the terminStart
     *
     * @param \DateTime $terminStart
     * @return void
     */
    public function setTerminStart(\DateTime $terminStart)
    {
        $this->terminStart = $terminStart;
    }

    /**
     * Returns the terminEnde
     *
     * @return \DateTime $terminEnde
     */
    public function getTerminEnde()
    {
        return $this->terminEnde;
    }

    /**
     * Sets the terminEnde
     *
     * @param \DateTime $terminEnde
     * @return void
     */
    public function setTerminEnde(\DateTime $terminEnde)
    {
        $this->terminEnde = $terminEnde;
    }

    /**
     * Returns the zeitVon
     *
     * @return string $zeitVon
     */
    public function getZeitVon()
    {
        return $this->zeitVon;
    }

    /**
     * Sets the zeitVon
     *
     * @param string $zeitVon
     * @return void
     */
    public function setZeitVon($zeitVon)
    {
        $this->zeitVon = str_replace( '.' , ':' , $zeitVon );
    }

    /**
     * Returns the zeitBis
     *
     * @return string $zeitBis
     */
    public function getZeitBis()
    {
        return $this->zeitBis;
    }

    /**
     * Sets the zeitBis
     *
     * @param string $zeitBis
     * @return void
     */
    public function setZeitBis($zeitBis)
    {
        $this->zeitBis = str_replace( '.' , ':' , $zeitBis );
    }

    /**
     * Returns the ort
     *
     * @return string $ort
     */
    public function getOrt()
    {
        return $this->ort;
    }

    /**
     * Sets the ort
     *
     * @param string $ort
     * @return void
     */
    public function setOrt($ort)
    {
        $this->ort = $ort;
    }

    /**
     * Returns the zimmer
     *
     * @return string $zimmer
     */
    public function getZimmer()
    {
        return $this->zimmer;
    }

    /**
     * Sets the zimmer
     *
     * @param string $zimmer
     * @return void
     */
    public function setZimmer($zimmer)
    {
        $this->zimmer = $zimmer;
    }

    /**
     * Returns the lehrerEcoId
     *
     * @return string $lehrerEcoId
     */
    public function getLehrerEcoId()
    {
        return $this->lehrerEcoId;
    }

    /**
     * Sets the lehrerEcoId
     *
     * @param string $lehrerEcoId
     * @return void
     */
    public function setLehrerEcoId($lehrerEcoId)
    {
        $this->lehrerEcoId = $lehrerEcoId;
    }

    /**
     * Returns the lehrpersonText
     *
     * @return string $lehrpersonText
     */
    public function getLehrpersonText()
    {
        return $this->lehrpersonText;
    }

    /**
     * Sets the lehrpersonText
     *
     * @param string $lehrpersonText
     * @return void
     */
    public function setLehrpersonText($lehrpersonText)
    {
        $this->lehrpersonText = $lehrpersonText;
    }


    /**
     * Returns the lehrpersonNachname
     *
     * @return string $lehrpersonNachname
     */
    public function getLehrpersonNachname()
    {
        return $this->lehrpersonNachname;
    }

    /**
     * Sets the lehrpersonNachname
     *
     * @param string $lehrpersonNachname
     * @return void
     */
    public function setLehrpersonNachname($lehrpersonNachname)
    {
        $this->lehrpersonNachname = $lehrpersonNachname;
    }

    /**
     * Returns the lehrpersonVorname
     *
     * @return string $lehrpersonVorname
     */
    public function getLehrpersonVorname()
    {
        return $this->lehrpersonVorname;
    }

    /**
     * Sets the lehrpersonVorname
     *
     * @param string $lehrpersonVorname
     * @return void
     */
    public function setLehrpersonVorname($lehrpersonVorname)
    {
        $this->lehrpersonVorname = $lehrpersonVorname;
    }


    /**
     * Returns the tstamp
     *
     * @return int $tstamp
     */
    public function getTstamp()
    {
        return $this->tstamp;
    }

    /**
     * Sets the tstamp
     *
     * @param int $tstamp
     * @return void
     */
    public function setTstamp($tstamp)
    {
        $this->tstamp = $tstamp;
    }

    /**
     * Adds a Lektion
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Lektion $dLektionen
     * @return void
     */
    public function addDLektionen(\Sfgz\SfgzKurs\Domain\Model\Lektion $dLektionen)
    {
        $this->dLektionen->attach($dLektionen);
    }

    /**
     * Removes a Lektion
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Lektion $dLektionenToRemove The Lektion to be removed
     * @return void
     */
    public function removeDLektionen(\Sfgz\SfgzKurs\Domain\Model\Lektion $dLektionenToRemove)
    {
        $this->dLektionen->detach($dLektionenToRemove);
    }

    /**
     * Returns the dLektionen
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Lektion> $dLektionen
     */
    public function getDLektionen()
    {
        return $this->dLektionen;
    }

    /**
     * Sets the dLektionen
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Lektion> $dLektionen
     * @return void
     */
    public function setDLektionen(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $dLektionen)
    {
        $this->dLektionen = $dLektionen;
    }
    

}
