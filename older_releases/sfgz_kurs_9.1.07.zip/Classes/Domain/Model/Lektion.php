<?php
namespace Sfgz\SfgzKurs\Domain\Model;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Lektion
 */
class Lektion extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * durchfuehrung
     *
     * @var int
     */
    protected $durchfuehrung = 0;

    /**
     * lektionenzahl
     *
     * @var int
     */
    protected $lektionenzahl = 0;

    /**
     * lektionDatum
     *
     * @var \DateTime
     */
    protected $lektionDatum = null;

    /**
     * zeitVon
     *
     * @var string
     */
    protected $zeitVon = '';

    /**
     * zeitBis
     *
     * @var string
     */
    protected $zeitBis = '';

    /**
     * ort
     *
     * @var string
     */
    protected $ort = '';

    /**
     * zimmer
     *
     * @var string
     */
    protected $zimmer = '';

    /**
     * lehrerEcoId
     *
     * @var string
     */
    protected $lehrerEcoId = '';

    /**
     * lehrpersonText
     *
     * @var string
     */
    protected $lehrpersonText = '';

    /**
     * Returns the durchfuehrung
     *
     * @return int $durchfuehrung
     */
    public function getDurchfuehrung()
    {
        return $this->durchfuehrung;
    }

    /**
     * Sets the durchfuehrung
     *
     * @param int $durchfuehrung
     * @return void
     */
    public function setDurchfuehrung($durchfuehrung)
    {
        $this->durchfuehrung = $durchfuehrung;
    }

    /**
     * Returns the lektionenzahl
     *
     * @return int $lektionenzahl
     */
    public function getLektionenzahl()
    {
        return $this->lektionenzahl;
    }

    /**
     * Sets the lektionenzahl
     *
     * @param int $lektionenzahl
     * @return void
     */
    public function setLektionenzahl($lektionenzahl)
    {
        $this->lektionenzahl = $lektionenzahl;
    }

    /**
     * Returns the lektionDatum
     *
     * @return \DateTime $lektionDatum
     */
    public function getLektionDatum()
    {
        return $this->lektionDatum;
    }

    /**
     * Sets the lektionDatum
     *
     * @param \DateTime $lektionDatum
     * @return void
     */
    public function setLektionDatum(\DateTime $lektionDatum)
    {
        $this->lektionDatum = $lektionDatum;
    }

    /**
     * Returns the zeitVon
     *
     * @return string $zeitVon
     */
    public function getZeitVon()
    {
        return $this->zeitVon;
    }

    /**
     * Sets the zeitVon
     *
     * @param string $zeitVon
     * @return void
     */
    public function setZeitVon($zeitVon)
    {
        $this->zeitVon = str_replace( '.' , ':' , $zeitVon );
    }

    /**
     * Returns the zeitBis
     *
     * @return string $zeitBis
     */
    public function getZeitBis()
    {
        return $this->zeitBis;
    }

    /**
     * Sets the zeitBis
     *
     * @param string $zeitBis
     * @return void
     */
    public function setZeitBis($zeitBis)
    {
        $this->zeitBis = str_replace( '.' , ':' , $zeitBis );
    }

    /**
     * Returns the ort
     *
     * @return string $ort
     */
    public function getOrt()
    {
        return $this->ort;
    }

    /**
     * Sets the ort
     *
     * @param string $ort
     * @return void
     */
    public function setOrt($ort)
    {
        $this->ort = $ort;
    }

    /**
     * Returns the zimmer
     *
     * @return string $zimmer
     */
    public function getZimmer()
    {
        return $this->zimmer;
    }

    /**
     * Sets the zimmer
     *
     * @param string $zimmer
     * @return void
     */
    public function setZimmer($zimmer)
    {
        $this->zimmer = $zimmer;
    }

    /**
     * Returns the lehrerEcoId
     *
     * @return string $lehrerEcoId
     */
    public function getLehrerEcoId()
    {
        return $this->lehrerEcoId;
    }

    /**
     * Sets the lehrerEcoId
     *
     * @param string $lehrerEcoId
     * @return void
     */
    public function setLehrerEcoId($lehrerEcoId)
    {
        $this->lehrerEcoId = $lehrerEcoId;
    }

    /**
     * Returns the lehrpersonText
     *
     * @return string $lehrpersonText
     */
    public function getLehrpersonText()
    {
        return $this->lehrpersonText;
    }

    /**
     * Sets the lehrpersonText
     *
     * @param string $lehrpersonText
     * @return void
     */
    public function setLehrpersonText($lehrpersonText)
    {
        $this->lehrpersonText = $lehrpersonText;
    }
}
