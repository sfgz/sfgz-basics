<?php
namespace Sfgz\SfgzKurs\Domain\Validator;

class KursValidator extends \TYPO3\CMS\Extbase\Validation\Validator\AbstractValidator {
    /**
    * Object Manager
    * 
    * @var \TYPO3\CMS\Extbase\Object\ObjectManagerInterface
    * @inject
    */
    protected $objectManager;
    
    /**
    * Validates the given value
    * 
    * @param mixed $object
    * @return bool
	* @throws \TYPO3\CMS\Extbase\Validation\Exception\InvalidValidationOptionsException
    */
    protected function isValid($object){
		$repository = $this->objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\KursRepository');
		if (!$repository instanceof \TYPO3\CMS\Extbase\Persistence\RepositoryInterface) {
			throw new \TYPO3\CMS\Extbase\Validation\Exception\InvalidValidationOptionsException('The option "repository" must refer to a class implementing RepositoryInterface.', 1336499435);
		}
		
		$propValue = $object->getKursCode();
		$uidValue = $object->getUid();
		
		$query = $repository->createQuery();
		$numberOfResults = $query->matching(
		    $query->logicalAnd(
				$query->equals('kursCode', $propValue),
				$query->logicalNot(
					$query->equals('uid', $uidValue)
				)
			)
		)->count();
		
		if( $numberOfResults > 0 ){
		    $error = $this->objectManager->get(
			  'TYPO3\\CMS\\Extbase\\Validation\\Error',
			  'KursCode "' . $propValue . '" wird bereits verwendet.',
			  1528385087
		    );
		    $this->result->forProperty($propertyName)->addError($error);
		    return false;
		}
		return true;
	  
    }
}
