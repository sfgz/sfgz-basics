<?php
namespace Sfgz\SfgzKurs\Domain\Repository;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * The repository for Kurs
 */
class KursRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    /**
     * @var array
     */
    protected $defaultOrderings = array(
        'kurs_code' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
    );
	
	/**
	 * findConcatTablesByFach
	 * or find newest until given date (eg. actual valid version)
	 *
	 * @param int $ecoFachid
	 * @param int $versionUid optional
	 * @return void
	 */
	public function findConcatTablesByFach( $ecoFachid , $versionUid = 0)
	{
			$sqlStatement = 'SELECT tk.kurs_code, tv.titel, tv.version_start, durchfuehrungs_code, code_suffix, eco_fachid';
 			$sqlStatement.= ', termin_start, termin_ende, zeit_von, zeit_bis, lektionen';
 			$sqlStatement.= ', veranstaltungen, lehrperson_text, zimmer';
			$sqlStatement.= ' FROM tx_sfgzkurs_domain_model_durchfuehrung td';
			$sqlStatement.= ' JOIN tx_sfgzkurs_domain_model_version tv ON td.version = tv.uid';
			$sqlStatement.= ' JOIN tx_sfgzkurs_domain_model_kurs tk ON tv.kurs = tk.uid';
			$sqlStatement.= ' WHERE eco_fachid =' . $ecoFachid;
			if( $versionUid ) $sqlStatement.= ' AND tv.uid =' . $versionUid;
			$sqlStatement.= ' ORDER BY version_start DESC' ;
	      
	      // execute sql-statement
	      return $this->callSqlStatement( $sqlStatement . ';' );
	
	}
	
	/**
	 * dbInfo
	 * returns the field definitions of a table
	 *
	 * @param string $tablename fullname like 'tx_sfgzkurs_domain_model_kurs'
	 * @return void
	 */
	public function dbInfo( $tablename )
	{
	    return $this->callSqlStatement( 'SHOW FULL COLUMNS FROM ' . $tablename . ';' );
	}

	/**
	 * @param string $qryStatement
	 * @param boolean $ReturnRawQueryResult
	 * @return void
	 */
	public function callSqlStatement($qryStatement, $ReturnRawQueryResult = TRUE) {
		$Query = $this->createquery();
		$Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
		$Query->getQuerySettings()->setRespectStoragePage(FALSE);
		$Query->statement($qryStatement);
		return $Query->execute($ReturnRawQueryResult);
	}

}
