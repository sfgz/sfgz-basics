<?php
namespace Sfgz\SfgzKurs\View\Kurs;
use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class ListXML
 * Displays date-specific data from json-file as HTML-formatted xml-document
 * 
 * 
 */
 
class ListXML extends \TYPO3\CMS\Extbase\Mvc\View\AbstractView {
   public function render() {
		
		$this->xmlUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\XmlUtility');
		
		$reqFromList = GeneralUtility::_GET('tx_sfgzkurs_vw');
		$stichtag = $reqFromList['stichtag'] ? $reqFromList['stichtag']: date('Y-m-d');
		
		// content of date-specific xml-document from json-file with HTML-tags
		$debug = $this->xmlUtility->ViewActualExportFile( $stichtag , 'html' );
		// add html PRE-tags
		$out = '<pre>'. htmlentities( $debug ).'</pre>';
		
		return $out;
   }
}
