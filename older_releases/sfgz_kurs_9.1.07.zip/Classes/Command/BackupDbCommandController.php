<?php
namespace Sfgz\SfgzKurs\Command;

 /** 
 * Class BackupDbCommandController
 * 
 * 
 */
 
class BackupDbCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {

    /**
        * sfgzkurs_backupEmails_kurs
        *  additional field
        *
        * @var string
    */
    public $sfgzkurs_backupEmails_kurs;

    /**
        * sfgzkurs_backupEmails_display
        *  additional field
        *
        * @var string
    */
    public $sfgzkurs_backupEmails_display;

    public function execute(){
        
        $backupUtility = new \Sfgz\SfgzKurs\Utility\BackupUtility();
        
        $args['mailtos'] = [];

        foreach( [ 'sfgzkurs_backupEmails_kurs' , 'sfgzkurs_backupEmails_display' ] as $fieldname ){
            if( empty($this->$fieldname) ) continue;
            $aNameParts = explode( '_' , $fieldname );
            $groupname = array_pop($aNameParts);
            $aEmailadresses = explode( ',' , $this->$fieldname );
            foreach($aEmailadresses as $adr ) $args['mailtos'][ trim($adr) ][ $groupname ] = $groupname;
        }
//         $args['Footer'] = 'Sendet Mo-Fr jeden Tag um 19:10 eine Email.';
        $result = $backupUtility->runBackup($args);

        return $result;
        
    }
	
	public function getAdditionalInformation() {
		$meldung = 'Sendet SQL-Backup Dateien an Emailadressen.';
		return $meldung;
	}

}
