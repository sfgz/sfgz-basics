<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SfgzKurs',
            'Conf',
            'Kurs Konfiguration'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SfgzKurs',
            'Lst',
            'Kurs Liste'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SfgzKurs',
            'Vw',
            'Kurs Verwaltung'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SfgzKurs',
            'Inf',
            'Kurs Info-Display'
        );

$pluginSignature = str_replace('_','',$extKey) . '_inf';
$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:' . $extKey . '/Configuration/FlexForms/flexform_inf.xml');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($extKey, 'Configuration/TypoScript', 'Kursverwaltung');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzkurs_domain_model_kategorie', 'EXT:sfgz_kurs/Resources/Private/Language/locallang_csh_tx_sfgzkurs_domain_model_kategorie.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzkurs_domain_model_kurs', 'EXT:sfgz_kurs/Resources/Private/Language/locallang_csh_tx_sfgzkurs_domain_model_kurs.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzkurs_domain_model_version', 'EXT:sfgz_kurs/Resources/Private/Language/locallang_csh_tx_sfgzkurs_domain_model_version.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzkurs_domain_model_link', 'EXT:sfgz_kurs/Resources/Private/Language/locallang_csh_tx_sfgzkurs_domain_model_info.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzkurs_domain_model_durchfuehrung', 'EXT:sfgz_kurs/Resources/Private/Language/locallang_csh_tx_sfgzkurs_domain_model_durchfuehrung.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzkurs_domain_model_lektion', 'EXT:sfgz_kurs/Resources/Private/Language/locallang_csh_tx_sfgzkurs_domain_model_lektion.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzkurs_domain_model_config', 'EXT:sfgz_kurs/Resources/Private/Language/locallang_csh_tx_sfgzkurs_domain_model_config.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzkurs_domain_model_belegung', 'EXT:sfgz_kurs/Resources/Private/Language/locallang_csh_tx_sfgzkurs_domain_model_belegung.xlf');

    },
    $_EXTKEY
);
