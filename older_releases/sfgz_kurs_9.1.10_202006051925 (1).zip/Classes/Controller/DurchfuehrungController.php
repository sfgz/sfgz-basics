<?php
namespace Sfgz\SfgzKurs\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * DurchfuehrungController
 */
class DurchfuehrungController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    
    /**
     * propertiesToSkip
     *
     * @var array
     */
    protected $propertiesToSkip = null;
    
    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     * @inject
     */
    protected $kursRepository = null;

    /**
     * versionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\VersionRepository
     * @inject
     */
    protected $versionRepository = null;
    
    /**
     * durchfuehrungRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\DurchfuehrungRepository
     * @inject
     */
    protected $durchfuehrungRepository = null;

    /**
     * lektionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\LektionRepository
     * @inject
     */
    protected $lektionRepository = null;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 */
	protected $persistenceManager = NULL;

    /**
     * timeZoneString
     *
     * @var string
     */
    protected $timeZoneString = 'Europe/Zurich';

    /**
     * initialize
     *
     * @return void
     */
    public function initializeAction()
    {
		$this->timeZone = new \DateTimeZone( $this->timeZoneString );
        date_default_timezone_set($timeZoneString);

		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		
		$this->kursRepository = $objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\KursRepository');
	    $this->kursRepository->setDefaultQuerySettings($querySettings);
		
		$this->versionRepository = $objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\VersionRepository');
	    $this->versionRepository->setDefaultQuerySettings($querySettings);
		
		$this->lektionRepository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\LektionRepository');
	    $this->lektionRepository->setDefaultQuerySettings($querySettings);

	    $this->kursbestaetigungUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\KursbestaetigungUtility');
		$this->filetransferUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\FiletransferUtility');

    }
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $durchfuehrungs = $this->durchfuehrungRepository->findAll();
        $this->view->assign('durchfuehrungs', $durchfuehrungs);
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {
		if( $this->request->hasArgument('version') ) {
			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
			$this->view->assign('version', $this->request->getArgument('version') );
		}
    }

    /**
     * initializeCreate
     *
     * @return void
     */
    public function initializeCreateAction()
    {
		if ($this->request->hasArgument('newDurchfuehrung')) {
			$arg = $this->arguments['newDurchfuehrung']->getPropertyMappingConfiguration();

			$propConf = $this->arguments->getArgument('newDurchfuehrung')->getPropertyMappingConfiguration();
		
		
			$reqDurchf = $this->request->getArgument('newDurchfuehrung');
			
			if( empty($reqDurchf['publikationStart']) ){
			    $propConf->skipProperties('publikationStart');
				$this->propertiesToSkip['publikationStart'] = 1;
			}else{
			      $arg->forProperty('publikationStart')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			if( empty($reqDurchf['publikationEnde']) ){
			    $propConf->skipProperties('publikationEnde');
				$this->propertiesToSkip['publikationEnde'] = 1;
			}else{
			      $arg->forProperty('publikationEnde')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
 			}
			
			if( empty($reqDurchf['anmeldeschluss']) ){
			    $propConf->skipProperties('anmeldeschluss');
				$this->propertiesToSkip['anmeldeschluss'] = 1;
			}else{
			     $arg->forProperty('anmeldeschluss')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			
			if( empty($reqDurchf['terminStart']) ){
			    $propConf->skipProperties('terminStart');
				$this->propertiesToSkip['terminStart'] = 1;
			}else{
			      $arg->forProperty('terminStart')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			if( empty($reqDurchf['terminEnde']) ){
			    $propConf->skipProperties('terminEnde');
				$this->propertiesToSkip['terminEnde'] = 1;
			}else{
			      $arg->forProperty('terminEnde')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
 			}
			
		}
    }

    /**
     * action create
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $newDurchfuehrung
     * @return void
     */
    public function createAction(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $newDurchfuehrung)
    {
        if( $this->request->hasArgument('abort') ) {
			$iVersionUid = $newDurchfuehrung->getVersion();
			if( $iVersionUid ) $this->redirect('edit', 'Version', NULL, array('version' => $iVersionUid ) );
			$this->redirect('list');
        }
        $this->addFlashMessage('Die Durchfuehrung wurde erstellt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        
        $newDurchfuehrung = $this->detectAndSetTheCode( $newDurchfuehrung );
        $newDurchfuehrung = $this->sanitizeDateFields($newDurchfuehrung);
        $this->durchfuehrungRepository->add($newDurchfuehrung);
        $this->persistenceManager->persistAll();
        $this->redirect('edit', NULL, NULL, array('durchfuehrung' => $newDurchfuehrung));
    }

    /**
     * action edit
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung
     * @ignorevalidation $durchfuehrung
     * @return void
     */
    public function editAction(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung)
    {
        if( $this->request->hasArgument('dupliz') ) {
			$dUid = $this->duplicateDurchfuehrung( $durchfuehrung );
			$this->redirect('edit', NULL, NULL, ['durchfuehrung'=>$dUid] );
		}else{
			$this->view->assign('durchfuehrung', $durchfuehrung);
		}
		$vUid = $durchfuehrung->getVersion();
        $oVersion = $this->versionRepository->findByUid($vUid);
        $kUid = $oVersion->getKurs();
        $oKurs = $this->kursRepository->findByUid($kUid);
        
        // select to change relation to parent recordset
        $objVersionen = $oKurs->getKVersionen();
        $selopt = array();
        $sortVersionen = array();
        foreach($objVersionen as $objVersion){
			$loopUid = $objVersion->getUid();
			$objStart = $objVersion->getVersionStart() ;
			if( !$objStart ) continue;
			$time = $objStart->format('U') ;
			$sortVersionen[$time] = $loopUid;
        }
        if( count($sortVersionen) ){
            ksort($sortVersionen);
            foreach( $sortVersionen as $time => $loopUid){
                $date = date( 'd.m.Y' , $time );
                $selopt[$loopUid] = $date;
                if( $vUid == $loopUid ) $selopt[$loopUid] .= ' (gewählt)';
            }
        }
        $this->view->assign( 'versionen' , $selopt );
        
        // in Title we need KursCode
        $kCode = '';
        if($oKurs) $kCode = $oKurs->getKursCode();
        $this->view->assign('kursCode', $kCode);
        
        // keep selected record
        $uidLektion = $this->request->hasArgument('index') ? $this->request->getArgument( 'index' ) : NULL;
        $this->view->assign('index', $uidLektion );
        
        // download Kursbestatigung
        $teilnehmerUpload = $this->request->hasArgument('teilnehmerUpload') ? $this->request->getArgument( 'teilnehmerUpload' ) : NULL;
        if( $teilnehmerUpload ){
			$versionUid = $durchfuehrung->getVersion();
			$objVersion = $this->versionRepository->findByUid($versionUid);
			$durchfuehrungUid = $durchfuehrung->getUid();
			$result = $this->kursbestaetigungUtility->BestaetigungPdf( $teilnehmerUpload , $durchfuehrungUid , $objVersion );
			if($result) $this->addFlashMessage('Die Kursbestaetigung wurde nicht erstellt, Resultat: ' . $result , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        }
        
		//$this->debug = $this->filetransferUtility->getCalendarsFtpFile();
       // $this->view->assign('debug', $this->debug );
       
    }

    /**
     * initializeUpdate
     *
     * @return void
     */
    public function initializeUpdateAction()
    {
		if ($this->request->hasArgument('durchfuehrung')) {
			$arg = $this->arguments['durchfuehrung']->getPropertyMappingConfiguration();

			$propConf = $this->arguments->getArgument('durchfuehrung')->getPropertyMappingConfiguration();
			$reqDurchf = $this->request->getArgument('durchfuehrung');
			
			if( empty($reqDurchf['publikationStart']) ){
			    $propConf->skipProperties('publikationStart');
				$this->propertiesToSkip['publikationStart'] = 1;
			}else{
			      $arg->forProperty('publikationStart')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			if( empty($reqDurchf['publikationEnde']) ){
			    $propConf->skipProperties('publikationEnde');
				$this->propertiesToSkip['publikationEnde'] = 1;
			}else{
			      $arg->forProperty('publikationEnde')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			
			if( empty($reqDurchf['anmeldeschluss']) ){
// 				Make empty field Possible: 
// 				Do not skip Property anmeldeschluss!
			}else{
			     $arg->forProperty('anmeldeschluss')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			
			if( empty($reqDurchf['terminStart']) ){
			    $propConf->skipProperties('terminStart');
				$this->propertiesToSkip['terminStart'] = 1;
			}else{
			      $arg->forProperty('terminStart')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			if( empty($reqDurchf['terminEnde']) ){
			    $propConf->skipProperties('terminEnde');
				$this->propertiesToSkip['terminEnde'] = 1;
			}else{
			      $arg->forProperty('terminEnde')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			
		}
    }

    /**
     * action update
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung
     * @return void
     */
    public function updateAction(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung)
    {

        if( $this->request->hasArgument('abort') ) {
			$iVersionUid = $durchfuehrung->getVersion();
			if( $iVersionUid ) $this->redirect('edit', 'Version', NULL, array('version' => $iVersionUid ) );
			$this->redirect('list');
        }
        
		if( $this->request->hasArgument('save') ){
			$durchfuehrung = $this->detectAndSetTheCode( $durchfuehrung );
			$durchfuehrung = $this->sanitizeDateFields($durchfuehrung);
			$this->durchfuehrungRepository->update($durchfuehrung);
			$this->addFlashMessage('Die Durchfuehrung wurde gespeichert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			
        }else{
			// teilnehmerliste hochladen und Kursbestaetigung herunterladen
			$teilnehmerUpload = $this->kursbestaetigungUtility->TeilnehmerlisteHochladen();
			if( $teilnehmerUpload ) $this->addFlashMessage('Datei hochgeladen: ' . $teilnehmerUpload , 'Hochladen', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        }
        
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        
        
        $this->redirect('edit', NULL, NULL, array('durchfuehrung' => $durchfuehrung , 'teilnehmerUpload' => $teilnehmerUpload ));
    }

    /**
     * action delete
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung
     * @return void
     */
    public function deleteAction(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung)
    {
        $version = $durchfuehrung->getVersion();
        $this->addFlashMessage('Die Durchfuehrung wurde entfernt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->durchfuehrungRepository->remove($durchfuehrung);
        $this->redirect('edit', 'Version', NULL, array('version' => $version ) );
    }

    /**
     * action storeLektionen
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung
     * @return void
     */
    public function storeLektionenAction(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung)
    {
		$recordAction = [ 'update' => [] , 'delete' => [] , 'add' => [] ];
        if( $this->request->hasArgument('lekt') ){
            $this->importfunctionsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ImportfunctionsUtility');
            $arrUdatedLektionen = $this->request->getArgument('lekt');
            
            foreach( $this->request->getArgument('lekt') as $uidLektion => $contents ){
                    // detect the object or create a new one
                    $objLektion = is_numeric($uidLektion) ? $this->lektionRepository->findByUid( $uidLektion ) : null;
                    if( $objLektion ) {
                        // update existing object
                        $recordAction['update'][$uidLektion] = $contents;
                    }else{
                        // add new object add Pid and Durchfuehrung uid
                        if( empty($contents['lektionDatum']) ) continue;
                        if( empty($contents['zeitVon']) ) continue;
                        if( empty($contents['zeitBis']) ) continue;
                        $objLektion = GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\Lektion');
                        $objLektion->setDurchfuehrung( $durchfuehrung->getUid() );
                        $objLektion->setPid( $durchfuehrung->getPid() );
                        $recordAction['add'][$uidLektion] = $contents;
                        $contents['lektionenzahl'] = '';
                    }
                    
                    // sanitize Date 
                    if( !empty($contents['lektionDatum']) ){
                        $aDatum = explode( '.' , $contents['lektionDatum'] );// 0=d 1=m 2=y
                        if( count($aDatum) != 3 ){
                            $contents['lektionDatum'] = '';
                        }else{
                            if( strlen($aDatum[2]) == 2 ) $aDatum[2] += 2000 ;// prepend millenium HACK Nr1
                            $contents['lektionDatum'] = new \DateTime( $aDatum[2].'-'.$aDatum[1].'-'.$aDatum[0].'T02:00:00' , $this->timeZone);// Y m d
                        }
                    }
                    
                    // sanitize lektionenzahl 
                    if( 0 == strlen(trim($contents['lektionenzahl'])) ){
                        // on column-edit mode we have only one field in $contents but full (old) object,
                        // on new mode we have all fields but empty object claculate lektionenzahl HACK Nr2
                        $timeFrom = empty($contents['zeitVon']) ? $objLektion->getZeitVon() : $contents['zeitVon'] ;
                        $timeTo = empty($contents['zeitBis']) ? $objLektion->getZeitBis() : $contents['zeitBis'] ;
                        $strZeitraum = $timeFrom . ',' . $timeTo; 
                        // calculate rounded amount of lessons
                        $contents['lektionenzahl'] = $this->importfunctionsUtility->import_lessonsCount( $strZeitraum  );
                    }
                    
                    // assign incomed field-values to object
                    foreach ( $contents as $domFormattedKey => $inputValue ) {
                        $objLektion->_setProperty( $domFormattedKey ,  $inputValue );
                    }
                    
                    // update or (add and persist)
                   if( isset($recordAction['update'][$uidLektion]) ) {
                        $this->lektionRepository->update($objLektion);
                        
                   }elseif( isset($recordAction['add'][$uidLektion]) ) {
                        $this->lektionRepository->add($objLektion);
                        $this->persistenceManager->persistAll();
                   }
            }
            // end of row 'lekt'
        }
        
        if( $this->request->hasArgument('delete_selection_nr') ){
            foreach( $this->request->getArgument('delete_selection_nr') as $i => $c ) {
                if($c) {
                    // do not delete if edit field exists
                    if( isset($recordAction['update'][$i] ) ) continue;
                    // choose the recordset and remove it from upper object
                    $objLektion = $this->lektionRepository->findByUid( $i );
                    if( $objLektion ) {
                        $this->lektionRepository->remove( $objLektion );
                        $recordAction['delete'][$i] = $c;
                    }
                }
            }
        }
        
        
        if( count($recordAction['update']) ){
            $this->addFlashMessage( count($recordAction['update']) . ' Lektion(en) gespeichert.' , 'Lektionen speichern', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        }
        if( count($recordAction['delete']) ){
            $this->addFlashMessage( count($recordAction['delete']) . ' Lektion(en) gelöscht.' , 'Lektionen löschen', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        }
        if( count($recordAction['add']) ){
            $this->addFlashMessage( count($recordAction['add']).' Lektion(en) erstellt.' , 'Lektionen erstellen', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
        }
        
        $this->redirect('edit', NULL, NULL, ['durchfuehrung'=>$durchfuehrung]);
    }

    /**
     * helper duplicateDurchfuehrung
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung
     * @param int $versionUid optional
     * @return void
     */
    public function duplicateDurchfuehrung(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung , $versionUid = 0 )
    {
			$newDurchfuehrung = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\Durchfuehrung');
			$properties = $durchfuehrung->_getProperties() ;
			unset($properties['uid']) ;
			if( $versionUid ) $properties['version'] = $versionUid;
			foreach ($properties as $key => $value ) $newDurchfuehrung->_setProperty( $key , $value );
			$this->durchfuehrungRepository->add( $newDurchfuehrung );
			$this->persistenceManager->persistAll();
			$newDurchfuehrungUid = $newDurchfuehrung->getUid();

			$objLekts = $durchfuehrung->getDLektionen();
			if( !$objLekts ) return $newDurchfuehrungUid;

			foreach( $objLekts as $objLektion ){
				$this->copyLektion($objLektion,$newDurchfuehrungUid);
			}

			return $newDurchfuehrungUid;
    }

    /**
     * helper copyLektion
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Lektion $lektion
     * @param int $newDurchfuehrungUid optional
     * @return int
     */
    public function copyLektion(\Sfgz\SfgzKurs\Domain\Model\Lektion $lektion , $newDurchfuehrungUid )
    {
 		  $newLektion = GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\Lektion');
		  $properties = $lektion->_getProperties() ;
 		  unset($properties['uid']) ;
		  $properties['durchfuehrung'] = $newDurchfuehrungUid;
		  foreach ($properties as $key => $value ) $newLektion->_setProperty( $key , $value );
		  $this->lektionRepository->add( $newLektion );
		  $this->persistenceManager->persistAll();
		  $newUid = $newLektion->getUid();
		  return $newUid;
    }

    /**
     * helper setDateTimeToNoon
     *
     * @param string $fieldname
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung
     * @return void
     */
    public function setDateTimeToNoon( $fieldname , \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung)
    {
				$getter = 'get' . ucFirst($fieldname);
				$setter = 'set' . ucFirst($fieldname);
				$objDate = $durchfuehrung->$getter();
				if( $objDate ) $durchfuehrung->$setter( new \DateTime($objDate->format('Y-m-d 12:00'),$this->timeZone) );
				return $durchfuehrung;
    }

    /**
     * helper sanitizeDateFields
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung
     * @return void
     */
    public function sanitizeDateFields(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung)
    {
			
			if( !isset($this->propertiesToSkip['publikationStart']) ) $durchfuehrung = $this->setDateTimeToNoon('publikationStart' , $durchfuehrung);
			if( !isset($this->propertiesToSkip['publikationEnde']) ) $durchfuehrung = $this->setDateTimeToNoon('publikationEnde' , $durchfuehrung);
			if( !isset($this->propertiesToSkip['anmeldeschluss']) ) $durchfuehrung = $this->setDateTimeToNoon('anmeldeschluss' , $durchfuehrung);
			if( !isset($this->propertiesToSkip['terminStart']) ) $durchfuehrung = $this->setDateTimeToNoon('terminStart' , $durchfuehrung);
			if( !isset($this->propertiesToSkip['terminEnde']) ) $durchfuehrung = $this->setDateTimeToNoon('terminEnde' , $durchfuehrung);
			
			
			$events = $durchfuehrung->getVeranstaltungen();
			if( !isset($this->propertiesToSkip) || (!count($this->propertiesToSkip) && !empty($events)) ) return $durchfuehrung;
			
			$messages = array();
			
			$this->calendarcalcUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\CalendarcalcUtility');
			$aDurchfuehrung = $this->calendarcalcUtility->setDurchfuehrungFromObj($durchfuehrung , $this->propertiesToSkip);
			if( $aDurchfuehrung['message'] ){
				$messages[$aDurchfuehrung['message']] = $aDurchfuehrung['message'];
				$method = $aDurchfuehrung['method'];
				if( method_exists( $durchfuehrung , $method ) ) $durchfuehrung->$method( $aDurchfuehrung['result' . $aDurchfuehrung['message'] ] );
			}
			if( count( $messages ) ){
				$this->addFlashMessage( 'Automatisch ausgefuellt: '.array_shift($messages), 'Autofill '  , \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			}
			if( count( $messages ) ){
				foreach($messages as $title => $strMsg)
				$this->addFlashMessage( '- ' . $strMsg , '' , \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
			}
			$skDates = $this->calendarcalcUtility->skippedDates;
			if( is_array($skDates) && count( $skDates ) ) $this->addFlashMessage( array_pop($skDates) . ': ' . implode(', ' , array_keys($this->calendarcalcUtility->skippedDates) ) , 'Schulfreie Tage'  , \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
			return $durchfuehrung;

    }

    /**
     * helper detectAndSetTheCode
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung
     * @return void
     */
    public function detectAndSetTheCode(\Sfgz\SfgzKurs\Domain\Model\Durchfuehrung $durchfuehrung)
    {
			$dCode = $durchfuehrung->getDurchfuehrungsCode();
			$dCodeSuffix = $durchfuehrung->getCodeSuffix();
			$versionUid = $durchfuehrung->getVersion();
			$kursID = $this->versionRepository->findByUid($versionUid)->getKurs();
			$kursCode = $this->kursRepository->findByUid($kursID)->getKursCode();
			return $durchfuehrung;
    }
}
