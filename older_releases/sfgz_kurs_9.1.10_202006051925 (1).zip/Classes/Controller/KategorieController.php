<?php
namespace Sfgz\SfgzKurs\Controller;

use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * KategorieController
 */
class KategorieController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * kategorieRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KategorieRepository
     * @inject
     */
    protected $kategorieRepository = null;

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $kategories = $this->kategorieRepository->findAll();
        $aGrp = [];
        foreach($kategories as $ix => $objKat ){
                $aGrp[$objKat->getKategorieGruppe()][$ix] = $objKat;
        }
        
        $this->view->assign('kategories', $aGrp);
		// overview: plugin-uid needed by sorting AJAX
		$this->view->assign('contentUid', $this->contentObj->data['uid'] );
		
        $this->view->assign('kategoriegruppen', $this->getKategorienGruppen() );
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {

        $this->view->assign('kategoriegruppen', $this->getKategorienGruppen() );

    }

    /**
     * initializeCreate
     *
     * @return void
     */
    public function initializeCreateAction()
    {
        if( $this->request->hasArgument('abort') ) $this->redirect('list');
    }

    /**
     * action create
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Kategorie $newKategorie
     * @return void
     */
    public function createAction(\Sfgz\SfgzKurs\Domain\Model\Kategorie $newKategorie)
    {
        if( $this->request->hasArgument('abort') ) $this->redirect('list');
        $this->addFlashMessage('Die Kategorie wurde erstellt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->kategorieRepository->add($newKategorie);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        $this->redirect('list');
    }

    /**
     * action edit
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Kategorie $kategorie
     * @ignorevalidation $kategorie
     * @return void
     */
    public function editAction(\Sfgz\SfgzKurs\Domain\Model\Kategorie $kategorie)
    {
//         if( empty($this->settings['kategoriegruppen']) ){
//             $aKategoriegruppen  = $this->getTranslationList('tx_sfgzkurs_domain_model_kategorie.kategoriegruppe.sel.');
//         }else{
//         }

        $this->view->assign('kategoriegruppen', $this->getKategorienGruppen() );
        
        $this->view->assign('kategorie', $kategorie);
    }

    /**
     * getKategorienGruppen
     *
     * @return void
     */
    Private function getKategorienGruppen()
    {
        $aKategoriegruppen = [];
        $aCatGrp = explode( ',' ,  $this->settings['kategoriegruppen'] );
        foreach( $aCatGrp as $i => $cat ) $aKategoriegruppen[$i+1] = trim($cat);
        return $aKategoriegruppen;
    }

    /**
     * getTranslationList
     *
     * @param string $llKey
     * @return void
     */
    private function getTranslationList( $llKey )
    {
		$translationItems = [];
        for( $z = 1 ; $z <= 10 ; ++$z ){
			$transl = LocalizationUtility::translate( $llKey . $z , 'SfgzKurs' );
			if( empty($transl) ) break;
			$translationItems[$z] = $transl;
        }
        return $translationItems;
    }

    /**
     * initializeUpdate
     *
     * @return void
     */
    public function initializeUpdateAction()
    {
        if( $this->request->hasArgument('abort') ) $this->redirect('list');
    }

    /**
     * action update
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Kategorie $kategorie
     * @return void
     */
    public function updateAction(\Sfgz\SfgzKurs\Domain\Model\Kategorie $kategorie)
    {
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        if( $this->request->hasArgument('abort') ) $this->redirect('list');
        $this->addFlashMessage('Die Kategorie wurde gespeichert. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        $this->kategorieRepository->update($kategorie);
        $this->redirect('list', 'Kategorie');
    }

    /**
     * action delete
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Kategorie $kategorie
     * @return void
     */
    public function deleteAction(\Sfgz\SfgzKurs\Domain\Model\Kategorie $kategorie)
    {
        $this->addFlashMessage('Die Kategorie wurde entfernt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->kategorieRepository->remove($kategorie);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        $this->redirect('list');
    }
}
