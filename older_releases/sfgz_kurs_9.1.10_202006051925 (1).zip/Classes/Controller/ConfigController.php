<?php
namespace Sfgz\SfgzKurs\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * ConfigController
 */
class ConfigController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * configRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\ConfigRepository
     * @inject
     */
    protected $configRepository = null;
    /**
     * initialize
     *
     * @return void
     */
    public function initializeAction()
    {
		$this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	    $this->configUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ConfigUtility');
	    $this->kursausschreibungUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\KursausschreibungUtility');
		
    }

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $configs = $this->configRepository->findAll();
        $this->view->assign('configs', $configs);
		
		if( $this->request->hasArgument('pageUid') ){
			$this->view->assign( 'pageUid', $this->request->getArgument('pageUid') );
        }
        
        if( 
			count( $this->configUtility->flashMessages ) && 
			is_array($this->configUtility->flashMessages) 
		) $this->addFlashMessage( implode( ', ' , $this->configUtility->flashMessages ) , 'configUtility', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
    }

    /**
     * action template
     * allows to upload a own docx-template for kursausschreibung 
     *
     * @return void
     */
    public function templateAction()
    {
        $configs = $this->configRepository->findAll();
        $this->view->assign('config', $configs);
        
		if( $this->request->hasArgument('download') ){
			$this->kursausschreibungUtility->filetransferUtility->downloadFile( $this->kursausschreibungUtility->kurseingabeOrdner . $this->kursausschreibungUtility->kurseingabeDatei );
        }
		$this->kursausschreibungUtility->VorlageHochladen();
		
		$this->view->assign( 'kurseingabeDatei', $this->kursausschreibungUtility->kurseingabeDatei );
        
        if( count( $this->kursausschreibungUtility->flashMessages ) && is_array($this->kursausschreibungUtility->flashMessages) ) {
			$this->addFlashMessage( implode( ', ' , $this->kursausschreibungUtility->flashMessages ) , 'kursausschreibungUtility', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        }
        $clearedTableSetting = $this->configUtility->getConfigTsFieldMapping();
        $this->view->assign('fieldmapping', $clearedTableSetting );
		
		if( $this->request->hasArgument('pageUid') ){
			$this->view->assign( 'pageUid', $this->request->getArgument('pageUid') );
        }
        
    }

    /**
     * action display
     *
     * @return void
     */
    public function displayAction()
    {
        $clearedTableSetting = $this->configUtility->getConfigTsFieldMapping();
        $this->view->assign('fieldmapping', $clearedTableSetting );
		
		if( $this->request->hasArgument('pageUid') ){
			$this->view->assign( 'pageUid', $this->request->getArgument('pageUid') );
        }
    }

    /**
     * action display
     * migratin data from old website
     *
     * @return void
     */
    public function migrateAction()
    {
		$this->migrationUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\MigrationUtility');
		
		if ($this->request->hasArgument('remove')) {
			$this->migrationUtility->deleteXmlFile();
			$importDb = [];
			
		}
		if ($this->request->hasArgument('reload')) {
			$importDb = $this->migrationUtility->readXmlFile();
		}
		
		if ($this->request->hasArgument('create')) {
			$importDb = $this->migrationUtility->compareDbAndXmlFile();
		}
		
        $this->view->assign('debug', $importDb);
        
        $cancreate = $this->migrationUtility->candoCreateXmlFile();
        $this->view->assign('cancreate', $cancreate );

        $isFile = $this->migrationUtility->isXmlFile();
        $this->view->assign('candelete', $isFile && $cancreate ? 1 : 0 );
		$this->view->assign('contentUid', $this->contentObj->data['uid'] );
		
		if( $this->request->hasArgument('pageUid') ){
			$this->view->assign( 'pageUid', $this->request->getArgument('pageUid') );
        }
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {

    }

    /**
     * initializeCreate
     *
     * @return void
     */
    public function initializeCreateAction()
    {
		if ($this->request->hasArgument('newConfig')) {
			$reqDurchf = $this->request->getArgument('newConfig');
			$propConf = $this->arguments->getArgument('newConfig')->getPropertyMappingConfiguration();
			if( empty($reqDurchf['fieldname']) ){
			    $propConf->skipProperties('fieldname');
			}
		}
    }

    /**
     * action create
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Config $newConfig
     * @return void
     */
    public function createAction(\Sfgz\SfgzKurs\Domain\Model\Config $newConfig)
    {
        if( $this->request->hasArgument('abort') ) $this->redirect('list');
        $this->addFlashMessage('Der Datensatz wurde erstellt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
	    $possibleRadiobuttons = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST('fieldname');
        if( is_array($possibleRadiobuttons) ) $newConfig->setFieldname( implode( $possibleRadiobuttons ) );
        $this->configRepository->add($newConfig);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        $this->redirect('list');
    }

    /**
     * action edit
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Config $config
     * @ignorevalidation $config
     * @return void
     */
    public function editAction(\Sfgz\SfgzKurs\Domain\Model\Config $config)
    {
        $this->view->assign('config', $config);
    }

    /**
     * action update
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Config $config
     * @return void
     */
    public function updateAction(\Sfgz\SfgzKurs\Domain\Model\Config $config)
    {
        if( $this->request->hasArgument('abort') ) $this->redirect('list');
	    
	    $possibleRadiobuttons = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST('fieldname');
        if( is_array($possibleRadiobuttons) ) $config->setFieldname( implode( $possibleRadiobuttons ) );
        
        
        $this->addFlashMessage('Der Datensatz wurde gespeichert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->configRepository->update($config);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
         $this->redirect('list');
    }

    /**
     * action delete
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Config $config
     * @return void
     */
    public function deleteAction(\Sfgz\SfgzKurs\Domain\Model\Config $config)
    {
        $this->addFlashMessage('Der Datensatz wurde entfernt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->configRepository->remove($config);
        $this->redirect('list');
    }
}
