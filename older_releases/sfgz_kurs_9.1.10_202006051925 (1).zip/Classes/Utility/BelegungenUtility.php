<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class BelegungenUtility
 * 
 * 
 */
 
class BelegungenUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     */
    protected $kursRepository = null;

    /**
     * versionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\VersionRepository
     */
    protected $versionRepository = null;

    /**
     * durchfuehrungRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\DurchfuehrungRepository
     */
    protected $durchfuehrungRepository = null;

    /**
     * lektionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\LektionRepository
     */
    protected $lektionRepository = null;

    /**
     * infoRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\InfoRepository
     * @inject
     */
    protected $infoRepository = null;

    /**
     * rpsMieterRepository
     *
     * @var \Mff\Mffrps\Domain\Repository\MieterRepository
     */
    protected $rpsMieterRepository = null;

    /**
     * rpsAnlassRepository
     *
     * @var \Mff\Mffrps\Domain\Repository\AnlassRepository
     */
    protected $rpsAnlassRepository = null;

    /**
     * rpsBelegungRepository
     *
     * @var \Mff\Mffrps\Domain\Repository\BelegungRepository
     */
    protected $rpsBelegungRepository = null;

    /**
     * settings
     *
     * @var array
     */
    protected $settings = null;

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
		$objectManager = GeneralUtility::makeInstance('TYPO3\CMS\Extbase\Object\ObjectManager');

		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		
		$this->kursRepository = $objectManager->get('Sfgz\SfgzKurs\Domain\Repository\KursRepository');
	    $this->kursRepository->setDefaultQuerySettings($querySettings);
		
		$this->versionRepository = $objectManager->get('Sfgz\SfgzKurs\Domain\Repository\VersionRepository');
	    $this->versionRepository->setDefaultQuerySettings($querySettings);
		
		$this->durchfuehrungRepository = $objectManager->get('Sfgz\SfgzKurs\Domain\Repository\DurchfuehrungRepository');
	    $this->durchfuehrungRepository->setDefaultQuerySettings($querySettings);
		
		$this->lektionRepository = $objectManager->get('Sfgz\SfgzKurs\Domain\Repository\LektionRepository');
	    $this->lektionRepository->setDefaultQuerySettings($querySettings);
		
		$this->infoRepository = $objectManager->get('Sfgz\SfgzKurs\Domain\Repository\InfoRepository');
	    $this->infoRepository->setDefaultQuerySettings($querySettings);
		
	}

	/**
	 * findRaumplanungByDatumAnzeige
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Public function findRaumplanungByDatumAnzeige( $sEnglDate )
	{
		
		$this->rpsMieterRepository = $objectManager->get('Mff\Mffrps\Domain\Repository\MieterRepository');
	    $this->rpsMieterRepository->setDefaultQuerySettings($querySettings);
		
		$this->rpsAnlassRepository = $objectManager->get('Mff\Mffrps\Domain\Repository\AnlassRepository');
	    $this->rpsAnlassRepository->setDefaultQuerySettings($querySettings);
		
		$this->rpsBelegungRepository = $objectManager->get('Mff\Mffrps\Domain\Repository\BelegungRepository');
	    $this->rpsBelegungRepository->setDefaultQuerySettings($querySettings);
	    
			$aRaumplanung = [];
			$rpBelegungen = $this->rpsBelegungRepository->findByDatum($sEnglDate);

			if( !count($rpBelegungen) ) return $aRaumplanung;
			
			foreach($rpBelegungen as $objBelegung ){
				$uid = $objBelegung->getUid();
				$uidAnlass = $objBelegung->getAnlass();
				$objAnlass = $this->rpsAnlassRepository->findByUid($uidAnlass);
				$uidMieter = $objAnlass->getMieter();
				$objMieter = $this->rpsMieterRepository->findByUid($uidMieter);
				$codeMieter = $objMieter->getKurz();
				$objZimmer = $objBelegung->getBelZimmer();
				if($objZimmer) $zimmer = trim( $objZimmer->getHaus() . ' ' . $objZimmer->getZimmer() );
				$aRaumplanung[$uid]['uid']=$uid;
				$aRaumplanung[$uid]['titel'] = $objBelegung->getBelegungstext();;
				$aRaumplanung[$uid]['code'] = '';
				$aRaumplanung[$uid]['zeitVon'] = $objBelegung->getAb();
				$aRaumplanung[$uid]['zeitBis'] = $objBelegung->getBis();
				$aRaumplanung[$uid]['zimmer'] = $zimmer;
				$aRaumplanung[$uid]['lehrperson'] = $codeMieter;
			}
			return $aRaumplanung;
	}

	/**
	 * findLektionenByDatumAnzeige
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Public function findLektionenByDatumAnzeige( $sEnglDate )
	{
		$aLektionen = $this->lektionRepository->findByLektionDatum( $sEnglDate );
		$lekt = [];
		foreach( $aLektionen as $ix => $objLektion ){
			$objDurchfuehrung = $this->durchfuehrungRepository->findByUid($objLektion->getDurchfuehrung());
			if( !$objDurchfuehrung ) continue;
			$objVersion = $this->versionRepository->findByUid($objDurchfuehrung->getVersion());
			if( !$objVersion ) continue;
			$objKurs = $this->kursRepository->findByUid($objVersion->getKurs());
			if( !$objKurs ) continue;
			
			$durchfuehrungStatus = $objDurchfuehrung->getStatus();
			$testStatus = 1;
			if( $this->settings['infodisplay_hideStatus_list'] ){
				$statesToRefuse = explode( ',' , $this->settings['infodisplay_hideStatus_list'] );
				foreach($statesToRefuse as $refStat ) {
					if( trim($refStat) ==  $durchfuehrungStatus){
						$testStatus = 0;
						break;
					}
				}
			}
			if( !$testStatus ) continue;

			$suffix = $objDurchfuehrung->getCodeSuffix();
			if( $suffix ) $suffix = '-' . $suffix;
			$code = $objKurs->getKursCode().$suffix.' '.$objDurchfuehrung->getDurchfuehrungsCode();
			
			$aLp = explode( ' ' , $objLektion->getLehrpersonText() );
			$vorname = array_shift( $aLp );
			$lehrperson = substr( $vorname , 0 , 1 ) . '. ' . implode( ' ' , $aLp );
			
			$zeitVon = $objLektion->getZeitVon();
			$zeitBis = $objLektion->getZeitBis();
			$zimmer = $objLektion->getZimmer();
			
			$lekt[ $zeitVon . '.' . $zeitBis . '.' . $zimmer . '.' . $ix] = [
				'uid' => $objLektion->getUid(),
				'titel' => $objVersion->getTitel(),
				'code' => $code,
				'zeitVon' => $zeitVon,
				'zeitBis' => $zeitBis,
				'zimmer' => $zimmer,
				'lehrperson' => $lehrperson,
				'source' => 'lektion'
			];
		}
		if( count($lekt) ) ksort($lekt);
		return $lekt;
	}

	/**
	 * findBelegungenAndLektionenByDatumAnzeige
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Public function findBelegungenAndLektionenByDatumAnzeige( $sEnglDate )
	{
		$objsBelegungen = $this->findBelegungenByDatumAnzeige( $sEnglDate );
        $aLektionen = $this->findLektionenByDatumAnzeige( $sEnglDate );
        
        if( !count($objsBelegungen) && !count($aLektionen) ) return [];
        if( !count($objsBelegungen) ) return $aLektionen;
        $sortBy = [ 'zeitVon' , 'zimmer' , 'zeitBis' ]; // lehrperson , titel
        
        foreach($objsBelegungen as $ix => $oBelegung) {
				$aLektion = [];
				$aLektion['zeitVon'] = trim($oBelegung->getZeitVon());
				$aLektion['zeitBis'] = trim($oBelegung->getZeitBis());
				$aLektion['zimmer'] = trim($oBelegung->getRaum());
				$aLektion['lehrperson'] = trim($oBelegung->getPerson());
				$aLektion['titel'] = trim($oBelegung->getBelegungstext());
				$aLektion['uid'] = trim($oBelegung->getUid());
				
				$sTest = implode( '' , $aLektion );
				if( empty($sTest) ) continue;

				$aIx = [];
				foreach( $sortBy as $sortFieldname ) $aIx[ $sortFieldname ] = $aLektion[ $sortFieldname ];
				$aIx['uid'] = $ix; // forces index to be unique. if uid is noticed already in sortBy, then this has no affect.
				$sIndex = implode( '.' , $aLektion );
				
				$aLektionen[ $sIndex ] = [
					'uid'=> $aLektion['uid'],
					'titel' => $aLektion['titel'],
					'code' => '',
					'zeitVon' => $aLektion['zeitVon'],
					'zeitBis' => $aLektion['zeitBis'],
					'zimmer' => $aLektion['zimmer'],
					'lehrperson' => $aLektion['lehrperson'],
					'source' => 'belegung',
				];
		}
		if( count($aLektionen) ) ksort($aLektionen);
		return $aLektionen;
	}

	/**
	 * findBelegungenByDatumAnzeige
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Public function findBelegungenByDatumAnzeige( $sEnglDate )
	{
        $objInfo = $this->findInfoByDatumAnzeige( $sEnglDate );
        if( !$objInfo ) return [];
        $objsBelegungen = $objInfo->getIBelegungen() ;
        if( !$objsBelegungen ) return [];
        return $objsBelegungen;
	}

	/**
	 * findInfoByDatumAnzeige
     * 
     * @param string $sEnglDate
	 * @return array
	 */
	Public function findInfoByDatumAnzeige( $sEnglDate )
	{
        $aObjInfo = $this->infoRepository->findByDatumAnzeige( $sEnglDate );
        if( count($aObjInfo) ){ foreach($aObjInfo as $objInfo) break; }
        return $objInfo;
	}

	/**
	 * setSettings
	 * settings are used for findLektionenByDatumAnzeige()
     * 
     * @param array $settings
	 * @return void
	 */
	Public function setSettings( $settings )
	{
		$this->settings = $settings;
	}

}
