<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/** 
* Class ConfigUtility
* 
* 
*/

class ConfigUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
    * configRepository
    *
    * @var \Sfgz\SfgzKurs\Domain\Repository\ConfigRepository
    */
    protected $configRepository = null;

    /**
    * flashMessages
    *
    * @var array
    */
    public $flashMessages = [];

    /**
    * exisitingRecord
    *
    * @var array
    */
    public $exisitingRecord = [];

    /**
    * construct
    *
    * @return void
    */
    public function __construct()
    {
    
        $this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
        $this->settings = $this->settingsUtility->getSettings( 'tx_sfgzkurs_conf' );
        $persistence = $this->settingsUtility->getPersistence( 'tx_sfgzkurs_conf' );
        array_unshift($persistence , ['pageUid'=> $this->settings['pageUid']['storagePid'] ] );

        $objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

        $querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
        $querySettings->setIgnoreEnableFields(TRUE);
        $querySettings->setRespectStoragePage(FALSE);
        $querySettings->setStoragePageIds( $persistence );

        $this->configRepository = $objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\ConfigRepository');
        $this->configRepository->setDefaultQuerySettings($querySettings);

        $this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
        $this->exisitingRecord = [];
        $this->exisitingRecord = $this->initiateConfigurationTable();
        
        $this->tableMapperUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\TableMapperUtility');
        $this->importfunctionsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\ImportfunctionsUtility');
    }
    
    /**
    * enrichFiletablesWithConfig
    * income:
    * - $configTable[$tablename]['table'][ 'conf_uid' | 'importaction' | 'no_checkbox' ]
    * - $configTable[$tablename]['fields'][ camelCaseFieldName ][ 'conf_uid' | 'importaction' | 'source' ]
    * and income: 
    * - $aFileAndDbContents[ $index ][$tablename][ camelCaseFieldName ] = value
    * returns array
    * - $aFileAndDbContents[ $index ][$tablename]['table'][ 'conf_uid' | 'importaction' | 'no_checkbox' | 'dbcount' ] = value
    * - $aFileAndDbContents[ $index ][$tablename]['fields'][ camelCaseFieldName ][ 'conf_uid' | 'importaction' | 'source' | 'csvValue' | 'dbvalue' ] = value
    * 
    * @param array $aFileAndDbContents  
    * @return array
    */
    Public function enrichFiletablesWithConfig( $aFileAndDbContents )
    {
        if( !count($aFileAndDbContents) ) return [];
        
        $configTable = $this->getConfigTsFieldMappingLowerCamelCase();

        if( !count($configTable) ) return $aFileAndDbContents;
        
        foreach( $aFileAndDbContents as $index => $aFileContent){
            if(  is_array( $aFileContent['lektion'] ) && isset( $aFileContent['general']['isOrphan'] ) && isset($configTable['orphan']) ){
                $aNewFileContWithDefaultConf = $this->enrichRecWithDefaultConfig( $aFileContent , $configTable );
                $aNewFileContents[ $index ] = $this->enrichRecWithOrphanConfig( $aNewFileContWithDefaultConf , $configTable );
            }else{
                $aNewFileContents[ $index ] = $this->enrichRecWithDefaultConfig( $aFileContent , $configTable );
            }
        }
        $aNewFileContents = $this->applyRouleToDefault( $aNewFileContents , $configTable );
        $aNewFileContents = $this->calculateOrphansAndApplyRoule( $aNewFileContents , $configTable );
        
        // append DB-values to SUBTABLE(s) lektion, convert object to array
        foreach( $aFileAndDbContents as $index => $aFileContent){
            foreach($this->settings['tables']  as $tablename => $aFtabToMap ){
                if( !isset( $aFtabToMap['mapTable']) ) continue;
                
                    if( !isset($aFtabToMap['mapTable']['parentTable']) || !is_array($aFileContent['db'][$tablename])  || !count($aFileContent['db'][$tablename]) ) continue;
                    foreach( $aFileContent['db'][$tablename] as $ix => $dbRow){
                        $aNewRow = [];
                        // prevent doublettes (2 or more recordsets with exactly the same contents in certain fields)
                        // FIXME definition $resultFromAction = [ (falseOrEmpty) | suspend | hint | forbid ] 
                        //    method to run $resultFromAction = detectDoublettes( $aRecords , $aRecordset , $strTablename , $strAction )
                        //    if $resultFromAction == 'suspend' then remove csv-entry from list!
                        foreach( array_keys($configTable[$tablename]['fields']) as $fieldName){
                            $sql_fieldname = GeneralUtility::camelCaseToLowerCaseUnderscored($fieldName);
                            if( !$this->settings['tables'][$tablename]['mapFields'][$sql_fieldname]['temporary'] )
                            $aNewRow[$fieldName] = $this->getStringFromObjectBySqlFieldname( $dbRow , $fieldName , $tablename);
                        }
                        $aNewFileContents[ $index ][$tablename]['values']['db'][] = $aNewRow;
                    }
                    
                
            }
            
        }
        foreach( $aNewFileContents as $index => $aFileContent){
                if( isset( $aFileContent['orphan'] ) && !isset( $aFileContent['general']['isOrphan'] )  ) unset( $aNewFileContents[$index]['orphan'] );
        }
        
        return $aNewFileContents;
    }
    
    /**
    * enrichRecWithDefaultConfig
    * 
    * @param array $aFileContent  
    * @param array $configTable  
    * @return array
    */
    Public function enrichRecWithDefaultConfig( $aFileContent , $configTable )
    {
            $newData = [];
            foreach( $configTable as $tablename => $aConfTypes ){
                
                // make a copy of $configTable[$tablename]['table'] AND $configTable[$tablename]['fields']
                $newData[$tablename] = $aConfTypes; 
                    
                if( isset($aConfTypes['fields']) && is_array($aFileContent[$tablename]) ) {
                    foreach( $aFileContent[$tablename] as $fieldName => $value ){
                        if( is_array( $value) ) {
                            // this is the subtable 'lektion'
                            $newData[$tablename]['values']['csv'][$fieldName] = $value;
                        }else{
                            // default table
                            $newData[$tablename]['fields'][$fieldName]['csvValue'] = $value;
                        }
                        
                        // Append DB-values to default tables. For table 'lektion' we append DB-values later
                        if( is_array( $aFileContent['db'][$tablename] ) && count( $aFileContent['db'][$tablename] )  && !isset( $this->settings['tables'][$tablename]['mapTable']) ){
                            $sql_fieldname = GeneralUtility::camelCaseToLowerCaseUnderscored($fieldName);
                            if( !$this->settings['tables'][$tablename]['mapFields'][$sql_fieldname]['temporary'] ){
                                $objValue = $this->getStringFromObjectBySqlFieldname( $aFileContent['db'][$tablename] , $fieldName , $tablename );
                                $newData[$tablename]['fields'][$fieldName]['dbValue'] = $objValue;
                            }
                        }
                    }
                }
                    
                // get DB-uid if there is a recordset in DB for this table
                if( isset( $aFileContent['db'][$tablename] )  && method_exists( $aFileContent['db'][$tablename] , 'getUid' ) ) {
                    $newData[$tablename]['table']['dbUid'] = $aFileContent['db'][$tablename]->getUid();
                }
                
            }
            
            return $newData;
    }
    
    /**
    * enrichRecWithOrphanConfig
    * 
    * @param array $aFileContent  
    * @param array $configTable  
    * @return array
    */
    Public function enrichRecWithOrphanConfig( $aFileContent , $configTable )
    {
            $aFileContent['general']['isOrphan'] = 1;
            
            foreach( $configTable as $tablename => $aConfTypes ){
                $aFileContent[$tablename]['table']['hasOrphan'] = 1;
            }
            
            foreach( $configTable['orphan'] as $section =>  $sectTable ){
                foreach( $sectTable as $fieldName =>  $fieldRsOrTabDef ){
                    if( is_array($fieldRsOrTabDef) ){
                        foreach( $fieldRsOrTabDef as $option => $value ) $aFileContent['durchfuehrung'][$section][$fieldName][$option] = $value;
                    }else{
                        $aFileContent['durchfuehrung'][$section][$fieldName] = $fieldRsOrTabDef;
                    }
                }
            }
            
            return $aFileContent;
    }
    
    /**
    * applyRouleToDefault
    * 
    * works with domFormattedFieldNames
    * 
    * @param array $aNewFileContents  
    * @param array $configTable  
    * @return array
    */
    Public function applyRouleToDefault( $aNewFileContents , $configTable )
    {
        // ApplyRole default
        foreach( $configTable as $tablename => $aConfTypes ){
            if( !isset($aConfTypes['fields']) ) {
                continue;
            }
            foreach( $aNewFileContents as $index => $aFileContent){
                if( $aFileContent['general']['isOrphan'] ) continue;
                if( is_array($aFileContent[$tablename]['fields']) ) {
                    foreach( $aFileContent[$tablename]['fields'] as $fieldName => $rs ){
                            $oldNewValue = isset($rs['csvValue']) ? $rs['csvValue']: '';
                            $newValue = $this->applyRoleToField( $aFileContent , $index , $tablename , $fieldName , $oldNewValue );
                            $aNewFileContents[$index][$tablename]['fields'][$fieldName]['calcValue'] = $newValue;
                            $aNewFileContents[$index][$tablename]['fields'][$fieldName]['calcRoule'] = $this->appliedRoules[ $index ][ $tablename ][$fieldName];
                    }
                }
            }
        }
        return $aNewFileContents;
    }

    
    /**
    * applyRouleToAllAndCalculateOrphans
    * this method calculates values with aggregate-methods based on one ore more fields in all rows of child-csv-table
    * only used in orphan mode
    * works with domFormattedFieldNames
    * 
    * @param array $aNewFileContents  
    * @param array $configTable  
    * @return array
    */
    Public function calculateOrphansAndApplyRoule( $aNewFileContents , $configTable )
    {

        if( !is_array( $this->settings['aggregateFunction']['orphan'] ) ) return $aNewFileContents;
        
        $toTable = $this->settings['aggregateFunction']['orphan']['parentTable'];
        $fromTable = $this->settings['aggregateFunction']['orphan']['childTable'];
        $aUsedFields = $this->settings['aggregateFunction']['orphan']['calcFields'];
        
        // Apply orphan role
        foreach( $aUsedFields as $sqlFieldname => $aFldConf ){
                $toFieldName = GeneralUtility::underscoredToLowerCamelCase( $sqlFieldname );
            
                foreach( $aNewFileContents as $index => $aFileContent){
                    
                    if( !isset( $aFileContent[ $fromTable ]['values']['csv'] ) ) continue; // no source $fromTable['values'] for target $toTable
                
                    $calcValue = '';
                    $method = 'aggregate_' . $aFldConf['function'];
                    if( method_exists( $this->importfunctionsUtility , $method ) ){
                        $calcValue = $this->importfunctionsUtility->$method(  $aFileContent[ $fromTable ]['values']['csv']  , $aFldConf['parameterFields'] );
                    }
                    if( $calcValue ) $aNewFileContents[$index][$toTable]['fields'][$toFieldName]['csvValue'] = $calcValue;
                    $newValue = $this->applyRoleToField( $aFileContent , $index , $toTable , $toFieldName , $calcValue );
                    $aNewFileContents[$index][$toTable]['fields'][$toFieldName]['calcValue'] = $newValue;
                    $aNewFileContents[$index][$toTable]['fields'][$toFieldName]['calcRoule'] = $this->appliedRoules[ $index ][ $toTable ][$toFieldName];

                }
            
        }
        
        return $aNewFileContents;
    }

    /**
    *  applyRoleToField
    *   returns the new csvValue
    *   
    *   for later import-procedures:
    *   if csvValue == dbValue then do nothing
    *
    * @param array $aFileContent  
    * @param string $registerIndex  
    * @param string $toTable
    * @param string $toFieldName
    * @param string $calcValue
    * @return string
    */
    Private function applyRoleToField( $aFileContent , $registerIndex , $toTable , $toFieldName , $calcValue )
    {
            // for new records alway accept new value (role 3 = override)
            if(	!isset($aFileContent[ $toTable ]['table']['dbUid']) && $this->settings['tables'][$toTable]['alwaysCheckNew'] ){
                $roule = 3;
            }else{
                $roule = isset( $aFileContent[ $toTable ]['fields'][$toFieldName]['importaction'] ) ? $aFileContent[ $toTable ]['fields'][$toFieldName]['importaction'] : 0;
            }
            $oldValue = isset( $aFileContent[ $toTable ]['fields'][$toFieldName]['dbValue'] ) ? $aFileContent[ $toTable ]['fields'][$toFieldName]['dbValue'] : '';

            if( $calcValue == 'NULL' ) $calcValue = '';

            $successfull = $this->applyRoleToValues( $roule , $oldValue , $calcValue );
            
            // register this roule-setting for later usage
            $this->appliedRoules[ $registerIndex ][ $toTable ][$toFieldName] = $successfull ? 10+$roule : 0;
            
            // return new-value if successed, old-value if failed
            return $successfull ? $calcValue : $oldValue;
    }
    
    /**
    *  applyRoleToValues
    *   returns boolean
    *
    * @param int $roule  
    * @param string $oldValue
    * @param string $calcValue
    * @return boolean
    */
    Private function applyRoleToValues( $roule , $oldValue , $calcValue  )
    {
            $successfull = true; // default is calcValue
            
            if( empty( $roule ) ){ // nichts
                $successfull = false;
                
            }elseif( $roule == 1 ){ // leere befuellen
                $successfull = empty($oldValue) && !empty($calcValue) ? true : false;
                
            }elseif( $roule == 2 ){ // mit werten ueberschreiben
                $successfull = empty($calcValue) ? false : true;
                
            } // 3 = auch leere: feld ueberschreiben $successfull = true
            
            return $successfull;
            
    }

    /**
    *  getConfigTsFieldMapping
    *
    * @return array with [ tablename ][ domFormattedFieldnames ]
    */
    Public function getConfigTsFieldMappingLowerCamelCase()
    {
        $enrichedFields = $this->getConfigTsFieldMapping();
        $configTable = [];
        foreach( $enrichedFields as $tablename => $aMapFields){
            foreach( $aMapFields as $aNam => $fldRow ){
                foreach( $fldRow as $sql_field_name => $content ){
                        $fieldName = GeneralUtility::underscoredToLowerCamelCase($sql_field_name);
                        if( !is_array($content) ){
                            $configTable[$tablename][$aNam][$fieldName] = $content;
                        }else{
                            foreach( $content as $cnt_key  => $aCntValue ){
                                $aCntKey = GeneralUtility::underscoredToLowerCamelCase($cnt_key);
                                $configTable[$tablename][$aNam][$fieldName][$aCntKey] = $aCntValue;
                            }
                        }
                }
            }
        }
        return $configTable;
    }

    /**
    *  getConfigTsFieldMapping
    *  Enriches TsFieldMapping with info about existing recordset , importaction and if roule is mandatory/optional.
    *  Fuses settings from TSconfig and recorsets from Config-Model.
    * 
    * returns:
    * - $enrichedFields[tablename]['table'][ conf_uid | importaction | no_checkbox ]
    * - $enrichedFields[tablename]['fields'][sql_formatted_fieldnames][ conf_uid | importaction | source ]
    *
    * @return array with [ tablename ][ sql_formatted_fieldnames ]
    */
    public function getConfigTsFieldMapping()
    {
        // get stored definitions for fields
        $confFields = $this->configRepository->findByOption2( '0' );
        foreach( $confFields as $confRecord ){
                $tableName = LocalizationUtility::translate( 'tx_sfgzkurs_domain_model_config.option1.dom.' . $confRecord->getOption1() , 'SfgzKurs' );
                $sql_field_name = $confRecord->getFieldname();
                $config['field'][strtolower($tableName)][$sql_field_name] = [ 'conf_uid'=>$confRecord->getUid() , 'action'=>$confRecord->getFieldvalue() ];
        }
        // get stoerd definitions for tables
        $erzwingen = LocalizationUtility::translate( 'tx_sfgzkurs_domain_model_config.fieldname.sel.1' , 'SfgzKurs' ) ;
        $confTables = $this->configRepository->findByOption2( '1' );
        foreach( $confTables as $confRecord ){
                $tableName = LocalizationUtility::translate( 'tx_sfgzkurs_domain_model_config.option1.dom.' . $confRecord->getOption1() , 'SfgzKurs' );
                $forceImport = $confRecord->getFieldname();
                $config['table'][strtolower($tableName)] = [ 'conf_uid' => $confRecord->getUid() , 'importaction' => $confRecord->getFieldvalue() , 'no_checkbox' => $forceImport == $erzwingen ? 1 : 0 ];
        }
        
        // get definitions from TS ($clearedFieldMapping) and enrich it with config stored in database ($config['table']) and ($config['field'])
        foreach($this->settings['tables']  as $tablename => $aTabConf ){
                
                // do not import table with autoimport==1 like calendar
                if( $this->settings['sourceFiles'][ $aTabConf['sourceFile'] ]['autoimport'] ) continue;
                
                // enrich table definition
                $enrichedFields[$tablename]['table'] = isset($config['table'][$tablename]) ? $config['table'][$tablename]: [ 'conf_uid'=>'' , 'importaction' => $this->settings['afforedRecordsets']['config'][$tablename]['fieldvalue'] , 'no_checkbox' => $this->settings['afforedRecordsets']['config'][$tablename]['fieldname']];
                $enrichedFields[$tablename]['table']['alwaysCheckNew'] = $aTabConf['alwaysCheckNew'];
                
                // enrich fields definition
                if( !is_array( $aTabConf['mapFields'] ) ) continue;
                foreach( $aTabConf['mapFields'] as $fieldname => $fldDef ){
                        //if( !isset($fldDef['source']) ) continue;
                        $action = isset($config['field'][$tablename][$fieldname]) ? $config['field'][$tablename][$fieldname]['action'] : $enrichedFields[$tablename]['table']['importaction'] ;
                        $enrichedFields[$tablename]['fields'][$fieldname]['importaction'] = $action;
                        if( isset($fldDef['postImportFunction']) && $fldDef['source']==NULL ){
                            $enrichedFields[$tablename]['fields'][$fieldname]['source'] = $fldDef['postImportFunction']['function'].'('.(isset($fldDef['postImportFunction']['parameterFields'])?$fldDef['postImportFunction']['parameterFields']:$fldDef['postImportFunction']['parameters']).')';
                        }else{
                            $enrichedFields[$tablename]['fields'][$fieldname]['source'] = $fldDef['source'];
                        }
                        if( isset($config['field'][$tablename][$fieldname]['conf_uid']) ) {
                            $enrichedFields[$tablename]['fields'][$fieldname]['conf_uid'] = $config['field'][$tablename][$fieldname]['conf_uid']; 
                        }
                        if( isset($fldDef['fieldType']) ) {
                            $enrichedFields[$tablename]['fields'][$fieldname]['fieldType'] = $fldDef['fieldType']; 
                        }else{
                            $enrichedFields[$tablename]['fields'][$fieldname]['fieldType'] = '-'; 
                        }
                }
        }
        
        // append aggreagate functions to table 'orphan'
        foreach($this->settings['aggregateFunction']  as $tablename => $aTabConf ){
                $enrichedFields[$tablename]['table'] = isset($config['table'][$tablename]) ? $config['table'][$tablename]: [ 'conf_uid'=>'' , 'importaction' => $this->settings['afforedRecordsets']['config'][$tablename]['fieldvalue'] , 'no_checkbox' => $this->settings['afforedRecordsets']['config'][$tablename]['fieldname']];
                foreach( $aTabConf['calcFields'] as $fieldname => $fldConf ){
                        $action = isset($config['field'][$tablename][$fieldname]) ? $config['field'][$tablename][$fieldname]['action'] : $enrichedFields[$tablename]['table']['importaction'] ;
                        $enrichedFields[$tablename]['fields'][$fieldname]['importaction'] = $action;
                        if( isset($config['field'][$tablename][$fieldname]['conf_uid']) ) {
                            $enrichedFields[$tablename]['fields'][$fieldname]['conf_uid'] = $config['field'][$tablename][$fieldname]['conf_uid']; 
                        }
                        $enrichedFields[$tablename]['fields'][$fieldname]['source'] = $fldConf['function'] . '('.$fldConf['parameterFields'].')';
                }
        }
        return $enrichedFields;
    }

    /**
    *  getStringFromObjectBySqlFieldname
    *  read from object
    *
    * @return array
    */
    public function getStringFromObjectBySqlFieldname( $obj , $fieldname , $tablename)
    {
            // handle obj as ARRAY
            if( is_array($obj) ){
                if( isset($obj[$fieldname]) ) return $obj[$fieldname];
                // cant read array, maybe deeper dimension eg. $obj[ someIndex ][$fieldname]
                return false;
            }
            
            // handle obj as OBJECT
            $objFunction = 'get' . ucFirst($fieldname);
            
            if( !method_exists( $obj , $objFunction ) ){
                $this->flashMessages[] = 'getStringFromObjectBySqlFieldname: Method to get content from field "'.$fieldname.'" missing!';
                return false;
            }
            
            // get value from field in object
            $objectValue = $obj->$objFunction();
            
            if( !$objectValue ) return $objectValue;
            
            // If a specific format for this field is defined in ts,
            // then convert. But only date-formats are supported yet (de + en).
            $sqlFieldname = GeneralUtility::camelCaseToLowerCaseUnderscored($fieldname);
            $convertedValue = $this->objectToDatestring( $objectValue , $sqlFieldname , $tablename );
            
            return $convertedValue;
    }

    /**
    *  objectToDatestring
    *  read from object
    *
    * @param mixed $obj object or string
    * @param string $sqlFieldname
    * @param string $tablename
    * @return string
    */
    public function objectToDatestring( $obj , $sqlFieldname , $tablename )
    {
            if( is_string($obj) ) return $obj;
// 			if( empty( $obj ) ) return $obj;
            
            $fieldType = $this->settings['tables'][$tablename]['mapFields'][$sqlFieldname]['fieldType'];
            
            if( $fieldType == 'date' ){
                $convertedValue = $obj->format( 'Y-m-d' );
            }else{
                $convertedValue = $obj;
            }
            return $convertedValue;
    }

    /**
    *  initiateConfigurationTable
    *
    * @return array
    */
    public function initiateConfigurationTable()
    {
//         $this->initiate_SanitizeConfigRecords( 0 );

        // get definitions for tables stored in db
        $exisitingRecord = $this->initiate_SanitizeConfigRecords( 1 );
        $lastNewSort = is_array($exisitingRecord) && count($exisitingRecord) ? max($exisitingRecord) : 0; // force integer value
        
        $newSort = ceil( $lastNewSort / 100 ) * 100;

        // evaluate affored tables from settings
        $added = 0;
        foreach( $this->settings['afforedRecordsets']['config'] as $tablename => $defaultImportOptions ){
            $tableNumber =  $this->tablename2number($tablename) ;
            if( strlen($tableNumber) <1 ) continue;
            if( isset( $exisitingRecord[$tableNumber] ) ) continue;
            $newSort += 100;
            $llIndex = $defaultImportOptions['fieldname']==1 ? 1 : 0;
            $no_checkbox = LocalizationUtility::translate( 'tx_sfgzkurs_domain_model_config.fieldname.sel.' . $llIndex , 'SfgzKurs' );
            // add new config for table tableNumber
            $objConf = GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\Config');
            // insert new values
            $objConf->_setProperty( 'fieldname' , $no_checkbox );
            $objConf->_setProperty( 'fieldvalue' , $defaultImportOptions['fieldvalue'] );
            $objConf->_setProperty( 'option1' , $tableNumber );
            $objConf->_setProperty( 'option2' , $defaultImportOptions['option2'] );
            $objConf->_setProperty( 'sorting' , $newSort );
            $objConf->_setProperty( 'pid' , $this->settings['pageUid']['storagePid'] );
            
            $this->configRepository->add( $objConf );
            $this->flashMessages[] = 'created: Config for table "'.$tablename.'"';
            $added +=1;
        }
        if( $added ) $this->persistenceManager->persistAll();
        return $exisitingRecord;
    }

    /**
    *  initiate_SanitizeFieldsConfiguration
    *
    * @param int $recordType default is 0 (fields-definition) [ 0 (fields) | 1 (tables) ]
    * @return array
    */
    public function initiate_SanitizeConfigRecords( $recordType = 0 )
    {
        // get definitions for fields stored in db
        $sortingRecord = [];
        $confTables = $this->configRepository->findAll();
        foreach( $confTables as $idx => $confRecord ) {
            $pgUid = $confRecord->getPid();
            if( $pgUid != $this->settings['pageUid']['storagePid'] ) continue;
            $fieldType = $confRecord->getOption2();
            if( $fieldType != $recordType ) continue;
            $tableNumber = $confRecord->getOption1();
            $sortingRecord[ $tableNumber ] = $confRecord->getUid();
        }
        return $sortingRecord;
    }

    /**
    *  updateConfTypeField
    *  json edit action
    *
    * @param string $tablename
    * @param string $fieldname
    * @param string $fieldvalue
    * @return array
    */
    public function updateConfTypeField( $tablename , $fieldname , $fieldvalue )
    {
        $tableNr = $this->tablename2number($tablename);
        // find where option2:0 AND option1:tableNr AND fieldname:fieldname
        if( strtolower($fieldname) != $fieldname ){
            // convert camelCaseFieldName to sql_field_name
            $fieldname = GeneralUtility::camelCaseToLowerCaseUnderscored($fieldname);
        }
        $confRecords = $this->configRepository->findByOption1andOption2andFieldname( $tableNr , '0' , $fieldname );
        $isRec = 0;
        if( $confRecords ){
            foreach( $confRecords as $firstFoundRecord){
                $isRec = $firstFoundRecord->getUid();
                break;
            }
        }

        // update fieldvalue or add record or remove record
        
        if( $fieldvalue == 4 ){
            // remove record if exists
            if( !empty($isRec) ){
                $this->configRepository->remove( $firstFoundRecord );
            }
        }else{
            if( !empty($isRec) ){
                // update fieldvalue
                $firstFoundRecord->setFieldvalue( $fieldvalue );
                $this->configRepository->update( $firstFoundRecord );
            }else{
                // add new config for field fieldname
                $lastMax = $this->getMaxSortNr( $tableNr  );
                $maxSortNr = ceil( $lastMax / 2 ) * 2;
                $objConf = GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\Config');
                // insert new values
                $objConf->_setProperty( 'fieldname' , $fieldname );
                $objConf->_setProperty( 'fieldvalue' , $fieldvalue );
                $objConf->_setProperty( 'option1' , $tableNr );
                $objConf->_setProperty( 'option2' , '0' );
                $objConf->_setProperty( 'sorting' , $maxSortNr + 2 );
                $objConf->_setProperty( 'pid' , $this->settings['pageUid']['storagePid'] );
                
                $this->configRepository->add( $objConf );
            }
        }
        
        $this->persistenceManager->persistAll();
        $GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        
        $response = $fieldvalue == 4 ? 'remove' : ' fieldname:' . $fieldname . '  fieldvalue:' . $fieldvalue . '';
        return 'configUtility->updateConfTypeField-OK-uid:'. $isRec .'-' . $response . '-END';
    }

    /**
    *  updateConfTypeTable
    *  json edit action
    *
    * @param string $tablename
    * @param string $confField name of the field in database [ 'fieldname' | 'fieldvalue' ]
    * @param string $confValue boolean for 'fieldname' [ false: Nachfragen | true: Erzingen ] OR fieldvalue (0...7 from input-select)
    * @return array
    */
    public function updateConfTypeTable( $tablename , $confField , $confValue )
    {
        $tableNr = $this->tablename2number($tablename);
        if( $confField == 'fieldname' ){
//          checkbox 'Regel erzwingen' [ true | false ]
            $aLL = [ 'false' => 0 , 'true' => 1 ];
            //false => Nachfragen | true => Erzwingen
            $oldValue = $confValue ? 0 : 1;
            $oldConfValue = LocalizationUtility::translate( 'tx_sfgzkurs_domain_model_config.fieldname.sel.' . $aLL[ $oldValue ] , 'SfgzKurs' ) ;
            $newConfValue = LocalizationUtility::translate( 'tx_sfgzkurs_domain_model_config.fieldname.sel.' . $aLL[ $confValue ] , 'SfgzKurs' ) ;
            // where 'fieldname' == $oldConfValue and option1==$tableNr , option2 ==1
            $confRecords = $this->configRepository->findByOption1andOption2andFieldname( $tableNr , '1' , $oldConfValue);
            
        }elseif( $confField == 'fieldvalue' ){
            // default action for table [0-3]
            $newConfValue = $confValue;
            $confRecords = $this->configRepository->findByOption1andOption2andFieldname( $tableNr , '1' );
            
        }else{
            return 'Error configUtility->updateConfTypeTable: confField "' . $confField . '" not found.';
        }

        // find where option1:tableNr AND option2:1 = record for table-wide options 
        $isRec = 0;
        if( $confRecords ){
            foreach( $confRecords as $firstFoundRecord){
                $isRec = $firstFoundRecord->getUid();
                break;
            }
        }
        if( $isRec ){
            // update fieldname or fieldvalue to confValue
            $proc = 'set' . ucFirst($confField) ;
            $firstFoundRecord->$proc( $newConfValue );
            $this->configRepository->update( $firstFoundRecord );
            $this->persistenceManager->persistAll();
            $GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
            $ex = count($this->exisitingRecord) ? implode( ', ' , array_keys( $this->exisitingRecord )) : 0;
            return 'configUtility->updateConfTypeTable-OK-tablename('. $tablename  . ')-tableNr('. $tableNr  . ')-confField(' . $confField . ')-confValue(' . $confValue . ')-fieldvalue(' . $newConfValue . ')-exist(' . $ex . ')-END';
        }else{
            // record for this table does not exists
            // this should never happen since we run initiateConfigurationTable() in construct()
            return 'configUtility->updateConfTypeTable-ERROR-field:' . $confField . '-fieldvalue=' . $newConfValue . '-END';
        }

    }
    

    /**
    * helper getMaxSortNr
    * returns the maxSort of filtered records
    *
    * @param string option1 
    * @param string option2
    * @return void
    */
    public function getMaxSortNr( $option1 , $option2 = '' )
    {
            $maxSortNr = 0;
            $aSrt = [];
            if( strlen($option2) <1 ) {
                $sameTableFieldRecords = $this->configRepository->findByOption1( $option1 );
            }else{
                $sameTableFieldRecords = $this->configRepository->findByOption1andOption2andFieldname( $option1 , $option2 );
            }
            foreach( $sameTableFieldRecords as $loopObjConf ){
                    $aSrt[] = $loopObjConf->getSorting();
            }
            $maxSortNr = count($aSrt) ? max($aSrt) : 0;
            return $maxSortNr;
    }
    

    /**
    * helper tablename2number
    * translate tablenames to numbers
    *
    * @param string $table 
    * @return void
    */
    public function tablename2number( $table )
    {
        for( $z = 0 ; $z <= 10; ++$z ){
            $tablename = LocalizationUtility::translate( 'tx_sfgzkurs_domain_model_config.option1.dom.' . $z , 'SfgzKurs' );
            if( $table == $tablename ) return $z;
            if( empty($tablename) ) break;
        }
        return false;
    }
    
    
}
