<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class SettingsUtility
 * 
 * 
 */
 
class SettingsUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * array dbInfo
	 */
	protected $dbInfo = null;

	/**
	 * array fullsettings
	 */
	protected $fullsettings = null;

	/**
	 * array settings
	 */
	protected $settings = null;

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_lst';
    
    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     */
    protected $kursRepository = null;

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
	
		$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$this->fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);

		$this->typoScriptService =  $this->objectManager->get('TYPO3\\CMS\\Extbase\\Service\\TypoScriptService');
		
	}
	
    /**
     *  getSettings
     *
     * @param string $pluginKey optional
     * @return array
     */
	Public function getSettings( $pluginKey = '' )
	{
			if( empty($pluginKey) ) $pluginKey = $this->pluginKey;
			$this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($this->fullsettings['plugin.'][ $pluginKey . '.' ]['settings.']);
			return $this->enrich_with_sql_info();
	}
	
    /**
     *  enrich_with_sql_info
     *
     * @return array
     */
	Protected function enrich_with_sql_info()
	{
			if( !isset($this->settings['tables']) ) return $this->settings;
			
			$this->dbInfo = $this->getSqlInfo();
			if( !count($this->dbInfo) ) return $this->settings;
			
			foreach($this->dbInfo as $tablename => $fieldTypes ){
					if( !isset($this->settings['tables'][$tablename]) || !isset($this->settings['tables'][$tablename]['mapFields']) ) continue;
					foreach( $this->settings['tables'][$tablename]['mapFields'] as $sql_fieldname => $fldConf ){
							// is there a new definition and is datatype not already set for this field?
							if( isset($fieldTypes[$sql_fieldname]) && !isset($fldConf['fieldType']) ) {
								$this->settings['tables'][$tablename]['mapFields'][$sql_fieldname]['fieldType'] = $fieldTypes[$sql_fieldname];
							}
					}
			}
			
			return $this->settings;
	}
	
    /**
     *  getSqlInfo
     *
     * @return array
     */
	Protected function getSqlInfo()
	{
			$this->kursRepository = $this->objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\KursRepository');
			
			$dbInfo['kurs']          = $this->kursRepository->dbInfo( 'tx_sfgzkurs_domain_model_kurs' );
			$dbInfo['version']       = $this->kursRepository->dbInfo( 'tx_sfgzkurs_domain_model_version' );
			$dbInfo['durchfuehrung'] = $this->kursRepository->dbInfo( 'tx_sfgzkurs_domain_model_durchfuehrung' );
			$dbInfo['lektion']       = $this->kursRepository->dbInfo( 'tx_sfgzkurs_domain_model_lektion' );
			
			$fieldTypes = [];
			foreach($dbInfo as $tablename => $tabbody ){
				foreach($tabbody as $row ){
						$typeSplit = explode( '(' , $row['Type'] );
 						$fieldTypes[$tablename][ $row['Field'] ] = $typeSplit[0];
				}
			}
			return $fieldTypes;
	}
	
    /**
     *  getPersistence
     *  returns a array with 1 single element, the storagePid: [ storagePid => int ]
     *
     * @param string $pluginKey optional
     * @return array
     */
	Public function getPersistence( $pluginKey = '' )
	{
			if( empty($pluginKey) ) $pluginKey = $this->pluginKey;
			$persistence = $this->typoScriptService->convertTypoScriptArrayToPlainArray($this->fullsettings['plugin.'][ $pluginKey . '.' ]['persistence.']);
			return $persistence;
	}
	
    /**
     *  getDbInfo
     *
     * @param string $tablename optional
     * @param string $sql_fieldname optional
     * @return array
     */
	Public function getDbFieldType( $tablename  = '' , $sql_fieldname = '' )
	{
			// perhaps this method is runned without (or bevore) the call to get settings...
			if( !count($this->dbInfo) ) $dummy = $this->getSettings();
			
			if( $tablename && $sql_fieldname ) {
				// return the info about a specific field
				$fieldType = $this->dbInfo[$tablename][$sql_fieldname];
				
			}elseif( $tablename ){
				// return the info about all fields of a table
				$fieldType = $this->dbInfo[$tablename];
				
			}else{
				// return the info about all fields in all tables
				$fieldType = $this->dbInfo;
			}
			
			// if still not set, then retrieve the value from ts-setting 
			// prevent NULL: if not set then return a empty string.
			if( empty($fieldType) ){
				$fieldType =  !isset($this->settings['tables'][$tablename]['mapFields'][$sql_fieldname]['fieldType']) ? '' : $this->settings['tables'][$tablename]['mapFields'][$sql_fieldname]['fieldType'];
			}
			
			return $fieldType;
	}
	
    /**
     *  getPluginKey
     *
     * @return string
     */
	Public function getPluginKey()
	{
			return $this->pluginKey;
	}
	
    /**
     *  setPluginKey
     *
     * @param string $pluginKey
     * @return void
     */
	Public function setPluginKey( $pluginKey  )
	{
			$this->pluginKey = $pluginKey;
	}

}
