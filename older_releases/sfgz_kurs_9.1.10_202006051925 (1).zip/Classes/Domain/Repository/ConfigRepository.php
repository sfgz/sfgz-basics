<?php
namespace Sfgz\SfgzKurs\Domain\Repository;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * The repository for Config
 */
class ConfigRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    /**
     * @var array
     */
    protected $defaultOrderings = array(
        'option2' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_DESCENDING,
        'option1' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING,
        'sorting' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING,
        'fieldname' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
    );

	  /**
	  *  findByOption1andOption2andFieldname
	  *  Find data from config by 
	  *  option2 AND option1 AND (optional)fieldname
	  * 
	  */
	  public function findByOption1andOption2andFieldname( $option1 , $option2 , $fieldname = '' ) {
	      
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setIgnoreEnableFields(FALSE);
 	      $querySettings->setRespectStoragePage(FALSE);
	      $this->setDefaultQuerySettings($querySettings);
	      
	      $query = $this->createQuery();
	      if(!empty($fieldname)){
			$query->matching(
				$query->logicalAnd(
					$query->equals('option1', $option1 ),
					$query->equals('option2', $option2 ),
					$query->equals('fieldname', $fieldname )
				)
			);
	      }else{
			$query->matching(
				$query->logicalAnd(
					$query->equals('option1', $option1 ),
					$query->equals('option2', $option2 )
				)
			);
	      }
	      return $query->execute();
	  }
}
