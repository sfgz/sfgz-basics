<?php
namespace Sfgz\SfgzKurs\Domain\Repository;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * The repository for Version
 */
class VersionRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    /**
     * @var array
     */
    protected $defaultOrderings = array(
        'version_start' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
    );
	
	/**
	 * findNewest
	 * or find newest until given date (eg. actual valid version)
	 *
	 * @param int    $parentsUidValue
	 * @param string $maxDate english datestring yyyy.mm.dd
	 * @param string $parentsUidFieldname optional, default fieldname is 'kurs' 
	 * @param array  $where optional, additional andWhere eg. $where = [ 'deleted=0' , 'hidden=0' ]
	 * @param string $fields optional, additional fields as comma separed list eg. 'deleted,hidden'
	 * @param string $dateField optional, default 'version_start'
	 * @param string $table optional, default 'tx_sfgzkurs_domain_model_version'
	 * @return void
	 */
	public function findNewest( $parentsUidValue , $maxDate='' , $parentsUidFieldname = 'kurs' , $where = array() , $fields = '' , $dateField = 'version_start' , $table = 'tx_sfgzkurs_domain_model_version'  ){

			$aSelfields = empty($fields) ? array() : explode( ',' , $fields );
			$aSelfields[] = 'uid';
			$aSelfields[] = $dateField;
			$aSelfields[] = $parentsUidFieldname;
			foreach( $aSelfields as $fld) $aFields[trim($fld)] = trim($fld);
			
			$dateWhere = strlen($maxDate) ? ' AND t2.' . $dateField . ' <= "' . $maxDate . '"' : '';
			
			$sqlStatement = 'SELECT ' . implode( ', ' , $aFields ) ;
			$sqlStatement .= ' FROM ' . $table . ' t1';
			$sqlStatement .= ' WHERE ' . $dateField . ' = (SELECT MAX(CAST(t2.' . $dateField . ' AS CHAR)) FROM ' . $table . ' t2 WHERE t1.' . $parentsUidFieldname . ' = t2.' . $parentsUidFieldname . $dateWhere . ')';
			$where[] = $parentsUidFieldname . ' = ' . $parentsUidValue;
			foreach( $where as $whereClause ) $sqlStatement .= ' AND ' . $whereClause ;
	      // execute sql-statement
	      return $this->callSqlStatement( $sqlStatement . ';' , TRUE );
	
	}

	/**
	 * @param $qryStatement
	 * @param $ReturnRawQueryResult
	 * @return void
	 */
	public function callSqlStatement($qryStatement, $ReturnRawQueryResult = TRUE) {
		$Query = $this->createquery();
		$Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
		$Query->getQuerySettings()->setRespectStoragePage(FALSE);
		$Query->statement($qryStatement);
		return $Query->execute($ReturnRawQueryResult);
	}

	  /**
	  *  Find data from Version with 
	  *  'kursId' and 
	  *  'version_start' equal today or later
	  * 
	  */
	  public function findeAbDatumMitKursId( $dateNow=0 , $kursId ) {// FIXME: todo dr 3.6.2018
	      if(empty($dateNow)) $dateNow = date( 'Y-m-d' ) . 'T04:00:00' ;
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setIgnoreEnableFields(FALSE);
 	      $querySettings->setRespectStoragePage(FALSE);
	      $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      $query->matching(
		    $query->logicalAnd(
				$query->equals('kurs', $kursId ),
			    $query->greaterThanOrEqual('version_start', $dateNow )
		    )
	      );
	      return $query->execute();
	  }
}
