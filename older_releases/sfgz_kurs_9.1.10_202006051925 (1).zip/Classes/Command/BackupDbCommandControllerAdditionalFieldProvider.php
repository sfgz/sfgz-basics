<?php
namespace Sfgz\SfgzKurs\Command;

 /** 
 * Class BackupDbCommandControllerAdditionalFieldProvider
 * 
 * 
 * 
 */
 
class BackupDbCommandControllerAdditionalFieldProvider implements \TYPO3\CMS\Scheduler\AdditionalFieldProviderInterface {
        
        public function getAdditionalFields(array &$taskInfo, $task, \TYPO3\CMS\Scheduler\Controller\SchedulerModuleController $parentObject) 
        {

            $additionalFields = array();
            foreach( [ 'sfgzkurs_backupEmails_kurs' , 'sfgzkurs_backupEmails_display' ] as $fieldname ){
                    // Initialize extra field value
                    if (empty($taskInfo[$fieldname])) {
                        if ($parentObject->CMD == 'add') {
                            // In case of new task and if field is empty
                            $taskInfo[$fieldname] = '';

                        } elseif ($parentObject->CMD == 'edit') {
                                // In case of edit, and editing a test task, set to internal value if not data was submitted already
                            $taskInfo[$fieldname] = $task->$fieldname;
                        } else {
                                // Otherwise set value.
                            $taskInfo[$fieldname] = '';
                        }
                    }
                    
                    $aNameParts = explode( '_' , $fieldname );
                    
                    // Write the code for the field
                    $fieldID = 'task_' . $fieldname;
                    $fieldCode = '<input type="text" name="tx_scheduler[' . $fieldname . ']" id="' . $fieldID . '" value="' . $taskInfo[$fieldname] . '" size="50" />';
                    $additionalFields[$fieldID] = array(
                        'code'     => $fieldCode,
                        'label'    => 'Emailadresse Backup ' . array_pop($aNameParts)
                    );
            }
            return $additionalFields;
        }
        
    /**
        * This method checks any additional data that is relevant to the specific task
        * If the task class is not relevant, the method is expected to return true
        *
        * @param	array					$submittedData: reference to the array containing the data submitted by the user
        * @param	\TYPO3\CMS\Scheduler\Controller\SchedulerModuleController $parentObject: reference to the calling object (Scheduler's BE module)
        * @return	boolean					True if validation was ok (or selected class is not relevant), false otherwise
        */
        public function validateAdditionalFields(array &$submittedData, \TYPO3\CMS\Scheduler\Controller\SchedulerModuleController $parentObject) 
        {
            return true;
        }
        
        public function saveAdditionalFields(array $submittedData, \TYPO3\CMS\Scheduler\Task\AbstractTask $task) 
        {
            $task->sfgzkurs_backupEmails_kurs = $submittedData['sfgzkurs_backupEmails_kurs'];
            $task->sfgzkurs_backupEmails_display = $submittedData['sfgzkurs_backupEmails_display'];
            $task->sfgzkurs_backupMailFooter = $submittedData['sfgzkurs_backupMailFooter'];
        }
}
