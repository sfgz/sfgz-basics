<?php
namespace Sfgz\SfgzKurs\ViewHelpers\Form;

/**
* View Helper which creates a text field (<input type="text">).
* 
* Use special function for converting to date after submit
* e.g. 
* $arg = $this->arguments['durchfuehrung']->getPropertyMappingConfiguration();
* $arg->forProperty('durchfuehrungStart')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
* 
* 
* = Examples =
* 
* on top of template or partial: 
* {namespace sfgz = Sfgz\SfgzKurs\ViewHelpers}
* 
* 1.
* <code title="Example with name and value">
* <mff:form.datepicker name="myDate" value="16.07.1993" />
* </code>
*
* <output title="Example with name and value">
* <input type="text" name="myDate" value="16.07.1993" />
* </output>
*
* 2.
* <code title="Example with property and form">
* <mff:form.datepicker property="myDate" form="myForm" /> ( property-value = 1519226001 )
* </code>
*
* <output title="Example with property and form">
* <input type="text" name="myExtension[myForm][myDate]" value="21.02.2018" />
* </output>
*
*/

class DatepickerViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper {
    
    /**
    * @var string
    */
    protected $tagName = 'input';
    
    /**
    * @var string
    */
    protected $dateFormat = 'd.m.Y';

    /**
    * Initialize the arguments.
    *
    * @return void
    * @api
    */
    public function initializeArguments() {
        parent::initializeArguments();
        $this->registerArgument('form','string','als Beispiel kalender',FALSE);
        $this->registerArgument('wrap','string','als Beispiel div',FALSE);
        // registerArgument( $name ,  $type , $description , $required = false , $defaultValue = null )
    }
    
    /**
    * Renders the textfield.
    *
    * @param boolean $required If the field is required or not
    * @param string $type The field type, e.g. "text", "email", "url" etc.
    * @return string
    * @api
    */
    public function render($required = NULL, $type = 'text') {
        $name = $this->getName();
        
        $form = $this->arguments['form'] !== NULL ? $this->arguments['form'] : $this->viewHelperVariableContainer->get('TYPO3\\CMS\\Fluid\\ViewHelpers\\FormViewHelper', 'formObjectName');
        
        $field = $this->arguments['property'] !== NULL ? $this->arguments['property'] : $this->arguments['name'];
        
        $css = $this->arguments['class'] !== NULL ? $this->arguments['class'] : '';
        
        $style = $this->arguments['style'] !== NULL ? $this->arguments['style'] : '';

        $wrap = $this->arguments['wrap'] !== NULL ? $this->arguments['wrap'] : 'div';
        
        $dateValue = $this->getValueAttribute();
        
        if ($required !== NULL) $this->tag->addAttribute('required', 'required');
        if ( is_object($dateValue) ){
            $this->tag->addAttribute('value', $dateValue->format('d.m.Y'));
        }elseif(!empty($dateValue) ){
            $this->tag->addAttribute('value', $dateValue);
        }else{
            $this->tag->addAttribute('value', '');
        }
        $this->tag->addAttribute('type', $type);
        $this->tag->addAttribute('name', $name);
        $this->tag->addAttribute( 'id' , ($this->arguments['id'] !== NULL ? $this->arguments['id'] : $field) );
        if( $this->arguments['size'] == NULL ) $this->tag->addAttribute( 'size' , 8 );
        if( $css ) $this->tag->addAttribute( 'class' , $css );
        
        $this->registerFieldNameForFormTokenGeneration($name);
        
        $this->setErrorClassAttribute();
        
        $jsText = $this->getJavaScript($field,$form);
        
        $renderedTag =  $jsText . $this->tag->render();

        if( empty($style) ){
            if( $wrap == 'div' ) $style = 'width:auto;float:left;white-space:nowrap;';
        }
    
        if( $wrap ){
            $wrappedTag = '<' . $wrap . ($css ? ' class="'.trim($css).'"':'') . ($style ? ' style="'.trim($style).'"' : '') . '>' . $renderedTag . '</' . $wrap . '>';
        }else{
            $wrappedTag = $renderedTag;
        }
        
        return $wrappedTag;
    }

    /**
    * Get the js part
    *
    * @param string $field name of the field e.g. datumbeginn
    * @return mixed
    */
    protected function getJavaScript($field,$form) {
        
        $jsText = '<div id="tcal'.$field.'" class="tcal"></div>';
        $jsText.= '<script language="JavaScript">';
        $jsText.= "new tcal ({'formname': '".$form."','controlname': '".$field."'});";
        $jsText.= '</script> ';
        return $jsText;
        
        // more possible Variables
        // $formObjectName = $this->viewHelperVariableContainer->get('TYPO3\\CMS\\Fluid\\ViewHelpers\\FormViewHelper', 'formObjectName');
        // $formObjectName_and_field = $this->getNameWithoutPrefix();
    }

}
