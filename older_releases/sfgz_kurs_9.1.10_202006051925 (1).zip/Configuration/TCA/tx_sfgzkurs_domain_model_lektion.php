<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_lektion',
        'label' => 'lehrperson_text',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
		'enablecolumns' => [
        ],
		'searchFields' => 'lektionenzahl,lektion_datum,zeit_von,zeit_bis,ort,zimmer,lehrer_eco_id,lehrperson_text',
        'iconfile' => 'EXT:sfgz_kurs/Resources/Public/Icons/tx_sfgzkurs_domain_model_lektion.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'lektionenzahl, lektion_datum, zeit_von, zeit_bis, ort, zimmer, lehrer_eco_id, lehrperson_text',
    ],
    'types' => [
		'1' => ['showitem' => 'lektion_datum, lektionenzahl, zeit_von, zeit_bis, ort, zimmer, lehrer_eco_id, lehrperson_text'],
    ],
    'columns' => [
        'lektionenzahl' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_lektion.lektionenzahl',
	        'config' => [
			    'type' => 'input',
			    'size' => 2,
			    'eval' => 'int'
			]
	    ],
	    'lektion_datum' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_lektion.lektion_datum',
	        'config' => [
			    'dbType' => 'date',
			    'type' => 'input',
			    'size' => 7,
			    'eval' => 'date',
			    'default' => '0000-00-00'
			]
	    ],
	    'zeit_von' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_lektion.zeit_von',
	        'config' => [
			    'type' => 'input',
			    'size' => 5,
			    'eval' => 'trim'
			],
	    ],
	    'zeit_bis' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_lektion.zeit_bis',
	        'config' => [
			    'type' => 'input',
			    'size' => 5,
			    'eval' => 'trim'
			],
	    ],
	    'ort' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_lektion.ort',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'zimmer' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_lektion.zimmer',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'lehrer_eco_id' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_lektion.lehrer_eco_id',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'lehrperson_text' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_lektion.lehrperson_text',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
        'durchfuehrung' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];
