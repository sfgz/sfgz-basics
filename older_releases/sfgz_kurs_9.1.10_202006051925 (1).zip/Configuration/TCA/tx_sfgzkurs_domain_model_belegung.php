<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_belegung',
        'label' => 'belegungstext',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
		'searchFields' => 'belegungstext,zeit_von,zeit_bis,raum,person',
        'iconfile' => 'EXT:sfgz_kurs/Resources/Public/Icons/tx_sfgzkurs_domain_model_belegung.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'belegungstext, zeit_von, zeit_bis, raum, person',
    ],
    'types' => [
		'1' => ['showitem' => 'belegungstext, zeit_von, zeit_bis, raum, person'],
    ],
    'columns' => [
	    'belegungstext' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_belegung.belegungstext',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'zeit_von' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_belegung.zeit_von',
	        'config' => [
			    'type' => 'input',
			    'size' => 5,
			    'eval' => 'trim'
			],
	    ],
	    'zeit_bis' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_belegung.zeit_bis',
	        'config' => [
			    'type' => 'input',
			    'size' => 5,
			    'eval' => 'trim'
			],
	    ],
	    'raum' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_belegung.raum',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'person' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sfgz_kurs/Resources/Private/Language/locallang_db.xlf:tx_sfgzkurs_domain_model_belegung.person',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
        'info' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];
