## optionally paste this in a new ts-template in the config part on the display page
## tx_sfgzkurs 
## reload page and set cache to zero
page {
  headerData {
    7 = TEXT
    7.value (
      <meta http-equiv=“Pragma” content=”no-cache”>
      <meta http-equiv=“Expires” content=”-1″>
      <meta http-equiv=“CACHE-CONTROL” content=”NO-CACHE”>
      <meta http-equiv="refresh" content="60">
    )
  }
}
