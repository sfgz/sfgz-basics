<?php

// Add new TCA field to the table "tt_content"
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns('tt_content', [
	'filelink_sorting_direction' => [
		'label' => 'Sortierrichtung:',
		'config' => [
			'type' => 'select',
			'renderType' => 'selectSingle',
			'items' => [
				['Aufsteigend', 0],
				['Absteigend', 1],
			],
			'size' => 1,
			'maxitems' => 1,
			'eval' => '',
			'default' => 0
		]
	],
]);
 
   // Add the field "filelink_sorting_direction" to the TCA palette "uploads"
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addFieldsToPalette('tt_content', 'uploads', 'filelink_sorting_direction', 'after:filelink_sorting'); 
