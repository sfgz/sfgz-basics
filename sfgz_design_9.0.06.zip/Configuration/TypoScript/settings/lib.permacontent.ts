## lib.permacontent
lib.permacontent = COA
lib.permacontent {
      wrap = |
      
      10 = RECORDS
      10 {
	  	  tables = tt_content
	  	  source = {$plugin.sfgz_design.settings.permacontent}
      }
}

## hide permacontent on handbuch-startpage
[globalVar = TSFE:id == {$plugin.sfgz_design.settings.handbuch_uid}]
	lib.permacontent >
[global]

lib.replacements = COA
lib.replacements {

  10 {
    search = #vorname#
    replace.cObject = COA_INT
    replace.cObject.1 = TEXT
    replace.cObject.1 {
      data = TSFE:fe_user|user|first_name
      insertData=1
    }
  }
  
  20 < .10
  20.search = #nachname#
  20.replace.cObject.1.data = TSFE:fe_user|user|last_name

  22 < .10
  22.search = #user#
  22.replace.cObject.1.data = TSFE:fe_user|user|username
  
  30 {
    search = #datum#
    replace.cObject = COA_INT
    replace.cObject.1 = TEXT
    replace.cObject.1 {
        data = date:U
        strftime = %d-%m-%Y
    }
  }
  32 < .30
  32.search = #jahr#
  32.replace.cObject.1.strftime = %Y
  
  70 {
    search = #baseurl#
    replace.cObject = TEXT
    replace.cObject.value = {$plugin.sfgz_design.settings.baseURL}
  }

}

lib.permacontent.stdWrap.replacement < lib.replacements
