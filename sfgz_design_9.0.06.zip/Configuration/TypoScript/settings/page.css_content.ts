## page.css_content
page.headerData.1542 = RECORDS
page.headerData.1542 {
   source = {$plugin.sfgz_design.settings.css_content}
   tables = tt_content
   conf.tt_content = COA
   conf.tt_content {
      20 = TEXT
      20.stdWrap.field = bodytext
	  20.wrap = <style>|</style>
   }
}
