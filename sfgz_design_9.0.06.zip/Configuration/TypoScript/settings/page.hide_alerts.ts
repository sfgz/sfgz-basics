# Meldungen langsam ausblenden, wenn 'hideAlerts' einen Wert größer als 0 (Null) hat
# hide alerts and hints after a while
[globalVar = LIT:0<{$plugin.sfgz_design.settings.hideAlerts}]
    page.headerData.38 = TEXT
    page.headerData.38.value = {$plugin.sfgz_design.settings.hideAlerts} * 1000
    page.headerData.38.prioriCalc = 1
    page.headerData.38.wrap (
	<script type="text/javascript">  function hideAlerts() {$('.typo3-messages').fadeOut(|);} window.onload = hideAlerts;</script>
    <style>.typo3-messages { color:#000 ; position:fixed; bottom:2px; margin-bottom:0; left:3px ; z-index:100 ; box-shadow:0 0 5px #113300 ; }</style>
    )
[global]
# hidealerts
plugin.tx_frontend_sfgz_hidealerts._CSS_DEFAULT_STYLE (
	.typo3-messages { border:1px thin #fff ;border-radius:10px; padding:5px;background:#FFF; }
	p.alert-message { margin:0; width:316px;}
	li.alert.alert-danger {background:#FFD0B0;border:1px thin #fff ;border-radius:7px; padding:3px;}
	li.alert.alert-info {background:#009ee0;border:1px thin #fff ;border-radius:7px; padding:3px;}
	li.alert.alert-success {background:#D0FFB0;border:1px thin #fff ;border-radius:7px; padding:3px;}
)
