styles.templates.partialRootPath = EXT:sfgz_design/Resources/Private/Partials/fluid_styled_content
styles.templates.templateRootPath = EXT:sfgz_design/Resources/Private/Templates/fluid_styled_content

plugin.perfectlightbox.slimbox2Path = EXT:sfgz_design/Resources/Public/Scr/slimbox.2.0.4.yui.js
styles.content.textmedia.linkWrap.lightboxEnabled = 1

styles.content.loginform.recursive = 1
styles.content.loginform.showForgotPasswordLink = 1
styles.content.loginform.showPermaLogin = 1
styles.content.loginform.dateFormat = d.m.Y H:i
styles.content.loginform.redirectMode = userLogin, groupLogin
styles.content.loginform.redirectFirstMethod = 1
styles.content.loginform.redirectPageLogout = 1
