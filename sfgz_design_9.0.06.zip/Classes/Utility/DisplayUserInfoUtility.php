<?php
namespace Sfgz\SfgzDesign\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

class DisplayUserInfoUtility implements \TYPO3\CMS\Core\SingletonInterface {
    
    /**    
    * getBlankField
    * $conf[fields]  at least one field affored. Can be separed by comma
    * $conf[separer] the glue between the fields on output, if more than one field is get in 'fields'. Default is an empty string.
    * $conf[blank]   remove tags or not [ true | false ] default is true
    * $conf[default] return value if field is empty
    * 
    * @param  string $content Empty string (no content to process)
    * @param  array $conf conf[ 'fields' , 'separer' , 'blank' ]
    * @return string
    */
    Public function getBlankField($content, $conf) 
    {
            if( !isset( $conf['fields'] ) || empty( $conf['fields'] ) ) return;
            if( !isset( $conf['blank'] ) ) $conf['blank'] = true;
            
            $aSignatureLines = [];
            $aFelder = explode( ',' , $conf['fields'] );
            foreach( $aFelder as $i => $fldname ) {
                // If field is not existing, then write the given fieldname. Can be used to insert tags.
                $strFieldcontent = isset( $GLOBALS['TSFE']->fe_user->user[$fldname] ) ? $GLOBALS['TSFE']->fe_user->user[$fldname] : ( $i ? $fldname : '' );
                if( $strFieldcontent ) $aSignatureLines[] = $conf['blank'] ? $this->removeTags( $strFieldcontent ) : $strFieldcontent ;
            }

            // implode by given separer. default is an empty string.
            $strBlankField = implode( isset( $conf['separer'] ) ? $conf['separer'] : '' , $aSignatureLines );

            if( empty($strBlankField) && isset($conf['default']) ) return $conf['default'];
            return $strBlankField;
    }
    
    /**    
    * removeTags
    * remove DIV- and P tags and replace /P with br
    * 
    * @param  string $content Empty string (no content to process)
    * @return string
    */
    Private function removeTags($content) 
    {
        // from RTE we remove <P> tags and replace with <br>
        // from textarea we replace \n with <br> then handle like for RTE
        // remove double <br> and remove <div> tags
        $aSrcRpl = [
            "\n"   => '<br>',
            '<br />'   => '<br>',
            '</p>'   => '<br>',
            '<p>'    => '',
            '<br><br>'   => '<br>',
            '</div>' => '',
            '<div'   => ''
        ];
        return str_replace( array_keys($aSrcRpl) , $aSrcRpl , $content );
    }

}
