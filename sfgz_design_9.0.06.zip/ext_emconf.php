<?php

/***************************************************************
 * Extension Manager/Repository config file for ext: "sfgz_design"
 *
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array(
	'title' => 'SfGZ Design',
	'description' => 'Minimal affored files for Theme SfGZ 2018',
	'category' => 'module',
	'author' => 'Daniel Rueegg',
	'author_email' => 'colormixture@verarbeitung.ch',
	'state' => 'stable',
	'internal' => '',
	'uploadfolder' => '0',
	'createDirs' => '',
	'clearCacheOnLoad' => 0,
	'version' => '9.0.06',
	'constraints' => array(
		'depends' => array(
			'typo3' => '7.6.0-9.9.99',
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
);
