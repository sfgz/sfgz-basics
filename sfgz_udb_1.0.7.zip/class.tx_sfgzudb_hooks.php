<?php
namespace Sfgz\SfgzUdb\Hook;

/***************************************************************
*  Copyright notice
*
*  (c) 2007-2014 Francois Suter (Cobweb) <typo3@cobweb.ch>
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/

/**
 * Hooks for the 'tx_sfgzudb' extension
 *
 * @author		Daniel Rueegg, Francois Suter (Cobweb) <typo3@cobweb.ch>
 * @package		TYPO3
 * @subpackage	tx_sfgzudb
 */
class tx_sfgzudb_hooks implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * extConf
	 *
	 * @var array
	 */
	protected $extConf;

	/**
	 * __construct
	 */
	public function __construct() {
		$this->extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['sfgz_udb']);

		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		
//  		$this->extConf['hide_if_in_list'] = $settings['plugin.']['tx_sfgzudb_edit.']['settings.']['hide_if_in_list.'];
		$this->extConf['studentPid'] = $settings['plugin.']['tx_sfgzudb_edit.']['settings.']['studentPid'];
		$this->extConf['teacherPid'] = $settings['plugin.']['tx_sfgzudb_edit.']['settings.']['teacherPid'];
		$this->extConf['storagePid'] = $settings['plugin.']['tx_sfgzudb_edit.']['persistence.']['storagePid'];

		date_default_timezone_set ( 'Europe/Zurich' );
		$this->extConf['timeZoneGMT'] = new \DateTimeZone( 'GMT' );
		$this->extConf['timeZoneLocal'] = new \DateTimeZone( 'Europe/Zurich' );
 		$this->extConf['excludeOldData'] = $this->extConf['importOldData'] ? 0 : 1;
	}

	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 *
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function processResponse($data, $pObj) {
		$hookName = $pObj->parameters['hook'];
		if(!empty($hookName) && $hookName != 'processResponse' && method_exists( $this , $hookName ) ) return $this->$hookName($data, $pObj);
		return false;
		// get data in form of an array instead of an object
		$rawData = json_decode($data, true);
 		return json_encode($rawData);
	}
	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * return only the body-part, not the code (wich is always 200)
	 *
	 * url for the svconnector_json object: [mixed]
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function body_processResponse($data, $pObj) {
		// get data in form of an array instead of an object
		$rawData = json_decode($data, true);
		$id=0;
		foreach($rawData['body'] as $locRow){
		    ++$id;
		    $locArr[$id]=$locRow;
		    $locArr[$id]['pid'] = $this->extConf['storagePid'];
		}
		return json_encode( $locArr );
	}
	
	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * it transforms fields for Klasse 
	 *
	 * url for the svconnector_json object: .../class
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function klasse_processResponse($data, $pObj) {
		$krzArr = array();
		$rawData = json_decode($data, true);
		$dateToNow = $this->parseLocalDate( date( 'Y-m-d' ).' 22:00:00');
		$classAdjustHelper = new \Sfgz\SfgzUdb\Utility\AdjustScoolclassUtility();
		if( isset($rawData['body']) ){
            foreach($rawData['body'] as $klsRow){
                $id = $klsRow['ID'];
                // classshort is like 'PBB15 A' but we need the 'PBB' part
                
                $stringClassShort = $classAdjustHelper->AdjustScoolclass( trim($klsRow['ClassShort']) );
                $aClassShort = explode( ' ' , $stringClassShort );
                $classPart = substr( $aClassShort[0] , 0 , strlen($aClassShort[0])-2 );
                
                $dateTo = $this->parseLocalDate($klsRow['EndDate']);
                if($this->extConf['excludeOldData'] && $dateTo < $dateToNow) continue;
                
                $krzArr[$id]=$klsRow;
                $krzArr[$id]['pid'] = $this->extConf['storagePid'];
                $krzArr[$id]['ClassShort']=$stringClassShort;
                $krzArr[$id]['klasse_kurz']=$classPart;
                $krzArr[$id]['klasse_zug'] = isset($aClassShort[1]) ? $aClassShort[1] : '';
                // date is like 2015-12-31 00:00:00
                $krzArr[$id]['klasse_jahr']= substr($klsRow['StartDate'], 2 , 2);
//                 $krzArr[$id]['klasse_start']= $this->parseLocalDate($klsRow['StartDate']);
//                 $krzArr[$id]['klasse_ende']= $dateTo;
                $krzArr[$id]['klasse_start']= $klsRow['StartDate'];
                $krzArr[$id]['klasse_ende']= $klsRow['EndDate'];
                //$krzArr[$id]['ref_class_id']= $id;
            }
		}
 		return json_encode( $krzArr );
	}
	
	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * and it filters out old records
	 *
	 * url for the svconnector_json object: .../teacher
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function teacher_processResponse($data, $pObj) {
		$teacherArr = array();
		$rawData = json_decode($data, true);
		$genderTransform = array( 'm'=> 0 , 'f'=>1 );
		foreach($rawData['body'] as $teaRow){
 		    if( empty($teaRow['Username']) ) continue;
		    $teacherArr[ $teaRow['ID'] ] = $teaRow;
		    $teacherArr[ $teaRow['ID'] ]['gid'] = $this->extConf['userGroupId'].','.$this->extConf['teacherGroupId'];
		    $teacherArr[ $teaRow['ID'] ]['pid'] = $this->extConf['teacherPid'];
		    $teacherArr[ $teaRow['ID'] ]['name'] =  trim( str_replace( '*' , '' , $teaRow['GivenName'] . ' ' . $teaRow['Lastname'] ) );
		    if( isset($teaRow['Gender']) ) $teacherArr[ $teaRow['ID'] ]['gender'] = $genderTransform[ $teaRow['Gender'] ];
		    $ID = $teaRow['ID'];
		    if( isset($teaRow['Acronym']) ) $teacherArr[ $teaRow['ID'] ]['Acronym'] = str_replace( 'Ö' , 'OE' , $teaRow['Acronym'] );
		    $namFirst = trim( str_replace( '*' , '' , htmlentities($teaRow['GivenName'] )) );
		    $namLast = trim( str_replace( '*' , '' , htmlentities($teaRow['Lastname'] )) );
		    if( strlen($namLast)>3 ) { $partOne = substr( $namLast , -2  ) ;}else{$partOne =  $namLast;}
		    $partTwo = strlen($namFirst)>2 ? substr( $namFirst , 0 , 2 ) : '';
 		    $teacherArr[ $teaRow['ID'] ]['password'] = $partOne .  $partTwo . '.' . substr( $ID , 0 , 4 ) ;
		}
 		return json_encode($teacherArr);
	}
	
	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * and it filters out old records
	 *
	 * url for the svconnector_json object: .../legicarddata
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function students_processResponse($data, $pObj) {
		$studArr = array();
		$classArr = array();
		// read klassen-records to get outdated classes
		$theRepository = $this->getRepository( 'Klasse' );
		$classes = $theRepository->findAll();
		// create an array for later test
		$classAdjustHelper = new \Sfgz\SfgzUdb\Utility\AdjustScoolclassUtility();
		foreach($classes as $row){$classArr[$row->getClassId()] = array( 'dateTo'=>$row->getKlasseEnde() , 'classShort'=>$classAdjustHelper->AdjustScoolclass($row->getClassShort()) ) ;}
		// set delay time: exclude record if class is outdated since x days
		$dateToNow = $this->parseLocalDate( date( 'Y-m-d' ).' 00:00:00');
		// get data in form of an array instead of an object
		$rawData = json_decode($data, true);
		foreach($rawData['body'] as $studRow){
		    $dateTo = $classArr[ $studRow['ClassID'] ]['dateTo'];
 		    if($this->extConf['excludeOldData'] && $dateTo < $dateToNow) continue;
 		    if( empty($studRow['Username']) ) continue;
		    $studArr[ $studRow['PersonID'] ] = $studRow;
		    $studArr[ $studRow['PersonID'] ]['gid'] = $this->extConf['userGroupId'].','.$this->extConf['studentGroupId'];
		    $studArr[ $studRow['PersonID'] ]['pid'] = $this->extConf['studentPid'];
		    $studArr[ $studRow['PersonID'] ]['name'] =  trim( str_replace( '*' , '' , $studRow['GivenName'] . ' ' . $studRow['Lastname'] ) );
		    $ID = $studRow['PersonID'];
		    $namFirst = trim( str_replace( '*' , '' , htmlentities($studRow['GivenName'] )) );
		    $namLast = trim( str_replace( '*' , '' , htmlentities($studRow['Lastname'] )) );
		    $studArr[ $studRow['PersonID'] ]['password'] =  substr( $namLast , strlen($namLast)-2 ) . substr( $namFirst , 0 , 2 ) . '.' . substr( $ID , 0 , 4 ) ;
		}
 		return json_encode($studArr);
	}

	/**
	 * returns the object of a Model like "Klasse" or "Kurs"
	 *
	 * @param string $table The name of table to return
	 * @return void
	 */
	protected function getRepository( $table ) {
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$querySettings = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
		$querySettings->setStoragePageIds( array($this->extConf['storagePid']) );
		// Repository instanziieren
		$oneRepository = $objectManager->get( str_replace( '##TABLENAME##' , $table , 'Sfgz\SfgzUdb\Domain\Repository\##TABLENAME##Repository') );
		$oneRepository->setDefaultQuerySettings($querySettings);
		return $oneRepository;
		//return $oneRepository->findAll();
	}
	
	/**
	 * transforms a given datestring to integer value
	 *
	 * @param string $datevalue A string-formatted Date like 2015-11-26 08:15:00
	 * @return integer
	 */
	public function parseLocalDate($datevalue) {
		$termin = new \DateTime( $datevalue );
		$termin->setTimeZone($this->extConf['timeZoneLocal']); 
		$value = $termin->getTimestamp();
// 		if (!empty($GLOBALS['TYPO3_CONF_VARS']['SYS']['serverTimeZone']) ) {
 			$value += $termin->getOffset();
// 		}
		return $value;
	}
	/**
	 * transforms a given datestring to unix-time
	 * same as before but with timezone GMT - same result
	 *
	 * @param string $datevalue A string-formatted Date like 2015-11-26 08:15:00
	 * @return integer
	 */
	public function parseTimestamp($datevalue) {
		$termin = new \DateTime( $datevalue , $this->extConf['timeZoneGMT'] );
		return $termin->getTimestamp();
	}
}
?>
