<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

// Register hook for import-routine
include_once(\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('sfgz_udb').'class.tx_sfgzudb_hooks.php');
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['svconnector_mff']['processResponse'][] = 'Sfgz\SfgzUdb\Hook\tx_sfgzudb_hooks';

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SfgzUdb',
            'Edit',
            [
                'Cloudquota' => 'list, new, create, edit, update, delete',
                'Fachbereich' => 'list, new, create, edit, update, delete',
                'Kurzklasse' => 'list, new, create, edit, update, delete',
                'Transfer' => 'upload, downloads'
            ],
            // non-cacheable actions
            [
                'Cloudquota' => 'list, edit, create, update, delete',
                'Fachbereich' => 'list, edit, create, update, delete',
                'Kurzklasse' => 'list, edit, create, update, delete',
                'Transfer' => 'upload, downloads'
            ]
        );

        // wizards
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
                'mod {
                    wizards.newContentElement.wizardItems.plugins {
                        elements {
                            edit {
                                iconIdentifier = sfgz_udb-plugin-edit
                                title = LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgz_udb_edit.name
                                description = LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgz_udb_edit.description
                                tt_content_defValues {
                                    CType = list
                                    list_type = sfgzudb_edit
                                }
                            }
                        }
                        show = *
                    }
            }'
        );
        
		$iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);

        $iconRegistry->registerIcon(
            'sfgz_udb-plugin-edit',
            \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
            ['source' => 'EXT:sfgz_udb/Resources/Public/Icons/user_plugin_edit.svg']
        );

        // Register scheduler-Tasks
        if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('scheduler')) {
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Sfgz\\SfgzUdb\\Command\\FillExportTableCommandController'] = array(
                'extension'			=> 'SfgzUdb',
                'title'				=> 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang.xlf:scheduler.title_export',
                'description'		=> 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang.xlf:scheduler.description_export',
                'additionalFields'	=> ''
            );
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Sfgz\\SfgzUdb\\Command\\KurzklasseCommandController'] = array(
                'extension'			=> 'SfgzUdb',
                'title'				=> 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang.xlf:scheduler.title_kurzklasse',
                'description'		=> 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang.xlf:scheduler.description_kurzklasse',
                'additionalFields'	=> ''
            );
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Sfgz\\SfgzUdb\\Command\\StudClassFromFileCommandController'] = array(
                'extension'			=> 'SfgzUdb',
                'title'				=> 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang.xlf:scheduler.title_studclassfromfile',
                'description'		=> 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang.xlf:scheduler.description_studclassfromfile',
                'additionalFields'	=> ''
            );
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Sfgz\\SfgzUdb\\Command\\UsergroupsCommandController'] = array(
                'extension'			=> 'SfgzUdb',
                'title'				=> 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang.xlf:scheduler.title_usergroups',
                'description'		=> 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang.xlf:scheduler.description_usergroups',
                'additionalFields'	=> ''
            );
        }
    }
);
