<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SfgzUdb',
            'Edit',
            'SfGZ User DB Editor'
        );

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('sfgz_udb', 'Configuration/TypoScript', 'Sfgz User DB');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzudb_domain_model_cloudquota', 'EXT:sfgz_udb/Resources/Private/Language/locallang_csh_tx_sfgzudb_domain_model_cloudquota.xlf');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzudb_domain_model_fachbereich', 'EXT:sfgz_udb/Resources/Private/Language/locallang_csh_tx_sfgzudb_domain_model_fachbereich.xlf');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzudb_domain_model_kurzklasse', 'EXT:sfgz_udb/Resources/Private/Language/locallang_csh_tx_sfgzudb_domain_model_kurzklasse.xlf');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzudb_domain_model_exportusers', 'EXT:sfgz_udb/Resources/Private/Language/locallang_csh_tx_sfgzudb_domain_model_exportusers.xlf');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzudb_domain_model_teacherrelation', 'EXT:sfgz_udb/Resources/Private/Language/locallang_csh_tx_sfgzudb_domain_model_teacherrelation.xlf');

        $GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist']['sfgzudb_edit'] = 'pi_flexform';
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue('sfgzudb_edit', 'FILE:EXT:sfgz_udb/Configuration/FlexForms/flexform_edit.xml');

        ### IMPORT definitions
        ### class
            // Load description of table tx_mffdb_domain_model_klasse
            // Typo3 7.6 ? // t3lib_div::loadTCA('tx_mffdb_domain_model_klasse');
        
        // Add the external information to the ctrl section
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['ctrl']['external'] = array(
            0 => array(
                'connector' => 'jsonis2',
                'parameters' => array(
                    'uri' => 'https://api.tam.ch/bgz/data/source/class',
                    'usr' => 'rest-viewdata',
                    'pwd' => 'BkVSZUtMjNJHmWJZbkbr',
                    'hook' => 'klasse_processResponse',
                    'encoding' => 'utf8'
                ),
                'data' => 'array',
                'referenceUid' => 'class_id',
                'enforcePid' => TRUE,
                'priority' => 110,
                'disabledOperations' => 'delete',
                'description' => 'Importiert klasse ab IS2 API'
            )
        );

        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['pid']['external'] = array(
            0 => array(
                'field' => 'pid'
            )
        );
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['class_id']['external'] = array(
            0 => array(
                'field' => 'ID'
            )
        );
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['class_short']['external'] = array(
            0 => array(
                'field' => 'ClassShort'
            )
        );
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['klassenname']['external'] = array(
            0 => array(
                'field' => 'Class'
            )
        );
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['department_id']['external'] = array(
            0 => array(
                'field' => 'DepartmentID'
            )
        );
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['klasse_start']['external'] = array(
            0 => array(
                'field' => 'klasse_start'
            )
        );
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['klasse_ende']['external'] = array(
            0 => array(
                'field' => 'klasse_ende'
            )
        );
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['klasse_jahr']['external'] = array(
            0 => array(
                'field' => 'klasse_jahr'
            )
        );
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['klasse_kurz']['external'] = array(
            0 => array(
                'field' => 'klasse_kurz'
            )
        );
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['klasse_zug']['external'] = array(
            0 => array(
                'field' => 'klasse_zug'
            )
        );
        $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['classteacher_id']['external'] = array(
            0 => array(
                'field' => 'TeacherID'
            )
        );
        
        ### Teacher and Students
        $GLOBALS['TCA']['fe_users']['ctrl']['default_sortby'] = 'ORDER BY uid';
                
        // Add the external information to the ctrl section
        $GLOBALS['TCA']['fe_users']['ctrl']['external'] = array(
            0 => array(
                'connector' => 'jsonis2',
                'parameters' => array(
                    'uri' => 'https://api.tam.ch/bgz/data/source/teacher',
                    'usr' => 'rest-viewdata',
                    'pwd' => 'BkVSZUtMjNJHmWJZbkbr',
                    'hook' => 'teacher_processResponse',
                    'encoding' => 'utf8'
                ),
                'data' => 'array',
                'referenceUid' => 'eco_key',
                'enforcePid' => FALSE,
                'priority' => 310,
                'disabledOperations' => 'delete',
                'description' => 'Importiert teacher ab IS2 API'
            ),
            1 => array(
                'connector' => 'jsonis2',
                'parameters' => array(
                    'uri' => 'https://intranet.tam.ch/bgz/rest/legicarddata',
                    'usr' => 'rest-legicard',
                    'pwd' => 'ct6BX7DBcdB9M5f',
                    'encoding' => 'utf8',
                    'hook' => 'students_processResponse'
                ),
                'data' => 'array',
                'referenceUid' => 'eco_key',
                'enforcePid' => FALSE,
                'priority' => 210,
                'disabledOperations' => 'delete',
                'description' => 'Importiert students ab IS2 Legicard-API'
            ),
            2 => array(
                'connector' => 'csv',
                'parameters' => array(
                    'filename' => 'uploads/tx_sfgzudb/students/is2students.csv',
                    'delimiter' => ';',
                    'text_qualifier' => '"',
                    'skip_rows' => '1',
                    'encoding' => 'UTF-8',
                    'locale' => 'de_CH.UTF-8'
                ),
                'data' => 'array',
                'referenceUid' => 'eco_key',
                'enforcePid' => FALSE,
                'priority' => 220,
                'disabledOperations' => 'delete',
                'description' => 'Lernende in Klassen einteilen ab CSV-Datei von Intranet Sek II'
            ),
        );

        $GLOBALS['TCA']['fe_users']['columns']['pid']['external'] = array(
            0 => array(
                'field' => 'pid'
            ),
            1 => array(
                'field' => 'pid'
            ),
            2 => array(
                'field' => 'pid'
            )
        );
        $GLOBALS['TCA']['fe_users']['columns']['eco_key']['external'] = array(
            0 => array(
                'field' => 'ID'
            ),
            1 => array(
                'field' => 'PersonID'
            ),
            2 => array(
                'field' => 'PersonID'
            )
        );
        $GLOBALS['TCA']['fe_users']['columns']['username']['external'] = array(
            0 => array(
                'field' => 'Username'
            ),
            1 => array(
                'field' => 'Username'
            ),
            2 => array(
                'field' => 'Username'
            )
        );
        $GLOBALS['TCA']['fe_users']['columns']['first_name']['external'] = array(
            0 => array(
                'field' => 'GivenName',
                'disabledOperations' => 'update'
            ),
            1 => array(
                'field' => 'GivenName',
                'disabledOperations' => 'update'
            ),
            2 => array(
                'field' => 'Vorname',
                'disabledOperations' => 'update'
            )
        );
        $GLOBALS['TCA']['fe_users']['columns']['last_name']['external'] = array(
            0 => array(
                'field' => 'Lastname',
                'disabledOperations' => 'update'
            ),
            1 => array(
                'field' => 'Lastname',
                'disabledOperations' => 'update'
            ),
            2 => array(
                'field' => 'Nachname',
                'disabledOperations' => 'update'
            )
        );
        $GLOBALS['TCA']['fe_users']['columns']['name']['external'] = array(
            0 => array(
                'field' => 'name'
            ),
            1 => array(
                'field' => 'name'
            ),
            2 => array(
                'field' => 'Name'
            ),
        );

        $GLOBALS['TCA']['fe_users']['columns']['email']['external'] = array(
            0 => array(
                'field' => 'Email'
            ),
            1 => array(
                'field' => 'Email'
            ),
            2 => array(
                'field' => 'EMail'
            )
        );

        $GLOBALS['TCA']['fe_users']['columns']['password']['external'] = array(
            0 => array(
                'field' => 'password',
                'disabledOperations' => 'update'
            ),
            1 => array(
                'field' => 'password',
                'disabledOperations' => 'update'
            ),
            2 => array(
                'field' => 'password',
                'value' => '65oK!-/$zY',
                'disabledOperations' => 'update'
            )
        );

        $GLOBALS['TCA']['fe_users']['columns']['eco_acronym']['external'] = array(
            0 => array(
                'field' => 'Acronym'
            )
        );

        $GLOBALS['TCA']['fe_users']['columns']['usergroup']['external'] = array(
            0 => array(
                'field' => 'gid',
            ),
            1 => array(
                'field' => 'gid',
                'disabledOperations' => 'update'
            ),
            2 => array(
                'field' => 'gid',
            )
        );
        $GLOBALS['TCA']['fe_users']['columns']['tx_extbase_type']['external'] = array(
            0 => array(
               'transformations' => [ 0 => ['value' => 'Tx_SfgzUdb_Ecouser' ] ]
            ),
            1 => array(
               'transformations' => [ 0 => ['value' => 'Tx_SfgzUdb_Ecouser' ] ]
            ),
            2 => array(
               'transformations' => [ 0 => ['value' => 'Tx_SfgzUdb_Ecouser' ] ]
            )
        );

        $GLOBALS['TCA']['fe_users']['columns']['eco_klasse']['external'] = array(
            1 => array(
                'field' => 'ClassID',
                'mapping' => array(
                    'table' => 'tx_mffdb_domain_model_klasse',
                    'reference_field' => 'class_id'
                )
            ),
            2 => array(
                'field' => 'ClassID',
                'mapping' => array(
                    'table' => 'tx_mffdb_domain_model_klasse',
                    'reference_field' => 'class_id'
                )
            )
        );

    }
);
