<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "svconnector_json".
 *
 * Auto generated 26-02-2017 02:23
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array (
  'title' => 'Jsonis2 service for Intranet Sek II -  SvConnector JSON with Authentification',
  'description' => 'Connector service for JSON data with authentication and backup functionality. Built for SfGZ DB.',
  'category' => 'services',
  'version' => '2.6.4',
  'state' => 'stable',
  'uploadfolder' => true,
  'createDirs' => '',
  'clearcacheonload' => true,
  'author' => 'Prakash A Bhat, Francois Suter (Cobweb), Daniel Rueegg (SfGZ)',
  'author_email' => 'typo3@cobweb.ch',
  'author_company' => '',
  'constraints' => 
  array (
    'depends' => 
    array (
      'typo3' => '7.6.0-9.99.99',
      'svconnector' => '3.0.0-9.9.99',
    ),
    'conflicts' => 
    array (
    ),
    'suggests' => 
    array (
    ),
  ),
);

