<?php
namespace Sfgz\SfgzCsvconvert\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class FileHandlerUtility
 */

class FileHandlerUtility implements \TYPO3\CMS\Core\SingletonInterface {
	
	/**
	* fileAttributes
	*
	* @var array
	*/
	public $fileAttributes = NULL;

	/**
	 * fileUpload
	 * handles file upload and deletion 
	 * returns string with filename if action was successful
	 *
	 * @param string $dateiname
	 * @param string $extKey
	 * @param string $pluginName
	 * @return string
	 */
	 
	public function fileUpload( $dateiname , $extKey , $pluginName ) {
		/**
		* 
		* The enctype is affored in the Form-Tag:
		*   form enctype="multipart/form-data"
		*   
		* The Input-Element on the Form looks like:
		*   input type="file" name="tx_{shrinked-extKey}_{pluginname}[dateiname]"
		*
		* Example for Plugin sfgz_converter_csv:
		*   extKey = sfgz_converter
		*   shrinkedExtKey = sfgzconverter
		*   pluginName = csv
		*   
		* The Input-Element on the Form looks like:
		*   input type="file" name="tx_sfgzconverter_csv[dateiname]"
		*/
		
		// $extKey = \TYPO3\CMS\Core\Utility\GeneralUtility::camelCaseToLowerCaseUnderscored($this->extensionName);
		// $pluginName = \TYPO3\CMS\Core\Utility\GeneralUtility::camelCaseToLowerCaseUnderscored($this->request->getPluginName());

		$uploadDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( 'uploads/tx_' . $extKey  ) . '/';
		$extKeyPlgNam = 'tx_' . $extKey . '_' . $pluginName;

		$fileName = '';
		if ($_FILES[$extKeyPlgNam]['tmp_name'][ $dateiname ]) {
			$fileName = $_FILES[$extKeyPlgNam]['name'][ $dateiname ];
			$aFn = explode( '.' ,  $fileName );
			$ext = array_pop( $aFn );
			$basename = implode( '.' , $aFn );
			$fileName = $basename . '_' . date('ymdHis') . '.' . $ext;
			if( file_exists($uploadDir.$fileName) ) @unlink($uploadDir.$fileName);
			\TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move( $_FILES[$extKeyPlgNam]['tmp_name'][ $dateiname ] , $uploadDir.$fileName );
		}
		return $fileName;
	}
	
	/**
	 * show a list of files
	 *
	 * @param string $dumpPath
	 * @return array
	 */
	public function show_file_list($dumpPath) {
		$d = dir( $dumpPath );
		$filelist = array();
		while (false !== ($entry = $d->read())) {
				$filename = pathinfo( $entry , PATHINFO_FILENAME );
				if( $entry == '.' || $entry == '..' ) continue;
				if( !is_file($dumpPath.'/'.$entry) ) continue;
				$filelist[$entry]['filename'] = $filename;
				$filelist[$entry]['size'] = round( filesize($dumpPath.'/'.$entry) / 1024 , 1 );
		}
		$d->close();
		ksort($filelist);

		return $filelist;
	}

	/**
	 * downloadAsCsv
	 * 
	 * @param string $strOut 
	 * @param string $filename
	 * @return void
	 */
	public function downloadAsCsv($strOut, $filename = 'verarbeitet.csv') {
 		header('Content-Type: application/csv');
		header('Content-Length: ' . strlen($strOut) );
		header('Content-Disposition: attachment; filename="'.$filename.'";');
		echo $strOut;
		die;
	}

	/**
	* analyse_file
	* 
	* from Ashley, http://php.net/manual/de/function.fgetcsv.php
	* 
	* Example Usage:
    * $Array = analyse_file('/www/files/file.csv', 10);
    *
    * example usable parts
    * $Array['charset']['value'] => ISO-8859-15
    * $Array['delimiter']['value'] => ,
    * $Array['linebreak']['value'] => \r\n
    * 
	* @param string $file 
	* @param integer $capture_limit_in_kb
	* @return array 
	*/
	function analyse_file($file, $capture_limit_in_kb = 10) {
		// capture starting memory usage
		$output['peak_mem']['start']    = memory_get_peak_usage(true);

		// log the limit how much of the file was sampled (in Kb)
		$output['read_kb']                 = $capture_limit_in_kb;
	
		// read in file
		$fh = fopen($file, 'r');
			$contents = fread($fh, ($capture_limit_in_kb * 1024)); // in KB
		fclose($fh);
	
		// specify allowed field delimiters
		$delimiters = array(
			'comma'     => ',',
			'semicolon' => ';',
			'tab'         => "\t",
			'pipe'         => '|',
			'colon'     => ':'
		);
	
		// specify allowed line endings
		$linebreaks = array(
			'rn'         => "\r\n",
			'n'         => "\n",
			'r'         => "\r",
			'nr'         => "\n\r"
		);

		// loop and count each line ending instance
		foreach ($linebreaks as $key => $value) {
			$line_result[$key] = substr_count($contents, $value);
		}

		// sort by largest array value
		asort($line_result);

		// log to output array
		$output['linebreak']['results']     = $line_result;
		$output['linebreak']['count']     = end($line_result);
		$output['linebreak']['key']         = key($line_result);
		$output['linebreak']['value']     = $linebreaks[$output['linebreak']['key']];
		$lines = explode($output['linebreak']['value'], $contents);

		// remove last line of array, as this maybe incomplete?
		array_pop($lines);
	
		// create a string from the legal lines
		$complete_lines = implode(' ', $lines);
	
		// log statistics to output array
		$output['lines']['count']     = count($lines);
		$output['lines']['length']     = strlen($complete_lines);
	
		// loop and count each delimiter instance
		foreach ($delimiters as $delimiter_key => $delimiter) {
			$delimiter_result[$delimiter_key] = substr_count($complete_lines, $delimiter);
		}
	
		// sort by largest array value
		asort($delimiter_result);
	
		// log statistics to output array with largest counts as the value
		$output['delimiter']['results']     = $delimiter_result;
		$output['delimiter']['count']         = end($delimiter_result);
		$output['delimiter']['key']         = key($delimiter_result);
		$output['delimiter']['value']         = $delimiters[$output['delimiter']['key']];

		$output['charset']['list'] = 'utf-8,utf-16,ucs2,iso-10646-ucs-2,iso-8859-15,iso-8859-1,windows-1251';
		$charsetlist = explode( ',' , $output['charset']['list'] );
		foreach ($charsetlist as $item) {
			if( strtolower(mb_detect_encoding( $complete_lines , $item , true)) == strtolower($item) ){ // first test ok
				$sample = iconv($item, $item, $complete_lines);
				if (md5($sample) == md5($complete_lines)) { // second test ok
					$output['charset']['value'] =  $item;
					break;
				}
			}
		}
	
		// capture ending memory usage
		$output['peak_mem']['end'] = memory_get_peak_usage(true);
		
		$this->fileAttributes = $output;
		
		return array( 'charset'=>$output['charset']['value'] , 'delimiter'=>$output['delimiter']['value'] , 'linebreak'=>$output['linebreak']['value'] , 'delimiter_key'=>$output['delimiter']['key'] , 'linebreak_key'=>$output['linebreak']['key'] );
	}

}
