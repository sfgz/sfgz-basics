<?php
namespace Sfgz\SfgzCsvconvert\Utility;

/***************************************************************
*
*  Copyright notice
*
*  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
*
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 3 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/

/**
* Class ShrinkTimetableUtility
*/

class ShrinkTimetableUtility implements \TYPO3\CMS\Core\SingletonInterface {
    
    /**
    * fieldnames
    * Wochentag;Zeit_von;Zeit_bis;Datum_von;Datum_bis;Periodizitaet;Periode;(Klasse);
    * Angebot;Fach;(Fachprefix);Lehrer;Gebaeude;Raum;Anz_Wochenlek
    *
    * @var array
    */
    public $fieldnames = NULL;
    
    /**
    * attributes_out
    *
    * @var array
    */
    public $attributes_out = NULL;
    
    /**
    * content_string
    *
    * @var string
    */
    public $content_string = NULL;
    
    /**
    * content_array
    *
    * @var array
    */
    public $content_array = NULL;
    
    /**
    * aProcess
    *
    * @var array
    */
    public $aProcess = NULL;

    /**
    * __construct
    *
    * @return void
    */
    public function __construct( ) {
            $this->fileUploadUtility = new \Sfgz\SfgzCsvconvert\Utility\FileHandlerUtility;
            
    }
    
    /**
    * shrinkTimetable
    *
    * @param string $dateiname
    * @param array $outAttributes
    * @param array $fileAttributes
    * @return void
    */
    public function shrinkTimetable( $dateiname , $outAttributes , $fileAttributes ) {
        
        $this->attributes_out = $outAttributes;
        
        $this->processReadFile( $dateiname , $fileAttributes);
        
        $this->processSanitizeWeekday();
        
        $aProcessed = $this->content_array;
        if( !is_array($aProcessed) ) return;
        if( !count($aProcessed) ) return;

        if( $this->attributes_out['zeitblocks'] ) $aProcessed = $this->shrinkArrayByTime( $aProcessed );
        if( $this->attributes_out['datumblocks'] ) $aProcessed = $this->shrinkArrayByDate( $aProcessed );


        $this->content_string = $this->array2string( $aProcessed );
        
        return  $aProcessed;
    }
    
    /**
    * getDifference
    *
    * @param array $aProcesOld
    * @param array $aProcesNew
    * @param string $scriptname
    * @return array
    */
    public function getDifference( $aProcesOld , $aProcesNew , $scriptname) {
        $aDiff = array();
        $aOld = array();
        $aNew = array();
        foreach( $aProcesOld as $ix => $aLine ){
            $groupBy = $aLine['Lehrer'] . '.';
            $groupBy.= $aLine['Angebot'] . '.';
            $groupBy.= $aLine['Fach'] . '.';
            $groupBy.= $aLine['Raum'] . '.';
            $groupBy.= $aLine['Wochentag']  . '.';
            $groupBy.= $aLine['Periodizitaet']. '.';
            $groupBy.= $aLine['Zeit_von'] . '.';
            $groupBy.= $aLine['Zeit_bis'] . '.';
            $groupBy.= $aLine['Datum_von'] . '.';
            $groupBy.= $aLine['Datum_bis']; 
            $aOld[$groupBy] = $ix;
        }
        foreach( $aProcesNew as $ix => $aLine ){
            $groupBy = $aLine['Lehrer'] . '.';
            $groupBy.= $aLine['Angebot'] . '.';
            $groupBy.= $aLine['Fach'] . '.';
            $groupBy.= $aLine['Raum'] . '.';
            $groupBy.= $aLine['Wochentag']  . '.';
            $groupBy.= $aLine['Periodizitaet']. '.';
            $groupBy.= $aLine['Zeit_von'] . '.';
            $groupBy.= $aLine['Zeit_bis'] . '.';
            $groupBy.= $aLine['Datum_von'] . '.';
            $groupBy.= $aLine['Datum_bis']; 
            $aNew[$groupBy] = $ix;
        }
        foreach( $aOld as $groupBy => $ix ){
            if( !isset($aNew[$groupBy]) ){
                $aProcesOld[$ix]['err'] = $scriptname . ':noNew';
                $aDiff[] = $aProcesOld[$ix];
            }
        }
        foreach( $aNew as $groupBy => $ix ){
            if( !isset($aOld[$groupBy]) ){
                $aProcesNew[$ix]['err'] = $scriptname . ':noOld';
                $aDiff[] = $aProcesNew[$ix];
            }
        }
        $this->fieldnames[] = 'err';
        return $aDiff;
    }
    
    /**
    * shrinkArrayByTime_mkGroup
    *  Helper for shrinkArrayByTime()
    *
    * @param array $aTable
    * @return array
    */
    public function shrinkArrayByTime_mkGroup( $aTable ) {
            // create day-groups
            $aGroups = array();
            foreach( $aTable as $lineNr => $aLine ){
                $groupBy = $aLine['Lehrer'] . '.';
                $groupBy.= $aLine['Angebot'] . '.';
                $groupBy.= $aLine['Fach'] . '.';
                $groupBy.= $aLine['Raum'] . '.';
                $groupBy.= $aLine['Wochentag']  . '.';
                $groupBy.= $aLine['Periodizitaet']. '.';
                $groupBy.= $aLine['Datum_von'] . '.';
                $groupBy.= $aLine['Datum_bis']; 
                $aGroups[$groupBy][$lineNr] = $this->time2decimal( $aLine['Zeit_von'] );
            }
            foreach( array_keys($aGroups) as $groupBy ){
                // sort each group asc by time (content) keeping key
                asort($aGroups[$groupBy]);
            }
            return $aGroups;
    }
    
    /**
    * shrinkArrayByDate_mkGroup
    * group by teacher, class, subject , room , time, weekday, periodicity.
    *
    * @param array $aTable
    * @return array
    */
    public function shrinkArrayByDate_mkGroup( $aTable ) {

            // group and prepare for sorting by date
            $aDateShrinked = array();
            foreach( $aTable as $lineNr => $aLine ){
                $groupBy = $aLine['Lehrer'] . '.';
                $groupBy.= $aLine['Angebot'] . '.';
                $groupBy.= $aLine['Fach'] . '.';
                $groupBy.= $aLine['Raum'] . '.';
                $groupBy.= $aLine['Wochentag']  . '.';
                $groupBy.= $aLine['Periodizitaet']. '.';
                $groupBy.= $aLine['Zeit_von'] . '.';
                $groupBy.= $aLine['Zeit_bis']; 
                $uxDateFrom = $this->date2unixtime( $aLine['Datum_von'] );
                $aDateShrinked[$groupBy][$lineNr] = $uxDateFrom;
            }
            foreach( array_keys( $aDateShrinked ) as $groupBy ) {
                // sort each group asc by date (content) keeping key
                asort($aDateShrinked[$groupBy]);
            }
            return $aDateShrinked;
    }
    
    /**
    * processReadFile
    *
    * @param string $dateiname
    * @param array $fileAttributes
    * @return void
    */
    public function processReadFile( $dateiname , $fileAttributes ) {

        $fileContent = file_get_contents( $dateiname );
        
        if( strtolower($this->attributes_out['charset']) != strtolower($fileAttributes['charset']) ){
            $fileContent = iconv( $fileAttributes['charset'] , $this->attributes_out['charset'] . '//TRANSLIT' , $fileContent );
        }
        
        $aDocument = explode( $fileAttributes['linebreak'] , $fileContent );
        $aRemoveIncomingEnclosure = [ '"' => '' , "'" => '' ];
        foreach( $aDocument as $lineNr => $strLine ){
            $aLine = explode( $fileAttributes['delimiter'] , trim($strLine) );
            foreach( $aLine as $fieldNr => $strContent ){
                if( $lineNr == 0 ) {
                    $this->fieldnames[$fieldNr] = trim( $strContent );
                    continue;
                }elseif( count($aLine) != count($this->fieldnames) ){
                    continue;
                }
                $cleanCellContent = trim( str_replace( array_keys($aRemoveIncomingEnclosure) , $aRemoveIncomingEnclosure , trim($strContent) ) );
                $this->content_array[ $lineNr ][ $this->fieldnames[$fieldNr] ] = $cleanCellContent ;
            }
        }
    }
    
    /**
    * processSanitizeWeekday
    *
    * @return void
    */
    public function processSanitizeWeekday() {
        if( !is_array($this->content_array) ) return;
        if( !count($this->content_array) ) return;
        foreach( $this->content_array as $lineNr => $aLine ){
            $unixTimeFrom = $this->date2unixtime( $aLine['Datum_von'] );
            if( !strlen($aLine['Wochentag']) ) $this->content_array[$lineNr]['Wochentag'] = date( 'w' , $unixTimeFrom );
        }
    }




    
    /**
    * shrinkArrayByTime
    *
    * @param array $aTable
    * @return array
    */
    public function shrinkArrayByTime( $aTable ) {
            // group by teacher, class, subject , room , date.
            // shrink by time
            
            $maxPauseInStunden = $this->attributes_out['zeitblocks'] / 60;
            
            // create day-groups
            $aGrp = $this->shrinkArrayByTime_mkGroup( $aTable );
            // Run throug each line of day-groups
            $newLines = array();
            foreach( $aGrp as $aGrpLines ){
                $groupLines = $this->shrinkGroupByTime( $aGrpLines , $aTable , $maxPauseInStunden );
                foreach( $groupLines as $lix => $lineRow ) $newLines[] = $lineRow;
            }
            return $newLines;
            
    }
    
    /**
    * shrinkGroupByTime 
    *  Helper for shrinkArrayByTime()
    *
    * @param array $aGrpLines
    * @param array $aTable
    * @param string $maxPauseInStunden
    * @return array
    */
    public function shrinkGroupByTime( $aGrpLines , $aTable , $maxPauseInStunden ) {
            
            
            $aOut = array();
            $aBlocks = array();
                
            $lastTimeTo = 0;
            $blockNr = 0;

            // build blocks with at least 2 elements
            foreach( $aGrpLines as $lineNr => $decTimeFrom ){
                // get lineNr of first loop 
                if( !$lastTimeTo ) {
                    $blockNr = 1;
                }else{
                // further loops
                    $minimalTimefromToOverlap = ( $decTimeFrom - $maxPauseInStunden );
                    if( $lastTimeTo < $minimalTimefromToOverlap ) {
                        // this one starts with a big pause
                        $blockNr += 1;
                    }
                }
                $aBlocks[$blockNr][$lineNr] = $lineNr;
                $lastTimeTo = $this->time2decimal( $aTable[$lineNr]['Zeit_bis'] );
            }
            
            // get first and last block and calculate the new row
            foreach( $aBlocks as $blockNr => $aBlocRows ){
                $aKeys = array_keys($aBlocRows);
                $aFirstKey = array_shift($aKeys);
                $aLastKey = count($aKeys) ? array_pop($aKeys) : $aFirstKey;
                $wl = 0;
                foreach( $aBlocRows as $lineNr ) if($aTable[$lineNr]['Anz_Wochenlek']) $wl += $aTable[$lineNr]['Anz_Wochenlek'];
                $aOut[ $aFirstKey ] = $aTable[$aFirstKey];
                $aOut[ $aFirstKey ]['Zeit_bis'] = $aTable[$aLastKey]['Zeit_bis'];
                $aOut[ $aFirstKey ]['Anz_Wochenlek'] = $wl;
            }
            return $aOut;
    }
    
    /**
    * shrinkArrayByDate
    *
    * @param array $aTable
    * @return array
    */
    public function shrinkArrayByDate( $aTable ) {
            // grouped by teacher, class, subject , room , time, weekday, periodicity.
            // shrink by date and set periodicity to 1,2 (,3,4)
            // grid per Day: round by date on noon
            // 
            
            $aDateShrinked = $this->shrinkArrayByDate_mkGroup( $aTable );
            
            $aOut = array();
            $aBlocks = array();
            
            if( !count($aDateShrinked) ) return $aOut; // some error occurred
            
            foreach( $aDateShrinked as $groupBy => $aGrpLines ) {
                $lastDateTo = 0;
                $blockNr = 0;
                foreach( $aGrpLines as $lineNr => $uxDateFrom ){
                    // get lineNr of first loop 
                    if( !$lastDateTo ) {
                        $blockNr = 1;
                    }else{
                    // further loops
                        $lastWeekNrTo = date( 'W' , $lastDateTo );
                        $p = $aTable[$lineNr]['Periodizitaet'] ? $aTable[$lineNr]['Periodizitaet'] : 1;
                        $thisWeekNrFrom = date( 'W' , $uxDateFrom );
                        if( $lastWeekNrTo + $p != $thisWeekNrFrom ) {
                            // this one starts with a big pause
                            $blockNr += 1;
                        }
                    }
                    $aBlocks[$groupBy][$blockNr][$lineNr] = $lineNr;
                    $lastDateTo = $this->date2unixtime( $aTable[$lineNr]['Datum_bis'] );
                }
                
            }
            // get first and last block and calculate the new row
            foreach( $aBlocks as $groupBy => $aGroups ){
                foreach( $aGroups as $blockNr => $aBlocRows ){
                    $aKeys = array_keys($aBlocRows);
                    $aFirstKey = array_shift($aKeys);
                    $aLastKey = count($aKeys) ? array_pop($aKeys) : $aFirstKey;
                    $aOut[ $aFirstKey ] = $aTable[$aFirstKey];
                    $aOut[ $aFirstKey ]['Datum_bis'] = $aTable[ $aLastKey ]['Datum_bis'];
                }
            }
            return $aOut;
    }

    /**
    * array2string
    *
    * @param array $aContent
    * @return void
    */
    public function array2string( $aContent ) {
    
            $linebreakOut = $this->attributes_out['linebreak'] ? $this->attributes_out['linebreak'] : "\n";
            $delimiterOut = $this->attributes_out['delimiter'];
            $textEnclosureOut = $this->attributes_out['enclosure'];
            
            $content_string = implode( $delimiterOut  , $this->fieldnames )  . $linebreakOut ;
            
            foreach( $aContent as $lineNr => $aLine ){
                foreach( $this->fieldnames as $cellName ){
                        $cellContent = isset( $aLine[$cellName] ) ? $aLine[$cellName] : '' ;
                        $aOut[$lineNr][$cellName] = $this->wrapField( $cellContent , $cellName );
                }
                $content_string .= implode( $delimiterOut  , $aOut[$lineNr] ) . $linebreakOut;
            }
            
            return $content_string;
            
    }
    
    /**
    * wrapField
    *
    * @param string $cellContent
    * @param string $cellName
    * @return string
    */
    public function wrapField( $cellContent , $cellName ) {
            if( empty($this->attributes_out['enclosure']) || empty($cellContent)  ){
                return  $cellContent ;
            }elseif( $cellName == 'Datum_von' || $cellName == 'Datum_bis'  ){
                return $this->attributes_out['enclosure'] . $this->sanitizeDatestring( $cellContent ) . $this->attributes_out['enclosure'];
            }elseif( is_numeric($cellContent) ){
                return $cellContent ;
            }else{
                return $this->attributes_out['enclosure'] . $cellContent . $this->attributes_out['enclosure'];
            }
            
    }
    
    /**
    * sanitizeDatestring
    *
    * @param string $dateString
    * @return string
    */
    public function sanitizeDatestring( $dateString ) {
            if( strlen( $dateString ) == 7 ) return '0' . $dateString;
            return $dateString;
    }
    
    /**
    * time2decimal
    *
    * @param array $timeValue
    * @return string
    */
    public function time2decimal( $timeValue ) {
            if( empty($timeValue) ) return ;
            $aTime = explode( ':' , $timeValue );
            if( count($aTime) != 2 ) return ;
            $hower = $aTime[0];
            $decMin = $aTime[1] / 60 ;
            return $hower + $decMin;
    }
    
    /**
    * date2unixtime
    *  
    *
    * @param array $dateValue between 5 and 8 chars
    * @return int
    */
    public function date2unixtime( $dateValue ) {
            if( empty($dateValue) ) return ;
            if( strlen($dateValue) == 8 || strlen($dateValue) == 6 ){ // 9.12.1999: 09121999 || 091299 
                $aDate['day'] = substr( $dateValue , 0 , 2 );
                $aDate['month'] = substr( $dateValue , 2 , 2 );
                $aDate['year'] = substr( $dateValue , 4 );
            }elseif( strlen($dateValue) == 7 || strlen($dateValue) == 5 ){ // 9.12.1999: 9121999 || 91299
                $aDate['day'] = substr( $dateValue , 0 , 1 );
                $aDate['month'] = substr( $dateValue , 1 , 2 );
                $aDate['year'] = substr( $dateValue , 3 );
            }else{
                return;
            }
            return mktime( 12,0,0 , $aDate['month'] , $aDate['day'] , $aDate['year'] );
    }
    
}
