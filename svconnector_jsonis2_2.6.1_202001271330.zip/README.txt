Connector services are designed to provide a standard way of connecting to remote applications.

This particular implementation is dedicated to reading JSON resources, either local or remote.

Please refer to the manual for full details.