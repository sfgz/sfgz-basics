<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($_EXTKEY, 'Configuration/TypoScript', 'sfgz Design');
// Als Standard: Verweis auf erste Unterseite der aktuellen Seite 
// Ausgeschaltet weil spaeter definiert in PageTS-Config: TCAdefaults.pages.shortcut_mode = 1
// $GLOBALS['TCA']['pages']['columns']['shortcut_mode']['config']['default'] = '1';
