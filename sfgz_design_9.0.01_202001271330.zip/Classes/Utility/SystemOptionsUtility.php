<?php
namespace Sfgz\SfgzDesign\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class SystemOptionsUtility
 * 
 */

class SystemOptionsUtility {

	/**
	* settings
	*
	* @var array
	*/
	Private $settings = array();
	
	protected $objectManager ;

	/**
	 * typoScriptService
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $typoScriptService = NULL;
	
	/**
	 * getSettings
	 * @return array
	 */
	public function getSettings( )
	{
	    return $this->settings;
	}
	
	/**
	 * getUserOptions
	 * 
	 * @return array
	 */
	public function getUserOptions() 
	{
	    $userObj = $GLOBALS['TSFE']->fe_user;
	    if( !$userObj ) return $this->settings['userfields'];
	    
	    $myData = $userObj->getKey('user', 'userfields');
	    if( count($myData) ){
			  foreach(array_keys($this->settings['userfields']) as $ix){
				      if( isset($myData[$ix]) ) $this->settings['userfields'][$ix] = $myData[$ix];
			  }
	    }
	    return $this->settings['userfields'];
	}
	
	/**
	 * resetUserOptions
	 * 
	 * @return array
	 */
	public function resetUserOptions() 
	{
	    $userObj = $GLOBALS['TSFE']->fe_user;
	    if( !$userObj ) return $this->settings['userfields'];
	    
	    $userObj->setKey("user","userfields", '');
	    $userObj->sesData_change = true;
	    $userObj->storeSessionData();
	    return $this->settings['userfields'];
	}
	
	/**
	 * setUserOptions
	 * 
	 * @param array $someSettings
	 * @return array
	 */
	public function setUserOptions( $someSettings ) 
	{
	      foreach(array_keys($this->settings['userfields']) as $ix){
				   if( isset($someSettings[$ix]) ) $this->settings['userfields'][$ix]['value'] = $someSettings[$ix];
	      }
	      $userObj = $GLOBALS['TSFE']->fe_user;
	      if( !$userObj ) return $this->settings['userfields'];
	      
	      $userObj->setKey("user","userfields", $this->settings['userfields']);
	      $userObj->sesData_change = true;
	      $userObj->storeSessionData();
	    return $this->settings['userfields'];
	}
}
