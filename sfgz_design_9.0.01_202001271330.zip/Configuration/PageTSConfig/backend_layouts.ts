mod {
    web_layout {
        BackendLayouts {
           1 {
                title = Dreispalter
                config {
					backend_layout {
							colCount = 3
							rowCount = 2
							rows {
								1 {
									columns {
										1 {
											name = Oben
											colPos = 0
											colspan = 4
										}
									}
								}
								2 {
									columns {
										1 {
											name = Linke Spalte
											colPos = 1
										}
										2 {
											name = Mittlere Spalte
											colPos = 2
											colspan = 2
										}
										3 {
											name = Rechte Spalte
											colPos = 3
										}
									}
								}
							}
					}
                }
                icon = EXT:sfgz_design/Resources/Public/Img/Backend/layout_3_cols_large.png
            }
            
            2 {
                title = Nur Inhalt ohne Menue
                config {
						backend_layout {
								colCount = 1
								rowCount = 1
								rows {
										1 {
											columns {
												1 {
													name = Inhalt (ohne Menue)
													colPos = 0
												}
											}
										}
								}
						}
                }
                icon = EXT:sfgz_design/Resources/Public/Img/Backend/layout_1_column.png
            }
            
        }
    }
}
# mod.web_layout.BackendLayouts.3 < mod.web_layout.BackendLayouts.1
# mod.web_layout.BackendLayouts.4 < mod.web_layout.BackendLayouts.1
# mod.web_layout.BackendLayouts.5 < mod.web_layout.BackendLayouts.1
