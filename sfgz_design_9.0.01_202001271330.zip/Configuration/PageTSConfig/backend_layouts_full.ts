mod {
    web_layout {
        BackendLayouts {
            1 {
                title = Dreispalter breit
                config {
					backend_layout {
							colCount = 4
							rowCount = 2
							rows {
								1 {
									columns {
										1 {
											name = Oben
											colPos = 0
											colspan = 4
										}
									}
								}
								2 {
									columns {
										1 {
											name = Linke Spalte
											colPos = 1
										}
										2 {
											name = Mittlere Spalte
											colPos = 2
											colspan = 2
										}
										3 {
											name = Rechte Spalte
											colPos = 3
										}
									}
								}
							}
					}
                }
                icon = EXT:sfgz_design/Resources/Public/Img/Backend/layout_3_cols_large.png
            }
            
            3 {
                title = Zweispalter links
                config {
					backend_layout {
							colCount = 3
							rowCount = 2
							rows {
								1 {
									columns {
										1 {
											name = Oben
											colPos = 0
											colspan = 2
										}
										2 {
											name = Rechte Spalte
											colPos = 3
											rowspan = 2
										}
									}
								}
								2 {
									columns {
										1 {
											name = Linke Spalte
											colPos = 1
										}
										2 {
											name = Mittlere Spalte
											colPos = 2
										}
									}
								}
							}
					}
                }
                icon = EXT:sfgz_design/Resources/Public/Img/Backend/layout_2_cols_left.png
            }
            
            4 {
                title = Zweispalter rechts
                config {
					backend_layout {
							colCount = 3
							rowCount = 2
							rows {
								1 {
									columns {
										1 {
											name = Linke Spalte
											colPos = 1
											rowspan = 2
										}
										2 {
											name = Oben
											colPos = 0
											colspan = 2
										}
									}
								}
								2 {
									columns {
										1 {
											name = Mittlere Spalte
											colPos = 2
										}
										2 {
											name = Rechte Spalte 
											colPos = 3
										}
									}
								}
							}
					}
                }
                icon = EXT:sfgz_design/Resources/Public/Img/Backend/layout_2_cols_right.png
            }
           
            2 {
                title = Nur Inhalt ohne Menue
                config {
						backend_layout {
								colCount = 1
								rowCount = 1
								rows {
										1 {
											columns {
												1 {
													name = Inhalt (ohne Menue)
													colPos = 0
												}
											}
										}
								}
						}
                }
                icon = EXT:sfgz_design/Resources/Public/Img/Backend/layout_1_column.png
            }
             
            5 {
                title = Zweispalter mit Sidebar links
                config {
					backend_layout {
							colCount = 2
							rowCount = 3
							rows {
								1 {
									columns {
										1 {
											name = Oben
											colPos = 0
											colspan = 2
										}
									}
								}
								2 {
									columns {
										1 {
											name = Linke Spalte
											colPos = 1
										}
										2 {
											name = Rechte Spalte
											colPos = 3
										}
										2 {
										}
									}
								}
								3 {
									columns {
										1 {
											name = Mittlere Spalte
											colPos = 2
											colspan = 2
										}
									}
								}
							}
					}
                }
                icon = EXT:sfgz_design/Resources/Public/Img/Backend/layout_sitemap.png
            }
            
        }
    }
}
