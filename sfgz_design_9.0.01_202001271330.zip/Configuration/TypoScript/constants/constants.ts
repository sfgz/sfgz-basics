# customcategory=sfgz_design=SfGZ Design
# customsubcategory=grund=Grundeinstellungen
# customsubcategory=style=Style
# customsubcategory=special1Uid=Spezielle Seiten
# customsubcategory=special2Content=Spezielle Inhalte
# customsubcategory=teaser=Teaser
 
plugin.sfgz_design {
	view {
		# cat=sfgz_design/file; type=string; label=Path to template root
		templateRootPaths.10 = EXT:sfgz_design/Resources/Private/Templates/
		# cat=sfgz_design/file; type=string; label=Path to template partials
		partialRootPaths.10 = EXT:sfgz_design/Resources/Private/Partials/
		# cat=sfgz_design/file; type=string; label=Path to template layouts 
		layoutRootPaths.10 = EXT:sfgz_design/Resources/Private/Layouts/
	}
	settings {
	    # cat=sfgz_design/grund; type=text; label=Browser-Titel:Website-Titel im Rahmen des Browsers.
	    browsertitle = Datenbanken
	    # cat=sfgz_design/grund; type=text; label=Website-Titel:Website-Titel auf Seite.
	    sitetitle = Technopolygrafie - Datenbanken
	    # cat=sfgz_design/grund; type=text; label=Small Dev Website-Titel:Website-Titel auf Smartphone Seite.
	    siteshorttitle = Datenbanken
	    # cat=sfgz_design/grund; type=text; label=Website-Subtitel:Kleiner Subtitel neben Website-Titel auf Seite.
	    sitesubtitle = SfGZ DBs
	    # cat=sfgz_design/grund; type=text; label=baseURL:Basis URL mit Protokoll zB. http://my.example.com/path2typo3/
	    baseURL = https://polygrafie.sfgz.ch/datenbanken/
	    # cat=sfgz_design/grund; type=text; label=absRefPrefix:Wenn gesetzt, wird der Pfadteil allen mit TypoScript erzeugten Links vorangestellt. Z.B.:  /path2typo3/
	    absRefPrefix = /datenbanken/
	    # cat=sfgz_design/grund; type=int; label=Meldungen nach x Sekunden ausblenden, oder nicht 0.
	    hideAlerts = 0
	    
	    # cat=sfgz_design/style/1; type=boolean; label=Extended Style:Icons und zusaetzliche Funktionen bereitstellen
	    extend = 0
	    
	    # cat=sfgz_design/special1Uid/1; type=int; label=Hauptseite uid.
	    mainpage_uid = 1
	    # cat=sfgz_design/special1Uid/2; type=int; label=Loginseite uid.
	    loginpage_uid = 5
	    # cat=sfgz_design/special1Uid/3; type=int; label=Kontakt: uid der Toolbox Seite Kontakt, wird immer angezeigt
	    kontakt_uid = 0
	    # cat=sfgz_design/special1Uid/4; type=int; label=Sitemap: uid der Toolbox Seite Sitemap, wird immer angezeigt
	    sitemap_uid = 0
	    # cat=sfgz_design/special1Uid/5; type=int; label=Profil uid: uid der Toolbox Seite Profil, wird nur angezeigt wenn eingeloggt
	    profil_uid = 0
	    # cat=sfgz_design/special1Uid/6; type=int; label=Handbuch Hauptseite: Uid der Seite mit Handbuch. Weitere Handbuecher benoetigen jeweils ein Seitentemplate.
	    handbuch_uid = 0
	    
	    # cat=sfgz_design/special2Content/6; type=int; label=permacontent:Uid des Content Elements in der Sidebar.
	    permacontent = 0
	    # cat=sfgz_design/special2Content/7; type=int; label=css_content:Uid des Content Elements mit CSS Code für Header.
	    css_content = 153
	    
	    # cat=sfgz_design/teaser/1; type=boolean; label=JQuery laden: Markierung aufheben wenn JQuery anderweitig geladen wird
	    loadjquery=1
	    # cat=sfgz_design/teaser/2; type=int; label=Dateispeicher Teaserbilder: Uid eines Dateispeichers, der den Ordner Teaser/ enthaelt
	    folderrecord_uid = 3
	    # cat=sfgz_design/teaser/3; type=string; label=Teaser auf Seite(n): Mehrere Seiten mit Pipe trennen [ 1|27|... ]
	    teaser_uid = 1

	    # cat=sfgz_design/teaser/4; type=int; label=Wartezeit: Wartezeit am Anfang bis ausblenden startet
	    delay = 1000
	    # cat=sfgz_design/teaser/5; type=int; label=Wechseldauer: Dauer des Ueberganges.
	    animation = 2500
	    # cat=sfgz_design/teaser/6; type=int; label=Ausblenddauer: Dauer bis Teaser ganz ausgeblendet wird.
	    fadeout = 25000

	    # cat=sfgz_design/file; type=string; label=Logos - Verzeichnis: relativer Pfad zum Bilder - Verzeichnis.
	    pathToImg = typo3conf/ext/sfgz_design/Resources/Public/Img/
	}
}


