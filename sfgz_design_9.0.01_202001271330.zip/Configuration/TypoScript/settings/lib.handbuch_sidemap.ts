## handbuch_sitemap almost like sitemap_page

lib.handbuch_sitemap = COA
lib.handbuch_sitemap {
		wrap = <div class="screen handbuch_sitemap visiblepage_navigation">|</div>

		20 = HMENU
		20 {
				### include pages with the checkbox "Not in menu" checked
				includeNotInMenu = 1
				### list only pages from specified directory
				special = directory
				special.value = {$plugin.sfgz_design.settings.handbuch_uid}
				### Erste Ebene ###
				1 = TMENU
				1 {
					wrap = <ul class="pages-menu">| </ul>
					expAll = 1
					NO.wrapItemAndSub = <li class="pages-menuitem-normal">|</li> 
					NO.ATagParams.cObject = COA
					NO.ATagParams.cObject.10 = TEXT
					NO.ATagParams.cObject.10.value = onfocus="this.blur()"
					ACT < .NO
					ACT = 1
					ACT.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
					ACT.wrapItemAndSub = <li class="pages-menuitem-selected">|</li>
				}
				2 < .1
				2.wrap = <ul class="sub-pages-menu">| </ul>
				2.NO = 1
				3 < .2
				3.NO = 1
				4 < .2
				4.NO = 1
				
			#   page-subtitle in navigation (disabled)
			#	2 {
			#		ACT.wrapItemAndSub.cObject = TEXT
			#		ACT.wrapItemAndSub.cObject.value =<li class="pages-menuitem-selected"> | &nbsp; <span class="smallhint">{page:subtitle}</span></li>
			#		ACT.wrapItemAndSub.cObject.insertData = 1
			#	}
		}
}


temp.handbuch_maintitle = TEXT
temp.handbuch_maintitle {
	wrap = <H3 class="info_pagetitle page-title ">|</H3>
		insertData = 1
		value = {DB:pages:{$plugin.sfgz_design.settings.handbuch_uid}:title}
		typolink.parameter = {$plugin.sfgz_design.settings.handbuch_uid}
}

## wenn unterhalb startseite handbuch
[PIDinRootline = {$plugin.sfgz_design.settings.handbuch_uid}] 
	lib.clicknavi_booklet = COA
	lib.clicknavi_booklet.wrap = <div class="clicknavi_booklet">|</div>
	lib.clicknavi_booklet.10 = TEXT
	lib.clicknavi_booklet.10 < temp.handbuch_maintitle
	lib.clicknavi_booklet.20 = HMENU
	lib.clicknavi_booklet.20 < lib.handbuch_sitemap
[global]


lib.handbuch_booktitle = COA_INT
lib.handbuch_booktitle {
	10 < temp.handbuch_maintitle

	# aktueller Seiten-Untertitel aus Tabelle page
	15 = COA_INT
	15 {
		wrap = |
		# wenn kein subtitle dann anders wrappen
		wrap.override.if.isFalse.data = page:subtitle
		wrap.override = <div style="display:none;">|</div>
		15 = TEXT
		15 {
			wrap = <div class="navigation_subtitle under-title">|</div>
			insertData = 1
			data = page:subtitle
		}
	}
	# aktueller Seitentitel aus Tabelle page
	20 = TEXT
	20 {
		wrap = <p style="margin:0;padding:0;font-size:90%;font-style:italic;">|</p>
		insertData = 1
		data = page:title
	}
}

## wenn auf startseite handbuch
[globalVar = TSFE:id = {$plugin.sfgz_design.settings.handbuch_uid}]
	lib.handbuch_sitemap.wrap = <div class="screen handbuch_sitemap">|</div>
	lib.clicknavi_booklet >=
	lib.handbuch_booktitle.20 >=
[global]

