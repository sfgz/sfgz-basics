## lib.permacontent
lib.permacontent = COA
lib.permacontent {
      wrap = <div class="handbuch_sitemap">|</div>
      
      10 = RECORDS
      10 {
	  	  tables = tt_content
	  	  source = {$plugin.sfgz_design.settings.permacontent}
      }
}

## dont show permacontent on handbuch-startpage
[globalVar = TSFE:id == {$plugin.sfgz_design.settings.handbuch_uid}]
	lib.permacontent >
[global]
