function fitStyleToWindowSize( breakpoint ) {
		viewportwidth = $(window).width();
		if (viewportwidth > breakpoint ) {
 			$('.clicknavi').fadeOut(0);
		}
}
$(document).ready(function(){
	fitStyleToWindowSize( 635 );
	window.onresize = function(event) { fitStyleToWindowSize( 635 ); }

	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 150) { // Wenn 150 Pixel gescrolled wurde
				$('.info_username').fadeOut(300);
				$('.info_upward').fadeIn(300);
			} else {
				$('.info_upward').fadeOut(300);
				$('.info_username').fadeIn(300);
			}
			
		});
	});	
	
});

function anfang() {
	$("body,html").animate({
		scrollTop: 0,
		scrollLeft: 0
	}, 550);
}

function ende() {
	$("body,html").animate({
		scrollTop: $(document).height() + $(window).height(),
		scrollLeft: 8
	}, 550);
}
