<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "sfgz_feloginrsaauth".
 *
 * Auto generated 16-01-2016 18:13
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array (
	'title' => 'SfGZ FE-Login Auth',
	'description' => 'Login gegen Webmail und preauth Link',
	'category' => 'fe',
	'version' => '9.5.56',
	'state' => 'stable',
	'uploadfolder' => 0,
	'createDirs' => '',
	'clearcacheonload' => 0,
	'author' => 'Daniel Rueegg',
	'author_email' => 'colormixture@verarbeitung.ch',
	'author_company' => 'sfgz',
	'constraints' => 
	array (
		'depends' => 
		array (
			'felogin' => '',
			'typo3' => '6.2.0-9.9.99',
		),
		'conflicts' => 
		array (
		),
		'suggests' => 
		array (
		),
	),
);

