<?php
namespace Sfgz\SfgzFeloginauth\Utility;

use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;

/***************************************************************
*
*  Copyright notice
*
*  (c) 2016 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
*
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 3 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/

/**
* Class PreauthLinkUtility
* Generiert Preauth-Links um auf «intern.sfgz.ch» einzuloggen
*/

class PreauthLinkUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
    * Property aIngredients
    *  The field-order 
    *  is set in the extension-configuration 
    *  and is essential for successful login!
    *
    * @var array
    */
    Public $aIngredients = null;
    
    /**    
    * __construct
    * 
    * @return void
    */
    public function __construct() {
            $this->setSecretIngredients();
    }
    
    /**    
    * preauthLink
    * 
    * @param  string $content Empty string (no content to process)
    * @param  array $conf TypoScript configuration
    * @return string
    */
    public function preauthLink($content, $conf) {
    
            $uri = $this->preauthUri();

            $timeInfo = 'g&uuml;ltig bis um ' . $this->getSanitizedTime( 600 )  . ' Uhr';
            $userFulllname = $GLOBALS['TSFE']->fe_user->user['name'];

            $subdom = isset($conf['subdomain'] ) && !empty( $conf['subdomain'] ) ? $conf['subdomain'] : '';
            $subdom2 = isset($conf['subdomain2'] ) && !empty( $conf['subdomain2'] ) ? $conf['subdomain2'] : '';
            
            $strTitle =  'title="Link f&uuml;r &laquo;'.$userFulllname.'&raquo;, '.$timeInfo.'"';

            $strForm =  '';
            $cssclass = isset( $conf['cssclass'] ) ? ' class="'.$conf['cssclass'].'"' : '';
            if( $subdom ) $strForm .=  '<a ' . $strTitle . $cssclass.' target="_blank" href="' . $subdom . '/apps/Login.aspx' . $uri . '">' . $subdom . '</a>';
            if( $subdom2 && $subdom) $strForm .= ', ';
            if( $subdom2 ) $strForm .=  '<a ' . $strTitle . $cssclass.' target="_blank" href="' . $subdom2 . '/apps/Login.aspx' . $uri . '">' . $subdom2 . '</a>';
            $strForm .= '';
            
            return $strForm;
    }
    
    /**    
    * preauthUri
    * 
    * @param  string $content Empty string (no content to process)
    * @param  array $conf TypoScript configuration
    * @return string
    */
    public function preauthUri( $content = '' , $conf = [] ) {

            $url = '';
            foreach( $this->aIngredients as $fieldname => $value ){
                $url .= empty($url) ? '?' : '&amp;';
                $url .= $fieldname . '=' . $value . '';
            }
            return $url;
    }
    
    /**    
    * setSecretIngredients
    * 
    * @return boolean
    */
    Private function setSecretIngredients() {
            $extensionConfiguration = GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('sfgz_feloginauth');

            // secret ingredients: preauthKey, role, school, fieldSeparer, fieldorder
            $aTmpIngredients = [
                'timestamp' => time() * 1000,
                'account' => $GLOBALS['TSFE']->fe_user->user['username'],
                'role' => $extensionConfiguration['role'],
                'school' => $extensionConfiguration['school'],
            ];
            $aOrder = explode( ',' , $extensionConfiguration['fieldorder'] );
            
            // rebuild array aIngredients
            unset($this->aIngredients);
            foreach( $aOrder as $rawFieldname ){
                $fieldname = trim($rawFieldname);
                $this->aIngredients[ $fieldname ] = isset($aTmpIngredients[$fieldname]) ? $aTmpIngredients[$fieldname] : '';;
            }
            
            // create preauth secret string
            $aPartlyIngred = $this->aIngredients;
            if( isset($aPartlyIngred['preauth']) ) unset($aPartlyIngred['preauth']);
            $xDataString = implode( $extensionConfiguration['fieldSeparer'] , $aPartlyIngred );
            $preauth = hash_hmac('sha1', $xDataString , $extensionConfiguration['preauthKey'] );
            $this->aIngredients['preauth'] = $preauth;
            
            return true;
    }

    /**
    * getSanitizedTime
    *
    * @param int $addSeconds
    * @return string
    */
    private function getSanitizedTime( $addSeconds = 0 )
    {
            
            $typo3Timezone = $GLOBALS['TYPO3_CONF_VARS']['SYS']['phpTimeZone'] ; // MEZ | UCT
            $localTimeZoneString = 'Europe/Zurich';
            if( $typo3Timezone ){
                $defaultTimeZoneString = $typo3Timezone;
            
            }else{
                $sysTimezone = date_default_timezone_get();
                $defaultTimeZoneString = $sysTimezone ? $sysTimezone : $localTimeZoneString;
            }
            
            $timeZone = new \DateTimeZone( $defaultTimeZoneString );

            $dateString = date( 'Y-m-d H:i:s' , ( time() + $addSeconds ) );
            $dateObject = new \DateTime( $dateString , $timeZone );
            
            if( $localTimeZoneString != $defaultTimeZoneString ){
                $localTimeZone = new \DateTimeZone( $localTimeZoneString );
                $dateObject->setTimezone( $localTimeZone );
            }
            
            return $dateObject->format('H:i');
    }
    
}
