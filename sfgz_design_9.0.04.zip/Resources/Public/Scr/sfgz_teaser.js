function showTeaser( delaytime , durationtime , fadeouttime , pathToImg ) {
	
	$('#container').prepend(
		'<div id="teaser_spacer"></div><div id="teaser_box"><img id="teaser_img" src="' + pathToImg + getRandomImage() + '" /></div>'
	);
	
   	$('#teaser_spacer').fadeIn(0); 
	
	setTimeout(function(){
		$({
			z: 7
		}).animate({
			z: 0
		}, {
			step: function() {
				$('#teaser_box').css('zIndex', ~~this.z);
			},
			duration: durationtime
		});
	
		setTimeout(function(){
			$('#teaser_box').fadeOut( fadeouttime ); 
		}, durationtime );
		
	}, delaytime );

}
function getRandomImage() {
    var imgAr = getTeaserImages();
	var num = Math.floor( Math.random() * imgAr.length );
    var img = imgAr[ num ];
    return img;
}
