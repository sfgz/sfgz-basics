#teaser images
[globalVar = TSFE:id = {$plugin.sfgz_design.settings.teaser_uid} ]
	page.30 = COA_INT
	page.30.stdWrap.noTrimWrap (
|<script>|</script>
|
		)
	page.30.10 = FILES
	page.30.10 {
		stdWrap.noTrimWrap (
|
		function getTeaserImages(){ return [ |"background01.svg" ];};
		showTeaser( {$plugin.sfgz_design.settings.delay} , {$plugin.sfgz_design.settings.animation} , {$plugin.sfgz_design.settings.fadeout} , '{$plugin.sfgz_design.settings.pathToImg}/Teaser/' );
|
		)
		folders = {$plugin.sfgz_design.settings.folderrecord_uid}:/
		renderObj = TEXT
		renderObj {
			stdWrap.data = file:current:name
			stdWrap.wrap = "|",
		}
	}
[global]

plugin.tx_sfgzkurs_teaser._CSS_DEFAULT_STYLE (
	#teaser_spacer {
		position:absolute;
		z-index:0;
		top:0;
		width:100%;
		min-height:1500px;
		display:none;
	}
	#teaser_box {
		position:absolute;
		z-index:7;
		top:-2px;
		left:8;
	}
	#teaser_img {
		height:1400px;
		width:1400px;
	}
)
