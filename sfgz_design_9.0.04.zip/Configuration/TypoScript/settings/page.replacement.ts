## make some variables accessable for FE: vorname, nachname, email, fachbereich

page.10.variables.content_main.stdWrap.replacement {
  
  7 {
    search = #preauth#
    replace.cObject = USER_INT
    replace.cObject.userFunc = Sfgz\SfgzFeloginauth\Utility\PreauthLinkUtility->preauthLink
    replace.cObject.cssclass = external-link
    replace.cObject.subdomain = https://daten.sfgz.ch
  }

  107 < .7
  107.search = #preauth_intern#
  107.replace.cObject.subdomain = https://intern.sfgz.ch

  108 < .7
  108.search = #preauth_alt#
    replace.cObject.cssclass = 
  108.replace.cObject.subdomain = https://alt.sfgz.ch
  
  8 {
    search = #preauthuri#
    replace.cObject = USER_INT
    replace.cObject.userFunc = Sfgz\SfgzFeloginauth\Utility\PreauthLinkUtility->preauthUri
  }
  
  10 {
    search = #vorname#
    replace.cObject = COA_INT
    replace.cObject.1 = TEXT
    replace.cObject.1 {
      data = TSFE:fe_user|user|first_name
      insertData=1
    }
  }
  
  11 {
    search = #is2filename#
    replace.cObject = COA_INT
    replace.cObject.1 = TEXT
    replace.cObject.1 {
        data = date:U
        strftime = %d-%m-%Y
        noTrimWrap = |Auswahl____|.csv|
    }
  }

  15 < .10
  15.search = _VORNAME_
  
  20 < .10
  20.search = #nachname#
  20.replace.cObject.1.data = TSFE:fe_user|user|last_name
  
  21 < .20
  21.search = _NACHNAME_

  22 < .10
  22.search = #user#
  22.replace.cObject.1.data = TSFE:fe_user|user|username
  
  23 < .22
  23.search = _USER_
  
  24 < .10
  24.search = #telephone#
  24.replace.cObject.1.data = TSFE:fe_user|user|telephone
  24 {
    replace.cObject = USER_INT
    replace.cObject.userFunc = Sfgz\SfgzDesign\Utility\DisplayUserInfoUtility->getBlankField
    replace.cObject.fields = telephone
    replace.cObject.default = +41 44 446 97 77
  }
  
  26 < .10
  26.search = #title#
  26.replace.cObject.1.data = TSFE:fe_user|user|title

  27 < .10
  27.search = #titel#
  27.replace.cObject.1.data = TSFE:fe_user|user|title

  30 < .10
  30.search = #email#
  30.replace.cObject.1.data = TSFE:fe_user|user|email
  
  35 < .30
  35.search = _EMAIL_
  
  40 < .10
  40.search = #fachbereich1#
  40.replace.cObject.1.data = TSFE:fe_user|user|company
  40.replace.cObject.1.wrap = |<br>
  40.replace.cObject.1.required = 1
  
  44 < .40
  44.search = #fachbereich#
  
  45 < .40
  45.search = _FACHBEREICH_
  
  50 < .10
  50.search = #fachbereich2#
  50.replace.cObject.1.data = TSFE:fe_user|user|city
  50.replace.cObject.1.wrap = |<br>
  50.replace.cObject.1.required = 1
  
  54 < .50
  54.search = #fachbereiche#
  
  55 < .50
  55.search = _FACHBEREICH2_
  
  61 < .10
  61.search = #name#
  61.replace.cObject.1.data = TSFE:fe_user|user|name
  
  62 < .10
  62.search = #abteilung#
  62.replace.cObject.1.data = TSFE:fe_user|user|abteilung
  
  63 {
    search = #signatur#
    replace.cObject = USER_INT
    replace.cObject.userFunc = Sfgz\SfgzDesign\Utility\DisplayUserInfoUtility->getBlankField
    replace.cObject.fields = abteilung
  }
  
  65 < .60
  65.search = _TITEL_
  
  66  < .10
  66.search = #fullname#
  66.replace.cObject.1.data = TSFE:fe_user|user|title
  66.replace.cObject.1.wrap = |&nbsp;
  66.replace.cObject.1.wrap.override.if.isFalse.data = TSFE:fe_user|user|title
  66.replace.cObject.1.wrap.override = |
  66.replace.cObject.3 < .66.replace.cObject.1
  66.replace.cObject.3.data = TSFE:fe_user|user|name
  66.replace.cObject.3.wrap = |
  68  < .66
  68.search = _NAME_
  69  < .66
  69.search = _FULLNAME_
  
  70 {
    search = #baseurl#
    replace.cObject = TEXT
    replace.cObject.value = {$plugin.sfgz_design.settings.baseURL}
  }
  75 < .70
  75.search = _BASEURL_

  80 < .70
  80 {
    search = &lt;s&gt;
    replace.cObject.value = <del>
  }
  82 < .80
  82.search = <s>
  
  84 < .70
  84 {
    search = &lt;/s&gt;
    replace.cObject.value = </del>
  }
  86 < .84
  86.search = </s>
  
  
  90 {
    search = _TO-PAGE_
	replace.cObject = COA_INT
	replace.cObject.10 = TEXT
    replace.cObject.10.value = 
	replace.cObject.20 = TEXT
  }
  95 < .90
  95.search = _PAGE_
  95.replace.cObject.20.data = GP:page

}

[globalVar = GP:page>0]
page.10.variables.content_main.stdWrap.replacement.90 {
	replace.cObject.10.value = ?id=
	replace.cObject.20.data = GP:page
}
[global]

page.10.variables.content_column_1.stdWrap.replacement < page.10.variables.content_main.stdWrap.replacement
page.10.variables.content_column_2.stdWrap.replacement < page.10.variables.content_main.stdWrap.replacement
page.10.variables.content_border.stdWrap.replacement < page.10.variables.content_main.stdWrap.replacement

