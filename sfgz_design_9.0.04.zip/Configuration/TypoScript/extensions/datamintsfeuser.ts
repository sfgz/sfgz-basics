# Use field 'company' for scool purpose
plugin.tx_srfeuserregister_pi1._LOCAL_LANG.default.Company = Schule
plugin.tx_srfeuserregister_pi1._LOCAL_LANG.de.Company = Schule

plugin.datamintsfeuser._CSS_DEFAULT_STYLE (
		.tx-datamintsfeuser-pi1 input[type=text],
		.tx-datamintsfeuser-pi1 input[type=password],
		.tx-datamintsfeuser-pi1 select,
		.tx-datamintsfeuser-pi1 textarea {
			max-width: 284px !important;
			width: 100% !important;
		}
)
