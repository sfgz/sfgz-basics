[globalString = IENV:HTTP_HOST=intern.sfgz.ch] && [globalString = ENV:HTTPS=on]
  plugin.sfgz_design.settings.baseURL = https://intern.sfgz.ch/

[globalString = IENV:HTTP_HOST=alt.sfgz.ch]
  plugin.sfgz_design.settings.baseURL = http://alt.sfgz.ch/
[globalString = IENV:HTTP_HOST=alt.sfgz.ch] && [globalString = ENV:HTTPS=on]
  plugin.sfgz_design.settings.baseURL = https://alt.sfgz.ch/

[globalString = IENV:HTTP_HOST=job.sfgz.ch]
  plugin.sfgz_design.settings.baseURL = http://job.sfgz.ch/
[globalString = IENV:HTTP_HOST=job.sfgz.ch] && [globalString = ENV:HTTPS=on]
  plugin.sfgz_design.settings.baseURL = https://job.sfgz.ch/

[global]
