<?php

namespace Sfgz\SfgzDesign\Hook;

/***************************************************************
 *
 *  https://bitbucket.org/snippets/scw_bihlmaier/5ezpaB
 * 
 * Class PreProcess
 * Frontend Editing: Repair links when saving
 * 
 * This hook is registered in ext_localconf.php: 
 * $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['FrontendEditing']['requestPreProcess'][] = \Sfgz\SfgzDesign\Hook\PreProcess::class;
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class PreProcessFeEdit
 *  used by Frontend Editing: Repair links when saving 
 *  loaded in ext_localconf.php
 */

class PreProcessFeEdit implements \TYPO3\CMS\FrontendEditing\RequestPreProcess\RequestPreProcessInterface
{
    public function preProcess(string $table, array $record, string &$fieldName, string $content, bool &$isFinished): string {

        $content = preg_replace_callback('/<a\s[^>]*href=\"([^\"]*)\"[^>]*>(.*)<\/a>/siU', function($matches) {
            $wrong = $matches[1];

            if(!preg_match('/^(t3|http|https|tel):\/\//', $wrong)) {
                if (substr($wrong, strlen($wrong)-1 ) == "/") {
                    $wrong = substr($wrong, 0, strlen($wrong) - 1);
                }

                $queryBuilder = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Database\ConnectionPool::class)->getQueryBuilderForTable('tx_realurl_pathdata');
                $page = $queryBuilder
                    ->select('page_id')
                    ->from('tx_realurl_pathdata')
                    ->where(
                        $queryBuilder->expr()->eq('pagepath', $queryBuilder->createNamedParameter($wrong))
                    )
                    ->execute()
                    ->fetchColumn(0);

                if($page) {
                    $replace = "t3://page?uid=" . $page;
                } else {
                    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') ||
                        $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                    $domainName = $_SERVER['HTTP_HOST'];
                    $replace = $protocol.$domainName . '/' . $wrong . '/';
                }

                $return = str_replace($matches[1], $replace, $matches[0]);

                return $return;
            } else {
                return  $matches[0];
            }
        }, $content);
        $isFinished = true;
        return $content;
    }
}
