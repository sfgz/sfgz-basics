<?php
namespace SfGZ\SfgzPlan\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;


/***
 *
 * This file is part of the "plan" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Daniel Rueegg
 *
 ***/
/**
 * TimetableController
 */
class TimetableController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * timetableRepository
     * 
     * @var \SfGZ\SfgzPlan\Domain\Repository\TimetableRepository
     * @inject
     */
    protected $timetableRepository = null;

	/**
	* dateUtility
	*
	* @var \SfGZ\SfgzPlan\Utility\DateUtility
	*/
	protected $dateUtility = null;
	
    /**
     * action list
     * 
     * @return void
     */
    public function listAction()
    {
        $this->dateUtility = GeneralUtility::makeInstance('SfGZ\\SfgzPlan\\Utility\\DateUtility');

        $timetables = $this->timetableRepository->findAll();
        $this->view->assign('timetables', $timetables);

       // $this->periodService = GeneralUtility::makeInstance('Mff\\MffLsb\\Domain\\Repository\\PeriodsRepository');
        $this->periodsRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\PeriodsRepository');

        $period = $this->periodsRepository->findAll();
        $this->view->assign('debug', [ 'tt' => $timetables , 'per' => $period ] );

//         $this->importJs2Service = GeneralUtility::makeInstance('SfGZ\\SfgzPlan\\Service\\ImportJs2Service');
//         $aTablesFromApi = $this->importJs2Service->importTablesFromApiIntoDB();
//         $aDat = $this->importJs2Service->data;
//         $aTablesFromApi[] = array_slice( $aDat , 0 , 100  );
//         $this->view->assign('settings', $aTablesFromApi );
        
    }
}
