<?php
namespace SfGZ\SfgzPlan\Service;

use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

/**
 * Service that reads JSON data for the "svconnector_jsonis2" extension.
 *
 * @author Dani Rueegg <colormixture@verarbeitung.ch>
 * @package TYPO3
 * @subpackage tx_sfgzplan
 */
class ImportJs2Service implements \TYPO3\CMS\Core\SingletonInterface
{

    /**
     * statistic
     * 
     * @var array
     */
    public $statistic = [];

    /**
     * data
     * 
     * @var array
     */
    public $data = [];

    /**
     * settings
     * 
     * @var array
     */
    public $settings = [];
    /**
     * extKey
     * 
     * @var string
     */
    public $extKey = 'sfgz_plan';    // The extension key.

    /**
     * dumpDirectory
     * 
     * @var string
     */
    public $dumpDirectory = '';    // The upload dir
    
    /**
     * timetableRepository
     * 
     * @var \SfGZ\SfgzPlan\Domain\Repository\TimetableRepository
     * @inject
     */
    protected $timetableRepository = null;

	/**
	* dateUtility
	*
	* @var \SfGZ\SfgzPlan\Utility\DateUtility
	*/
	protected $dateUtility = null;

	/**
	* periodService
	*
	* @var \Mff\MffLsb\Service\PeriodService
	*/
	protected $periodService = null;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

    /**
     *
     * @return boolean TRUE if the service is available
     */
    public function __construct()
    {
            // settings, directories, extConf
            $dumpDirectory = 'uploads/tx_' . str_replace( '_' , '' , $this->extKey ) . '/js2/';
            $this->dumpDirectory = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $dumpDirectory );

            $this->extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf'][$this->extKey]);
            
            $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
            $this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
            
            $this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
            $fullsettings = $this->configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
            $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
            $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray( $fullsettings['plugin.']['tx_sfgzplan_tt.']['settings.'] );
            
            // repositories and persistence
            $storageLsb = $this->typoScriptService->convertTypoScriptArrayToPlainArray( $fullsettings['plugin.']['tx_mfflsb_template.']['persistence.'] );
            $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $querySettings->setRespectStoragePage( FALSE );
            $querySettings->setStoragePageIds( [ $this->settings['storagePid'] ] );
            $this->timetableRepository = $this->objectManager->get('SfGZ\\SfgzPlan\\Domain\\Repository\\TimetableRepository');
            $this->timetableRepository->setDefaultQuerySettings( $querySettings );

            $queryS2ettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $queryS2ettings->setRespectStoragePage( FALSE );
            $queryS2ettings->setStoragePageIds( [ $storageLsb['periodsStoragePid'] ] );
            $this->periodsRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\PeriodsRepository');
            $this->periodsRepository->setDefaultQuerySettings( $queryS2ettings );
            
            // Utilities
            $this->dateUtility = GeneralUtility::makeInstance('SfGZ\\SfgzPlan\\Utility\\DateUtility');

            // periodService deafult is mfflsb fallback is own
            $this->periodService = GeneralUtility::makeInstance('Mff\\MffLsb\\Service\\PeriodService');
            
            $this->statistic = [ 'created'=>0 , 'existent'=>0  , 'pid'=>$this->settings['storagePid'] , 'timeElapsed'=>time(), 'periodenEingesetzt'=>0  ];
            return true;
    }

    /**
     * importTablesFromApiIntoDB
     * 
     * @return array
     */
    Public function importTablesFromApiIntoDB()
    {
        $this->data = $this->fuseRelatedViews( false );// do not store json-files
        
        $this->setPeriod();
        
        $statistic = $this->storeDataAsObject();
        return $statistic;
    }

    /**
     * fuseRelatedViews
     * 
     * @param bool $store optional, default is 'true'
     * @return array
     */
    Private function fuseRelatedViews( $store = false )
    {
        $data = $this->importAllTables($store);

        $aClass = [];
        if(is_array($data['class']) ){
            foreach( $data['class'] as $i => $rs ){
                $aClass[ $rs['ID'] ] = [ 'class_short'=> $rs['ClassShort'] ];
            }
        }
        
        $aLocation = [];
        foreach( $data['location'] as $i => $rs ){
            $aLocation[ $rs['ID'] ] = [ 'room'=> $rs['room'], 'building'=>$rs['building']];
        }
        
        $aCourse = [];
        foreach( $data['course'] as $i => $rs ){
            foreach( $this->settings['table_mapping_course'] as $sqlFld => $dmFld ){
                $aCourse[ $rs['ID'] ][$sqlFld] = $rs[$dmFld ];
            }
        }
        
        $aTeacher = [];
        foreach( $data['teacher'] as $i => $rs ){
            foreach( $this->settings['table_mapping_teacher'] as $sqlFld => $dmFld ){
                $aTeacher[ $rs['ID'] ][$sqlFld] = $rs[$dmFld ];
            }
        }

        $oData = [];
        foreach( $data['timetable'] as $i => $rs ){
            $ttId = $rs['ID'];
            
            foreach( $this->settings['table_mapping_timetable'] as $sqlFld => $dmFld ){
                $oData[$ttId][ $sqlFld ] =  $rs[ $dmFld ];
            }
            
            $mainClassId = $aCourse[ $rs['CourseID'] ]['MainClass'];

            $oData[$ttId]['import_index'] = $ttId;
            $oData[$ttId]['txt_teacher'] = $aTeacher[ $rs['TeacherID'] ]['given_name'] . ' ' . $aTeacher[ $rs['TeacherID'] ]['last_name'];
            $oData[$ttId]['eml_teacher'] = $aTeacher[ $rs['TeacherID'] ]['email'] ;
            $oData[$ttId]['txt_room'] = $aLocation[ $rs['LocationID'] ]['room'];
            $oData[$ttId]['txt_building'] = $aLocation[ $rs['LocationID'] ]['building'];
            $oData[$ttId]['txt_class'] = $aClass[ $mainClassId ]['class_short'];
//             $oData[$ttId]['classes'] = $aCourse[ $rs['CourseID'] ]['Classes']; // comma separed list with shortClass
            $oData[$ttId]['txt_subject'] = $aCourse[ $rs['CourseID'] ]['CourseShort'];
            $oData[$ttId]['txt_subjectlong'] = $aCourse[ $rs['CourseID'] ]['Course'];
            $oData[$ttId]['department'] = $aCourse[ $rs['CourseID'] ]['DepartmentID'] ;
//             $oData[$ttId]['note'] = $aCourse[ $rs['CourseID'] ]['DepartmentID'] ;
            
        }
        return $oData;
        
    
    }

    /**
     * setPeriod
     * 
     * @return array
     */
    Private function setPeriod()
    {
        $aPeriods = [];
        $allPr = $this->periodsRepository->findAll();
		//die( 'anz.: ' . count($allPr));
        foreach( $allPr as $objPeriod ){
            $datStartPeriodDat = $objPeriod->getDavorBis();
            $datEndPeriodDat = $objPeriod->getDanachAb();
            $uid = $objPeriod->getUid();
            $aPeriods[$uid] = [
                    'uid'=> $uid,
                    'PeriodStart' => $datStartPeriodDat->format('Y-m-d') ,
                    'PeriodEnd' => $datEndPeriodDat->format('Y-m-d') ,
                    'objPeriod'=> $objPeriod ,
                    'semester'=> $objPeriod->getSemester()
            ];
        }
        
        $allTt = $this->timetableRepository->findAll();
        $added = 0;
        foreach( $allTt as $objTimetable ){
                $strStartTimetable = $objTimetable->getDateStart()->format('Y-m-d');
                $strEndTimetable = $objTimetable->getDateEnd()->format('Y-m-d');
                foreach( $aPeriods as $aPeriod ){
                    if( $aPeriod['PeriodStart'] <= $strStartTimetable && $aPeriod['PeriodEnd'] >= $strEndTimetable ){
                            // detect if there is work to do
                            $controllPeriodUid = $objTimetable->getPeriod();
                            if( !empty($controllPeriodUid) && $controllPeriodUid == $aPeriod['uid'] ) continue; // rs is ok
                            
                            $objTimetable->setPeriod( $aPeriod['objPeriod']->getSemester() );
                            $objTimetable->setRelPeriod( $aPeriod['objPeriod'] );
                            $this->timetableRepository->update( $objTimetable );
                            $added += 1;
                    }
                }
        }
        if( $added ) {
            $this->statistic['periodenEingesetzt'] = $added ;
            $this->persistenceManager->persistAll();
		}
        
    }

    /**
     * storeDataAsObject
     * 
     * @return array
     */
    Private function storeDataAsObject()
    {
        
         $tableMapping = $this->settings['table_mapping_timetable'];
         
         $tableMapping['rel_class'] = 'rel_class';
         $tableMapping['rel_subject'] = 'rel_subject';
         $tableMapping['rel_period'] = 'rel_period';
         $tableMapping['period'] = 'period';
         $tableMapping['txt_teacher'] = 'txt_teacher';
         $tableMapping['eml_teacher'] = 'eml_teacher';
         $tableMapping['txt_class'] = 'txt_class';
         $tableMapping['txt_subject'] = 'txt_subject';
         $tableMapping['txt_subjectlong'] = 'txt_subjectlong';
         $tableMapping['txt_room'] = 'txt_room';
         $tableMapping['txt_building'] = 'txt_building';
         $tableMapping['department'] = 'department';
         $tableMapping['import_index'] = 'import_index';
         $tableMapping['pid'] = $this->settings['storagePid'];
         
        // create tables
        foreach( $this->data as $i => $cnt ){
            $aTmp = $this->timetableRepository->findByImportIndex( $cnt['import_index'] );
            foreach( $aTmp as $possObj ) break;
            
            if( !$possObj ) {
                $newObject = GeneralUtility::makeInstance('SfGZ\SfgzPlan\Domain\Model\Timetable'  );
                $newObject->setPid( $this->settings['storagePid'] );
                 ++$this->statistic['created'];
           }else{
                $newObject = $possObj;
                ++$this->statistic['existent'];
            }
                // step trough fields
                
                foreach( $tableMapping as $sql_format => $mxFromFld ){
                    if( !isset( $cnt[$sql_format] ) ) continue;
                    
                    $DomUcFormat = GeneralUtility::underscoredToUpperCamelCase( $sql_format );
                    $cmd = 'set' . $DomUcFormat ;
                    if( method_exists( $newObject , $cmd ) ){
                            if( $this->settings['field_definition'][ $sql_format ] == 'date' ){
                                    $sanitizedValue = $this->dateUtility->sanitizeMixedDateTimestringToObject( $cnt[$sql_format] );
                            }else{
                                    $sanitizedValue = $cnt[$sql_format];
                            }
                            $newObject->$cmd( $sanitizedValue );
                    }
                }
//                 $newObject->setDepartment( $cnt['department'] );
                
                if( !$possObj ) {
                    $this->timetableRepository->add( $newObject );
                }else{
                    $this->timetableRepository->update( $newObject );
                }
                
        }
		$this->persistenceManager->persistAll();
		
        $this->statistic['timeElapsed'] =  time() - $this->statistic['timeElapsed'];
        
		return $this->statistic;
        
    }

    /**
     * $parameters: [ uri | usr | pwd | tablename ]
     *
     * @param bool $store optional, default is 'true'
     * @return mixed Server response
     */
    Private function importAllTables( $store = true )
    {
            $data = [];
            $tablenames = explode( ',' , 'location,course,teacher,timetable,class' );
            
            $amountDel = $this->cleanFileDir();
            
            foreach( $tablenames as $tablename ){
               $dataForTable = $this->importOneTable( $tablename , $store );
               //$data[$tablename] = ['a','b','c'];
                if( $dataForTable ){
                    if( is_array($dataForTable) ){
                        $objTab = $dataForTable;
                    }else{
                        $objTab = json_decode( $dataForTable , true );
                    }
                    if($objTab){
                        foreach( $objTab as $i => $c){
                            if( $i == 'body' ) {
                                $data[$tablename] = $c;
                            }
                        }
                    }
                }
            }

            return $data;
    }

    /**
     * $parameters: [ uri | usr | pwd | tablename ]
     *
     * @param str $tablename
     * @param bool $store optional, default is 'true'
     * @return mixed Server response
     */
    Protected function importOneTable( $tablename , $store = true )
    {
        $parameters['filename'] = $tablename . '.json';
        $parameters['uri'] = $this->extConf['is2_url'] . '' . $tablename . '';
        $parameters['usr'] = $this->extConf['is2_user'];
        $parameters['pwd'] = $this->extConf['is2_key'];
        // get a table from js2 API

        $data = $this->query( $parameters );
        
        // store as file: 
        if( $data ){
            if( $store ) $this->storeDataInFile( $data , $parameters );
        }else{
            die( 'no_data uri:' . $parameters['uri'] . ' usr:' . $parameters['usr'] . '' );
        }
        
        $encDat = json_decode( $data , TRUE );
        return $encDat;
    }

    /**
     * This method reads the content of the JSON DATA defined in the parameters
     * and returns it as an array
     *
     * NOTE:    this method does not implement the "processParameters" hook,
     *          as it does not make sense in this case
     *
     * @param array $parameters Parameters for the call
     * @throws SourceErrorException
     * @return array Content of the json
     */
    Protected function query( $parameters )
    {

        if (!empty($parameters['uri'])) {
            $report = array();
            // Define the headers
            $headers = false;
            if ( isset($parameters['usr']) && isset($parameters['pwd']) ) {
                    
                    // With authoriation. Special part svconnector_jsonis2
                    // hook jsonis2_import/class.tx_sfgzudb_hooks.php registered in sfgz_udb/ext_localconf.php
                    
                    $headers = array(
                        'Content-Type:application/json',
                        'Authorization: Basic '. base64_encode($parameters['usr'] . ':' . $parameters['pwd'])
                    );
                    $rest = curl_init();
                    curl_setopt($rest,CURLOPT_URL,$parameters['uri']);
                    curl_setopt($rest,CURLOPT_HTTPHEADER,$headers);
                    curl_setopt($rest,CURLOPT_SSL_VERIFYPEER, true);   
                    curl_setopt($rest,CURLOPT_RETURNTRANSFER, true);
                    $data = curl_exec($rest);  
                    $report['message'] = curl_error($rest);
                    curl_close($rest);

            }else{
                    // Without authoriation. Part from original script
                    // Prakash A Bhat (Cobweb) <typo3@cobweb.ch>
                    // Francois Suter (Cobweb) <typo3@cobweb.ch>
                    
                    $rest = curl_init();
                    curl_setopt($rest,CURLOPT_URL,$parameters['uri']);
                    curl_setopt($rest,CURLOPT_SSL_VERIFYPEER, true);   
                    curl_setopt($rest,CURLOPT_RETURNTRANSFER, true);
                    $data = curl_exec($rest);  
                    $report['message'] = curl_error($rest);
                    curl_close($rest);
                    
            }

            if ( !empty($report['message'])) {
                $message = 'json_not_fetched: ' . $parameters['uri'] . ' ' . $report['message'];
                die( $message );
            }
            
        }
        
        // Return the result
        return isset($data) ? $data : false;
    }

    /**
     * storeDataInFile
     * stores data on the fly for later re-imports
     * 
     * NEEDS file-permission AND corresponding storage-recordset 
     * AND user _cli_scheduler must be in a group with table-rights
     * for realtive folder "uploads"
     * 
     * @param string $data The records to transform
     * @param array $parameters Parameters for the call
     * @return array ingredients for Header
     */
    Protected function storeDataInFile( $data , $parameters ){
           $encDat = json_encode( $data );
           file_put_contents( $this->dumpDirectory.$parameters['filename']  , $encDat );
           return $encDat;
//           file_put_contents( $this->dumpDirectory.$parameters['filename']  , $data );
    }
	
    /**
      * deletes old imported files from $this->dumpDirectory
      *
      * @return void
      */
    Private function cleanFileDir() {
	    $this->statisticer = 0;
	    $d = dir( $this->dumpDirectory );
	    while ( false !== ( $entry = $d->read() ) ) {
		      if( $entry == '.' ) continue;
		      if( $entry == '..' ) continue;
		      if( is_file($this->dumpDirectory . '/' . $entry) ){
                unlink( $this->dumpDirectory . '/' . $entry );
                ++$this->statisticer;
		      }
		}
	    $d->close();
	    return $this->statisticer;
    }
}
