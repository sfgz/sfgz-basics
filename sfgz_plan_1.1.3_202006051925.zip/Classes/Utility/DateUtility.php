<?php
namespace SfGZ\SfgzPlan\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class DateUtility
 * 
 * 
 */
 
class DateUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
     * timeZoneString
     *
     * @var string
     */
    protected $timeZoneString = 'Europe/Zurich';

    /**
     * defaultTimeZoneString
     *
     * @var string
     */
    protected $defaultTimeZoneString = NULL;

    /**
     * timeZone
     *
     * @var \DateTimeZone
     */
    Public $timeZone = NULL;

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
			$typo3Timezone = $GLOBALS['TYPO3_CONF_VARS']['SYS']['phpTimeZone'] ; // MEZ | UCT
			if( $typo3Timezone ){
				$this->defaultTimeZoneString = $typo3Timezone;
			
			}else{
				$sysTimezone = date_default_timezone_get();
				$this->defaultTimeZoneString = $sysTimezone ? $sysTimezone : $this->timeZoneString;
			}
			
			$this->timeZone = new \DateTimeZone( $this->timeZoneString );
	}


	/**
	 * sanitizeYear
	 *
     * @param str $yy
	 * @return str yyyy
	 */
	Public function sanitizeYear( $yy )
	{
			if( strlen($yy) == 2 ) return ( $yy + 2000 );
			return $yy;
	}

	/**
	 * sanitizeDateTimeStringToEnglish
	 * sanitize gernam dateString [ dd.mm.yyyy HH:ii ] to english dateString [ yyyy-mm-dd HH:ii ]
	 * 
	 * returns defaultValue if dateString was incorrect
	 *
     * @param str $strMixedDate
     * @param str $defaultValue optional
	 * @return str english datestring or empty
	 */
	Public function sanitizeDateTimeStringToEnglish( $strMixedDate , $defaultValue = false )
	{
			if( empty($strMixedDate) ) return $defaultValue;
			
			$strMixedGdate = str_replace( 'T' , ' ' , trim($strMixedDate) );
			$aDateTime = explode( ' ' , $strMixedGdate );
			
			// incomed value is english date
			$isEnglish = (bool)preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$aDateTime[0]);

			if( $isEnglish ) return $strMixedDate;

			$strGdate = str_replace( '-' , '.' , $aDateTime[0] );
			$aDate = explode( '.' , $strGdate );
			if( count($aDate) != 3 ) return $defaultValue;
			
			// time string given
			if(count($aDateTime) == 2){
				$strTime = str_replace( '.' , ':' , $aDateTime[1] ); // replace dots with :
				if( strlen($strTime) == 5 ) $strTime .= ':00'; // add seconds if correct HH:MM
			}else{
				$strTime = '';
			}
			$englDate = $this->sanitizeYear($aDate[2]) . '-' . $aDate[1] . '-' . $aDate[0] . ' ' . $strTime;
			
			return trim($englDate);
    }

	/**
	 * sanitizeMixedDateTimestringToObject
	 *
     * @param string $dateTimeString english date like Y-m-d H:i:s OR germanDate d.m.Y
	 * @return \DateTime
	 */
	Public function sanitizeMixedDateTimestringToObject( $dateTimeString )
	{
			$englishDatestring = $this->sanitizeDateTimeStringToEnglish( $dateTimeString );
			
			if( $this->checkIsAValidDate($englishDatestring)) {
                if( strlen($englishDatestring) == 10 ) $englishDatestring .='T12:00:00';
				$dateObject = new \DateTime( $englishDatestring , $this->timeZone );

			} else {
			
				$dateObject = new \DateTime( date( 'Y-m-dT12:00:00' ) , $this->timeZone );
			}
			
			
			return $dateObject;
			$objDate = $this->sanitizeDateTime( $dateObject );
			return $objDate;
    }
    
	/**
	 * checkIsAValidDate
	 *
     * @param string $dateTimeString
	 * @return bool
	 */
	function checkIsAValidDate($dateTimeString){
		return (bool)strtotime($dateTimeString);
	}

	/**
	 * sanitizeDateTime
	 *
     * @param \DateTime $dateObject
	 * @return \DateTime
	 */
	Public function sanitizeDateTime( $dateObject )
	{
		if( $this->defaultTimeZoneString == $this->timeZoneString ) {
			$dateObject->setTimezone( $this->timeZone );
			return $dateObject;
		}

		$offset = $this->timeZone->getOffset( $dateObject );
		
		if( $offset > 0 ) {
		
				$dateObject->add( new \DateInterval( 'PT' . $offset . 'S' ) );
		
		}elseif( $offset < 0 ){
		
				$dateObject->sub( new \DateInterval( 'PT' . $offset . 'S' ) );
		
		}
		
        return $dateObject;
    }
	
	/**
	 * timestampToObject
	 *
     * @param int $timestamp optional, default is now
	 * @return \DateTime
	 */
	Public function timestampToObject( $timestamp = 0 )
	{
			if( empty($timestamp) ){
				$dateString = date( 'Y-m-d H:i:s' ) ;
				$dateObject = new \DateTime( $dateString );
			}else{
				$dateString = date( 'Y-m-d H:i:s' , $timestamp );
				$dateObject = new \DateTime( $dateString , $this->timeZone );
			}
			$objDate = $this->sanitizeDateTime( $dateObject );
			return $objDate;
    }
	
}
