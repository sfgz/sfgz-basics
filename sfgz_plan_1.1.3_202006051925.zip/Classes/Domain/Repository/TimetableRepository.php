<?php
namespace SfGZ\SfgzPlan\Domain\Repository;


/***
 *
 * This file is part of the "plan" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Daniel Rueegg
 *
 ***/
/**
 * The repository for Timetables
 */
class TimetableRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
	
	/**
	*  findBySemesterGroupByKlasseTeacherFiltered
	 *  Dtensaetze...
	 *  - haben eine Klasse
	 *  - subject ist 
	 *  - txtSubject ist Fach-kurzbezeichnung ( Ges )
	 *  - txtSubjectlong ist Fach-lange Bezeichnung ( Gesellschaft )
	* 
	* @param int $semesterUid
	* @return void
	*/
	public function findBySemesterGroupByKlasseTeacherFiltered( $semesterUid ) {
	    $query = $this->createQuery();
	    
	    $query->matching(
            $query->logicalAnd(
                $query->equals('rel_period', $semesterUid ) ,
                $query->greaterThan('txt_class', '' ) 
            )
	    );

	    return $query->execute();
	}
	
	/**
	 * findBySemesterGroupByKursregelTeacherFiltered
	 * used by extension MffLsb LimeSurveyBaker
	 * 
	 *  WB Kurse gefiltert nach Semester gruppiert nach Lehrperson
	 *  Daten aus Sekretariat zu is2-Stundenplan ohne Klassen
	 *  - haben keine Klasse
	 *  - txtSubject ist kurs Nr
	 *  - txtSubjectlong ist Kurs-Beezeichnung
	 *  - 
	 * @param int $semesterUid
	 * @return void
	 */
	public function findBySemesterGroupByKursregelTeacherFiltered( $semesterUid ){
	    $query = $this->createQuery();
	    
	    $query->matching(
            $query->logicalAnd(
                $query->equals('rel_period', $semesterUid ),
                $query->equals('txt_class', '' )
            )
	    );

	    return $query->execute();
	}
	
	/**
	 * findPeriodsUnixTimeBySemester
	 * used by extension MffLsb LimeSurveyBaker
	 *
	 * @param int $semesterUid
	 * @return void
	 */
	public function findPeriodsUnixTimeBySemester( $semesterUid  ){
	      $sqlStatement = 'SELECT  UNIX_TIMESTAMP(davor_bis) as ab,UNIX_TIMESTAMP(danach_ab) as bis ';
 	      $sqlStatement .= ' FROM tx_sfgzplan_domain_model_period ';
//	      $sqlStatement .= ' FROM tx_mfflsb_domain_model_periods ';
	      $sqlStatement .= ' WHERE uid = ' . $semesterUid ;
	      // execute sql-statement
	      $aPeriod = $this->callSqlStatement( $sqlStatement );
	      // return the first element
	      return array_shift( $aPeriod );
	}

	/**
	 * @param $qryStatement
	 * @param $ReturnRawQueryResult
	 * @return void
	 */
	public function callSqlStatement($qryStatement, $ReturnRawQueryResult = TRUE) {
		$Query = $this->createquery();
		$Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
		$Query->getQuerySettings()->setRespectStoragePage(FALSE);
		$Query->statement($qryStatement);
		return $Query->execute($ReturnRawQueryResult);
	}
	
}
