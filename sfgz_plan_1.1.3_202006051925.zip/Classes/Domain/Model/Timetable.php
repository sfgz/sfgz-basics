<?php
namespace SfGZ\SfgzPlan\Domain\Model;


/***
 *
 * This file is part of the "plan" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Daniel Rueegg
 *
 ***/
/**
 * Timetable
 */
class Timetable extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * weekday
     * 
     * @var int
     */
    protected $weekday = 0;

    /**
     * period
     * 
     * @var string
     */
    protected $period = '';

    /**
     * periodicity
     * 
     * @var int
     */
    protected $periodicity = 0;

    /**
     * department
     * 
     * @var string
     */
    protected $department = '';

    /**
     * dateStart
     * 
     * @var \DateTime
     */
    protected $dateStart = null;

    /**
     * dateEnd
     * 
     * @var \DateTime
     */
    protected $dateEnd = null;

    /**
     * timeFrom
     * 
     * @var string
     */
    protected $timeFrom = '';

    /**
     * timeTo
     * 
     * @var string
     */
    protected $timeTo = '';

    /**
     * note
     * 
     * @var string
     */
    protected $note = '';

    /**
     * txtTeacher
     * 
     * @var string
     */
    protected $txtTeacher = '';

    /**
     * emlTeacher
     * 
     * @var string
     */
    protected $emlTeacher = '';

    /**
     * txtClass
     * 
     * @var string
     */
    protected $txtClass = '';

    /**
     * txtSubject
     * 
     * @var string
     */
    protected $txtSubject = '';

    /**
     * txtSubjectlong
     * 
     * @var string
     */
    protected $txtSubjectlong = '';

    /**
     * txtRoom
     * 
     * @var string
     */
    protected $txtRoom = '';

    /**
     * txtBuilding
     * 
     * @var string
     */
    protected $txtBuilding = '';

    /**
     * shortclass
     * 
     * @var string
     */
    protected $shortclass = '';

    /**
     * importIndex
     * 
     * @var int
     */
    protected $importIndex = '';

    /**
     * relTeacher
     * 
     * @var int
     */
    protected $relTeacher = 0;

    /**
     * relPeriod
     * 
     * @var int
     */
    protected $relPeriod = 0;

    /**
     * Returns the weekday
     * 
     * @return int $weekday
     */
    public function getWeekday()
    {
        return $this->weekday;
    }

    /**
     * Sets the weekday
     * 
     * @param int $weekday
     * @return void
     */
    public function setWeekday($weekday)
    {
        $this->weekday = $weekday;
    }

    /**
     * Returns the period
     * 
     * @return int $period
     */
    public function getPeriod()
    {
        return $this->period;
    }

    /**
     * Sets the period
     * 
     * @param int $period
     * @return void
     */
    public function setPeriod($period)
    {
        $this->period = $period;
    }

    /**
     * Returns the periodicity
     * 
     * @return int $periodicity
     */
    public function getPeriodicity()
    {
        return $this->periodicity;
    }

    /**
     * Sets the periodicity
     * 
     * @param int $periodicity
     * @return void
     */
    public function setPeriodicity($periodicity)
    {
        $this->periodicity = $periodicity;
    }

    /**
     * Returns the department
     * 
     * @return string $department
     */
    public function getDepartment()
    {
        return $this->department;
    }

    /**
     * Sets the department
     * 
     * @param string $department
     * @return void
     */
    public function setDepartment($department)
    {
        $this->department = $department;
    }

    /**
     * Returns the dateStart
     * 
     * @return \DateTime $dateStart
     */
    public function getDateStart()
    {
        return $this->dateStart;
    }

    /**
     * Sets the dateStart
     * 
     * @param \DateTime $dateStart
     * @return void
     */
    public function setDateStart(\DateTime $dateStart)
    {
        $this->dateStart = $dateStart;
    }

    /**
     * Returns the dateEnd
     * 
     * @return \DateTime $dateEnd
     */
    public function getDateEnd()
    {
        return $this->dateEnd;
    }

    /**
     * Sets the dateEnd
     * 
     * @param \DateTime $dateEnd
     * @return void
     */
    public function setDateEnd(\DateTime $dateEnd)
    {
        $this->dateEnd = $dateEnd;
    }

    /**
     * Returns the timeFrom
     * 
     * @return string $timeFrom
     */
    public function getTimeFrom()
    {
        return $this->timeFrom;
    }

    /**
     * Sets the timeFrom
     * 
     * @param string $timeFrom
     * @return void
     */
    public function setTimeFrom($timeFrom)
    {
        $this->timeFrom = $timeFrom;
    }

    /**
     * Returns the timeTo
     * 
     * @return string $timeTo
     */
    public function getTimeTo()
    {
        return $this->timeTo;
    }

    /**
     * Sets the timeTo
     * 
     * @param string $timeTo
     * @return void
     */
    public function setTimeTo($timeTo)
    {
        $this->timeTo = $timeTo;
    }

    /**
     * Returns the note
     * 
     * @return string $note
     */
    public function getNote()
    {
        return $this->note;
    }

    /**
     * Sets the note
     * 
     * @param string $note
     * @return void
     */
    public function setNote($note)
    {
        $this->note = $note;
    }


    /**
     * Returns the txtTeacher
     * 
     * @return string $txtTeacher
     */
    public function getTxtTeacher()
    {
        return $this->txtTeacher;
    }

    /**
     * Sets the txtTeacher
     * 
     * @param string $txtTeacher
     * @return void
     */
    public function setTxtTeacher($txtTeacher)
    {
        $this->txtTeacher = $txtTeacher;
    }

    /**
     * Returns the emlTeacher
     * 
     * @return string $emlTeacher
     */
    public function getEmlTeacher()
    {
        return $this->emlTeacher;
    }

    /**
     * Sets the emlTeacher
     * 
     * @param string $emlTeacher
     * @return void
     */
    public function setEmlTeacher($emlTeacher)
    {
        $this->emlTeacher = $emlTeacher;
    }

    /**
     * Returns the txtClass
     * 
     * @return string $txtClass
     */
    public function getTxtClass()
    {
        return $this->txtClass;
    }

    /**
     * Sets the txtClass
     * 
     * @param string $txtClass
     * @return void
     */
    public function setTxtClass($txtClass)
    {
        $this->txtClass = $txtClass;
    }

    /**
     * Returns the txtSubject
     * 
     * @return string $txtSubject
     */
    public function getTxtSubject()
    {
        return $this->txtSubject;
    }

    /**
     * Sets the txtSubject
     * 
     * @param string $txtSubject
     * @return void
     */
    public function setTxtSubject($txtSubject)
    {
        $this->txtSubject = $txtSubject;
    }

    /**
     * Returns the txtSubjectlong
     * 
     * @return string $txtSubjectlong
     */
    public function getTxtSubjectlong()
    {
        return $this->txtSubjectlong;
    }

    /**
     * Sets the txtSubjectlong
     * 
     * @param string $txtSubjectlong
     * @return void
     */
    public function setTxtSubjectlong($txtSubjectlong)
    {
        $this->txtSubjectlong = $txtSubjectlong;
    }

    /**
     * Returns the txtRoom
     * 
     * @return string $txtRoom
     */
    public function getTxtRoom()
    {
        return $this->txtRoom;
    }

    /**
     * Sets the txtRoom
     * 
     * @param string $txtRoom
     * @return void
     */
    public function setTxtRoom($txtRoom)
    {
        $this->txtRoom = $txtRoom;
    }


    /**
     * Returns the txtBuilding
     * 
     * @return string $txtBuilding
     */
    public function getTxtBuilding()
    {
        return $this->txtBuilding;
    }

    /**
     * Sets the txtBuilding
     * 
     * @param string $txtBuilding
     * @return void
     */
    public function setTxtBuilding($txtBuilding)
    {
        $this->txtBuilding = $txtBuilding;
    }

    /**
     * Returns the shortclass
     * 
     * @return string $shortclass
     */
    public function getShortclass()
    {
        return $this->shortclass;
    }

    /**
     * Sets the shortclass
     * 
     * @param string $shortclass
     * @return void
     */
    public function setShortclass($shortclass)
    {
        $this->shortclass = $shortclass;
    }

    /**
     * Returns the importIndex
     * 
     * @return int $importIndex
     */
    public function getImportIndex()
    {
        return $this->importIndex;
    }

    /**
     * Sets the importIndex
     * 
     * @param int $importIndex
     * @return void
     */
    public function setImportIndex($importIndex)
    {
        $this->importIndex = $importIndex;
    }

    /**
     * Returns the relTeacher
     * 
     * @return int $relTeacher
     */
    public function getRelTeacher()
    {
        return $this->relTeacher;
    }

    /**
     * Sets the relTeacher
     * 
     * @param int $relTeacher
     * @return void
     */
    public function setRelTeacher($relTeacher)
    {
        $this->relTeacher = $relTeacher;
    }

    /**
     * Returns the relPeriod
     * 
     * @return int $relPeriod
     */
    public function getRelPeriod()
    {
        return $this->relPeriod;
    }

    /**
     * Sets the relPeriod
     * 
     * @param int $relPeriod
     * @return void
     */
    public function setRelPeriod($relPeriod)
    {
        $this->relPeriod = $relPeriod;
    }
}
