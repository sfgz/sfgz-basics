<?php
namespace SfGZ\SfgzPlan\Task;

 /** 
 * Class RequestTask
 * look up if new responses camed in
 * 
 * 
 */
 
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Scheduler\Task\AbstractTask;
 
class ImportTask extends AbstractTask {


	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

	/**
	* initiate
	*
	* @return void
	*/
	public function initiate( ) {
			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$flashMessageService = $this->objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
			$this->messageQueue = $flashMessageService->getMessageQueueByIdentifier();
			
	}

	public function execute(){
			$this->initiate();
			
			$this->importPeriodFromCalendar( 144 , 10 );
			$this->importTablesFromApi();
			
			return true;
	}
	
	/**
	* importTablesFromApi
	*
	* @return int
	*/
	public function importTablesFromApi(){
			$this->importJs2Service = GeneralUtility::makeInstance('SfGZ\\SfgzPlan\\Service\\ImportJs2Service');
            $messages = $this->importJs2Service->importTablesFromApiIntoDB();
			
			$msg = '' . $messages['created'] . ' Datensätze erstellt, ' . $messages['existent'] .  ' vorhanden.';
			$msgLead = ' Views ab Intranet importieren und verknüpfen auf PID ' . $messages['pid'] . '. ' . $messages['periodenEingesetzt'] . ' Perioden eingesetzt.';
			
			$message = GeneralUtility::makeInstance(
					'TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
					 $msg . $msgLead,
					'Import Timetable', 
					!empty($messages['created']) ? \TYPO3\CMS\Core\Messaging\FlashMessage::OK : \TYPO3\CMS\Core\Messaging\FlashMessage::INFO
			);
			$this->messageQueue->addMessage($message);
			
			
			return 1;
	}
	
	/**
	* importPeriodFromCalendar
	*  default is 10 years (120 Mth) in future nad 2 yearas in past.
	*   
	* @param int $futureMonths
	* @param int $pastYears
	* @return bool
	*/
	public function importPeriodFromCalendar( $futureMonths = 120 , $pastYears = 10 ){ 
 	    $success = FALSE;
	    
        $calendarService = new \Mff\MffLsb\Service\PeriodService();
        
        $datBeginn = new \DateTime( date('Y-m-d') . "-" . $pastYears . " year" );
	    $answer = $calendarService->addPeriodToRepository( $datBeginn->format('Y-m-d') , $futureMonths );

	    $message = GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
		    $answer , 'Datenbank-Abfrage Ausgeführt', \TYPO3\CMS\Core\Messaging\FlashMessage::INFO
	    );

	    $this->messageQueue->addMessage($message);
	    
	    $success = TRUE;
	    return $success;
       
	}

}
