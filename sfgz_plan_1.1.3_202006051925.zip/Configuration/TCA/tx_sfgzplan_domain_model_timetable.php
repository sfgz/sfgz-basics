<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable',
        'label' => 'weekday',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'enablecolumns' => [
        ],
        'searchFields' => 'time_from,time_to,note,import_index',
        'iconfile' => 'EXT:sfgz_plan/Resources/Public/Icons/tx_sfgzplan_domain_model_timetable.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'rel_period,period,weekday, periodicity, date_start, date_end, time_from, time_to, note, import_index, rel_teacher, txt_teacher, eml_teacher, txt_class, txt_subject , txt_room,shortclass,department',
    ],
    'types' => [
        '1' => ['showitem'   =>  'rel_period,period,weekday, periodicity, date_start, date_end, time_from, time_to, note, import_index, rel_teacher, txt_teacher, eml_teacher, txt_class, txt_subject , txt_room,shortclass,department'],
    ],
    'columns' => [

        'weekday' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.weekday',
            'config' => [
                'type' => 'input',
                'size' => 4,
                'eval' => 'int'
            ]
        ],
        'periodicity' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.periodicity',
            'config' => [
                'type' => 'input',
                'size' => 4,
                'eval' => 'int'
            ]
        ],
        'date_start' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.date_start',
            'config' => [
                'dbType' => 'date',
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'size' => 7,
                'eval' => 'date',
                'default' => null,
            ],
        ],
        'date_end' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.date_end',
            'config' => [
                'dbType' => 'date',
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'size' => 7,
                'eval' => 'date',
                'default' => null,
            ],
        ],
        'time_from' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.time_from',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'time_to' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.time_to',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'note' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.note',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'import_index' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.import_index',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'rel_teacher' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.rel_teacher',
            'config' => [
                'type' => 'input',
                'size' => 4,
                'eval' => 'int'
            ]
        ],
        'rel_period' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.rel_period',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
				'items' => array( array('keine', 0)),
                'foreign_table' => 'tx_mfflsb_domain_model_periods',
                'minitems' => 0,
                'maxitems' => 1,
            ]
        ],
        'period' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.period',
            'config' => [
                'type' => 'none',
                'size' => 30,
                'eval' => 'trim'
            ]
        ],
        'department' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.department_id',
            'config' => [
                'type' => 'input',
                'size' => 4,
                'eval' => 'int'
            ]
        ],
    
        'txt_teacher' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.txt_teacher',
            'config' => [
                'type' => 'none',
            ],
        ],
    
        'eml_teacher' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.eml_teacher',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
    
        'txt_class' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.txt_class',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
    
        'txt_subject' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.txt_subject',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'txt_subjectlong' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.txt_subjectlong',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
    
        'txt_room' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.txt_room',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
    
        'txt_building' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.txt_building',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
    
        'shortclass' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgzplan_domain_model_timetable.shortclass',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],

    ],
];
