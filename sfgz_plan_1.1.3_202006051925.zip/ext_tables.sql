#
# Table structure for table 'tx_sfgzplan_domain_model_timetable'
#
CREATE TABLE tx_sfgzplan_domain_model_timetable (

	weekday int(11) DEFAULT '0' NOT NULL,
	periodicity int(11) DEFAULT '0' NOT NULL,
	date_start date DEFAULT NULL,
	date_end date DEFAULT NULL,
	time_from varchar(255) DEFAULT '' NOT NULL,
	time_to varchar(255) DEFAULT '' NOT NULL,
	note varchar(255) DEFAULT '' NOT NULL,
	department varchar(255) DEFAULT '' NOT NULL,
	import_index varchar(255) DEFAULT '' NOT NULL,
	rel_teacher int(11) DEFAULT '0' NOT NULL,
	rel_period int(11) DEFAULT '0' NOT NULL,
	
	period varchar(255) DEFAULT '' NOT NULL,
	txt_teacher varchar(255) DEFAULT '' NOT NULL,
	eml_teacher varchar(255) DEFAULT '' NOT NULL,
	txt_class varchar(255) DEFAULT '' NOT NULL,
	txt_subject varchar(255) DEFAULT '' NOT NULL,
	txt_subjectlong varchar(255) DEFAULT '' NOT NULL,
	txt_room varchar(255) DEFAULT '' NOT NULL,
	txt_building varchar(255) DEFAULT '' NOT NULL,
	shortclass varchar(255) DEFAULT '' NOT NULL,

);
