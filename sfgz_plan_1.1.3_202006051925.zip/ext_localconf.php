<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'SfGZ.SfgzPlan',
            'Tt',
            [
                'Timetable' => 'list'
            ],
            // non-cacheable actions
            [
                'Timetable' => 'list'
            ]
        );

    // wizards
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
        'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {
                    tt {
                        iconIdentifier = sfgz_plan-plugin-tt
                        title = LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgz_plan_tt.name
                        description = LLL:EXT:sfgz_plan/Resources/Private/Language/locallang_db.xlf:tx_sfgz_plan_tt.description
                        tt_content_defValues {
                            CType = list
                            list_type = sfgzplan_tt
                        }
                    }
                }
                show = *
            }
       }'
    );
		$iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);
		
			$iconRegistry->registerIcon(
				'sfgz_plan-plugin-tt',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:sfgz_plan/Resources/Public/Icons/user_plugin_tt.svg']
			);
		
		// Register scheduler-Tasks
		if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('scheduler')) {
			$extKey = 'SfgzPlan';
			$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks'][\SfGZ\SfgzPlan\Task\ImportTask::class] = array(
				'extension'			=> 'SfgzPlan',
				'title'				=> 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang.xlf:scheduler.import.title',
				'description'		=> 'LLL:EXT:sfgz_plan/Resources/Private/Language/locallang.xlf:scheduler.import.description',
				'additionalFields'	=> ''
			);
		};
    }
);
