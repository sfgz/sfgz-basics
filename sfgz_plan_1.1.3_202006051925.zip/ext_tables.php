<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'SfGZ.SfgzPlan',
            'Tt',
            'timetable'
        );

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('sfgz_plan', 'Configuration/TypoScript', 'plan');

//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzplan_domain_model_period', 'EXT:sfgz_plan/Resources/Private/Language/locallang_csh_tx_sfgzplan_domain_model_period.xlf');
//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_sfgzplan_domain_model_period');

//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sfgzplan_domain_model_timetable', 'EXT:sfgz_plan/Resources/Private/Language/locallang_csh_tx_sfgzplan_domain_model_timetable.xlf');
//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_sfgzplan_domain_model_timetable');

    }
);
