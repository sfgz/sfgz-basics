<?php
namespace Sfgz\SfgzKurs\Domain\Model;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018
 *
 ***/

/**
 * Info
 */
class Info extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * Y-d-m H:i:s
     *
	 * @validate NotEmpty,DateTime
     * @var \DateTime
     */
    protected $datumAnzeige = null;

    /**
     * infotext
     *
     * @var string
     */
    protected $infotext = '';

    /**
     * iBelegungen
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Belegung>
     * @cascade remove
     */
    protected $iBelegungen = null;

    /**
     * Returns the datumAnzeige
     *
     * @return \DateTime $datumAnzeige
     */
    public function getDatumAnzeige()
    {
        return $this->datumAnzeige;
    }

    /**
     * Sets the datumAnzeige
     *
     * @param \DateTime $datumAnzeige
     * @return void
     */
    public function setDatumAnzeige(\DateTime $datumAnzeige)
    {
        $this->datumAnzeige = $datumAnzeige;
    }

    /**
     * Returns the infotext
     *
     * @return string $infotext
     */
    public function getInfotext()
    {
        return $this->infotext;
    }

    /**
     * Sets the infotext
     *
     * @param string $infotext
     * @return void
     */
    public function setInfotext($infotext)
    {
        $this->infotext = $infotext;
    }

    /**
     * Adds a Belegung
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Belegung $iBelegungen
     * @return void
     */
    public function addIBelegungen(\Sfgz\SfgzKurs\Domain\Model\Belegung $iBelegungen)
    {
        $this->iBelegungen->attach($iBelegungen);
    }

    /**
     * Removes a Belegung
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Belegung $iBelegungenToRemove The Belegung to be removed
     * @return void
     */
    public function removeIBelegungen(\Sfgz\SfgzKurs\Domain\Model\Belegung $iBelegungenToRemove)
    {
        $this->iBelegungen->detach($iBelegungenToRemove);
    }

    /**
     * Returns the iBelegungen
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Belegung> $iBelegungen
     */
    public function getIBelegungen()
    {
        return $this->iBelegungen;
    }

    /**
     * Sets the iBelegungen
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzKurs\Domain\Model\Belegung> $iBelegungen
     * @return void
     */
    public function setIBelegungen(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $iBelegungen)
    {
        $this->iBelegungen = $iBelegungen;
    }
}
