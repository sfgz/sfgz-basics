<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

class BackupUtility {

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_vw';

    /**
        * settings
        *
        * @var array
        */
    protected $settings = array();

    /**
    * __construct
    *
    * @return void
    */
    public function __construct() {
			$this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
		    $settings = $this->settingsUtility->getSettings( $this->pluginKey );
            $this->settings = [
                'prefix' => 'tx_sfgzkurs_',
                'backupGroups' => [
                    'kurs' => [ 'domain_model_kategorie' , 'domain_model_kurs' , 'domain_model_version' , 'domain_model_durchfuehrung' , 'domain_model_lektion' , 'kurs_kategorie_mm' , 'domain_model_config' ],
                    'display' => [ 'domain_model_info' , 'domain_model_belegung' ]
                ],
                'mailtos' => [
                    'musterEmail(at)Adresse' => [ 'kurs' , 'display' ]
                ],
            ];
            $sr = [ '##DATE##' => date('Y.m.d H:i' , time() ) , '##DATETIME##' => date('d.m.Y H:i:s T \(\G\M\T P\)' , time() ) , '##URL##'=>$_SERVER['SERVER_NAME'] ];
            $this->settings['Subject'] = str_replace( array_keys($sr) , $sr  , $settings['mail']['backuptext']['Subject']);
            $this->settings['Body'] = str_replace( array_keys($sr) , $sr  , $settings['mail']['backuptext']['Body']);
            $this->settings['Footer'] = str_replace( array_keys($sr) , $sr  , $settings['mail']['backuptext']['Footer']);
            $this->settings['fallbackMailFrom'] = $settings['mail']['fallbackMailFrom'];
            $this->settings['imagePath'] = rtrim( PATH_site , '/' ) . $settings['mail']['imagePath'];
            $this->settings['uploadPath'] = rtrim( PATH_site , '/' ) . $settings['mail']['uploadPath'];
    }

    /**
    * runBackup
    * 
    * @param array $additionalSettings
    * @return boolean
    */
    public function runBackup( $additionalSettings = [] ){
            
            // overwrite settings by incoming values
            if(count($additionalSettings)){
                foreach( $additionalSettings as $nam => $aSettings ){
                    $this->settings[$nam] = $aSettings;
                }
            }
            
            // create message, subject and mailToAdress
            $mailData = [
                    'From' => !empty($GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromAddress']) ? $GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromAddress'] : $this->settings['fallbackMailFrom'] ,
                    'Subject' => $this->settings['Subject'],
                    'Body' => $this->settings['Body'],
                    'Footer' => $this->settings['Footer']
            ];
            
            // create the sql files
            $aMapGroupToDateiname = [];
            foreach( $this->settings['backupGroups'] as $backupname => $aBackupTables ) {
                $filename = $this->createSqlDumpFiles( $backupname , $aBackupTables , $this->settings['prefix'] , $this->settings['uploadPath'] );
                if( file_exists($filename) ) {
                    $dateiname = pathinfo( $filename , PATHINFO_BASENAME );
                    $aMapGroupToDateiname[$backupname] = ['dateiname'=>$dateiname , 'content'=> file_get_contents($filename) ];
                    // clean up created files
                    unlink($filename);
                }
            }
            
            // create send message and send
            if( count($this->settings['mailtos']) ){
                    foreach( $this->settings['mailtos'] as $adress => $aUserBackupGroups ){
                        if( $adress == 'musterEmail(at)Adresse' ) continue;
                        // build attachments for each adress
                        $aMailAttatchments = [];
                        foreach( $aUserBackupGroups as $sGrp ){
                            if( !isset($aMapGroupToDateiname[ trim($sGrp) ] ) ) continue;
                            $aMailAttatchments[$aMapGroupToDateiname[trim($sGrp)]['dateiname']] = $aMapGroupToDateiname[trim($sGrp)]['content'];
                        }
                        // send mail
                        $mailData['To'] = $adress;
                        $mailData['Attatchments'] = $aMailAttatchments;
                        $this->sendWithAttatchment( $mailData );
                    }
            }
            
            return true;
    }

    /**
    * createSqlDumpFiles
    * 
    * @param string $backupname
    * @param array $aBackupTables  list with short-named tablenames
    * @param string $prefix
    * @param string $uploadPath
    * @return string 
    */
    private function createSqlDumpFiles( $backupname , $aBackupTables , $prefix , $uploadPath ){
        // build filename to store the sql in
        if( !is_dir($uploadPath) ) mkdir( $uploadPath );
        $writeToFilePathName = $uploadPath . $backupname . '_' . date('ymd_hi') . '.sql';
        if( file_exists($writeToFilePathName) ) unlink($writeToFilePathName);
        
        // remove prefix if already given, prepend prefix
        foreach($aBackupTables as $tab){ $aTablenames[] = $prefix . str_replace( $prefix , '' , strtolower(trim($tab)) ); }
        
        // build list of fully qualified tablenames
        $tabelle = implode( ' ' , $aTablenames );

        $aT3db = $GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default'];
            
        $createCommand = 'mysqldump -h ' . $aT3db['host'];
        $createCommand .= ' -u ' . $aT3db['user'];
        $createCommand .= ' -p' . $aT3db['password']; 
        $createCommand .= ' ' . $aT3db['dbname'] . ' ' . $tabelle;
        $createCommand .= ' -r ';
        $createCommand .= $writeToFilePathName;
        
/*        
        $createCommand = 'mysqldump -h ' . TYPO3_db_host;
        $createCommand .= ' -u ' . TYPO3_db_username;
        $createCommand .= ' -p' . TYPO3_db_password; 
        $createCommand .= ' ' . TYPO3_db . ' ' . $tabelle;
        $createCommand .= ' -r ';
        $createCommand .= $writeToFilePathName;
*/
        exec($createCommand,$error);
        
        return $writeToFilePathName;
    }

	/**
	 * sendWithAttatchment
	 * used by sendmailAction() in AnlassController
	 *
	 * @param array $mailData
	 * @return void
	 */
	private function sendWithAttatchment( $mailData ) {
            
            $mail = $this->wrapMessageWithHtmlBodyframe( $mailData['Body'] , trim($mailData['Footer']) );
            
            foreach( $mailData['Attatchments'] as $dateiname => $output ){
                $attachment = \Swift_Attachment::newInstance( $output, $dateiname , $this->mailGetContentType($dateiname) );
                $mail->attach($attachment);
            }
            $mail->setSubject( $mailData['Subject'] );
            $mail->setFrom( $mailData['From'] );
            $mail->setTo( $mailData['To'] );
            if( isset($mailData['Cc']) && count($mailData['Cc']) ) $mail->setCc( $mailData['Cc'] );
            if( isset($mailData['Bcc']) && count($mailData['Bcc']) ) $mail->setBcc( $mailData['Bcc'] );
            $mail->send();
            return true;
	}
	
	/**
	 * wrapMessageWithHtmlBodyframe
	 *
	 * @param srtring $message
	 * @param srtring $footertext
	 * @return void
	 */
	private function wrapMessageWithHtmlBodyframe( $message , $footertext = '' ) {
			$mail = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');
			$embedImage = file_exists($this->settings['imagePath']) ? $mail->embed(\Swift_Image::fromPath($this->settings['imagePath'])) : '';
			$bodyText =  '<div style="color:#222;">';
			$bodyText .= str_replace( "\n" , "<br />" , $message);
			$bodyText .= '</div>';
			$bodyText .= '<div style="font-size:9pt;color:#999;padding-top:10px;">';
			$bodyText .= $footertext;
			if( !empty($embedImage) ) $bodyText .= '<img src="' . $embedImage . '" alt="Image" width="280px;" />';
			$bodyText .= '</div>';
			$mail->setBody( $bodyText , 'text/html' );
			return $mail;
	}

    /**
    * mailGetContentType
    * used by mailer to construct attatchment-header
    * returns a string with the mymetype and content-type of the attatched file
    * 
    * @param string $dateiname
    * @return string 
    */
    private function mailGetContentType($dateiname){ 
            $mimeTypes = array( 'pdf'=>'application/pdf' , 'txt'=>'text/txt' , 'mp3'=>'application/octet-stream');
            $mimeTypeImg=array("jpg"=>1,"jpeg"=>1,"gif"=>1,"png"=>1,"xbm"=>1);
            $ext = strtolower( pathinfo($dateiname,PATHINFO_EXTENSION) );
            
            if(!empty($mimeTypeImg[$ext])){
                $contentType =  "image/".$ext;
            }elseif(!empty($mimeTypes[$ext])){
                $contentType = $mimeTypes[$ext];
            }else{	      
                $contentType = "application/".$ext;
            }
            return $contentType;
    }
    
}
?>
