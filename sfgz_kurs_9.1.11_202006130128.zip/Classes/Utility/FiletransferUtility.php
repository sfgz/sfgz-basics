<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/** 
 * Class FiletransferUtility
 * 
 * 
 */
 
class FiletransferUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     * @inject
     */
    protected $kursRepository = null;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 */
	protected $persistenceManager = NULL;

	/**
	 * array settings
	 */
	protected $settings = array();

    /**
     * uploadFolder
     *
     * @var string
     */
    Public $uploadFolder = 'eg. /uploads/tx_sfgzkurs/';

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_lst';

    /**
     * kurstabelle
     *
     * @var array
     */
    protected $kurstabelle = NULL;

    /**
     * fileFieldname
     *
     * @var string
     */
    protected $fileFieldname = 'dateiname';

	/**
	 * construct
	 *
     * @param array $conf optional
	 * @return void
	 */
	public function __construct( $conf = array() )
	{
	
		if( isset($conf['pluginKey']) && !empty($conf['pluginKey']) ) $this->pluginKey = $conf['pluginKey'];
		if( isset($conf['fileFieldname']) && !empty($conf['fileFieldname']) ) $this->fileFieldname = $conf['fileFieldname'];

		$this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
	    $this->settings = $this->settingsUtility->getSettings( $this->pluginKey );
	    $persistence = $this->settingsUtility->getPersistence( $this->pluginKey );
		$pidArr['storagePid'] = $persistence['storagePid'];
	
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(TRUE);
		$querySettings->setStoragePageIds($pidArr);
		
		$this->kursRepository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\KursRepository');
	    $this->kursRepository->setDefaultQuerySettings($querySettings);
		
		$this->versionRepository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\VersionRepository');
	    $this->versionRepository->setDefaultQuerySettings($querySettings);
		
		$this->durchfuehrungRepository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\DurchfuehrungRepository');
	    $this->durchfuehrungRepository->setDefaultQuerySettings($querySettings);
	    
		$uploadDir = rtrim(PATH_site, '/') . '/' . trim($this->settings['filePaths']['subfolder'], '/')  . '/' ;
		$this->uploadFolder =  GeneralUtility::getFileAbsFileName($uploadDir);
		$this->createDirectory( $this->uploadFolder );
		$this->createDirectory( $this->uploadFolder . '/' . $this->settings['filePaths']['temp'] );
		
		$this->dateUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\DateUtility');
		$this->tableMapperUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\TableMapperUtility');
	}

	/**
	 * setPluginKey
     * 
	 * @param string $pluginKey
	 * @return void
	 */
	Public function setPluginKey( $pluginKey )
	{
		$this->pluginKey = $pluginKey;
	}

	/**
	 * concatFileTables
	 * returns a 3-dim array: Array[ associative-Index ][ tablename ][ domFieldName ] = value
	 * 
	 * detects orphan table
	 * 
	 * @param string $parentFileTable
	 * @return array
	 */
	Public function concatFileTables( $parentFileTable = 'course' )
	{
		$aCachedContent = $this->getCachedConcatFileTables( $parentFileTable );
		if( $aCachedContent ) return $aCachedContent;
		
		// import: read from json-file
		$jsonFile = $this->uploadFolder . $parentFileTable . '/' . $this->settings['sourceFiles'][$parentFileTable]['fileName'] . '.json';
		if( file_exists($jsonFile) ){
			$aParentFileContents = json_decode( file_get_contents($jsonFile) , true ) ;
		}else{
			$aParentFileContents = array();
		}
		
		$aOrphans = [];
		foreach( $this->settings['tables'] as $table => $tabDef ){
				// $table == timetable
				if( !isset($tabDef['mapTable']) ) continue;
				$jsonLektFile = $this->uploadFolder . $tabDef['sourceFile'] . '/' . $this->settings['sourceFiles'][$tabDef['sourceFile']]['fileName'] . '.json';
				if( !file_exists($jsonLektFile) ) continue;
				$aChildFileContents = json_decode( file_get_contents( $jsonLektFile ) , true );
				if( !count($aChildFileContents) ) continue;
				
				// append childs
				// $table e.g. = lektion
				$parentTable = $tabDef['mapTable']['parentTable']; // durchfuehrung
				$parentJoinFieldSql = GeneralUtility::underscoredToLowerCamelCase( $tabDef['mapTable']['parentJoinField'] ); // ecoFachid
				$childJoinFieldSql = GeneralUtility::underscoredToLowerCamelCase( $tabDef['mapTable']['childJoinField'] ); // fachid
				// if kurse.csv:
				// seek for matching parents for lektionen.csv in kurse.csv
				// append child (lektionen) to parent (durchfuehrung) table
				foreach( $aParentFileContents as $index => $aFileContent ){
					if( isset($aFileContent[$parentTable][$parentJoinFieldSql]) ){
						$ecoFachid = $aFileContent[$parentTable][$parentJoinFieldSql];
						foreach( $aChildFileContents as $ix => $row ){
								if( $ecoFachid != $row[$table][$childJoinFieldSql] ) continue;
								$aParentFileContents[$index][$table][] = $row[$table];
								unset( $aChildFileContents[$ix][$table] );
						}
					}
				}
				// if there are remaining $aChildFileContents 
				// or if there was no kurse.csv:
				// Orphans. Childs without parents. (lektionen ohne durchfuehrung, version und kurs)
				foreach( $aChildFileContents as $ix => $row ){
						if( isset($row[$table]) ) {
							$lektionFachid = $row[$table][$childJoinFieldSql];
							$aGroupedOrphans[$fileTableName][$table][$lektionFachid][$ix] = $row[$table];
						}
				}
				
		}
		
		// handle orphans
		$notIndexedDb =  $this->createOrphansFromFilecontent( $aGroupedOrphans );
		if( is_array($notIndexedDb) && count($notIndexedDb) ){
			// append orphans to regular records
			$orphansFromFile = $this->tableMapperUtility->rebuildIndex($notIndexedDb,'course');
			foreach( $orphansFromFile as $key => $aRecordset ) $aParentFileContents[ $key ] = $aRecordset;
		}

		// cache the result and return it
		return $this->cacheConcatFileTables( $aParentFileContents , $parentFileTable );
	}

	/**
	 * createOrphansFromFilecontent
	 *
	 * @param array $aGroupedOrphans
	 * @return array
	 */
	Private function createOrphansFromFilecontent( $aGroupedOrphans )
	{
		if( !is_array($aGroupedOrphans) || !count($aGroupedOrphans) ) return;
		
		// evaluate durchfuehrung-uid 
		$englDate = $this->dateUtility->getStichtag();// today or a stored date in engl format
		
		// create array with fachid => versionUid
		// POSSIBLE version.
		foreach( $aGroupedOrphans as $fileTableName => $tabDefMapTable ){
				foreach( $tabDefMapTable as $table => $groupedTable ){
						foreach( $groupedTable as $lektionFachid => $rowTable){
								if( isset($aOrphans[$table][$lektionFachid]['versionUid']) ) continue;
								$possibleObjDurchf = $this->durchfuehrungRepository->findByEcoFachid($lektionFachid);
								foreach($possibleObjDurchf as $objDurchf ){
									if( isset($aOrphans[$table][$lektionFachid]['versionUid']) ) continue; // $objDurchf
									$possibleVersionUid = $objDurchf->getVersion();
									$possibleObjVersion = $this->versionRepository->findByUid($possibleVersionUid);
									$kursUid = $possibleObjVersion->getKurs();
 									$aVersion = $this->versionRepository->findNewest( $kursUid , $englDate );
									foreach( $aVersion as $version ) {
										$aOrphans[$table][$lektionFachid]['versionUid'] = $version['uid'] ;
										// durchf mit fachid  [ 'lektion' ][ '796967' ]['versionUid'] = 5 
									}
								}
						}
				}
		}
		
		
		$aParentFileContents = [];
		foreach( $aGroupedOrphans as $fileTableName => $tabDefMapTable ){
				foreach( $tabDefMapTable as $table => $groupedTable ){
						foreach( $groupedTable as $lektionFachid => $rowTable){
								
								if( !isset($aOrphans[$table][$lektionFachid]['versionUid']) ) continue;
								
								$versionUid = $aOrphans[$table][$lektionFachid]['versionUid'];
								$rows = $this->kursRepository->findConcatTablesByFach($lektionFachid , $versionUid );
								foreach($rows as $ix => $combiRow){
										
										$aSingleRow = [];
										$aSingleRow['general']['isOrphan'] = 1;
										$aSingleRow['kurs']['kursCode'] = $combiRow['kurs_code']; // part of index
										$aSingleRow['version']['titel'] = $combiRow['titel'];
										$aSingleRow['durchfuehrung']['durchfuehrungsCode'] = $combiRow['durchfuehrungs_code']; // part of index
										$aSingleRow['durchfuehrung']['codeSuffix'] = $combiRow['code_suffix']; // part of index
										$aSingleRow['durchfuehrung']['version'] = $versionUid;
										$aSingleRow['durchfuehrung']['ecoFachid'] = $combiRow['eco_fachid'];
										$aSingleRow['durchfuehrung']['veranstaltungen'] = $combiRow['veranstaltungen'];
										$aSingleRow['durchfuehrung']['lektionen'] = $combiRow['lektionen'];
										$aSingleRow['durchfuehrung']['terminStart'] = $combiRow['termin_start'];
										$aSingleRow['durchfuehrung']['terminEnde'] = $combiRow['termin_ende'];
										$aSingleRow['durchfuehrung']['zeitVon'] = $combiRow['zeit_von'];
										$aSingleRow['durchfuehrung']['zeitBis'] = $combiRow['zeit_bis'];
										$aSingleRow['durchfuehrung']['lehrpersonText'] = $combiRow['lehrperson_text'];
										$aSingleRow['durchfuehrung']['zimmer'] = $combiRow['zimmer'];
										$aSingleRow['durchfuehrung']['ort'] = $combiRow['ort'];
										$aSingleRow['durchfuehrung']['lehrerEcoId'] = $combiRow['lehrer_eco_id'];
										$aSingleRow[$table] = $rowTable;
										
 										$aParentFileContents[] = $aSingleRow;
								}
						}
				}
		}
 		return $aParentFileContents; 
	}

	/**
	 * cacheConcatFileTables
	 * 
	 * @param array $aParentFileContents
	 * @param string $parentFileTable
	 * @return array
	 */
	Public function cacheConcatFileTables( $aParentFileContents , $parentFileTable )
	{
		if( count($aParentFileContents) ) file_put_contents( $this->uploadFolder . $parentFileTable . '/' . 'concatFileTables.ser' , serialize($aParentFileContents) );
		return $aParentFileContents;
	}

	/**
	 * getCachedConcatFileTables
	 * 
	 * returns the cached result of method concatFileTables()
	 * if no json-file is newer than the serialized one
	 * 
	 * @return array
	 */
	Public function getCachedConcatFileTables( $parentFileTable = 'course' )
	{
		$serFile = $this->uploadFolder . $parentFileTable . '/' . 'concatFileTables.ser';
		if( !file_exists($serFile) ) return false;
		$serFileMtime = filemtime( $serFile );
		
		$cacheEnabled = true;
		
		$jsonParentFile = $this->uploadFolder . $parentFileTable . '/' . $this->settings['sourceFiles'][$parentFileTable]['fileName'] . '.json';
		
		// json file for parent table is newer than serialized, delete serialized file to force rewriting the chache
		if( file_exists($jsonParentFile) && filemtime( $jsonParentFile ) > $serFileMtime ) $cacheEnabled = false;
		
		foreach( $this->settings['tables'] as $tabDef ){
				if( !isset($tabDef['mapTable']) ) continue;
				$jsonFile = $this->uploadFolder . $tabDef['sourceFile'] . '/' . $this->settings['sourceFiles'][$tabDef['sourceFile']]['fileName'] . '.json';
				if( !file_exists($jsonFile) ) continue;
				if( filemtime( $jsonFile ) <= $serFileMtime ) continue;
				// json file is newer than serialized, delete serialized file to force rewriting the chache
				$cacheEnabled = false;
				break;
		}
		
		$serializedContent = file_get_contents($serFile);
		
		if( !$cacheEnabled || empty($serializedContent) ) {
			unlink( $serFile );
			return false;
		}
		
		$aUnserializedContent = unserialize($serializedContent);
		return $aUnserializedContent;
		
	}


	/**
	 * getFtpFiles
	 * get all ftp files
	 * 
	 * @return void
	 */
	Public function getFtpFiles()
	{
		foreach( array_keys( $this->settings['sourceFiles'] ) as $folderName ) $this->getFtpFile( $folderName );
	}

	/**
	 * getCalendarsFtpFile
	 *
	 * @return array
	 */
	Public function getCalendarsFtpFile()
	{
		$unsortDB = [] ;
		$calendarDB = [] ;
        $jsonFile = $this->uploadFolder . '/calendar/' . $this->settings['sourceFiles']['calendar']['fileName'] . '.json';
		if( file_exists($jsonFile) ){
			$calDb = json_decode( file_get_contents($jsonFile) , true ) ;
			foreach( $calDb as $row ){
				$aDate = explode( ' ' , $row['calendar']['sortDate'] );
				$unsortDB[ $aDate[0]][$row['calendar']['zeitVon'] ] = [ 'zeitVon' => $row['calendar']['zeitVon'], 'zeitBis' => $row['calendar']['zeitBis'], 'typ' => $row['calendar']['typ'] ];
			}
			ksort($unsortDB);
			foreach( $unsortDB as $date => $row ){
				ksort($unsortDB[$date]);
				$calendarDB[$date] = array_pop( $unsortDB[$date] );
			}
		}
		return $calendarDB;
	}

	/**
	 * getFtpFile
	 *
	 * @param string $fileName
	 * @return string
	 */
	Public function getFtpFile( $folderName )
	{
			$callingUrl = 'ftp://';
			$callingUrl .= $this->settings['ftp']['username'] . ':' ;
			$callingUrl .=  $this->settings['ftp']['password'] . '@' ;
			$callingUrl .=  $this->settings['ftp']['url'] . '/' ;
			$callingUrl .=  $this->settings['sourceFiles'][$folderName]['fileName'];
			$callingUrl .= '.csv';
			
			$strContent = file_get_contents($callingUrl);
			if( empty($strContent) ) return false;

			$uploadSubFolder = $this->uploadFolder . $folderName . '/'; 
			$uploadFileBasename = $uploadSubFolder . $this->settings['sourceFiles'][$folderName]['fileName'];
			
			// if folder exists then clear it, if not then make directory. Writable for all (0777) , Recursive if parent folder not exist (TRUE) 
			if( FALSE == $this->createDirectory($uploadSubFolder) ) $this->clearFolder( $folderName );
			
			return $this->prePocessUploadedFile( $uploadFileBasename , $strContent );
	}


	/**
	 * uploadFile
	 *
	 * @return string
	 */
	Public function uploadFile()
	{
			$fileName = $this->uploadFileTo( $this->uploadFolder );
			
			if( empty($fileName) ) return false;
			if( !file_exists($this->uploadFolder . $fileName) ) return false;
			
			$uploadFileBasename = $this->moveUploadedFile( $fileName );
				
			$strContent = file_get_contents( $uploadFileBasename . '.csv' );
			return $this->prePocessUploadedFile( $uploadFileBasename , $strContent );
	}

	/**
	 * uploadFileTo
	 *
	 * @param string $uploadFolder
	 * @return string
	 */
	Public function uploadFileTo( $uploadFolder = '' )
	{
			if( !$_FILES[$this->pluginKey]['tmp_name'][$this->fileFieldname] ) return false;
		
			$fileName = $_FILES[$this->pluginKey]['name'][$this->fileFieldname];
			if( empty( $fileName ) || empty( $uploadFolder ) ) return false;
			
			if( file_exists($uploadFolder . $fileName) ) @unlink( $uploadFolder . $fileName );
			GeneralUtility::upload_copy_move( $_FILES[$this->pluginKey]['tmp_name'][$this->fileFieldname] , $uploadFolder . $fileName );
			
			if( empty( $fileName) ) return false;
			if( !file_exists($uploadFolder . $fileName) ) return false;
			return $fileName;
	}

	/**
	 * moveUploadedFile
	 *
	 * @param string $fileName
	 * @return string
	 */
	Private function moveUploadedFile( $fileName )
	{
			$folderName = $this->detectTableTypeInFile( $this->uploadFolder . $fileName );
			$uploadSubFolder = $this->uploadFolder . $folderName . '/'; 
			
			$uploadFileBasename = $uploadSubFolder . $this->settings['sourceFiles'][$folderName]['fileName'];
			
			// if folder exists then clear it, if not then make directory. Writable for all (0777) , Recursive if parent folder not exist (TRUE) 
			if( FALSE == $this->createDirectory($uploadSubFolder) ) $this->clearFolder( $folderName );

			rename( $this->uploadFolder . $fileName , $uploadFileBasename . '.csv' );
			return $uploadFileBasename;
	}

	/**
	 * prePocessUploadedFile
	 *
	 * @param string $uploadFileBasename
	 * @param string $strContent
	 * @return string
	 */
	Private function prePocessUploadedFile( $uploadFileBasename , $strContent )
	{
			$uploadDirFile = $uploadFileBasename . '.csv';
			$jsonFilename =  $uploadFileBasename . '.json';
			
			$strSanitized = $this->tableMapperUtility->sanitizeLinebreaksInCsvString( $strContent );
			if( file_exists($uploadDirFile) ) @unlink( $uploadDirFile );
			file_put_contents( $uploadDirFile , $strSanitized );
			
			$aContent = $this->tableMapperUtility->getContentFromFile($uploadDirFile);
			if( file_exists($jsonFilename) ) @unlink( $jsonFilename );
			file_put_contents( $jsonFilename , json_encode( $aContent ) );
			
			return $uploadDirFile;
	}

	/**
	 * helper detectTableTypeInFile
	 *
	 * @param string $uploadFile
	 * @return array 
	 */
	Public function detectTableTypeInFile( $uploadFile )
	{

			$aLines = file($uploadFile);
			if( !is_array($aLines) ) return ['no array'];
			
			// evaluate tabletype from inColumn-Name
			$rawHeadline = array_shift( $aLines );
			$aHeadLine = explode( $this->settings['csv_options']['delimiter'] , $rawHeadline );
			foreach( $aHeadLine as $colNr => $fromField ) {
					$sanitizedFieldName = str_replace( ' ' , '-' , trim($fromField) );
					$rowNameToRowNr[$sanitizedFieldName] = $colNr;
			}
			
			foreach( $this->settings['sourceFiles'] as $tablename => $tabDef ) {
				$fromField = str_replace( ' ' , '-' , trim($tabDef['detectByField']) );
				if( isset($rowNameToRowNr[$fromField]) ) return $tablename;
			}
			// fallback [ course | timetable]
			return 'course';
    }


	/**
	 * createDirectory
	 *
	 * @param string $folderpathName
	 * @return void
	 */
	Public function createDirectory( $folderpathName )
	{
		if( !file_exists($folderpathName) ){
			@mkdir( $folderpathName ,  0777, TRUE );
			return true;
		}
		return false;
	}

	/**
	 * clearFolder
	 *
	 * @param string $uploadSubFolder
	 * @param boolean $delFolder
	 * @return void
	 */
	Public function clearFolder( $uploadSubFolder , $delFolder = false )
	{
		$subDirectory = trim( $uploadSubFolder , '/' ) . '/';
		if( $subDirectory == '/' ) $subDirectory = '';
		$uploadDir = $this->uploadFolder . $subDirectory;

		if( !file_exists( $uploadDir ) || !is_dir( $uploadDir ) ) return false;
		$d = dir($uploadDir);
		while ( false !== ( $fullFilename = $d->read() ) ) {
			if( $fullFilename === '..' || $fullFilename === '.' || empty($fullFilename) ) continue;
			if( is_dir( $uploadDir . $fullFilename ) && $delFolder == false ) continue; // only delete sub-directories if $delFolder == true
			@unlink( $uploadDir . $fullFilename );
		}
		$d->close();
		if( $delFolder && $uploadDir != $this->uploadFolder ) @rmdir( $uploadDir );
    }

	/**
	 * getFtpFolderContent
	 * used by KursController->OverviewAction
	 * 
	 * contains ftp-commands 
	 *
	 * @param string $folder
	 * @return array 
	 */
	Public function getFtpFolderContent()
	{
		// Verbindung aufbauen, Login mit Benutzername und Passwort, Verbindung schließen
		$conn_id = ftp_connect($this->settings['ftp']['url']);
		$login_result = ftp_login( $conn_id, $this->settings['ftp']['username'], $this->settings['ftp']['password'] );
		ftp_pasv( $conn_id, true );
		
		$response = $this->ftp_mlsd( $conn_id );
		
		ftp_close( $conn_id );
		
		return $response;
    }
    
    /**
     * ftp_mlsd
     * - Workaround for new PHP command 
     * - Returns a list of files in the given directory
     * 
     * The PHP command «ftp_mlsd» is implemented in PHP 7.2
     * 
	 * @param resource $conn_id
	 * @param string $dir optional, default is current folder
	 * @return array 2-dimensional list with filenames and properties
     */
	Private function ftp_mlsd( $conn_id , $dir = '.' ) {
		
		if (function_exists('ftp_mlsd') ) {
			return ftp_mlsd( $conn_id , $dir );
		}
		
		$ret = ftp_rawlist( $conn_id , $dir );
		$file = [];
		foreach($ret as $line){
			$aline = explode( ' ' , $line );
			$filename = array_pop($aline);
			if( '.' == $filename || '..' == $filename ) continue;
			$ucTimestamp = ftp_mdtm( $conn_id , $filename );
			$localDate = $this->dateUtility->sanitizeDateTimestamp( $ucTimestamp );
			$weekdayLetters = LocalizationUtility::translate( 'format.day.' . $localDate->format('w') , 'SfgzKurs' );
			$file[ $filename ]['datum'] = $weekdayLetters . ' ' . $localDate->format('d.m.y H:i:s');
			$file[ $filename ]['dateTime'] = $localDate;
			$fSizeByte = ftp_size( $conn_id , $filename );
			$file[ $filename ]['size'] = number_format( $fSizeByte / 1024 , 3 , '.' , "'" ) . ' K';
		}
		return $file;
		
	} 

	
	/**
	 * helper getFileList
	 * create a list of files
	 *
	 * @param string $uploadSubFolder optional
	 * @return array 
	 */
	Public function getFileList( $uploadSubFolder = '' )
	{
		if( !empty($uploadSubFolder) ) {
			$uploadSubFolder = $uploadSubFolder == '/' ? '' : trim( $uploadSubFolder , '/' ) . '/';
		}
		$uploadDir = $this->uploadFolder . $uploadSubFolder;
		
		if( !file_exists( $uploadDir ) || !is_dir( $uploadDir ) ) return 'dir does not exist: '.$uploadDir;

		$filelist = array();
		$fileSizeSum = 0;
		
		$d = dir($uploadDir);
		while ( false !== ( $fullFilename = $d->read() ) ) {
			if( $fullFilename === '.' || $fullFilename === '..' ) continue;
			$pathFilename = $uploadDir . $fullFilename;
			$fileSize = filesize($pathFilename);
			$filelist[$fullFilename] = [
				'filename' => $fullFilename,
				'extension' => pathinfo( $fullFilename , PATHINFO_EXTENSION ),
				'size' => round( $fileSize / 1024, 3 ),
				'time' => filemtime( $pathFilename ),
				'shortfilename' => pathinfo( $fullFilename , PATHINFO_FILENAME ),
			];
			$fileSizeSum += $fileSize;
		}
		$d->close();
		ksort($filelist);
		return $filelist;
	}
	
	/**
	 * downloadFile
	 * used to download docx Documents. 
	 * can handle many mimetypes
	 *
     * @param string $fullPath
     * @param string $outputName optional, can be extracted
     * @param boolean $deleteFile optional, default ist false. deletes file after download
	 * @return void
	 */
	Public function downloadFile( $fullPath , $outputName = '' , $deleteFile = false )
	{
		if( !file_exists($fullPath) || !is_file($fullPath) ) return false;
		
		$fsize = filesize($fullPath);
		$path_parts = pathinfo($fullPath);
		if( !$outputName ) $outputName = $path_parts['basename'];
		$ext = strtolower($path_parts['extension']);
		
		if ($fd = fopen ($fullPath, 'r')) {
			if ($ext == 'pdf' || $ext == 'csv' ) {
				// use 'attachment' to force a download
				header('Content-type: application/' . $ext); 
				header('Content-Disposition: attachment; filename="'.$outputName.'"');
			}else{
				// Other document formats (doc, docx, odt, ods etc)
				header('Content-type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
				header('Content-Disposition: filename="'.$outputName.'"');
			}
			header('Content-length: '.$fsize);
			//header('Cache-control: private'); //use this to open files directly
            header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
            header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
			while(!feof($fd)) {
				$buffer = fread($fd, 2048);
				echo $buffer;
			}
		}
		fclose ($fd);
		
		if( $deleteFile ) @unlink( $fullPath );
		
		exit;
	}

	/**
	* analyse_file
	* 
	* from Ashley, http://php.net/manual/de/function.fgetcsv.php
	* 
	* Example Usage:
    * $Array = analyse_file('/www/files/file.csv', 10);
    *
    * output:
    * $Array['charset'] => ISO-8859-15
    * $Array['delimiter'] => ,
    * $Array['linebreak'] => \r\n
    * $Array['delimiter_key'] => comma
    * $Array['linebreak_key'] => rn
    * 
	* @param string $file 
	* @param integer $capture_limit_in_kb
	* @return array 
	*/
	Private function unused_analyse_file( $file , $capture_limit_in_kb = 10) {
		if( !file_exists($file) ) return NULL;
		// capture starting memory usage
		$output['peak_mem']['start']    = memory_get_peak_usage(true);

		// log the limit how much of the file was sampled (in Kb)
		$output['read_kb']                 = $capture_limit_in_kb;
	
		// read in file
		$fh = fopen($file, 'r');
			$contents = fread($fh, ($capture_limit_in_kb * 1024)); // in KB
		fclose($fh);
	
		// specify allowed field delimiters
		$delimiters = array(
			'comma'     => ',',
			'semicolon' => ';',
			'tab'         => "\t",
			'pipe'         => '|',
			'colon'     => ':'
		);
	
		// specify allowed line endings
		$linebreaks = array(
			'rn'         => "\r\n",
			'n'         => "\n",
			'r'         => "\r",
			'nr'         => "\n\r"
		);
	
		// loop and count each line ending instance
		foreach ($linebreaks as $key => $value) {
			$line_result[$key] = substr_count($contents, $value);
		}
	
		// sort by largest array value
		asort($line_result);
	
		// log to output array
		$output['linebreak']['results']     = $line_result;
		$output['linebreak']['count']     = end($line_result);
		$output['linebreak']['key']         = key($line_result);
		$output['linebreak']['value']     = $linebreaks[$output['linebreak']['key']];
		$lines = explode($output['linebreak']['value'], $contents);
	
		// remove last line of array, as this maybe incomplete?
		array_pop($lines);
	
		// create a string from the legal lines
		$complete_lines = implode(' ', $lines);
	
		// log statistics to output array
		$output['lines']['count']     = count($lines);
		$output['lines']['length']     = strlen($complete_lines);
	
		// loop and count each delimiter instance
		foreach ($delimiters as $delimiter_key => $delimiter) {
			$delimiter_result[$delimiter_key] = substr_count($complete_lines, $delimiter);
		}
	
		// sort by largest array value
		asort($delimiter_result);
	
		// log statistics to output array with largest counts as the value
		$output['delimiter']['results']     = $delimiter_result;
		$output['delimiter']['count']         = end($delimiter_result);
		$output['delimiter']['key']         = key($delimiter_result);
		$output['delimiter']['value']         = $delimiters[$output['delimiter']['key']];

		$output['charset']['list'] = 'utf-8,utf-16,ucs2,iso-10646-ucs-2,iso-8859-15,iso-8859-1,windows-1251';
		$charsetlist = explode( ',' , $output['charset']['list'] );
		foreach ($charsetlist as $item) {
			if( strtolower(mb_detect_encoding( $complete_lines , $item , true)) == strtolower($item) ){ // first test ok
				$sample = iconv($item, $item, $complete_lines);
				if (md5($sample) == md5($complete_lines)) { // second test ok
					$output['charset']['value'] =  $item;
					break;
				}
			}
		}
	
		// capture ending memory usage
		$output['peak_mem']['end'] = memory_get_peak_usage(true);
		
		return array( 'charset'=>$output['charset']['value'] , 'delimiter'=>$output['delimiter']['value'] , 'linebreak'=>$output['linebreak']['value'] , 'delimiter_key'=>$output['delimiter']['key'] , 'linebreak_key'=>$output['linebreak']['key'] );
	}
	
}
