<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class MigrationUtility
 * Import ab Gadola Server. Nun stillgelegt.
 * 
 */
 
class MigrationUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * array settings
	 */
	protected $settings = null;

    /**
     * urlToXml
     *
     * @var string
     */
    protected $urlToXml = 'http://intern.sfgz.ch/wbkurscms/getxml.aspx';
	
	/**
	 * Property aHtmlReplace
	 *
	 * @var array
	 */
	protected $aHtmlReplace = [
		'html2txt' => [ 
							'<br>'=>'', 
							'<br />'=>'', 
							'<p>'=>'', 
							'</p>'=>''
					],
		'search'=> [
							'&amp;', 
							'&lt;', 
							'&gt;', 
							'&apos;', 
							'&quot;', 
							'&nbsp;'
					],
		'replace'=> [
							'&' , 
							'<' , 
							'>' , 
							"'" , 
							'"' , 
							' '
					]
	];
    
    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     */
    protected $kursRepository = null;
    
    /**
     * kategorieRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KategorieRepository
     */
    protected $kategorieRepository = null;

    /**
     * versionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\VersionRepository
     */
    protected $versionRepository = null;

    /**
     * durchfuehrungRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\DurchfuehrungRepository
     */
    protected $durchfuehrungRepository = null;

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
	
		$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		
		$this->kursRepository = $this->objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\KursRepository');
	    $this->kursRepository->setDefaultQuerySettings($querySettings);
		
		$this->kategorieRepository = $this->objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\KategorieRepository');
	    $this->kategorieRepository->setDefaultQuerySettings($querySettings);
		
		$this->versionRepository = $this->objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\VersionRepository');
	    $this->versionRepository->setDefaultQuerySettings($querySettings);
		
		$this->durchfuehrungRepository = $this->objectManager->get('Sfgz\\SfgzKurs\\Domain\\Repository\\DurchfuehrungRepository');
	    $this->durchfuehrungRepository->setDefaultQuerySettings($querySettings);

	    $this->filetransferUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\FiletransferUtility');
		$this->xmlToAssocUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\XmlToAssocUtility');
		
	}
	
    /**
     * candoCreateXmlFile
     *
     * @return string
     */
	public function candoCreateXmlFile(){
		// read xml from given URL and transform it to array $xmlArr
		$strContent = file_get_contents( $this->urlToXml );
		return empty($strContent) ? FALSE : TRUE ;
	}
	
    /**
     * createXmlFile
     *
     * @return string
     */
	public function createXmlFile(){
		$importFile = $this->filetransferUtility->uploadFolder .  '/fullImportFromCurrent.xml';
		if( file_exists($importFile) ) return $importFile;
		
		// read xml from given URL and transform it to array $xmlArr
		$xmlArr = $this->xmlToAssocUtility->parseUrl( $this->urlToXml );
		
		// store the array in a file and return the filename
		file_put_contents( $importFile , serialize($xmlArr) );
		
		return $importFile;
	}
	
    /**
     * compareDbAndXmlFile
     *
     * @return array
     */
	public function compareDbAndXmlFile(){
			$aObjKategorien = $this->kategorieRepository->findAll();
			$aKategorieToId = [];
			foreach( $aObjKategorien as $oKategorie ) $aKategorieToId[ trim( $oKategorie->getKategorieName() ) ] = $oKategorie;
			
			$xmlData = $this->readXmlFile();
			$objKurs = [];
			$out = ['Hinweis'=>'Durchfuehrungen und Termine bitte separat importieren'];
			foreach( $xmlData as $code => $aKurs ){
				$objExisting = $this->kursRepository->findByKursCode($code);
				if( count($objExisting) ){
					foreach( $objExisting as $obj ) break;
					$isHidden = $obj->getAusblenden();
					if( !$isHidden && ( !is_array($aKurs['durchfuehrungen']) || !count($aKurs['durchfuehrungen']) ) ){
							$obj->setAusblenden( 1 );
							$this->kursRepository->update($obj);
							$out[$code . ''] = 'ausgeblendet';
					}elseif( $isHidden && is_array($aKurs['durchfuehrungen']) && count($aKurs['durchfuehrungen']) ){
							$obj->setAusblenden( 0 );
							$this->kursRepository->update($obj);
							$out[$code . ''] = 'eingeblendet';
					}else{
							$out[$code . ''] = 'belassen';
					}
					continue;
				}

				$objKurs[$code] = $this->createObjectFromList( ['kursCode'=>$code , 'titel'=>$aKurs['titel'] , 'stufeWb'=>$aKurs['stufe-wb'] ] , 'kurs' );
				$out[$code . '_erstellt'] = $objKurs[$code];

				if( is_array($aKurs['kategorien']) ){
					foreach( $aKurs['kategorien'] as $ix => $aKat ){
						if( isset($aKat[0]) && isset($aKategorieToId[ trim($aKat[0]) ]) ) {
							$objKurs[$code]->addKKategorien( $aKategorieToId[ trim($aKat[0]) ] );
						}
					}
				}
				
				if( !is_array($aKurs['durchfuehrungen']) || !count($aKurs['durchfuehrungen']) ){
						$objKurs[$code]->setAusblenden( 1 );
						$out[$code] = 'ausgeblendet';
				}
				
				if( is_array($aKurs['version']) ){
					$objVersion = $this->createObjectFromList(
						[
							'kurs'=>$objKurs[$code]->getUid(),
							'titel'=>$aKurs['version']['titel'],
							'subTitel'=>$aKurs['version']['sub-titel'],
							'versionStart'=>$aKurs['version']['start'],
							'versionEnde'=>$aKurs['version']['ende'],
							'zielgruppe'=>$aKurs['version']['zielgruppe'],
							'ziel'=>$aKurs['version']['ziel'],
							'inhalt'=>$aKurs['version']['inhalt'],
							'hinweis'=>$aKurs['version']['hinweis'],
							'kursunterlagen'=>$aKurs['version']['kursunterlagen'],
							'methode'=>$aKurs['version']['methode'],
							'zertifikat'=> $this->html2text( $aKurs['version']['zertifikat'] ),
							'voraussetzungen'=>  $aKurs['version']['voraussetzungen'] ,
							'weitereInfos'=>$aKurs['version']['weitere-infos'],
							'textLead'=>$aKurs['version']['lead']
						],
						'version'
					);
					$objKurs[$code]->addKVersionen($objVersion);
				}
				
			}
			
			return $out;
	}
	
    /**
     *  html2text
     *
     * @param string $strHtml
     * @return string
     */
    Protected function html2text( $strHtml )
    {
		$noBreaks = str_replace( array_keys($this->aHtmlReplace['html2txt']) , $this->aHtmlReplace['html2txt'] , $strHtml );
		return str_replace( $this->aHtmlReplace['search'] , $this->aHtmlReplace['replace'] , $noBreaks );
	}
	
    /**
     *  createObjectFromList
     *
     * @param array $aImportList
     * @param string $tablename
     * @return \TYPO3\CMS\Extbase\Persistence\Repository $newObject
     */
    Protected function createObjectFromList( $aImportList , $tablename )
    {
			$repository = strtolower($tablename) . 'Repository';
			
			$newObject = GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\\' . ucFirst($tablename) );
			
			// insert new values: main work of the method
			foreach ($aImportList as $domFormattedKey => $fieldValue ) {
				$newObject->_setProperty( $domFormattedKey , $fieldValue );
			}
				
			$this->$repository->add( $newObject );
			
			return $newObject;
	}
	
    /**
     * isXmlFile
     *
     * @return boolean
     */
	public function isXmlFile(){
			$importFile = $this->filetransferUtility->uploadFolder .  '/fullImportFromCurrent.xml';
			return file_exists($importFile);
	}
	
    /**
     * readXmlFile
     *
     * @return array
     */
	public function readXmlFile(){
			$importFile = $this->filetransferUtility->uploadFolder .  '/fullImportFromCurrent.xml';
			if( !file_exists($importFile) ) $importFile = $this->createXmlFile();
			if( !file_exists($importFile) ) return false;
			
			$xmlArr = unserialize( file_get_contents( $importFile ) );
			
			$dateNow = date( 'Y-m-d' );
			
			$importDb = [];
			//$importDb['kategorien'] = $xmlArr['document'][0]['kategorien']['kategorie'];
			if( is_array($xmlArr['document'][0]['kurse']['kurs']) ){
					foreach( $xmlArr['document'][0]['kurse']['kurs'] as $kix => $kursRow){
						if( !isset($kursRow['versionen']['version'][0]) ) continue;
						$test = 0;
						foreach( $kursRow['versionen']['version'] as $vix => $version ){
							//if( !isset($version['durchfuehrungen']['durchfuehrung']) ) continue;
							//if( !isset($version['ende'][0]) || $version['ende'][0] < $dateNow ) continue;
							$test = 1;
						}
						if( !$test ) continue;
						// kurs fields
						$code = $kursRow['kurs-code'][0];
						$importDb[$code]['kurs-code'] = $code;
						$importDb[$code]['stufe-wb'] = $kursRow['stufe-wb'][0];
						$importDb[$code]['titel'] = $kursRow['titel'][0];
						// kurs-kategorie records
						if( isset( $kursRow['kategorien']['kategorie'] ) ) {
							$importDb[$code]['kategorien'] = $kursRow['kategorien']['kategorie'] ;
						}
						foreach(  $kursRow['versionen']['version'] as $vix  => $version){
							foreach( $version as $colname => $content ){
								if( $colname == 'durchfuehrungen' ){ // version-durchfuehrung records
									if( !isset($content['durchfuehrung']) ) continue;
									foreach($content['durchfuehrung'] as $dix => $durchfuehrung ){
										foreach($durchfuehrung as $dFldName => $dFelCont ){
											if( $dFldName == 'termine' ){ // durchfuehrung-termine records
												if( !isset($dFelCont['termin']) ) continue;
												foreach($dFelCont['termin'] as $tix => $termin ){
													foreach( $termin as $tFld => $tCnt ){ // termin fields
														if( isset($tCnt[0]) ) $importDb[$code][$colname][$dix][$dFldName.'.'.$tix][$tFld] = $tCnt[0];
													}
												}
											}elseif( isset($dFelCont[0]) ){ // durchfuehrung fields
												$importDb[$code][$colname][$dix][$dFldName] = $dFelCont[0];
											}
										}
									}
								}elseif( isset( $content[0] ) ){ // version fields
									$importDb[$code]['version'][$colname] = $content[0];
								}
							}
						}
					}
			}
			ksort($importDb);
			return $importDb;
	}
	
    /**
     * deleteXmlFile
     *
     * @return void
     */
	public function deleteXmlFile(){
		$importFile = $this->filetransferUtility->uploadFolder .  '/fullImportFromCurrent.xml';
		if( file_exists($importFile) ) {
			@unlink($importFile);
		}
	}
	

}
