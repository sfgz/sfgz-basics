<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/** 
 * Class ExportfunctionsUtility
 * 
 * 
 */
 
class ExportfunctionsUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
     * englStichtag
     *
     * @var string
     */
    protected $englStichtag = '';

	/**
	 * array settings
	 */
	protected $settings = null;

	/**
	 * array dbStatic
	 */
	protected $dbStatic = null;

	/**
	 * array records
	 */
	protected $records = null;

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_sfgzkurs_lst';

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
			$this->settingsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\SettingsUtility');
		    $this->settings = $this->settingsUtility->getSettings( $this->pluginKey );

	}

	
	// Postrender EXPORT-FUNCTIONS
    /**
     *  postrender_renderHtmlContent
     *  links to other kurse
     *  replaces parts in URL if numeric
     *
     * @param string $strFieldContent
     * @return string
     */
	Protected function postrender_renderHtmlContent( $strFieldContent )
	{
		if( !strpos( $strFieldContent , '</a>') ) return $strFieldContent;
		
		$sr = [ 'https://'=>'' , 'http://'=>'' ];
		
		$aReplacements = [];
		
		// <a href="h!kurs=ttp://2747">
		
		for( $z=0 ;  $z < strlen($strFieldContent) ; ++$z) {
				$fPos1 = strpos( $strFieldContent , 'href="' , $z );
				if( !$fPos1 ) break;
				
				$sPos = $fPos1 + strlen('href="') ;
				$fPos2 = strpos( $strFieldContent , '"' , $sPos );
				if( !$fPos2 ) break;
				
				$uLen = $fPos2-$sPos;
				$url = substr($strFieldContent , $sPos , $uLen );
				$protFreeUrl = trim( str_replace( array_keys($sr) , $sr , $url ) );
				
				if( is_numeric($protFreeUrl) ) {
					$aReplacements[ strlen($url) ][$url] = $this->settings['export']['rteLinksPrefixNumericUrls'] . $protFreeUrl;
				}
				$z = $fPos2+1;
		}
		if( !count($aReplacements) )  return $strFieldContent;
		
		krsort($aReplacements);
		
		foreach($aReplacements as $sortArr) $strFieldContent = str_replace( array_keys($sortArr) , $sortArr , $strFieldContent );
		
		return $strFieldContent ;
	}

	// EXPORT-FUNCTIONS

    /**
     *  export_translate
     *
     * @param array $strMixParam string with 1 element | translationKey |
     * @return string
     */
	Public function export_translate( $strMixParam )
	{
			$aMixedOptions = explode( '|' , trim( $strMixParam , '|' ) );
			return LocalizationUtility::translate( trim($aMixedOptions[0]) , 'SfgzKurs' );
	}

    /**
     *  export_sanitizeBoolean
     *
     * @param array $strMixParam string with 1 element | table.field |
     * @return string
     */
	Public function export_sanitizeBoolean( $strMixParam )
	{
			$aMixedOptions = explode( '|' , trim( $strMixParam , '|' ) );
				$aTabFld = explode( '.' , trim($aMixedOptions[0]) );
				$bValue = $this->dbStatic[$aTabFld[0]][$aTabFld[1]];
				return $bValue ? 'TRUE' : 'FALSE';
	}

    /**
     *  export_sanitizeLineBreaks
     *
     * @param array $strMixParam string with 1 element | table.field |
     * @return string
     */
	Public function export_sanitizeLineBreaks( $strMixParam )
	{
			$aSr = [ 
							'<br>'=>   "\n" , 
							'<br />'=> "\n" , 
							'<p>'=> '' , 
							'</p>'=> "\n"
					];
			$aMixedOptions = explode( '|' , trim( $strMixParam , '|' ) );
			$aTabFld = explode( '.' , trim($aMixedOptions[0]) );
			$bValue = $this->dbStatic[$aTabFld[0]][$aTabFld[1]];
				
			return str_replace( array_keys($aSr) , $aSr , $bValue );
	}

    /**
     *  export_calculate
     * CommaSeparedTableFieldnamePairs is like | durchfuehrung.lektionen, durchfuehrung.veranstaltungen |
     * strMaskedCalculation is like | %1 * %2 OR round( %1 / %2 , 3 ) etc.
     *
     * @param array $strMixParam string with 2 elements: | CommaSeparedTableFieldnamePairs | strMaskedCalculation
     * @return string
     */
	Public function export_calculate( $strMixParam )
	{
			$aMixedOptions = explode( '|' , trim( $strMixParam , '|' ) );
			$groupFieldList = explode( ',' , trim($aMixedOptions[0]) ); // durchfuehrung.lektionen, durchfuehrung.veranstaltungen
			$strMaskedCalculation = trim( $aMixedOptions[1] ); // %1 * %2
			
			$isEmpty = 0;
			foreach($groupFieldList as $z => $tabFldPair ){
				$aTabFld = explode( '.' , trim($tabFldPair) );
				$rep[ '%' . ($z +1) ] = $this->dbStatic[$aTabFld[0]][$aTabFld[1]];
				$isEmpty += empty($rep[ '%' . ($z +1) ]) ? 1 : 0;
			}
			// return zero if one operand is empty
			if( $isEmpty ) return 0;
			
			// return the operands value, if only one operand is given
			if( count( $groupFieldList ) < 2 ) return isset($rep['%1']) ? $rep['%1'] : 0;
			// return zero if operation is empty
			if( empty( $strMaskedCalculation ) ) return 0;
			
			$calculation = str_replace( array_keys( $rep ) , $rep , $strMaskedCalculation );
			if( str_replace( '*' , '' , $calculation) == '' ) return 0;
			@eval( '$result = (' . $calculation . ');' );
			return $result;
			
	}
	
    /**
     *  export_translateFieldValue
     *
     * @param array $strMixParam string with with 2 elements: | tablename.fieldname | taggedTanslationKey_%1 |
     * @return string
     */
	Public function export_translateFieldValue( $strMixParam )
	{
			$aMixedOptions = explode( '|' , trim( $strMixParam , '|' ) );
			$groupFieldList = explode( ',' , trim($aMixedOptions[0]) ); // kategorie.gruppe.uid OR kategorie.gruppe.uid, table.field, table2.field2
			
			foreach($groupFieldList as $z => $tabFldPair ){
				$aTabFld = explode( '.' , trim($tabFldPair) );
				$rep[ '%' . ($z +1) ] = $this->dbStatic[$aTabFld[0]][$aTabFld[1]];
			}
			$translationKey = str_replace( array_keys( $rep ) , $rep , trim( $aMixedOptions[1] ) );
			return LocalizationUtility::translate( $translationKey , 'SfgzKurs' );
			
	}

    /**
     *  export_concatFormatValues
     *
     * @param array $strMixParam string with 2-3 elements: | CommaSeparedTableFieldnamePairs | tagged_%1_OutPut_%2-Format | trimChars |
     * @return string
     */
	Public function export_concatFormatValues( $strMixParam )
	{
			$aMixedOptions = explode( '|' , trim( $strMixParam , '|' ) );
			$groupFieldList = explode( ',' , trim($aMixedOptions[0]) ); // kurs.kurs_code OR kurs.kurs_code, durchfuehrung.durchfuehrungs_code , durchfuehrung.code_suffix
			$outputFormat = trim( $aMixedOptions[1] ); // |%1-,%2 ,%3|
			$splitChars = count($aMixedOptions) >= 3 ? trim($aMixedOptions[2]) : '';// |,|
			
			foreach($groupFieldList as $z => $tabFldPair ){
				$aTabFld = explode( '.' , trim($tabFldPair) );
				$rep[ '%' . ($z +1) ] = $this->dbStatic[$aTabFld[0]][$aTabFld[1]];
			}
			
			if( !strlen($splitChars) ) {
				$untrimmedResult = str_replace( array_keys( $rep ) , $rep , $outputFormat );
				return $untrimmedResult;
			}
			
			$aPatternParts = explode( $splitChars , $outputFormat );
			
			$strNewOutputFormat = '';
			foreach($aPatternParts as $z => $pattern){
				if( !empty($rep['%'.($z+1)]) ) $strNewOutputFormat .= $pattern;
			}
			
			$untrimmedResult = str_replace( array_keys( $rep ) , $rep , $strNewOutputFormat );
			return $untrimmedResult;
			
			
	}

    /**
     *  export_getSortNrWhere
     *
     * @param array $strMixParam string with 2 elements: | CommaSeparedTableFieldnamePairs | Tablename |
     * @return int
     */
	Public function export_getSortNrWhere( $strMixParam )
	{
			$aMixedOptions = explode( '|' , trim( $strMixParam , '|' ) );
			$groupFieldList = explode( ',' , $aMixedOptions[0] ); // kurs.kurs_code OR kurs.kurs_code, durchfuehrung.durchfuehrungs_code , durchfuehrung.code_suffix
			$tableToMark = trim( $aMixedOptions[1] ); // version OR durchfuehrung
		    
		    // initial setting, run once
		    if( !isset($this->settings['temp']) ) $this->helper_setTempTablenamesMapping();
			
			$plural = $this->settings['temp']['pluralOfTablenames'][ $tableToMark ];
			$dbAggregatename = $this->settings['export']['mapXmlToDbTablenames'][$plural];

			// collect to-group-fields as where-conditions for specified tables and fields
			foreach($groupFieldList as $tabFldPair ){
				$aTabFld = explode( '.' , trim($tabFldPair) );
				// matchWords = array[ matchInTable ][ matchInField ] = value
				$matchWords[ $aTabFld[0] ][ $aTabFld[1] ] = $this->dbStatic[$aTabFld[0]][$aTabFld[1]];
			}
			
			$aMarkedTables = $this->helper_getFilteredIndizes( $tableToMark , $matchWords , $this->records );
			
			$uid = $this->dbStatic[$tableToMark]['uid'];
			
			$z = 0;
			foreach( $aMarkedTables as $ix => $subtab ){
				if( !is_array( $subtab ) ){
					++$z; if( $ix == $uid ) return $z;
				}else{
					foreach($subtab as $verIx => $versRow ){
						if( !is_array( $versRow ) ){
							++$z; if( $verIx == $uid ) return $z;
						}else{
							foreach($versRow as $durchIx => $durchRow ){
								if( !is_array( $durchRow ) ){
									++$z; if( $durchIx == $uid ) return $z;
								}else{
									foreach($durchRow as $lektIx => $lektRow ) {
										++$z; if( $lektIx == $uid ) return $z;
									}
								}
							}
						}
					}
				}
			}
			
			return $z;
	}
	
    /**
     *  export_getNextRecordRenderDateFunction
     *  
     *  search the next record in table $dbAggregatename, get value from specified field and calculate on that value: 
     *  step 1: define $tableToLoop: detect data of table $dbAggregatename
     *  step 2: in $tableToLoop loop to actual record $actualUid and set $stepDone
     *  step 3: step to the next recordset 
     *  step 4: get the value from specified field $fieldToLookFor
     *  step 5: render $searchedValue with date - command and return the claculated value
     *
     * @param array $strMixParam string with 2 elements: | tablename.fieldname | postFunctionName |
     * @return string english date in format Y-d-m
     */
	Public function export_getNextRecordRenderDateFunction( $strMixParam )
	{
			$aMixedOptions = explode( '|' , trim( $strMixParam , '|' ) );
			$tabFieldToLookFor = trim($aMixedOptions[0]); // version.version_start
			$postFunctionName = trim($aMixedOptions[1]); //-3 day
			$fallbackYearsToAdd = trim($aMixedOptions[2]) > 0 ? trim($aMixedOptions[2]) : 50; // 30 (years to add)
		    
		    // initial setting, run once
		    if( !isset($this->settings['temp']) ) $this->helper_setTempTablenamesMapping();
			
			$aTabFld = explode( '.' , $tabFieldToLookFor );
			$tableToMark = $aTabFld[0];
			$fieldToLookFor = $aTabFld[1];
			
			$tablenameOfParent = $this->settings['temp']['tablenameToParentTable'][ $tableToMark ];
			
			$plural = $this->settings['temp']['pluralOfTablenames'][ $tableToMark ];
			$dbAggregatename = $this->settings['export']['mapXmlToDbTablenames'][$plural];
			
			$actualUid = $this->dbStatic[$tableToMark]['uid'];
			$parentsUid = $this->dbStatic[$tableToMark][$tablenameOfParent];
			
			$searchedValue = '';
			// step 1: define $tableToLoop: detect data of table $dbAggregatename
			$tableToLoop = [];
			foreach( $this->records as $index => $dbKurs ){
				foreach( $dbKurs as $fieldOrTabName => $mxFieldContent ){
					// $fieldOrTabName could be like  kurs_code OR k_versionen or k_kategorie
					if( is_array($mxFieldContent) ){
						if( $dbKurs['uid'] == $parentsUid && $dbAggregatename == $fieldOrTabName && !count($tableToLoop) ){
							$tableToLoop = $mxFieldContent;
							break;
						}
						foreach( $mxFieldContent as $subKursIndex => $subKursRow ){
							foreach( $subKursRow as $fieldOrTabSubName => $mxFieldSubContent ){
								// $fieldOrTabSubName could be like version_start OR v_durchfuehrungen
								if( is_array($mxFieldSubContent) ){
									if( $subKursRow['uid'] == $parentsUid && $dbAggregatename == $fieldOrTabSubName && !count($tableToLoop) ){
										$tableToLoop = $mxFieldSubContent;
										break;
									}
									foreach( $mxFieldSubContent as $durchfuehrungIndex => $durchfuehrungRow ){
										foreach( $durchfuehrungRow as $fieldOrTabDurchfName => $mxFieldDurchfContent ){
											// $fieldOrTabDurchfName could be like durchfuehrungs_code OR d_lektionen
											if( is_array($mxFieldDurchfContent) ){
												if( $durchfuehrungRow['uid'] == $parentsUid && $dbAggregatename == $fieldOrTabDurchfName && !count($tableToLoop) ){
													$tableToLoop = $mxFieldDurchfContent;
													break;
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			// step 2-4: get the value from specified field $fieldToLookFor
			$stopLoop = 0;
			foreach( $tableToLoop as $index => $row ){
				if( $stopLoop ){ 
					$searchedValue = trim($row[$fieldToLookFor]);
					break; 
				}
				if( isset($row['uid']) && $row['uid'] == $actualUid ){ 
					// reached the own recordset. Get start date in case of there is no newer record than this
					$stopLoop = 1; 
					$startDate = trim($row[$fieldToLookFor]); 
				}
			}

			if( !$searchedValue ) {
				// if there is no newer startdate then add 30 years to start
				$aStartDate = explode( '-' , $startDate);
				$searchedValue = ($aStartDate[0] + $fallbackYearsToAdd ) . '-' . $aStartDate[1] . '-' . $aStartDate[2];
			}
			
			// test: if value is not a date then return value from actual record
			$aDate = explode( '-' , $searchedValue );
			$dateCheck = count($aDate) == 3 ? checkdate ( $aDate[1] , $aDate[2] , $aDate[0] ) : false;
			if( !$dateCheck ) {
				$actualValue = $this->dbStatic[$tableToMark][$fieldToLookFor];
				return $actualValue;
			}
			
			// step 5: render $searchedValue with date - command and return the claculated value
			// this calculation with strtotime is quite dirty - better would be to use a newer PHP function like DateTime::add or DateTime::sub
			$calculatedUxTimestamp = strtotime( $searchedValue . ' ' . $postFunctionName );
			return date('Y-m-d', $calculatedUxTimestamp );

	}
	
	
    /**
     *  export_isNewGetScript
     *
     * @param array $strMixParam string with 3 elements: | DATEfield | thenFieldOrValue | elseFieldOrValue
     * @return string
     */
	Public function export_isNewGetScript( $strMixParam )
	{
			$aMixedOptions = explode( '|' , trim( $strMixParam , '|' ) );
			
			// we need 3 parameters
			// 1. param [0] date
			// 2. param [1] thenValue
			// 3. param [2] elseValue
			
			$optionsForFunction = [];
			$params = count($aMixedOptions);
			
			if( !$params ) return 'FEHLENDER Parameter in isNewGetScript';
			
			// we need 3 parameters optNr 0,1,2
			for( $optNr = 0 ; $optNr <=2 ; ++$optNr ){
				// while optNr < params there are incomedParam, otherwise set empty string
				if( $optNr < $params ){
					if( strpos($aMixedOptions[$optNr] , '.' ) ){
						// set value from db-field as option
						$aOptTabFld = explode( '.' , trim( $aMixedOptions[$optNr] ) );
						$optionsForFunction[$optNr] = $this->dbStatic[ $aOptTabFld[0] ][ $aOptTabFld[1] ];
					}else{
						// set incomed value as options
						$optionsForFunction[$optNr] = trim( $aMixedOptions[$optNr] );
					}
				}else{
					// set a empty string for the option
					$optionsForFunction[$optNr] = '';
				}
			}
			
			// functioname and parameter
			$isNewScript = 'functions.isDateInFuture | '. implode( '|' , $optionsForFunction );
			
			// if the date is younger (greater) or equal than now then its NEW (or not started), 
			//   return function for later with ElseVALUE as parameter
			//   else date is passed (old or started) return ElseVALUE 
			if( empty( $this->englStichtag ) ) $this->englStichtag = date('Y-m-d');
			return $optionsForFunction[0] >= $this->englStichtag ? $isNewScript : $optionsForFunction[2] ;

	}
	
    /**
     *  export_isDateInFuture
     *
     * @param array $strMixParam string with 3 elements: | englishDateString | TrueValueAsString | FalseValueAsString
     * @return string
     */
	Public function export_isDateInFuture( $strMixParam )
	{
			$aMixedOptions = explode( '|' , trim( $strMixParam , '|' ) );
			$englishDateString = trim( $aMixedOptions[0] );
			
			$optionsForFunction = [];
			$params = count($aMixedOptions);
			// we need 3 parameters optNr 0,1,2
			for( $optNr = 0 ; $optNr <=2 ; ++$optNr ){
				// while optNr < params there are incomedParam, otherwise set empty string
				if( $optNr < $params ){
						$optionsForFunction[$optNr] = trim( $aMixedOptions[$optNr] );
				}else{
					// set default for the option if parameters are missed
					$optionsForFunction[$optNr] = $optNr == 1 ? 'TRUE' : 'FALSE';
				}
			}

			// if the date is younger (greater) or equal than now 
			//  then date is in future  return TrueValueAsString (eg. TRUE or 1,2,3)
			//  else date is not in future, return incoming default-value FalseValueAsString (eg. FALSE or 4)
			if( empty( $this->englStichtag ) ) $this->englStichtag = date('Y-m-d');
			return $optionsForFunction[0] >= $this->englStichtag ? $optionsForFunction[1] : $optionsForFunction[2];
	}
	
    /**
     *  export_getStichtag
     *  with parameters ist adds or substracts timespans eg: export_getStichtag( '[+|-][1-n] [day|month|week|year]' ) 
     *  uses the PHP strtotime() function
     *
     * @param array $strMixParam string with 0 or 1 element: | +1 day |
     * @return string
     */
	Public function export_getStichtag( $strMixParam )
	{
			$engDateString = $this->getStichtag();
			
			$postFunctionName = trim( trim( $strMixParam , '|' ) ); //-3 day
			if( empty($postFunctionName) || strpos( $postFunctionName , '|' ) ) return $engDateString;
			
			$calculatedUxTimestamp = strtotime( $engDateString . ' ' . $postFunctionName );
			if( empty($calculatedUxTimestamp) ) return $engDateString;

			$calculatedEngDateString = date('Y-m-d', $calculatedUxTimestamp );
			return $calculatedEngDateString;
	}

	
	// HELPER for EXPORT-FUNCTIONS

    /**
     *  helper_getFilteredIndizes
     *  used by export_getSortNrWhere()
     *
     * @param string $tableToMark
     * @param array $matchWords
     * @param array $records
     * @return string
     */
	Protected function helper_getFilteredIndizes( $tableToMark , $matchWords , $records )
	{
			// detect the table to get sortNr for and loop trough records until actual uid is reached
			// respect the where-conditions while looping throught records and diving into tables
			// go as deep as $dbAggregatename is reached eg v_durchfuehrungen
			
			$aMarkedTables = [];
			foreach( $records as $index => $dbKurs ){
				// disable row if there is a where clause for kurs and it does not match
				if( isset($matchWords['kurs']) ){
					$stop = 0;
					foreach($matchWords['kurs'] as $fld => $cnt ){
						if( $dbKurs[$fld] != $cnt ) ++$stop;
					}
					if($stop) continue; 
				}
				if( 'kurs' == $tableToMark ){
						$aMarkedTables[$index] = $index;
						continue;
				}
				
				if( !is_array($dbKurs['k_versionen']) ) continue;
				foreach( $dbKurs['k_versionen'] as $subKursIndex => $subKursRow ){
					
							if( isset($matchWords[ 'version' ]) ){
								$stop = 0;
								foreach($matchWords[ 'version' ] as $fld => $cnt ){
									if( $subKursRow[$fld] != $cnt ) ++$stop;
								}
								if($stop) continue;
							}
							if( 'version' == $tableToMark ){ // last table, deepness reached 
								$aMarkedTables[$index][$subKursIndex] = $subKursIndex;
								continue;
							}
							
							if( !is_array($subKursRow['v_durchfuehrungen']) ) continue;
							foreach( $subKursRow['v_durchfuehrungen'] as $durchfIdx => $durchfRow ){
								
								if( isset($matchWords[ 'durchfuehrung' ]) ){
									$stop = 0;
									foreach($matchWords[ 'durchfuehrung' ] as $fld => $cnt ){
										if( $durchfRow[$fld] != $cnt ) ++$stop;
									}
									if($stop) continue;
								}
								if( 'durchfuehrung' == $tableToMark ){ // last table, deepness reached
									$aMarkedTables[$index][$subKursIndex][$durchfIdx] = $durchfIdx;
									continue;
								}
							
								if( !is_array($durchfRow['d_lektionen']) ) continue;
								foreach( $durchfRow['d_lektionen'] as $lektIdx => $lektRow ){
									
									if( isset($matchWords[ 'lektion' ]) ){
										$stop = 0;
										foreach($matchWords[ 'lektion' ] as $fld => $cnt ){
											if( $lektRow[$fld] != $cnt ) ++$stop;
										}
										if($stop) continue;
									}
									if( 'lektion' == $tableToMark ){ // last table, deepness reached
										$aMarkedTables[$index][$subKursIndex][$durchfIdx][$lektIdx] = $lektIdx;
										continue;
									}
									
								}
								
							}
				}
			
			}
			return $aMarkedTables ;
	}

    /**
     *  helper_trimCharsInString
     *  used by export_concatFormatValues()
     *
     * @param string $untrimmedString
     * @param string $trimchars
     * @return string
     */
	Protected function helper_trimCharsInString( $untrimmedString , $trimchars )
	{
			$aWords = explode( ' ' , $untrimmedString );
 			for( $p = 0; $p < strlen($trimchars); ++$p ){
				$trimChar = substr( $trimchars , $p , 1 );
				foreach($aWords as $ix => $word){ $aWords[$ix] = trim( $word , $trimChar ); }
			}
			return implode( ' ' , $aWords ) ;
	}

    /**
     *  helper_setTempTablenamesMapping
     *  used by export_getSortNrWhere()
     *  used by export_getNextRecordRenderDateFunction()
     *
     *  unfortunately the tables in db has different names than in xml affored
     *  tranlsate kategorie to k_kategorien and termin to d_lektionen and so on ...
     *  
     * @return string
     */
	Protected function helper_setTempTablenamesMapping()
	{
			// look for parent name of a node in config-setting eg. from termin 2 termine
			$singleMapToPlural = [];
			$mapFieldStructure = $this->settings['export']['mapFieldStructure']['kurse'];
			foreach( $mapFieldStructure as $sTabnam1 => $tabConf1 ){
					$singleMapToPlural[ $sTabnam1 ] = 'kurse';
					
					if( !isset($tabConf1['node']) ) continue;
					foreach( $tabConf1['node'] as $tabnam2 => $tabConf2 ){//$tabnam2 = kategorien / versionen
						if( !is_array($tabConf2) ) continue;
						foreach( $tabConf2 as $sTabnam3 => $tabConf3 ){
								$singleMapToPlural[ $sTabnam3 ] = $tabnam2; // $sTabnam3 kategorie or version
								$tablenameToParentTable[ $sTabnam3 ] = $sTabnam1;
								
								if( !isset($tabConf3['node']) ) continue;
								foreach( $tabConf3['node'] as $tabnam4 => $tabConf4 ){// $tabnam4 = durchfuehrungen
									if( !is_array($tabConf4) ) continue;
									foreach( $tabConf4 as $sTabnam5 => $tabConf5 ) {// $sTabnam5 = durchfuehrung
											$singleMapToPlural[ $sTabnam5 ] = $tabnam4;
											$tablenameToParentTable[ $sTabnam5 ] = $sTabnam3;
											
											if( !isset($tabConf5['node']) ) continue;
											foreach( $tabConf5['node'] as $tabnam6 => $tabConf6 ){//$tabnam6 = lektionen
												if( !is_array($tabConf6) ) continue;
													foreach( $tabConf6 as $sTabnam7 => $tabConf7 ) {// $sTabnam7 = lektion
														$singleMapToPlural[ $sTabnam7 ] = $tabnam6;
														$tablenameToParentTable[ $sTabnam7 ] = $sTabnam5;
													}
											}
									}
								}
								
						}
					}
					
			}
			$this->settings['temp']['pluralOfTablenames'] = $singleMapToPlural;
			$this->settings['temp']['tablenameToParentTable'] = $tablenameToParentTable;
	}

	
	// UTILITY DEFAULT-FUNCTIONS
	
    /**
     *  getStichtag
     *
     * @return string
     */
	Public function getStichtag()
	{
			if( empty( $this->englStichtag ) ) $this->englStichtag = date('Y-m-d');
			return $this->englStichtag;
	}
	
    /**
     *  setStichtag
     *
     * @param string $stichtag
     * @return void
     */
	Public function setStichtag( $stichtag  )
	{
			$this->englStichtag = $stichtag;
	}
	
}
