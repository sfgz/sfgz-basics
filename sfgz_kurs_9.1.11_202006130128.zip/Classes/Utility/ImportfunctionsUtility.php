<?php
namespace Sfgz\SfgzKurs\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/** 
 * Class ImportfunctionsUtility
 * 
 * 
 */
 
class ImportfunctionsUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$this->typoScriptService =  $objectManager->get('TYPO3\\CMS\\Extbase\\Service\\TypoScriptService');
	    
	    $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.'][  'tx_sfgzkurs_conf.' ]['settings.']);
		
	}

    /**
     *  aggregate_count
     *  aggregate-function count
     *
     * @param array $records 2-dim array
     * @param string $fieldNames unused sourceFieldNames. Not used in this method
     * @return string
     */
    public function aggregate_count( $records , $fieldNames = '' )
    {
			if( !is_array($records) ) return 0;
			return count( $records );
	}

    /**
     *  aggregate_max
     *  aggregate-function max
     *
     * @param array $records 2-dim array
     * @param string $fieldNames sourceFieldname
     * @return array
     */
    public function aggregate_max( $records , $fieldNames )
    {
 			if( !count($records) ) return;
 			
			$fieldName = GeneralUtility::underscoredToLowerCamelCase( trim( $fieldNames ) ) ;
			
			$fieldSampler = $this->helper_redimTableToOneColumn( $records , $fieldName );
			if( !count($fieldSampler) ) return;
			
			return max($fieldSampler);

	}

    /**
     *  aggregate_min
     *  aggregate-function min
     *
     * @param array $records 2-dim array
     * @param string $fieldNames sourceFieldname
     * @return array
     */
    public function aggregate_min( $records , $fieldNames )
    {
 			if( !count($records) ) return;
 			
			$fieldName = GeneralUtility::underscoredToLowerCamelCase( trim( $fieldNames ) ) ;
			
			$fieldSampler = $this->helper_redimTableToOneColumn( $records , $fieldName );
			if( !count($fieldSampler) ) return;
			
			return min($fieldSampler);
			
	}

    /**
     *  aggregate_maxAppear
     *  aggregate-function maxAppear
     *
     * @param array $records 2-dim array
     * @param string $fieldNames comma-separed list with 1) sourceField and 2..) sourceKeyFields: sourceKeyFieldA, sourceKeyFieldB...
     * @return string
     */
    public function aggregate_maxAppear( $records , $fieldNames )
    {
 			if( !count($records) ) return;
 			
			$aField_names = explode( ',' , $fieldNames );
			if( count($aField_names) < 1 ) return;

			$firstName = array_shift( $aField_names );
			$fieldNameMaxAppear = GeneralUtility::underscoredToLowerCamelCase( trim( $firstName ) );
 			$keyFields[$fieldNameMaxAppear] = '#' . $fieldNameMaxAppear . '#';

 			// if there are keys to map, they dont have to be registered to store
 			if( count($aField_names) ){
				foreach($aField_names as $keyFieldname ){
					$loopKeyField = GeneralUtility::underscoredToLowerCamelCase( trim( $keyFieldname ) );
					$keyFields[$loopKeyField] = '#' . $loopKeyField . '#';
				}
 			}
 			if( !count($keyFields) ) return;
 			
 			$indexTemplate = implode( '|' , $keyFields ) ;
 			
 			$oneDimTable = [];
			foreach( $records as $ix => $csvRs ) {
					$oneDimTable[$ix] = $indexTemplate;
					foreach( array_keys($keyFields) as $keyFieldName ){
						$oneDimTable[$ix] = str_replace( '#' . $keyFieldName . '#' , $csvRs[ $keyFieldName ] , $oneDimTable[$ix] );
					}
 			}
 			if( !count($oneDimTable) ) return;
 			
			$fieldSampler = $this->helper_countAppearanceInOneColumnTable( $oneDimTable );
			if( !count($fieldSampler) ) return;
			
			// $fieldSampler[ '08:15|11:40|Ay' ] = 5x;
			
			$maxVal = max($fieldSampler);
			$maxKeys = array_keys( $fieldSampler , $maxVal );
			$firstMaxAppearedFieldname = array_shift( $maxKeys );
			
			$aValues = explode( '|' , $firstMaxAppearedFieldname );

			return $aValues[0];
 			
	}

    /**
     *  aggregate_averageLessonsCount
     *  aggregate-function averageLessonsCount
     *
     * @param array $records 2-dim array
     * @param string $fieldNames comma-separed list with sourceFieldNames 'field_name_time_from, field_name_time_to'
     * @return int
     */
    public function aggregate_averageLessonsCount( $records , $fieldNames )
    {
 			if( !count($records) ) return;
 			
			$aField_names = explode( ',' , $fieldNames );
			if( count($aField_names) < 2 ) return;
			
			$fieldNameTimeFrom = GeneralUtility::underscoredToLowerCamelCase( trim( $aField_names[0] ) );
			
			$fieldNameTimeTo = GeneralUtility::underscoredToLowerCamelCase( trim( $aField_names[1] ) );
			
			$aListLessonsAmount = [];
			foreach( $records as $ix => $csvRs ) {
					$aListLessonsAmount[] = $this->helper_countLessons( $csvRs[$fieldNameTimeFrom] , $csvRs[$fieldNameTimeTo] );
			}
			$count = count($aListLessonsAmount);
			if( !$count ) return;
			
			$sum = array_sum($aListLessonsAmount);
			if( !$sum ) return;
			
			return round( $sum / $count ) ;

	}

    /**
     *  import_lessonsCount
     *  default-function lessonsCount
     *
     * @param string $options timeFrom, timeTo formatted as [ HH:MM,HH:MM ] white-space no matters
     * @return string
     */
    public function import_lessonsCount( $options = '08:00, 09:15'  )
    {
			if( empty($options) ) return 0;
			$options = trim( $options , '|' );
			$aTimeFromTo = explode( ',' , $options );
			return $this->helper_countLessons( trim($aTimeFromTo[0]) , trim($aTimeFromTo[1]) );
	}

    /**
     *  import_concat
     *
     * @param string $options text to return
     * @return string
     */
    public function import_concat( $options = '| value1 value2 |'  )
    {
			return trim( $options , '|' );
	}

    /**
     *  import_date
     *  default-function date
     *
     * @param string $options date-format as d.m.Y
     * @return string
     */
    public function import_date( $options = 'Y-m-d , -1'  )
    {
			$options = trim( $options , '|' );
			$aOptions = explode( ',' , $options );
			if( $aOptions[1] ) return date( trim($aOptions[0])  , time() + ( trim($aOptions[1]) * (3600*24) ) );
	}

    /**
     *  import_ucfirst
     *
     * @param string $options 
     * @return string
     */
    public function import_ucfirst( $options )
    {
			$options = trim( $options , '|' );
			return ucFirst( $options );
	}

    /**
     *  import_translate
     *
     * @param string $options 
     * @return string
     */
    public function import_translate( $options )
    {
			$options = trim( $options , '|' );
			return LocalizationUtility::translate( $options , 'SfgzKurs' );
	}

    /**
     *  import_translateToInteger
     *
     * @param string $options 
     * @return string
     */
    public function import_translateToInteger( $options  )
    {
			$options = trim( $options , '|' );
			$translated = $this->import_translate( $options );
			$intValue = empty($translated) ? '0' : $translated;
			return $intValue;
	}

    /**
     *  helper_redimTableToOneColumn
     *  helper for aggregate-functions 
     *  used in aggregate_min , aggregate_max , aggregate_maxAppear
     *
     * @param array $csvTable 2-dim array
     * @param string $fieldName name of the row that has to be returned
     * @return array
     */
    Private function helper_redimTableToOneColumn( $csvTable , $fieldName )
    {
			$fieldSampler = [];
			if( !count($csvTable) ) return $fieldSampler;
			
			foreach( $csvTable as $ix => $csvRs ) {
					$fieldSampler[$ix] = $csvRs[$fieldName];
			}
			return $fieldSampler;
	}

    /**
     *  helper helper_countLessons
     *
	 * @param string $strFromTime
     * @param string $strToTime
     * @return int
     */
    Private function helper_countLessons( $strFromTime , $strToTime )
    {
			if( empty($strFromTime) || empty($strToTime) ) return 0;
			$aTime_From = explode( ':' , $strFromTime );
			$aTime_To = explode( ':' , $strToTime );
			
			$iFrom = $aTime_From[0] * 60 + $aTime_From[1];
			$iTo = $aTime_To[0] * 60 + $aTime_To[1];
			
			$iDelta = $iTo - $iFrom;
			$iLesson = $this->settings['averageLessons']['lesson_minutes'] ; // eg 45
			$iPause =  $this->settings['averageLessons']['pause_minutes'] ; // eg 7.5 or 6.66 evenings
			$iTimespanWithoutLastLesson = $iDelta - $iLesson;
			$iFullLessionWithPause = $iLesson + $iPause;
			$lessonsCount = $iDelta <= $iFullLessionWithPause ? 1 : round( $iTimespanWithoutLastLesson / $iFullLessionWithPause  ) + 1 ;
			
			return $lessonsCount;
	}

    /**
     *  helper_countAppearanceInOneColumnTable
     *  helper for aggregate-functions 
     *  used in aggregate aggregate_averageLessonsCount , aggregate_maxAppear
     *
     * @param array $oneDimTable
     * @return array
     */
    Private function helper_countAppearanceInOneColumnTable( $oneDimTable )
    {
			$fieldSampler = [];
			if( !count($oneDimTable) ) return $fieldSampler;
			
			foreach( $oneDimTable as $ix => $csvFieldvalue ) {
					
					if( isset($fieldSampler[$csvFieldvalue]) ){
						++$fieldSampler[$csvFieldvalue];
					}else{
						$fieldSampler[$csvFieldvalue] = 1 ;
					}
				
			}
			return $fieldSampler;
	}
	
}
