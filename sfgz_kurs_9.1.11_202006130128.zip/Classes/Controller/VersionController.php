<?php
namespace Sfgz\SfgzKurs\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "Kursverwaltung" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Rueegg Daniel <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * VersionController
 */
class VersionController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    
    /**
     * propertiesToSkip
     *
     * @var array
     */
    protected $propertiesToSkip = null;

    /**
     * versionRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\VersionRepository
     * @inject
     */
    protected $versionRepository = null;
    
    /**
     * kursRepository
     *
     * @var \Sfgz\SfgzKurs\Domain\Repository\KursRepository
     * @inject
     */
    protected $kursRepository = null;

    /**
     * initialize
     *
     * @return void
     */
    public function initializeAction()
    {
		
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		
		$this->kursRepository = $objectManager->get('Sfgz\SfgzKurs\\Domain\\Repository\\KursRepository');
	    $this->kursRepository->setDefaultQuerySettings($querySettings);
		
		$this->kursausschreibungUtility = GeneralUtility::makeInstance('Sfgz\\SfgzKurs\\Utility\\KursausschreibungUtility');
		
    }

	
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $versions = $this->versionRepository->findAll();
        $this->view->assign('versions', $versions);
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {
			
		if( $this->request->hasArgument('kurs') ) {
			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
			$kursUid = $this->request->getArgument('kurs');
			$this->view->assign('kurs', $kursUid );
			
			$objKurs = $this->kursRepository->findByUid( $kursUid );
			$kursTitel = $objKurs->getTitel();
			$kursCode = $objKurs->getKursCode();
			$this->view->assign('kursCode', $kursCode );
			
			$dateObject = new \DateTime( date( 'Y-m-d H:i:s' ) );
			$dateObject->sub(new \DateInterval('P1D'));
			
			$newVersion = GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\Version');
			$newVersion->setVersionStart($dateObject);
			$newVersion->setKurs( $kursUid );
			$newVersion->setTitel( $kursTitel );
			$this->view->assign('newVersion', $newVersion );
			
		}
    }

    /**
     * initializeCreate
     *
     * @return void
     */
    public function initializeCreateAction()
    {
		if ($this->request->hasArgument('newVersion')) {
			$bel = $this->request->getArgument('newVersion');
			$arg = $this->arguments->getArgument('newVersion')->getPropertyMappingConfiguration();
			
			$arg->forProperty('versionStart')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			$arg->forProperty('versionEnde')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			$arg->forProperty('neuBis')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			
			if( empty($bel['versionStart']) ){
				$this->propertiesToSkip['versionStart'] = 1;
			    $arg->skipProperties('versionStart');
			}
			
			if( empty($bel['versionEnde']) ){
				$this->propertiesToSkip['versionEnde'] = 1;
			    $arg->skipProperties('versionEnde');
			}
			
			if( empty($bel['neuBis']) ){
				$this->propertiesToSkip['neuBis'] = 1;
			    $arg->skipProperties('neuBis');
			}
			
		}
    }

    /**
     * helper sanitizeDateFields
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Version $version
     * @return void
     */
    public function sanitizeDateFields(\Sfgz\SfgzKurs\Domain\Model\Version $version)
    {
			if( !isset($this->propertiesToSkip['versionStart']) ){
				$dateStart = $version->getVersionStart();
				$version->setVersionStart( $dateStart->format('Y-m-d') . ' 12:00:00'  );
			}
			if( !isset($this->propertiesToSkip['versionEnde']) ){
				$dateEnde = $version->getVersionEnde();
				$version->setVersionEnde( $dateEnde->format('Y-m-d') . ' 12:00:00'  );
			}
			if( !isset($this->propertiesToSkip['neuBis']) ){
				$dateNeuBis = $version->getNeuBis();
				$version->setNeuBis( $dateNeuBis->format('Y-m-d') . ' 12:00:00'  );
			}
			if( !count($this->propertiesToSkip) ){
				return $version;
			}
			foreach( $this->propertiesToSkip as $key => $value ) {
				if( empty($value) ) continue;
				$setter = 'set' . ucfirst($key) ;
				$version->$setter( NULL );
			}
			return $version;
    }

    /**
     * action create
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Version $newVersion
     * @return void
     */
    public function createAction(\Sfgz\SfgzKurs\Domain\Model\Version $newVersion)
    {
        if( $this->request->hasArgument('abort') ) {
			$iKursUid = $newVersion->getKurs();
			if( $iKursUid ) $this->redirect('edit', 'Kurs', NULL, array('kurs' => $iKursUid ));
			$this->redirect('list', 'Kurs' , NULL);
        }
        $this->addFlashMessage('Die Version wurde erstellt', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $newVersion = $this->sanitizeDateFields($newVersion);
        $this->versionRepository->add($newVersion);
        $this->persistenceManager->persistAll();
        $this->redirect('edit' , NULL , NULL , [ 'version' => $newVersion] );
    }

    /**
     * action edit
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Version $version
     * @ignorevalidation $version
     * @return void
     */
    public function editAction(\Sfgz\SfgzKurs\Domain\Model\Version $version)
    {
        if( $this->request->hasArgument('dupliz') ) {
			$vUid = $this->duplicateVersion( $version );
// 			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
			$this->redirect('edit', NULL, NULL, ['version'=>$vUid] );
		}
		
		if( $this->request->hasArgument('kursausschreibung') ){
			$outputDocument = $this->kursausschreibungUtility->AusschreibungVorlage( $version );
		}
		
		$aCont['textLead'] = $version->getTextLead();
		$aCont['ziel'] = $version->getZiel();
		$aCont['zielgruppe'] = $version->getZielgruppe();
		$aCont['voraussetzungen'] = $version->getVoraussetzungen();
		$aCont['inhalt'] = $version->getInhalt();
		$aCont['kursunterlagen'] = $version->getKursunterlagen();
		$aCont['methode'] = $version->getMethode();
		$aCont['hinweis'] = $version->getHinweis();
		$aCont['weitereInfos'] = $version->getWeitereInfos();
		
		foreach( $aCont as $fieldname => $content ){
            $len = strlen( $content );
            $zeilenzahl = ceil( ( $len / 77.1666666 )  );
            $contentinfo[$fieldname] = [
                'class'  => $content ? 'filled':'',  
                'size'   =>  $zeilenzahl ? $zeilenzahl . '' : '0' ,
                'title'  => $len ? 'Enthält etwa ' . $zeilenzahl . ' ' . ( $zeilenzahl != 1 ? 'Zeilen':'Zeile') . '. (' . $len . ' Zeichen)': 'Leer',
            ];
		}
		
		$this->view->assign('contentinfo', $contentinfo );
		
		$this->view->assign('version', $version);
        
        // set select-options to change relation to parent recordset
        $objKurse = $this->kursRepository->findAll();
        $this->view->assign('kurse', $objKurse);
    }

    /**
     * initializeUpdate
     *
     * @return void
     */
    public function initializeUpdateAction()
    {
		if ($this->request->hasArgument('version')) {
			$bel = $this->request->getArgument('version');
			$arg = $this->arguments->getArgument('version')->getPropertyMappingConfiguration();
			
			if( empty($bel['versionStart']) ){
				$this->propertiesToSkip['versionStart'] = 1;
				$arg->skipProperties('versionStart');
			}else{
				$arg->forProperty('versionStart')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			
			if( empty($bel['versionEnde']) ){
				$this->propertiesToSkip['versionEnde'] = 1;
				$arg->skipProperties('versionEnde');
			}else{
				$arg->forProperty('versionEnde')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			
			if( empty($bel['neuBis']) ){
				$this->propertiesToSkip['neuBis'] = 1;
				$arg->skipProperties('neuBis');
			}else{
				$arg->forProperty('neuBis')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
			
		}
    }

    /**
     * action update
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Version $version
     * @return void
     */
    public function updateAction(\Sfgz\SfgzKurs\Domain\Model\Version $version)
    {
        if( $this->request->hasArgument('abort') ) {
			$iKursUid = $version->getKurs();
			if( $iKursUid ) $this->redirect('edit', 'Kurs', NULL, array('kurs' => $iKursUid ));
			$this->redirect('list', NULL, NULL);
        }
         $this->addFlashMessage('Die Version wurde gespeichert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $version = $this->sanitizeDateFields($version);
        $this->versionRepository->update($version);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        $this->redirect('edit', NULL, NULL, array('version' => $version ));
    }
	
    /**
     * action delete
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Version $version
     * @return void
     */
    public function deleteAction(\Sfgz\SfgzKurs\Domain\Model\Version $version)
    {
        $this->addFlashMessage('Die Version wurde entfernt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->versionRepository->remove($version);
        $this->redirect('list');
    }

    /**
     * helper duplicateVersion
     *
     * @param \Sfgz\SfgzKurs\Domain\Model\Version $version
     * @return int
     */
    public function duplicateVersion(\Sfgz\SfgzKurs\Domain\Model\Version $version)
    {
 		  $newVersion = GeneralUtility::makeInstance('Sfgz\SfgzKurs\Domain\Model\Version');
		  $properties = $version->_getProperties() ;
		  unset($properties['uid']) ;
		  foreach ($properties as $key => $value ) $newVersion->_setProperty( $key , $value );
		  $this->versionRepository->add( $newVersion );
		  $this->persistenceManager->persistAll();
		  $newUid = $newVersion->getUid();
		  return $newUid;
    }
}
