## <INCLUDE_TYPOSCRIPT: source="FILE:EXT:sfgz_kurs/Configuration/TypoScript/lib.clock.ts">

plugin.tx_sfgzkurs_vw {
    view {
        templateRootPaths.0 = EXT:sfgz_kurs/Resources/Private/Templates/
        templateRootPaths.1 = {$plugin.tx_sfgzkurs_vw.view.templateRootPath}
        partialRootPaths.0 = EXT:sfgz_kurs/Resources/Private/Partials/
        partialRootPaths.1 = {$plugin.tx_sfgzkurs_vw.view.partialRootPath}
        layoutRootPaths.0 = EXT:sfgz_kurs/Resources/Private/Layouts/
        layoutRootPaths.1 = {$plugin.tx_sfgzkurs_vw.view.layoutRootPath}
    }
    persistence {
        storagePid = {$plugin.tx_sfgzkurs_vw.persistence.storagePid}
        #recursive = 1
    }
    features {
        requireCHashArgumentForActionArguments = 0
    }
    settings {
            
            kategoriegruppen = {$plugin.tx_sfgzkurs_vw.settings.kategoriegruppen}
            
            remote_url = {$plugin.tx_sfgzkurs_vw.settings.remote_url}
            pageUid {
                konfiguration = {$plugin.tx_sfgzkurs_vw.settings.konfiguration}
                storagePid = {$plugin.tx_sfgzkurs_vw.persistence.storagePid}
            }
                
            averageLessons {
                lesson_minutes = 45
                pause_minutes = 7.1
            }

            csv_options {
                enclosure = "
                delimiter = ;
                delimiter_key = semicolon
                charset = ISO-8859-15
            }
            
            ftp {
                username = {$plugin.tx_sfgzkurs_vw.settings.username}
                password = {$plugin.tx_sfgzkurs_vw.settings.password}
                url = {$plugin.tx_sfgzkurs_vw.settings.url}
            }
            
            mail {
                backuptext {
                    Subject = Backup Kursplanung ##DATE##
                    Body = Backup der Kursplanung auf SfGZ. <br>Ein Dienst von <a href='https://##URL##'>##URL##</a> | ##DATETIME##
                    Footer = <p>Diese Nachricht wurde automatisch generiert. Emailadressen werden im Backend des Typo3 CMS im Modul Planer (Scheduler) eingetragen.</p>
                }
                fallbackMailFrom = daten@sfgz.ch
                imagePath = /typo3conf/ext/sfgz_kurs/Resources/Public/logo/logo.svg
                uploadPath = /uploads/tx_sfgzkurs/temp/backup/
            }
            
            filePaths {
                subfolder = /uploads/tx_sfgzkurs/
                selection_filename = importSelection.json
                exportfolder = public
                temp = temp
                kurseingabe = docx
            }

            sourceFiles {
                course {
                    fileName = WB_Kurse
                    detectByField = Angebot_Beginn
                    rebuildIndex = kurs.kursCode, durchfuehrung.durchfuehrungsCode, durchfuehrung.codeSuffix
                }
                timetable {
                    fileName = WB_Lektionen
                    detectByField = Datum
                }
                calendar {
                    fileName = WB_Ferien
                    detectByField = Beschreibung
                    autoimport = 1
                }
            }

            afforedRecordsets {
                # description 
                #		fieldname = noCheckbox [ (0) | 1 ]
                #		fieldvalue = defaultAction [ 0 | 1 | 2 | 3 ]
                #		fieldvalue if(option1=lektion) = [ 0 | 5 | 6 | 7 ]
                #		option1 = tableName
                #		option2 = confType [ (0):field | 1:table ]
                # 
                config {
                    kurs {
                        fieldname = 0
                        fieldvalue = 2
                        option1 = 0
                        option2 = 1
                    }
                    version {
                        fieldname = 1
                        fieldvalue = 0
                        option1 = 1
                        option2 = 1
                    }
                    durchfuehrung {
                        fieldname = 0
                        fieldvalue = 2
                        option1 = 2
                        option2 = 1
                    }
                    lektion {
                        fieldname = 1
                        fieldvalue = 7
                        option1 = 3
                        option2 = 1
                    }
                    orphan {
                        fieldname = 0
                        fieldvalue = 2
                        option1 = 4
                        option2 = 1
                    }
                }
            }
            
            kurseingabe {
                    output_document_name {
                        pattern = kurseingabe_%1.docx
                        source.1 = kurs.kurs_code
                    }
            }
            # set to 0 to display all at any time
            infodisplay_hideLessonsAfterMinutes = {$plugin.tx_sfgzkurs_vw.settings.infodisplay_hideLessonsAfterMinutes}
            infodisplay_hideStatus_list = 2
            
            searchCaseSensitive = 0
            searchFields {
                kurs {
                    titel = 1
                    kurs_code = 1
                    stufe_wb = 1
                }
                version {
                    titel = 1
                    sub_titel = 1
                    kurs_bezeichnung_lang = 1
                    voraussetzungen = 1
                    text_lead = 1
                    ziel = 1
                    zielgruppe = 1
                    inhalt = 1
                    kursunterlagen = 1
                    methode = 1
                    hinweis = 1
                    weitere_infos = 1
                }
                # not implemented yet
                durchfuehrung {
                    lehrperson_nachname = 0
                    lehrperson_vorname = 0
                }
            }

            memberlist {
                
                start_body = 70
                logo_filepathname = typo3conf/ext/sfgz_kurs/Resources/Public/templates/logo.png
                signature_linebreaks = 3
                
                headerText_language_key = pdf_headtext.
                
                language_keys {
                    titel_bestaetigung = label.kurs.bestaetigung
                    titel_inhalte = label.kurs.inhalte
                    titel_leitung = label.kurs.leitung
                    titel_dauer = label.kurs.dauer
                    kopierrecht = label.kurs.copyright
                }
                
                file_source {
                    name = KT_Name
                    vorname = KT_Vorname
                }
                
                database_source {
                    titel.source = version.titel
                    kursleitung_vorname.source = durchfuehrung.lehrperson_vorname
                    kursleitung_nachname.source = durchfuehrung.lehrperson_nachname
                    kursinhalte.source = version.inhalt
                    datum_start {
                        source = durchfuehrung.termin_start
                        dateformat = d.m.
                    }
                    datum_ende {
                        source = durchfuehrung.termin_ende
                        dateformat = d.m.Y
                    }
                    anzahl_veranstaltungen.source = durchfuehrung.veranstaltungen
                    anzahl_lektionen.source = durchfuehrung.lektionen
                    anmerkung.source = durchfuehrung.anmerkung
                }
            }
            
                
            aggregateFunction {
                orphan {
                    parentTable = durchfuehrung
                    childTable = lektion
                    calcFields {
                            termin_start {
                                function = min
                                parameterFields = lektion_datum
                            }
                            termin_ende {
                                function = max
                                parameterFields = lektion_datum
                            }
                            veranstaltungen {
                                function = count
                            }
                            zeit_von {
                                function = maxAppear
                                parameterFields = zeit_von, zeit_bis, lehrer_eco_id
                            }
                            zeit_bis {
                                function = maxAppear
                                parameterFields = zeit_bis, zeit_von, lehrer_eco_id
                            }
                            lektionen {
                                function = averageLessonsCount
                                parameterFields = zeit_von, zeit_bis
                            }
                            zimmer {
                                function = maxAppear
                                parameterFields = zimmer
                            }
                            ort {
                                function = maxAppear
                                parameterFields = ort
                            }
                            lehrer_eco_id {
                                function = maxAppear
                                parameterFields = lehrer_eco_id
                            }
                            lehrperson_text {
                                function = maxAppear
                                parameterFields = lehrperson_text
                            }
                            lehrperson_vorname {
                                function = maxAppear
                                parameterFields = lehrer_vorname
                            }
                            lehrperson_nachname {
                                function = maxAppear
                                parameterFields = lehrer_name
                            }
                    }
                }
            }
            
            tables {
            
                    kurs {
                        sourceFile = course
                        alwaysCheckNew = 1
                        mapFields {
                                kurs_code {
                                        source = Kurs_Code
                                }
                                titel {
                                        source = Kurs_Titel
                                }
                                stufe_wb {
                                        source = Text_Anspruchsniveau
                                }
                        }
                    }
                    
                    version {
                        sourceFile = course
                        alwaysCheckNew = 1
                        mapFields {
                                titel {
                                        source = Kurs_Titel
                                }
                                # sub_titel {
                                #		source = Kurs_Beschreibung
                                # }
                                kurs_bezeichnung_lang {
                                        source = Kurs_Bezeichnung_lang
                                }
                                weitere_infos {
                                        source = Text_Kursbeschreibung
                                }
                                ziel {
                                        source = Text_Ziel
                                }
                                inhalt {
                                        source = Text_Inhalt_Schwerpunkte
                                }
                                hinweis {
                                        source = Text_Hinweis_Bemerkungen
                                }
                                zertifikat {
                                        source = Text_Abschluss
                                }
                                voraussetzungen {
                                        source = Text_Voraussetzungen
                                }
                                kursunterlagen {
                                        source = Text_Unterlagen
                                }
                                zielgruppe {
                                        source = Text_Zielgruppe
                                }
                                methode {
                                        source = Text_Arbeitsweise
                                }
                                version_start {
                                        fieldType = date
                                        postImportFunction {
                                            function = date
                                            # parameters = Y-m-d , -1
                                            parameters = Y-m-d 
                                        }
                                }
                                kosten_material {
                                        source = Text_Kurskosten_Lernende
                                        fieldType = decimal
                                }
                            }
                    }
                    
                    durchfuehrung {
                        sourceFile = course
                        alwaysCheckNew = 1
                        mapFields {
                                durchfuehrungs_code {
                                        source = Kurs_Periode_Kurzzeichen
                                }
                                code_suffix {
                                        source = Zusatz1
                                }
                                status {
                                        source = Kursstatus_Code
                                        postImportFunction {
                                            function = translateToInteger
                                            parameterFields = status
                                            parameters = import_action.translate.status.%1
                                            override = 2
                                            # override makes only sense if field has defined source, otherwise its empty anyway
                                            # 0:override if target is not emty
                                            # 1:override if function returns result
                                            # 2:override even if result is empty (clear field)
                                        }
                                }
                                eco_fachid {
                                        source = Fach_Id
                                }
                                eco_mandant {
                                        source = Mandant_Id
                                }
                                eco_angebotid {
                                        source = Angebot_Id
                                }
                                maxteilnehmer {
                                        source = Max_Teilnehmer
                                }
                                kurskosten {
                                        source = Kurskosten
                                        fieldType = decimal
                                }
                                kosten_lernende {
                                        source = Kurskosten_Lernende
                                        fieldType = decimal
                                }
                                kosten_extern {
                                        source = Kurskosten_AK_Kurse
                                        fieldType = decimal
                                }
                                anmeldeschluss {
                                        source = Anmeldeschluss
                                        fieldType = date
                                }
                                publikation_start {
                                        source = Publikation_Beginn
                                        fieldType = date
                                }
                                publikation_ende {
                                        source = Publikation_Ende
                                        fieldType = date
                                }
                                anmerkung {
                                        source = Text_Daten
                                }
                                termin_start {
                                        source = Angebot_Beginn
                                        fieldType = date
                                }
                                termin_ende {
                                        source = Angebot_Ende
                                        fieldType = date
                                }
                                veranstaltungen {
                                        source = Anzahl_Veranstaltungen
                                }
                                periodika {
                                        fieldType = int
                                        postImportFunction {
                                            function = concat
                                            parameters = 1
                                        }
                                }
                                zeit_von {
                                        source = Zeit_von
                                        fieldType = timestring
                                }
                                zeit_bis {
                                        source = Zeit_bis
                                        fieldType = timestring
                                }
                                lektionen {
                                        source = Anzahl Wochenlektionen
                                        fieldType = decimal
                                }
                                zimmer {
                                        source = Zimmer
                                        postImportFunction {
                                            function = ucfirst
                                            parameterFields = zimmer
                                            parameters = |%1|
                                        }
                                }
                                ort {
                                        source = Gebaeude
                                }
                                lehrer_eco_id {
                                        source = Lehrer_Code
                                }
                                lehrperson_nachname {
                                        source = Lehrer_Name
                                }
                                lehrperson_vorname {
                                        source = Lehrer_Vorname
                                }
                                lehrperson_text {
                                        postImportFunction {
                                            function = concat
                                            parameterFields = lehrperson_vorname, lehrperson_nachname
                                            parameters = |%1 %2|
                                            override = 1
                                        }
                                }
                        }
                    }
                    
                    lektion {
                        sourceFile = timetable
                        alwaysCheckNew = 1
                        mapTable {
                            parentTable = durchfuehrung
                            parentJoinField = eco_fachid
                            childJoinField = fachid
                        }
                        mapFields {
                                fachid {
                                        source = fach_id
                                        temporary = 1
                                }
                                lektion_datum {
                                        source = Datum
                                        fieldType = date
                                }
                                lehrer_eco_id {
                                        source = Lehrer_Code
                                }
                                lehrer_name {
                                        source = Lehrer_Name
                                        temporary = 1
                                }
                                lehrer_vorname {
                                        source = Lehrer_Vorname
                                        temporary = 1
                                }
                                lehrperson_text {
                                        postImportFunction {
                                            function = concat
                                            parameterFields = lehrer_vorname, lehrer_name
                                            parameters = |%1 %2|
                                            override = 1
                                        }
                                }
                                zeit_von {
                                        source = Zeit_von
                                        fieldType = timestring
                                }
                                zeit_bis {
                                        source = Zeit_bis
                                        fieldType = timestring
                                }
                                zimmer {
                                        source = Zimmer
                                        postImportFunction {
                                            function = ucfirst
                                            parameterFields = zimmer
                                            parameters = |%1|
                                        }
                                }
                                ort {
                                        source = Gebaeude
                                }
                                lektionenzahl {
                                        postImportFunction {
                                            function = lessonsCount
                                            parameterFields = zeit_von, zeit_bis
                                            parameters = |%1,%2|
                                            override = 1
                                        }
                                        onUpdateFunction {
                                            function = lessonsCount
                                            parameterFields = zeit_von, zeit_bis
                                            parameters = |%1,%2|
                                            override = 0
                                        }
                                }
                        }
                    }
                
                    calendar {
                        sourceFile = calendar
                        mapFields {
                            sort_date {
                                fieldType = datetime
                                source = Datum
                            }
                            zeit_von {
                                source = Zeit_von
                            }
                            zeit_bis {
                                source = Zeit_bis
                            }
                            beschreibung {
                                source = Beschreibung
                            }
                            typ {
                                source = Typ
                            }
                        }
                    }

            }
            
            export {
                
                rteLinksPrefixNumericUrls = #REP_URL#
                file_datepattern = %Y%m%d
                
                tags{
                    xml {
                        open_starttag = <
                        open_endtag = </
                        close_tag = >
                        tab_space = 2
                        line_end = n
                    }
                    html {
                        open_starttag = <
                        open_endtag = </
                        close_tag = >
                        tab_space = 1
                        line_end = n
                    }
                }
                xmlDocuHeader = <?xml version="1.0" encoding="utf-8"?>
                # possible placeholders: _DATE_DOKU_ / _DATE_DOKUNAME_ / _DATE_NOW_
                xmlDocuDef.start = <document latest-change="_DATE_NOW_" document-created="_DATE_DOKU_">
                xmlDocuDef.end = </document>
                
                debugNodeSuffix {
                    # tablename = xmlFieldname
                    kurs = kurs-code
                    version = start
                    durchfuehrung = code
                }
                
                keepOldExportFiles = 2
                
                optionListsLanguageKeys {
                    EKursStatus = tx_sfgzkurs_domain_model_durchfuehrung.statusse.sel.%n
                    ETerminPeriodika = tx_sfgzkurs_domain_model_durchfuehrung.periodika.sel.%n
                }
                
                recordRestrictions {
                    keepEmpyFields = 0
                    keepEmpySubrecords = 0
                    tablesSelectWhere {
                        # displays row if condition is true OR if none set. Usage: 
                        # xmlTablename = table1.sql_field1 != function.getStichtag
                        # operators [ != , <= , >= , == , > , < , NOT , IS ]
                        # keywords: NULL (instead of table.field or function..)

                        # do not keep empty kurse
                        kurs = kurs.aktuell != EMPTY
                        
                        # only display actual version
                        version = kurs.aktuell == version.uid 
                        
                        # hide overdue records in durchfuehrung
                        durchfuehrung = durchfuehrung.publikation_ende >= functions.getStichtag |+1 day|
                    }
                }
                
                fieldRestrictions {
                    # disable field if termin_ausblenden != 0 
                    # durchfuehrung.termin_ausblenden.ende = 0
                    # durchfuehrung.termin_ausblenden.lektionen = 0
                    # durchfuehrung.termin_ausblenden.veranstaltungen = 0
                    # durchfuehrung.termin_ausblenden.zeit-von = 0
                    # durchfuehrung.termin_ausblenden.zeit-bis = 0
                }
                
                recordSortOrder {
                    # xmlTableInPlural = field order, sql_field2, sql_field3, ...
                    # order [ASC|DESC] default is ASC
                    kurse = titel, kurs_code
                    versionen = version_start
                    durchfuehrungen = durchfuehrungs_code,code_suffix ASC
                    # termine = lektion_datum
                }

                mapXmlToDbTablenames {
                    kategorien = k_kategorien
                    versionen = k_versionen
                    durchfuehrungen = v_durchfuehrungen
                    termine = d_lektionen
                    termin = lektion
                }
                
                mapDataTypes {
                    # function-name to db-type
                    functionsFieldtype {
                        getNextRecordRenderDateFunction = date
                        getSortNrWhere = int
                        concatFormatValues = varchar
                    }
                    # db-type to xml-type
                    fieldtypes {
                        tinyint.datatyp = Boolean
                        date.datatyp = DateTime
                        int.datatyp = Int32
                        int_uid.datatyp = Guid
                        decimal.datatyp = Single
                        timestring {
                            datatyp = String
                            format  = text
                            max-len = 5
                        }
                        varchar {
                            datatyp = String
                            format  = text
                            max-len = 255
                        }
                        text {
                            datatyp = String
                            format  = html
                            max-len = 2147483647
                            renderFunct = renderHtmlContent
                        }
                    }
                }
                
                mapFieldStructure {
                    # keywords: 
                    # functions, EMPTY,
                    # node (contains fieldnames that contains dbFieldnames as values)
                    # data (contains dbFieldnames as value. Used when a element contains data and attributes)
                    # attr (contains a attribute that contains dbFieldnames as value)
                    # In PHP we add temporarly attr.aktuell and attr.nodename
                    # Do not include this attributes in the xml!
                    # 
                    metadaten {
                        enumeratoren {
                            typ.attr.name = typ.name
                            typ.node {
                                element.attr.wert = element.wert
                                element.data = element.data
                            }
                        }
                        komplexe-typen {
                            typ.attr.name = typ.name
                            typ.node {
                                feld.attr.name = feld.name
                                feld.node {
                                    datatyp = feld.datatyp
                                    format = feld.format
                                    max-len = feld.max-len
                                    beschreibung = feld.beschreibung
                                }
                            }
                        }
                    }
                    kategorien {
                        kategorie.attr.id = kategorie.id
                        kategorie.attr.name = functions.translateFieldValue | kategorie.id | tx_sfgzkurs_domain_model_kategorie.kategoriegruppe.sel.%1 |
                        kategorie.node {
                            kategorie.attr.id = kategorie.id
                            kategorie.attr.reihenfolge = kategorie.reihenfolge
                            kategorie.attr.parent-id = kategorie.parent-id
                            kategorie.data = kategorie.data
                        }
                    }
                    kurse {
                        kurs.attr.id = kurs.uid
                        kurs.attr.rubrik-id = EMPTY
                        kurs.node {
                            reihenfolge = functions.getSortNrWhere |kurs.pid|kurs|
                            titel = kurs.titel
                            kurs-code = kurs.kurs_code
                            stufe-wb = kurs.stufe_wb
                            kategorien {
                                kategorie.attr.id = kategorie.uid
                                kategorie.attr.reihenfolge = kategorie.reihenfolge
                                kategorie.attr.parent-id = kurs.uid
                                kategorie.data = kategorie.kategorie_name
                            }
                            versionen {
                                version.attr.id = version.uid
                                version.attr.nummer = functions.getSortNrWhere |kurs.kurs_code|version|
                                version.node {
                                    titel = version.titel
                                    sub-titel = version.sub_titel
                                    neu = functions.isNewGetScript | version.neu_bis | TRUE | FALSE 
                                    start = version.version_start
                                    ende = functions.getNextRecordRenderDateFunction | version.version_start | -1 day|30|
                                    lead = version.text_lead
                                    text1 = EMPTY
                                    label1 = EMPTY
                                    text2 = EMPTY
                                    label2 = EMPTY
                                    zielgruppe = version.zielgruppe
                                    ziel = version.ziel
                                    inhalt = version.inhalt
                                    voraussetzungen = version.voraussetzungen
                                    beratung = EMPTY
                                    hinweis = version.hinweis
                                    weitere-infos = version.weitere_infos
                                    kursunterlagen = version.kursunterlagen
                                    selbstlernzeit = EMPTY
                                    methode = version.methode
                                    zertifikat = version.zertifikat
                                    meta-titel = EMPTY
                                    meta-keywords = EMPTY
                                    meta-description = EMPTY
                                    durchfuehrungen {
                                        durchfuehrung.attr.id = durchfuehrung.uid
                                        durchfuehrung.node {
                                            code = functions.concatFormatValues |kurs.kurs_code, durchfuehrung.code_suffix, durchfuehrung.durchfuehrungs_code|%1, %2,-%3|,|
                                            durchfuehrungs-code = durchfuehrung.durchfuehrungs_code
                                            publikation-start = durchfuehrung.publikation_start
                                            publikation-ende = durchfuehrung.publikation_ende
                                            start = durchfuehrung.termin_start
                                            ende = durchfuehrung.termin_ende
                                            anmerkung = durchfuehrung.anmerkung
                                            termin-ausblenden = functions.sanitizeBoolean | durchfuehrung.termin_ausblenden
                                            kosten = durchfuehrung.kurskosten
                                            kosten-text = EMPTY
                                            kosten-lernende = durchfuehrung.kosten_lernende
                                            kosten-extern = durchfuehrung.kosten_extern
                                            status = durchfuehrung.status
                                            lektionen = functions.calculate | durchfuehrung.lektionen, durchfuehrung.veranstaltungen | %1 * %2
                                            maxteilnehmer = durchfuehrung.maxteilnehmer
                                            anmeldeschluss = durchfuehrung.anmeldeschluss
                                            reihenfolge = functions.getSortNrWhere |kurs.kurs_code, version.uid|durchfuehrung|
                                            eco_mandant = durchfuehrung.eco_mandant
                                            eco_angebot_id = durchfuehrung.eco_angebotid
                                            eco_fach_id = durchfuehrung.eco_fachid
                                            veranstaltungen = durchfuehrung.veranstaltungen
                                            periodika = durchfuehrung.periodika
                                            zeit-von = durchfuehrung.zeit_von
                                            zeit-bis = durchfuehrung.zeit_bis
                                            ort = durchfuehrung.ort
                                            zimmer = durchfuehrung.zimmer
                                            lehrer-per-id = durchfuehrung.lehrer_eco_id
                                            lehrperson-name = EMPTY
                                            lehrperson-text = functions.concatFormatValues |durchfuehrung.lehrperson_vorname, durchfuehrung.lehrperson_nachname|%1 %2
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
    }
}

plugin.tx_sfgzkurs_lst < plugin.tx_sfgzkurs_vw

plugin.tx_sfgzkurs_inf < plugin.tx_sfgzkurs_vw

plugin.tx_sfgzkurs_conf < plugin.tx_sfgzkurs_vw
plugin.tx_sfgzkurs_conf.persistence.storagePid = {$plugin.tx_sfgzkurs_conf.persistence.storagePid}


# js for tx_sfgzkurs_conf
# editConfigUrl
config.removeDefaultJS = external
page.jsInline.11 = TEXT
page.jsInline.11 {
	value (
		
		// extension sfgzkurs_conf: editConfigUrl
		function editConfigUrl( action ) {
		
	)
}
page.jsInline.12 = TEXT
page.jsInline.12 {
	insertData = 1
	typolink.parameter.data = TSFE:id
	typolink.additionalParams=&type=1529269797&tx_sfgzkurs_conf[controller]=Json
	typolink.noCacheHash = 1
	typolink.forceAbsoluteUrl = 1
	typolink.returnLast = url
	noTrimWrap (
		|	return '|' + '&tx_sfgzkurs_conf[action]=' + action;
		}
		|
	)
}

page.includeJS.jquery_shiftcheckbox = typo3conf/ext/sfgz_fetools/Resources/Public/Scr/gistfile1.js
page.includeJS.kursverwaltung_js = typo3conf/ext/sfgz_kurs/Resources/Public/script/kursverwaltung.js
page.includeJS.kurs_config_js = typo3conf/ext/sfgz_kurs/Resources/Public/script/kurs_config.js

# config for tx_sfgzkurs_conf
# update config
json_edconf = PAGE
json_edconf {
  config {
    disableAllHeaderCode = 1
    debug = 0
    no_cache = 1
    additionalHeaders {
      10 {
        header = Content-Type: application/json
        replace = 1
      }
    }
  }
  typeNum = 1529269797
  10 < tt_content.list.20.sfgzkurs_conf
}

[globalVar = GP:type=1529269797]
    tt_content.list.20.stdWrap.prefixComment = 
    tt_content.stdWrap.prefixComment =
    tt_content.stdWrap.innerWrap.cObject.default = 
    lib.stdheader >
[global]

# config for sfgzkurs_lst
# update stichtag 
# the pageType 1583418974 (formerly 1527806882) appears in 
# Templates/Kurs/List.html,  
# Partials/Kurs/Stichtag.html, 
# Partials/Kurs/Optionen.html,
json_update < json_edconf
json_update {
  typeNum = 1583418974
  10 < tt_content.list.20.sfgzkurs_lst
}

# config for tx_sfgzkurs_vw
# view export-xml in a div (in-box view)
xmlPage = PAGE
xmlPage {
	config {
		disableAllHeaderCode = 1
		disableCharsetHeader = 1
		no_cache = 1
		doctype = xhtml_strict
		
		#XHTML cleaning:
		xhtml_cleaning = all

		removeDefaultJS = 1

		# move css in an external file:
		inlineStyle2TempFile = 1
		# disable some of the comments:
		disablePrefixComment = 1

		# UTF8 Output:
		metaCharset = utf-8
		additionalHeaders = Content-Type:application/xml

		# Additional Parameter in the <a>-Tag
		ATagParams =
	}
	typeNum = 90
	15 = USER
	15 {
		userFunc = TYPO3\CMS\Extbase\Core\Bootstrap->run
		extensionName = SfgzKurs
		pluginName = Vw
		vendorName = Sfgz
		controller = Kurs
		action = export
		format = XML
		switchableControllerActions {
			Kurs {
				1 = export
			}
		}
		view < plugin.tx_sfgzkurs_vw.view
		persistence < plugin.tx_sfgzkurs_vw.persistence
		settings < plugin.tx_sfgzkurs_vw.settings
	}
}

[globalVar = GP:type=90]
    config.noPageTitle = 1
[global]

page.includeCSS.kursverwaltung_css = typo3conf/ext/sfgz_kurs/Resources/Public/css/sfgz_kursverwaltung.css

plugin.tx_sfgzkurs._CSS_DEFAULT_STYLE (
/* tx_sfgzkurs flow error handling */
    
    textarea.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    input.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    .typo3-messages .message-error {
        color:red;
    }

    .typo3-messages .message-ok {
        color:green;
    }
    
)
