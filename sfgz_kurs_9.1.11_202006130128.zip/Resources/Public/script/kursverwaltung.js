        
        // extension sfgz_kurs: Kurs->editKategorien  handle groups of checkboxes to display data from a multiselect input field.
        function scrollToAnchor(aid){
            var aTag = $('#'+ aid );
            $('html,body').animate({
                scrollTop: aTag.offset().top
            },'slow');
        }
        
        function checkgroupClick( selectorid , optionvalue ) {
            var is_checked = $('#chk_' + optionvalue ).prop('checked' );
            $('#' + selectorid + ' option[value=' + optionvalue + ']').prop('selected',is_checked);
        }
        function isSelected( selectorid , optionvalue ) {
            if($('#' + selectorid + ' option[value=' + optionvalue + ']').prop('selected')){
                return 1;
            }else{
                return 0;
            }
        }
        
        // extension sfgz_kurs: handle register-tabs. events for REGISTERS
        // display tab when click or simulate-click on register-tab 
        // registermap_id = #hauptregister
        function registerTabChange( tab , registermap_id ) {
            // contents: remove all div with class register_inhalt, then add specific by id
            $( '#' + registermap_id + ' div.register_inhalt').hide();
            
            $( '#' + tab ).show();
            // contents: add child elements  with own form-wrap
            $( '#' + registermap_id + ' .child_of_' + tab ).show();
            // register-tabs: remove selected on all tabs, then append on one specific tab by class
            $( '#' + registermap_id + ' UL.register LI' ).removeClass( 'selected' );
            $( '#' + registermap_id + ' UL.register LI.' + tab ).addClass( 'selected' );
        }

        // store tab-name when click on register-tab 
        function storeActualRegisterTabName( tab ) {
            var registermap_id = $( 'li.' + tab ).closest( 'div.registermap' ).prop( 'id' );
            var formname = formnameFromRegisterId( registermap_id );
            localStorage.setItem('registerpage_' + registermap_id + '_' + formname , tab );
        }

        // get tab-name 
        function actualRegisterTabName( registermap_id ) {
            var formname = formnameFromRegisterId( registermap_id );
            var tab = localStorage.getItem( 'registerpage_' + registermap_id + '_' + formname );
            return tab;
        }

        // get form-name 
        function formnameFromRegisterId( registermap_id ) {
            // if there is no form, use upper div-id as formname 
            var formname = $( '#' + registermap_id ).closest( 'form' ).prop( 'name' );
            if( formname ){
                return formname;
            }
            formname = $( '#' + registermap_id ).closest( 'div' ).prop( 'id' );
            return formname;
        }

        // extension sfgz_kurs: handle TREE in OVERWIEV LIST
        // on load 1) bind events and 2) open/close tree-branches depending on stored values
        function setTreeNodeStatus( id_prefix ) {
            // id_prefix is  branch_
//             console.log( 'setTreeNodeStatus("' + id_prefix + '")' );
            // bind events
            $( "[id*='" + id_prefix + "']" ).addClass('pointer').html('+ ').on( 'click', function() {
                storeTreeNode( id_prefix , $( this ).attr( 'id' ).substr( id_prefix.length ) );
            });
            // open/close tree-branches depending on stored values
            $( "[id*='" + id_prefix + "']" ).each(function(){
                var kurs_uid = $(this).attr('id').substr( id_prefix.length );
                var kursrow_uid = id_prefix + kurs_uid;
                var new_value = localStorage.getItem( kursrow_uid );
                // console.log( 'kurs_uid = "' + kurs_uid + '" ' + 'kursrow_uid = "' + kursrow_uid + '" new_value = "' + new_value + '" '  );
                switchTreeNodeTo( kursrow_uid , new_value );
            });
            markRowsAsSelected();
            
        }
        // store tree-node when click on tree in overview-list 
        function storeTreeNode( id_prefix , kurs_uid ) {
            // id_prefix:branch_ kurs_uid:5
            var kursrow_uid = id_prefix + kurs_uid;
            var new_value = localStorage.getItem( kursrow_uid );
            if( new_value > 0 ){ 
                new_value = 0;
            }else{ 
                new_value = 1; 
            }
            localStorage.setItem( kursrow_uid , new_value );
            switchTreeNodeTo( kursrow_uid , new_value );
            // console.log( 'storeTreeNode id_prefix:»' + id_prefix + '« kurs_uid: » kursrow_uid:»' + kursrow_uid + '« kurs_uid: »' + kurs_uid + '« to ' + new_value );
        }
        function switchTreeNodeTo( kursrow_uid , new_value ) {
            // on startup, kursrow_uid is like branch_3
            if( new_value > 0 ){ 
                $( "[id='" + kursrow_uid + "']" ).html('&minus;');
                $("TR[class*='" + kursrow_uid + "']").show(); 
            }else{ 
                $( "[id='" + kursrow_uid + "']" ).html('+');
                $("TR[class*='" + kursrow_uid + "']").hide(); 
            }
            // console.log( 'switchTreeNodeTo kursrow_uid:»' + kursrow_uid + '« to ' + new_value );
        }
        
        // view/hide toggle onclick event bound on a element (eg. button or span)
        function toggleTree( id_prefix ) {
            // bound on toggle-button
            var new_value = localStorage.getItem( id_prefix );
            if( new_value > 0 ){ new_value = 0; }else{  new_value = 1; }
            switchTreeTo( id_prefix , new_value );
        }
        function switchTreeTo( id_prefix , new_value ) {
            // bound on toggle-button
            localStorage.setItem( id_prefix , new_value );
            if( new_value ){ 
                openTreeNodes( id_prefix );
            }else{
                clearTreeNodes( id_prefix );
            }
        }
        function openTreeNodes( id_prefix ) {
            $( "[id*='" + id_prefix + "']" ).each(function(){
                // insert - in open branches
                $(this).html( '-' );
                var kurs_uid = $(this).attr('id').substr( id_prefix.length );
                var kursrow_uid = id_prefix + kurs_uid;
                localStorage.setItem( kursrow_uid , 1 );
                switchTreeNodeTo( kursrow_uid , 1 );
            });
        }
        function clearTreeNodes( id_prefix ) {
            // hide rows with class 'branch_' and store branch as 0
            for (var i = 0; i < localStorage.length; i++){
                var stored_key = localStorage.key(i);
                if( stored_key.substr(0,id_prefix.length) == id_prefix ){ 
                    $("TR[class*='" + stored_key + "']").hide();
                    localStorage.setItem( stored_key , 0 );
                }
            }
            // insert + in closed branches
            $( "[id*='" + id_prefix + "']" ).each(function(){
                $(this).html( '+' );
            });
        }
        
        // Starter markRowsAsSelected
        function markRowsAsSelected() {
                // events for LIST OVERVIEW
                // bind klick-event on list-items to change the color
                $('div.tx-sfgz-kurs table.tx_sfgzkurs.overview TD' ).on( 'click', function() {
                    $(this).addClass('choosen'); 
                });
                
                // define selected item by click in list to display single-view
                // get Value from element  #selected_uid
                var activeid = getActiveUid();
                var formname = $('#active_id').closest('form').prop('name');
                if( formname && activeid ){
                    var targetname = 'lst_' + formname + '_' + activeid;
                    var classListItem = $('.' + targetname).attr('class');
                    if( classListItem ){
                        var classList = classListItem.split(/\s+/);
                        $('.' + targetname).addClass('selected');
                        for (var i = 0; i < classList.length; i++) {
                            var classparts = classList[i].split('_');
                            if (classparts[0] == 'parent') {
                                 $('.lst_version_' + classparts[2]).addClass('selected');
                            }
                            if (classparts[0] == 'branch') {
                                $('#lst_kurs_' + classparts[1] ).addClass('selected');
                                localStorage.setItem( classList[i] , 1 );
                                // make scrollable: display hidden row if selected
                                switchTreeNodeTo( classList[i] , 1 );
                            }
                        }
                        scrollToPositionInList( '#' + targetname + 'z');
                    }
                }
        }
        
        function scrollToPositionInList( target ) {
                var scrollDistance = $('#scrollkurslist').scrollTop() + $(target).offset().top - $('#scrollkurslist').offset().top;
                $('#scrollkurslist').animate( {	scrollTop: scrollDistance - 100 } );
        }
        
        function getActiveUid() {
                if( $('#selected_uid').val() > 0 ){
                    var activeid = $('#selected_uid').val();
                    localStorage.setItem('activeid' , activeid );
                }else{
                    // if there occures a user-error during form-filling then the #selected_uid will be empty; 
                    // in this case get value from #active_id OR stored value instead
                    if( $('#active_id').val() > 0 ){
                        var activeid = $('#active_id').val();
                    }else{
                        // load stored selection and insert the value in element #selected_uid
                        var activeid = localStorage.getItem( 'activeid' );
                    }
                    $('#selected_uid').val(activeid);
                }
                return activeid;
        }
        
        // extension sfgz_kurs: AJAX update checkbox
        function jsUpdateConfigTable( URL , table , field , value ) {
            opt = {};
            opt['tab'] = table;
            opt['fld'] = field;
            opt['val'] = value;
            usropt = {};
            usropt['options'] = opt;
            $.ajax({
                url : URL,
                type : 'GET',
                data: usropt,
                dataType:'json',
                success : function(data) {
// 					console.log('ok jsUpdateConfigTable... ' + data['responseText'] + '; ' + opt['tab'] + '; '  + opt['fld'] + '='  + opt['val'] + ' ' + URL + ' Request OK: ');
                    return true;
                },
                error : function(request,error)
                {
                    if( request['status'] > 0 ){
                        alert('error... ' + URL + ' Request ' + error + ': '+JSON.stringify(request));
                        return false;
                    }
                    return true;
                }
            });
            
        }
        function jsUpdateFromObject( URL , table , changeObj ) {
        
            value = $( changeObj ).prop( 'checked' ) ;
            answerObj  = $( changeObj ).closest('DIV.imp_statusdiv').find('.answer');
            nameparts = changeObj.attr("class").split(' ');
            var classparts = nameparts[0].split('_');
            
            opt = {};
            opt['table'] = classparts[2];
            opt['index'] = classparts[1];
            opt['value'] = value;
            
            usropt = {};
            usropt[table] = opt;
            usropt['table'] = table;
            
            return jsUpdateFromArray( URL , table , usropt , answerObj );
            
        }
        function jsUpdateFromArray( URL , table , usropt , answerObj ) {
            $.ajax({
                url : URL,
                type : 'GET',
                data: usropt,
                dataType:'json',
                success : function(data) {
                    $( answerObj ).fadeIn( 250 );
                    $( answerObj ).html( data.responseText );
                    $( answerObj ).fadeOut( 2750 );
                    return true;
                },
                error : function(request,error)
                {
                    if( request['status'] > 0 ){
                        alert('error: ' + URL + ' Request ' + error + ': '+JSON.stringify(request));
                        return false;
                    }
                    return true;
                }
            });
        }
        function jsUpdateValue( URL , table , selId ) {
            opt = {};
            var content = $('#' + selId).val();
            if( content ){
                opt[selId] = content;
            }else{
                opt[selId] = $('#' + selId).html();
            }
            usropt = {};
            usropt[table] = opt;
            usropt['table'] = table;
            $.ajax({
                url : URL,
                type : 'GET',
                data: usropt,
                dataType:'json',
                success : function(data) {
                    if( data.responseText == 'ok' ){
                        $( '#' + selId + '_answer' ).fadeIn( 250 );
                        $( '#' + selId + '_answer' ).html( data.responseText );
                        $( '#' + selId + '_answer' ).fadeOut( 750 );
                    }
                    if( data.responseText == 'css' ){
                        $('#' + selId).removeClass( data.nocss );
                        $('#' + selId).addClass( data.css );
                        $('#' + selId).html( data.debug );
                        if( data.debug ){
                            $('#' + selId).attr( 'title' , 'Ausgeblendet: (Ja)' );
                        }else{
                            $('#' + selId).attr( 'title' , 'Ausgeblendet: (Nein)' );
                        }
                    }
                    return true;
                },
                error : function(request,error)
                {
                    if( request['status'] > 0 ){
                        alert('error: ' + URL + ' Request ' + error + ': '+JSON.stringify(request));
                        return false;
                    }
                    return true;
                }
            });
        }
        
        function ajaxSorting( URL , table , direction , selId ) {
            usropt = {};
            usropt['direction'] = direction;
            usropt['selId'] = selId;
            usropt['table'] = table;
            $.ajax({
                url : URL,
                type : 'GET',
                data: usropt,
                dataType:'json',
                success : function(data) {
                    var fields = [ 'kategorieName' , 'bearbeiten' , 'entfernen' , 'auf' , 'ab' ];
                    var i;
                    for (i = 0; i < fields.length; ++i) {
                        var cls = '.' + fields[i];
                        var oldVal = $( '.c' + selId + cls ).html();
                        $( '.c' + selId + cls ).html( $( '.c' + data.responseText + cls ).html() );
                        $( '.c' + data.responseText + cls ).html(oldVal);
                        $( '.c' + selId + cls ).addClass('t' + selId);
                        $( '.c' + selId + cls ).removeClass('c' + selId);
                        
                        $( '.c' + data.responseText + cls ).addClass('c' + selId);
                        $( '.c' + data.responseText + cls ).removeClass('c' + data.responseText);
                        $( '.t' + selId + cls ).addClass('c' + data.responseText);
                        $( '.t' + selId + cls ).removeClass('t' + selId);
                    }                    
                    
                    return true;
                },
                error : function(request,error)
                {
                    if( request['status'] > 0 ){
                        alert('error: ' + URL + ' Request ' + error + ': '+JSON.stringify(request));
                        return false;
                    }
                    return true;
                }
            });
        }
        
        function initiate() {
            // extension sfgz_kurs: REGISTERS
                // remove focus after click buttons
                $( 'input[type="submit"]' ).on( 'click', function() { $( this ).blur(); } );
                $( 'button[type="submit"]' ).on( 'click', function() { $( this ).blur(); } );
                
                // events for REGISTERS
                // bind click-event with registerTab-setter
                $('div.registermap UL.register LI' ).on( 'click', function() {
                    registermap_id = $( this ).closest( 'div' ).prop( 'id' ); // #hauptregister
                    // detect the class, that for first remove class 'selected' if set
                    $( this ).removeClass('selected');
                    var tab = $( this ).attr('class');
                    if( tab ){
                        registerTabChange( tab , registermap_id ); 
                        storeActualRegisterTabName( tab ); 
                    }
                });
                // choose tab after page-loading (trigger the klick)
                $( "div.registermap" ).each(function( index ) {
                        var tab = actualRegisterTabName( this.id );
                        if( $('#' + tab ).length ){
                            registerTabChange( tab , this.id );
                        } else {
                            $( '#' + this.id + ' UL.register LI' ).first().trigger( 'click' );
                        }
                });
                
            // extension sfgz_kurs: LISTS + OVERVIEW Kurs->overviewAction Kurs->importlistAction Handles pointer and datefilter in lists
                // handle tree branches is done by script storeTreeNode()->switchTreeNodeTo(). Binded on start by setTreeNodeStatus('branch_')
                // events for LIST OVERVIEW are handled by markRowsAsSelected(). Binded on start by setTreeNodeStatus()
                
                // events for STICHTAG in LIST OVERVIEW
//                 if( $('#ist_stichtag').attr('checked') ){ $('#box_stichtag').show(); }else{ $('#box_stichtag').hide(); }

                // SEARCH in KURSE-LIST extension sfgz_kurs: Kurs-Controller listAction
                    $('.search_but' ).find('label').addClass('pointer');
                    $('.search_but' ).find('input[type="radio"]').on( 'click', function() { $("form[name='liste']").submit(); });
                
                // events for IMPORT-LIST
                $( "div.tx-sfgz-kurs FORM[name*='import'] input[type='checkbox']" ).on( 'click', function() {
                    var classname = $(this).attr("class");
                    $( '.' + classname ).prop( 'checked' , $( this ).prop( 'checked' ) );
                    actionUri = editConfigUrl( 'update' );
                    jsUpdateFromObject( actionUri , 'importSelection' , $( this ) );
                });
                
                var importindex = localStorage.getItem( 'importsel' );
                $('.impdiv').removeClass('selected');
                $('#imp_' + importindex).addClass('selected');
                
            // scroll to anchor on page loading - this has to be done on the end of loading.
                var url = $(location).attr("href");
                var posOfPattern = url.indexOf("#");
                if( posOfPattern > 10 ){
                    var stringBehindPattern = url.substring( posOfPattern +1 );
                    scrollToAnchor(stringBehindPattern);
                }
        }

$(document).ready(function(){ initiate(); });

