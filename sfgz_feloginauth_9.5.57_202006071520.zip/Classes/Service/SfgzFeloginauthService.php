<?php
namespace Sfgz\SfgzFeloginauth\Service;

use TYPO3\CMS\Core\Authentication\AuthenticationService;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;

/*
* This file is part of the TYPO3 CMS project.
*
* It is free software; you can redistribute it and/or modify it under
* the terms of the GNU General Public License, either version 2
* of the License, or any later version.
*
* For the full copyright and license information, please read the
* LICENSE.txt file that was distributed with this source code.
*
* The TYPO3 project - inspiring people to share!
*/

/**
* Service "SfGZ authentication" for the "SfgzFeloginauth" extension. 
* Subtypes getUserFE and authUserFE
* 
* Subtype getUserFE provides getUser by
* - preauthLink if GeneralUtility::_GET( 'account' )
* - webmail API
*
* Subtype authUserFE provides authUser by
* - preauthLink if GeneralUtility::_GET( 'account' ), hashed with secret key. 
*   returns 101 if not responsible, -1 if not successfull
*   
* - webmail API by emailadress from user $this->login['uname'] 
*   returns 102 if not responsible, -1 if not successfull
* 
* returns 200 if successfull
*/


class SfgzFeloginauthService extends AuthenticationService
{

    /**
    * Find a user (eg. look up the user record in database when a login is sent)
    *
    * @return mixed User array or FALSE
    */
    public function getUser() 
    {
            $user = $this->getUser_preauthLink();
            if($user) return $user;
            
            $user = $this->fetchUserRecord( $this->login['uname'] ); // get the fe_user from typo3
            return $user;
    }

    /**
    * Find a user (eg. look up the user record in database when a login is sent)
    *
    * @return mixed User array or FALSE
    */
    public function getUser_preauthLink() 
    {
            $username = GeneralUtility::_GET('account');
            if( empty($username) ) return false; // not called by link

            // get the fe_user from typo3
            $user =  $this->fetchUserRecord( $username );
            return $user;
    }

    /**
    * Authenticate a user (Check various conditions for the user that might invalidate its authentication, eg. password match, domain, IP, etc.)
    *
    * @param array $user Data of user.
    *
    * @return integer >= 200: User authenticated successfully.
    *                         No more checking is needed by other auth services.
    *                 >= 100: User not authenticated; this service is not responsible.
    *                         Other auth services will be asked.
    *                 > 0:    User authenticated successfully.
    *                         Other auth services will still be asked.
    *                 <= 0:   Authentication failed, no more checking needed
    *                         by other auth services.
    */
    public function authUser(array $user): int
    {
            $backendConfiguration = GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('sfgz_feloginauth');
            
            $account = $this->getUser_preauthLink();
            if( $account ) {
                    // auth against link returns -1 or 101 or 200
                    return $this->authUser_preauthLink( $account['username'] , $backendConfiguration['preauthKey'] , $backendConfiguration['lifetime'] , $backendConfiguration['fieldSeparer'] );
            }
            
            $notResponsible = 102;
            if( $user == false ) return $notResponsible;
            
            $urlWebmail = str_replace( '_USEREMAIL_' , $user['email'] , $backendConfiguration['urlWebmail'] );
            $success = $this->authAgainstZimbra( $user['email']  , $this->login['uident_text'] , $urlWebmail );
            return $success ? 200 : $notResponsible;
    }
    
    /**
    * Authenticate a user over a link (login-URL)
    * returns responsibleButFaild -1 | notRespsonsible 101 | successfull 200
    * 
    * @param string $submittedUsername username
    * @param string $secretString 
    * @param int $toleranceInMinutes optional, default is 10
    * @param string $fieldSeparer optional a single char. default is - (minus)
    * @return integer 
    */
    Private function authUser_preauthLink( $submittedUsername , $secretString , $toleranceInMinutes = 10 , $fieldSeparer = '-') {
            
            $OK = 101;
            // refused, no username given!
            if( empty($submittedUsername) ) return $OK;
            
            // HINT the field-order is a secret and essential for successfull login!
            $aRequest = [];
            $aRequest['account'] = $submittedUsername;
            $aRequest['timestamp'] = GeneralUtility::_GET('timestamp'); // timestamp is in milliseconds!
            $aRequest['school'] = GeneralUtility::_GET('school');
            $aRequest['preauth'] = GeneralUtility::_GET('preauth');
            $aRequest['role'] = GeneralUtility::_GET('role');

            $this->preauthLinkUtility = GeneralUtility::makeInstance('Sfgz\\SfgzFeloginauth\\Utility\\PreauthLinkUtility');
            
            // ingredients to overwrite for hash
            $strAuthFieldOrder = $this->preauthLinkUtility->aIngredients;
            // unset ingredients that not should appear in the second argument of function hash_hmach() - but as third argument.
            if( isset($strAuthFieldOrder['preauth']) ) unset($strAuthFieldOrder['preauth']);
            // overwrite 
            $aSha1RequestWithoutPreauth = [];
            foreach(  array_keys( $strAuthFieldOrder ) as $fieldname ) $aSha1RequestWithoutPreauth[$fieldname] = $aRequest[$fieldname];
            $calculatedToken = hash_hmac('sha1', implode( $fieldSeparer , $aSha1RequestWithoutPreauth ) , $secretString );
            
            $OK = ( strtolower( $calculatedToken ) == strtolower( $aRequest['preauth'] ) ) ? 200 : -1;
            
            if( $OK == 200 ){
                $toleranceInSeconds = $toleranceInMinutes * 60;
                $creationTimeInMinutes = $aRequest['timestamp'] / 60000 ; // transform milliseconds to minutes
                $timeBeforeThenMinutes = ( time() - $toleranceInSeconds ) / 60;
                // refused if timestamp to old!
                if( $creationTimeInMinutes < $timeBeforeThenMinutes ) $OK = -1;
                $timeInTwentyMinutes = ( time() + ( 2* $toleranceInSeconds ) ) / 60;
                // refused if timestamp to far in future!
                if( $creationTimeInMinutes > $timeInTwentyMinutes ) $OK = -1;
            }
            return $OK;
    }
    
    /**
    * authenticate against Zimbra by calling the Calendar
    *
    * @param string $userEmail username with following [at]domain.ch
    * @param string $password plain password
    * 
    * @return mixed TRUE or FALSE
    */
    function authAgainstZimbra( $userEmail , $password , $urlName ){
            $res = false;
            if( empty($userEmail) || empty($password) || empty($urlName) ) return $res;
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL , $urlName);
            curl_setopt($ch, CURLOPT_USERPWD , $userEmail.':'.$password);
            curl_setopt($ch, CURLOPT_HTTPAUTH , CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER , false); 
            curl_setopt($ch, CURLOPT_RETURNTRANSFER , true);
            $result = curl_exec($ch);
            curl_close($ch);
           
            // if a mail-folder was choosen
            $arr = json_decode( $result , true );
            if( is_array($arr) ) $res = true;
            
            // if a calendar was choosen
            if(substr( $result, 1 , 7 ) == '"appt":' ) { $res = true; }
            return $res;
    }

}
