<?php 
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}
 
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addService(
	$_EXTKEY,  
	'auth',  
	\Sfgz\SfgzFeloginauth\Feloginauth\SfgzFeloginauthService::class,
	[
		'title' => 'Cascading-Authenticaton-Service',
		'description' => 'Authenticates against API service',
		'subtype' => 'authUserFE,getUserFE',
		'available' => TRUE,
		'priority' => 70,
		'quality' => 70,
		'os' => '',
		'exec' => '',
		'className' => \Sfgz\SfgzFeloginauth\Feloginauth\SfgzFeloginauthService::class
	]);

