function showTeaser( delaytime , fadeouttime , pathToImg ) {
	$("body,html").animate({
		scrollTop: 0,
		scrollLeft: 0
	}, 550);
	$('BODY').css('background','#FFF');
	
    var jsText = '<!-- sfgz_design_teaser loaded by js --> <div id="teaser_spacer"></div><div id="teaser_box"><img id="teaser_img" src="' + pathToImg + getRandomImage() + '" /></div><!-- /sfgz_design_teaser loaded by js -->';
    $('#container').prepend( jsText );
    $('#blank_container').prepend( jsText );
	
   	$('#teaser_spacer').fadeIn(0); 
	
		$({
			z: 7
		}).animate({
			z: 0
		}, {
			step: function() {
				$('#teaser_box').css('zIndex', ~~this.z);
			},
			duration: delaytime
		});
	
		setTimeout(function(){
			$('#teaser_box').fadeOut( fadeouttime ); 
		}, delaytime );

}
function getRandomImage() {
    var imgAr = getTeaserImages();
	var num = Math.floor( Math.random() * imgAr.length );
    var img = imgAr[ num ];
    return img;
}
