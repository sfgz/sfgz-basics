## handbuch_pagetitle almost like navigation_subtitle
## 
## immer: [title] der Hauptseite
## wenn aktuelle Seite nicht Hauptseite
## dann [: title] der aktuellen Seite
## wenn aktuelle Seite = Hauptseite UND subtitle nicht leer
## dann [: subtitle] sonst nichts

lib.handbuch_subtitle = COA_INT
lib.handbuch_subtitle {

    wrap = <div class="navigation_subtitle under-title">|</div>

	## Subtitel der Hauptseite
	15 = TEXT
	15 {
				wrap = <H1>|</H1>
				insertData = 1
				value = {DB:pages:{$plugin.sfgz_design.settings.handbuch_uid}:subtitle}
				#typolink.parameter = {$plugin.sfgz_design.settings.handbuch_uid}
	}
	
}

lib.handbuch_pagetitle = COA_INT
lib.handbuch_pagetitle {
    # aktuelle Unterseite Seitentitel aus Tabelle page
    5 = TEXT
    5 {
        insertData = 1
        value = {page:title}
        noTrimWrap = | <H2>|</h2> |
    }
}
