## + lib.info.ts

## contains:
## lib.info_baseURL
## lib.info_pagelayout
## lib.info_pagetitle
## lib.info_username

lib.info_baseURL = COA_INT
lib.info_baseURL.insertData = 1
lib.info_baseURL = {$plugin.sfgz_design.settings.baseURL}

## info_pagelayout
lib.info_pagelayout = TEXT
lib.info_pagelayout.insertData = 1
lib.info_pagelayout.value = {page:layout}

## info_pagetitle
lib.info_pagetitle = COA_INT
lib.info_pagetitle {
	wrap = <H3 class="info_pagetitle page-title ">|</H3>
    10 = TEXT
	10.insertData = 1
	10.data = page:title
}

## info_username
lib.info_username = COA_INT
lib.info_username.wrap = <div class="info_user_box"><div class="info_username"> | </div></div><div class="info_user_box"><div class="info_upward" onClick="anfang()">Nach oben &uarr;</div></div>
lib.info_username.10 = TEXT
lib.info_username.10.value = 
lib.info_username.20 = TEXT
## lib.info_username.20.value = Schule für Gestaltung Zürich
lib.info_username.20.value = 
lib.info_username.20.wrap = <div class="smallhint"> | </div>
lib.info_username.20.stdWrap.typolink.parameter = {$plugin.sfgz_design.settings.loginpage_uid}
lib.info_username.20.stdWrap.typolink.ATagParams = class="smallhint" onfocus="this.blur()"
lib.info_username.20.stdWrap.typolink.title = zur Anmeldung

[globalVar = TSFE:fe_user|user|usergroup > 0]
		lib.info_username.10.value = Angemeldet als 
		lib.info_username.20.data = TSFE:fe_user|user|name
		lib.info_username.20.noTrimWrap = | ||
		lib.info_username.20.insertData = 1
		lib.info_username.20.dataWrap = <i>|</i>
		lib.info_username.20.stdWrap.typolink.title = Profil ändern...
		lib.info_username.20.stdWrap.typolink.parameter = {$plugin.sfgz_design.settings.profil_uid}
		lib.info_username.20.data.override.if.isFalse.data = TSFE:fe_user|user|name
		lib.info_username.20.data.override = TSFE:fe_user|user|username
[global]

## NEW DESIGN motioned by sfgz_navigation.js
#lib.info_username.30 = TEXT
#lib.info_username.30.value = Neues Design, <br>die Daten bleiben <br>dieselben <span style="font-style:italic;font-size:10pt;">22.03.2020</span>.
#lib.info_username.30.wrap = <div style="border-radius:5px;background:#fff;margin:5px 0 0 -5px;padding:5px;width:auto;float:left;">|</div><div style="clear:left;"></div>
## 

#lib.preauthlink = USER_INT                                                      
#lib.preauthlink {
#		userFunc = Sfgz\SfgzFeloginrsaauth\Utility\PreauthLinkUtility->preauthLink
#		subdomain = http://intern.sfgz.ch
#		subdomain2 = http://daten.sfgz.ch
#}
