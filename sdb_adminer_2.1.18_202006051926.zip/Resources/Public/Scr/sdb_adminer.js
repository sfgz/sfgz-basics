/*!
 * sdb_adminer.js
 * 
 * Licensed MIT © Daniel Rueegg
 */

$(document).ready(function(){
	initiateLinks(); 
 	initiateFilters(); 
	initiateSearch(); 
	displayPagerPages(); 
});
// called on load
function initiateLinks() {
	// each fieldname  could contain a url for example if fieldnames are uid, name: jsUrl_uid, jsUrl_name ...
	$('.data').each(function (index, value) {
		var outerObj = $( this );
		var aName = $( this ).attr('name').split('_');
		// bind klick event on links
		if( aName[0] == 'jsUrl' ){
			$('.page-container .jslink.fld_' + aName[2] ).click(function() {
				var newHref = outerObj.val().replace( '_REP_VALUE_' , $( this ).html() )
				document.location.href = newHref;
			});
		}
		if( aName[0] == 'jsPopupUrl' ){
			$('.page-container .jslink.pop_' + aName[2] ).click(function() {
                var target = outerObj.attr('data');
				var newHref = outerObj.val().replace( '_REP_VALUE_' , $( this ).html() )
                vHWin = window.open( newHref , 'FEopenLink', target );
                vHWin.focus();
                return false;
			});
		}
	});
	
}
// called on load
function initiateFilters() {
	$('.data').each(function (index, value) {
		var outerObj = $( this );
		var aName = $( this ).attr('name').split('_');
		// load filter for select-options
		if( aName[0] == 'selectFilter' ){
			var url = $( this ).attr('data');
			var optionsSuffix = aName[3];
			var searchChars = $( this ).val();
			var selectorId = 'text_' + aName[1] + '_' + aName[2] ;
			jsSetOptions( url , optionsSuffix , searchChars , selectorId );
		}
	});
}
// called on load
function initiateSearch() {
	$('.data').each(function (index, value) {
		var outerObj = $( this );
		var aName = $( this ).attr('name').split('_');
		
		// load search form
		if( aName[0] == 'searchChars' ){
			var pluginUid = aName[1];
			var url = $( '#result_' + pluginUid ).attr('data');
			// get data from storage and insert in search form
			var searchPattern = localStorage.getItem( 'searchChars_' + pluginUid );
			$( outerObj ).val( searchPattern );
			// fire first oninput event on search form
			jsSearchResults( url , pluginUid );
			// bind oninput event on search form
			$( outerObj ).on('input', function() {
				localStorage.setItem( 'searchChars_' + pluginUid , outerObj.val() );
				jsSearchResults( url , pluginUid );
			});
		}
		
	});
}
// called on load
function displayPagerPages() {
	
	$( '.skala-container' ).each(function( key, value)
	{
		var arrId = $( this ).attr('id').split('_');
		var pluginUid = arrId[1];

		$('.pi_' + pluginUid + '.visible').addClass('invisible').removeClass('visible');
		$('.pi_' + pluginUid + '.page_1' ).addClass('visible').removeClass('invisible');

		var id_prefix = 'pagerstatus_' + pluginUid + '_';
		for (var i = 0; i < localStorage.length; i++){
			var stored_key = localStorage.key(i);
			if( stored_key.substr(0,id_prefix.length) == id_prefix ){
				var pagerStatus = localStorage.getItem( stored_key );
				var keyParts = stored_key.split('_');
				var idx = keyParts[2];
				if( pagerStatus == 1 ){
					$('.pi_' + pluginUid + '.page_1' ).addClass('invisible').removeClass('visible');
					$('.pi_' + pluginUid + '.page_' + idx ).addClass('visible').removeClass('invisible');
				}
			}
		}
		
	});

}

// ask bevore delete-behavor
function ask(url, message) {
  question = window.confirm( '«' + message + '» wirklich löschen?' ); 
  if(question) document.location.href = url; 
}

// called by the onChange-event from select html-element defined in TemplateUtility->setDefaultTemplates()
function actionSelectChange( newValue , urlId ) {
	if ( newValue ) {
		
		$('.data').each(function (index, value) {
			var outerObj = $( this );
			// bind klick event on links
			if( $( this ).attr('name') == urlId ){
				var newHref = outerObj.val().replace( '_REP_VALUE_' , newValue );
				window.location.href = newHref;
			}
		});
	}
}

// called by the onClick event of pager-choosing-elements in List.html section "as_page_pager_element"
function changePagerPages( pluginUid , idx ) {
	var id_prefix = 'pagerstatus_' + pluginUid + '_';
	for (var i = 0; i < localStorage.length; i++){
		var stored_key = localStorage.key(i);
		if( stored_key.substr(0,id_prefix.length) == id_prefix ){ 
			localStorage.setItem( stored_key , 0 );
		}
	}
	localStorage.setItem( id_prefix + idx , 1 );
	$('.pi_' + pluginUid + '.visible').addClass('invisible').removeClass('visible');
	$('.pi_' + pluginUid + '.page_' + idx ).addClass('visible').removeClass('invisible');
}

// binded by initiateSearch
function jsSearchResults( URL , pluginUid ) {
	var searchPattern = localStorage.getItem( 'searchChars_' + pluginUid );
	var minCharsToStart = $( '#searchChars_' + pluginUid ).attr('data');
	if( searchPattern && minCharsToStart ) {
		if( searchPattern.length >= minCharsToStart ) {
				ajaxSearchResults( URL , searchPattern , '#result_' + pluginUid );
		}else{
				$( '#result_' + pluginUid ).html( 'Die Suche wird gestartet, sobald der Suchbegriff mindestens ' + minCharsToStart + ' Zeichen lang ist.' );
		}
	}else{
		if( minCharsToStart > 0 ) {
				$( '#result_' + pluginUid ).html( 'Die Suche wird gestartet, sobald der Suchbegriff mindestens ' + minCharsToStart + ' Zeichen lang ist.' );
		}else{
				ajaxSearchResults( URL , searchPattern , '#result_' + pluginUid );
		}
	}
}


// called by jsSearchResults
function ajaxSearchResults( URL , searchPattern , resultElement ) {
			usroption = {};
			usroption['data'] = {};
			usroption['data']['subaction'] = 'getListData';
			usroption['data']['searchchars'] = searchPattern;
			var res_pid = $( resultElement ).attr('id').split('_');
			var pluginUid = res_pid[1];
			var displayType = $( '#template_' + pluginUid ).attr('data');
			
			$( resultElement ).append( '<span style="color:#080;font-size:90%;">...</span>' );
			
			$.ajax({
				url : URL,
				type : 'GET',
				data: usroption,
				dataType:'json',
				success : function(returnvalue) {
					
					var obj = JSON.parse( returnvalue );
					
					$( resultElement ).empty();
					
					var output = '';//obj.resultdata.length + ' Zeilen.';
					
					if( displayType == 1 ){
						// as page: pager
						output = renderAjaxSearchResults_Page( obj , pluginUid );
						$( resultElement ).append( output );
						
						$( "span.pager-skala" ).click(function() {
							var aName = $( this ).attr('name').split('_');
							$( '.pager-skala' ).addClass('invisible').removeClass('visible');
							$( '.pi_' + aName[1]  ).addClass('invisible');
							$( '.pi_' + aName[1] + '.page_' + aName[2] ).addClass('visible').removeClass('invisible');
						});
						initiateLinks();
						
					}else{
						// as list
						output = renderAjaxSearchResults_Table( obj , pluginUid );
						$( resultElement ).append( output );
						var defaultPagerSize = $( '#tablepager_' + pluginUid ).attr('data');
						if( obj.resultdata.length > defaultPagerSize ){
							$( '#recordCounter' + pluginUid ).hide();
							$( '#pager_' + pluginUid ).fadeIn();
						}else{
							$( '#pager_' + pluginUid ).hide();
							$( '#recordCounter' + pluginUid ).fadeIn();
						}
						
						initiateLinks();
						initiateSortTable();
					}
					
					return true;
					
				},
				error : function(request,error)
				{
					if( request['status'] > 0 ){
						alert('error: ' + URL + ' Request ' + error + ': '+JSON.stringify(request));
						return false;
					}
					return true;
				}
			});
}
// called by ajaxSearchResults
function initiateSortTable() {
	$('.page-container th').css("cursor", "pointer");
	$('.page-container th').click(function(){
		var table = $(this).parents('table').eq(0)
		var rows = table.find('tr:gt(0)').toArray().sort(sortTableComparer($(this).index()))
		this.asc = !this.asc
		if (!this.asc){rows = rows.reverse()}
		for (var i = 0; i < rows.length; i++){table.append(rows[i])}
	})
}
// called by ajaxSearchResults -> initiateSortTable
function sortTableComparer(index) {
    return function(a, b) {
        var valA = sortTableGetCellValue(a, index), valB = sortTableGetCellValue(b, index)
        return $.isNumeric(valA) && $.isNumeric(valB) ? valA - valB : valA.toString().localeCompare(valB)
    }
}
// called by ajaxSearchResults -> sortTableComparer
function sortTableGetCellValue(row, index){ 
	return $(row).children('td').eq(index).text() 
}
// called by ajaxSearchResults
function renderAjaxSearchResults_Page( obj , pluginUid ) {
		output = '<div class="skala-container">';
		$.each(obj.resultdata,function( key, content) 
		{
			var rowForm = decodeEntities( $( '#pager_' + pluginUid ).val() );
			$.each( content.data , function( skey, scontent ){ 
				//rowForm = rowForm.replace( '_' + skey + '_' , scontent.value ); 
				rowForm = rowForm.split( '_' + skey + '_' ).join( scontent.rendered );
			});
			if( content.selected ){
				output = output + '<span name="pi_' + pluginUid + '_' + key + '" class="visible pager-skala pi_' + pluginUid + ' page_' + key + '">' + rowForm + '</span> ';
			}else{
				output = output + '<span name="pi_' + pluginUid + '_' + key + '" class="pager-skala pi_' + pluginUid + ' page_' + key + '">' + rowForm + '</span> ';
			}
		});
		output = output + '</div>';
		
		// as page: content
		output = output + '<div class="page-container">';
		$.each(obj.resultdata,function( key, content) 
		{
			var rowForm = decodeEntities( $( '#template_' + pluginUid ).val() );
			$.each( content.data , function( skey, scontent ){ 
				rowForm = rowForm.split( '_' + skey + '_' ).join( scontent.rendered );
			});
			if( content.selected ){
				output = output + '<div class="visible ';
			}else{
				output = output + '<div class="invisible ';
			}
			output = output + 'pi_' + pluginUid + ' pager-page page_' + key + '">' + rowForm + '</div> ';
			
		});
		output = output + '</div> ';
		return output;
}
// called by ajaxSearchResults
function renderAjaxSearchResults_Table( obj , pluginUid ) {
		output = '<div class="page-container">';
		
        var rowForm = decodeEntities( $( '#leadtext_' + pluginUid ).val() );
        $.each( obj.resultdata[0].data , function( skey, scontent ){ 
            rowForm = rowForm.split( '_' + skey + '_' ).join( scontent.rendered );
        });
		output = output + rowForm; 
                    
		var defaultPagerSize = $( '#tablepager_' + pluginUid ).attr('data');
		// display pager on top if more than 1 pager-page
		if( obj.resultdata.length > defaultPagerSize ) { output = output + decodeEntities( $( '#tablepager_' + pluginUid ).val() ); }
		
		$.each(obj.resultdata,function( key, content) 
		{
				if( key == 0 ){
					// first row
					var rowForm = decodeEntities( $( '#headrow_' + pluginUid ).val() );
					$.each( content.data , function( skey, scontent ){ 
						// multireplae with split/join instead of replace(), which replaces only once
						rowForm = rowForm.split( '_' + skey + '_' ).join( scontent.rendered );
					});
					output = output + rowForm;
					// render also as middle row
				}
				if( key + 1 == obj.resultdata.length ){
					// last row
					var rowForm = decodeEntities( $( '#footrow_' + pluginUid ).val() );
					$.each( content.data , function( skey, scontent ){ 
						rowForm = rowForm.split( '_' + skey + '_' ).join( scontent.rendered );
					});
					output = output + rowForm;
				}else{
					// middle rows
					var rowForm = decodeEntities( $( '#mainrow_' + pluginUid ).val() );
					$.each( content.data , function( skey, scontent ){ 
						rowForm = rowForm.split( '_' + skey + '_' ).join( scontent.rendered );
					});
					output = output + rowForm;
				}
		});
		
		output = output + '</div> ';
		return output;
}
// called by ajaxSearchResults -> renderAjaxSearchResults_Page and renderAjaxSearchResults_Table
function decodeEntities(encodedString) {
  var textArea = document.createElement('textarea');
  textArea.innerHTML = encodedString;
  return textArea.value;
}


// 	bind by initiateFilters() onClick event of elements with name = selectFilter
function jsSetOptions( URL , optionsSuffix , searchChars , selectorId ) {
	usroption = {};
	usroption['data'] = {};
	usroption['data']['subaction'] = 'getSelectOptions';
	usroption['data']['optionsSuffix'] = optionsSuffix;
	usroption['data']['searchchars'] = searchChars;
	var selectedOpt = $( '#' + selectorId ).attr('data-val');

    var res_pid = selectorId.split('_');
	var pluginUid = res_pid[1];
	
	$.ajax({
		url : URL,
		type : 'GET',
		data: usroption,
		dataType:'json',
		success : function( returnvalue ) {
			var obj = JSON.parse( returnvalue );
			$( '#' + selectorId ).empty();

			$.each(obj.resultdata,function(key, value) 
			{
				if( value.option == selectedOpt ){
					var addSelected = ' selected="selected" ';
				}else{
					var addSelected = '';
				}
				$( '#' + selectorId ).append('<option value="' + value.option + '"' + addSelected + '>' + value.label + '</option>');
			});
            
//             "use strict";
//             var func = new Function(
//                 "return pluginAfterjsSetOptionsNr" + pluginUid + ""
//             )();
//             func( $( '#label_' + res_pid[1] + '_' + res_pid[2]  ).val() + ' und ' + $( '#' + selectorId ).val() );
            
            return true;
		},
		error : function(request,error)
		{
			if( request['status'] > 0 ){
				alert('error: ' + URL + ' Request ' + error + ': '+JSON.stringify(request));
				return false;
			}
			return true;
		}
	});
}

// called directly by onclick-event of checkbox-element in Partials/Editor/OptionGroup.html section options_groups > render_single_option
function jsUpdateFromArray( URL , ownValue , foreignValue , chk , responseId ) {
	$( '#' + responseId ).html( '...' );
	usroption = {};
	usroption['data'] = {};
	usroption['data']['ownValue'] = ownValue;
	usroption['data']['foreignValue'] = foreignValue;
	usroption['data']['selected'] = chk;

    if( !responseId ) return;
    var res_pid = responseId.split('_');
	var pluginUid = res_pid[1];
    
	$.ajax({
		url : URL,
		type : 'GET',
		data: usroption,
		dataType:'json',
		success : function(data) {
			$( '#' + responseId ).html( data.sql );
            if( chk ){
                if ( $( '#el_nm_' + data.pluginUid + '_' + foreignValue ).length ) {
                    $( '#el_nm_' + data.pluginUid + '_' + foreignValue ).fadeIn();
                }else{
                    $( '#container_nm_' + data.pluginUid  ).prepend(
                        '<span onclick="scrollToPositionInSpecBox( \'chk_' + data.pluginUid + '_' + foreignValue + '\' , \'scrollList\' );" class="pointer" id="el_nm_' + data.pluginUid + '_' + foreignValue + '">' + data.label + ', </span>' 
                    );
                }
            }else{
                if ( $( '#el_nm_' + data.pluginUid + '_' + foreignValue ).length ) {
                        $( '#el_nm_' + data.pluginUid + '_' + foreignValue ).remove();
                }
            }
			return true;
		},
		error : function(request,error)
		{
			if( request['status'] > 0 ){
				alert('error: ' + URL + ' Request ' + error + ': '+JSON.stringify(request));
				return false;
			}
			return true;
		}
	});
}

function scrollToPositionInSpecBox( target , boxId ) {
            var scrollDistance = $('#' + boxId).scrollTop() + $('#' + target).offset().top - $('#' + boxId).offset().top;
            $('#' + boxId).animate( {	scrollTop: scrollDistance - 100 } );
}


// editing tables in a list
function callAjaxFillFormFromButton(  URLtoUpdate , calledFromId , tablename , indexfield , fieldname , responseId ) {
            var value = $( '#editData' ).val();
            if( value == '' ){ return false; }
            
            if( window.confirm( fieldname  + '=' + value + ' wirklich erfassen?' ) == 0 ){ return false; }
            updateResposeId = $( '#' + calledFromId ).attr('data-answer');
            
            usroption = {};
            usroption['data'] = {};
            usroption['data']['tablename'] = tablename;
            usroption['data']['indexfield'] = indexfield;
            usroption['data']['index'] = 0;
            usroption['data']['fieldname'] = fieldname;
            usroption['data']['value'] = value;
            usroption['data']['action'] = 'insert';
            edlistAjaxUpdate( usroption , updateResposeId , calledFromId , URLtoUpdate ) ;
}

function callAjaxFillFormFromSelect( URL , calledFromId , responseId , pluginUid ) {
        var argument = $( '#' + calledFromId ).attr( 'name' ) + '=' + $( '#' + calledFromId ).val();
        var uri = URL.split('cHash');
        var realUri = uri[0] + argument + '&type=100&cnt=' + pluginUid;
        ajaxFillForm( realUri , responseId );
}
function ajaxFillForm( URI , responseId ) {
        $( '#' + responseId ).html( '<span class="blinker">...</span>' );
        
        $.ajax({
            url : URI,
            type : 'GET',
            dataType:'text',
            success : function(data) {
                $( '#' + responseId ).html( data );
                return true;
            },
            error : function(request,error)
            {
                if( request['status'] > 0 ){
                    alert('error: ' + URI + ' Request ' + error + ': '+JSON.stringify(request));
                    $( '#' + responseId ).html( 'Fehler beim Aufruf von Ajax ' );
                    return false;
                }
                return true;
            }
        });
}

function initiateEditList( tablename , indexfield , responseId , URL ) {
		$('.edit').addClass( 'pointer' );
		$('.edit').each(function (index, value) {
                var arrIndex = $(this).attr('id').split('_');
                var buttonId = 'store_' + arrIndex[1] + '_' + arrIndex[2] ;
                var abortId  = 'abort_' + arrIndex[1] + '_' + arrIndex[2] ;
                var deleteId  = 'delete_' + arrIndex[1] + '_' + arrIndex[2]  ;
				$( this ).click( function() { edlistSwitchEdit( $(this).attr('id') ,  responseId , tablename , indexfield , URL ); });
                $( '#' + buttonId ).click(function() { edlistSwitchEdit( buttonId ,  responseId , tablename , indexfield , URL ); });
                $( '#' + deleteId ).click(function() { edlistSwitchEdit( deleteId ,  responseId , tablename , indexfield , URL ); });
                $( '#' + abortId ).click(function() { edlistSwitchEdit( abortId ,  responseId , tablename , indexfield , URL ); });
		});
}
function edlistSwitchEdit( clickedId , responseId , tablename , indexfield , URL ) {
    var arrIndex = clickedId.split('_');
    var index = arrIndex[1];
    var fieldname = arrIndex[2];
    var spanId   = 'field_' + index + '_' + fieldname ;
    var buttonId = 'store_' + index + '_' + fieldname ;
    var abortId  = 'abort_' + index + '_' + fieldname ;
    var deleteId  = 'delete_' + index + '_' + fieldname  ;
    var status = $( '#' + spanId ).attr( 'data-state');
    
    // abort, end editing
    if( clickedId == abortId && status == 1 ){
        var beforeValue = $( '#' + spanId ).attr( 'data-value' );
        edlistEndEdit( clickedId , beforeValue );
        //$( '#' + responseId ).html( '<span> Aborted ' + index + '</span>' );
    }
    // delete, end editing
    if( clickedId == deleteId && status == 1 ){
            if( window.confirm( 'wirklich löschen?' ) ){
                usroption = {};
                usroption['data'] = {};
                usroption['data']['tablename'] = tablename;
                usroption['data']['indexfield'] = indexfield;
                usroption['data']['index'] = index;
                usroption['data']['value'] = $( '#input_' + index + '_' + fieldname ).val();
                usroption['data']['action'] = 'delete';
                edlistAjaxUpdate( usroption , responseId , clickedId , URL ) ;
                return true;
            }
    }
    // update, end editing
    if( clickedId == buttonId && status == 1 ){
            usroption = {};
            usroption['data'] = {};
            usroption['data']['tablename'] = tablename;
            usroption['data']['indexfield'] = indexfield;
            usroption['data']['index'] = index;
            usroption['data']['fieldname'] = fieldname;
            usroption['data']['value'] = $( '#input_' + index + '_' + fieldname ).val();
            usroption['data']['action'] = 'update';
            edlistAjaxUpdate( usroption , responseId , clickedId , URL ) ;
            return true;
    }
    // start editing
    if( clickedId == spanId && status != 1 ){
            var beforeValue = $( '#' + spanId ).attr( 'data-value' );
            edlistStartEdit( clickedId , beforeValue );
            return true;
    }
}
function edlistEndEdit( clickedId , newValue ) {
        var arrIndex = clickedId.split('_');
        var index = arrIndex[1];
        var fieldname = arrIndex[2];
        var spanId   = '#field_' + index + '_' + fieldname ;
        
        $( '#store_' + index + '_' + fieldname ).removeClass( 'save' );
        $( '#abort_' + index + '_' + fieldname ).removeClass( 'arrowleft' );
        $( '#delete_' + index + '_' + fieldname ).removeClass( 'delete' );
        $( spanId ).attr( 'data-state' , 0 );
        $( spanId ).attr( 'data-value' , newValue )
        $( spanId ).html( newValue );
        $( spanId ).addClass( 'edit' );
}
function edlistStartEdit( clickedId , newValue ) {
        var arrIndex = clickedId.split('_');
        var index = arrIndex[1];
        var fieldname = arrIndex[2];
        var spanId   = '#field_' + index + '_' + fieldname ;
        var buttonId = '#store_' + index + '_' + fieldname ;
        var abortId  = '#abort_' + index + '_' + fieldname ;
        var deleteId  = '#delete_' + index + '_' + fieldname  ;
    
        $( buttonId ).addClass( 'pointer' );
        $( buttonId ).addClass( 'save' );
        $( abortId ).addClass( 'pointer' );
        $( abortId ).addClass( 'arrowleft' );
        $( deleteId ).addClass( 'pointer' );
        $( deleteId ).addClass( 'delete' );
        $( spanId ).attr( 'data-state' , 1 );
        $( spanId ).html( '<input class="listEditInput" id="input_' + index + '_' + fieldname + '" name="data[' + index + '][' + fieldname + ']" value="' + newValue + '" />' );
        $( spanId ).removeClass( 'edit' );
}
function edlistAjaxUpdate( usroption , responseId , clickedId , URL ) {
    $.ajax({
        url : URL,
        type : 'GET',
        data: usroption,
        dataType:'json',
        success : function(data) {
			var obj = JSON.parse( data );
            
            if( obj.status == 'updated' ){
                var arrIndex = clickedId.split('_');
                var index = arrIndex[1];
                edlistEndEdit( clickedId , usroption['data']['value'] );
                $( '#' + responseId ).html( '<span> Gespeichert ' + obj.idx + '</span>' );
                
            } else if ( obj.status == 'deleted' ) {
                var arrIndex = clickedId.split('_');
                var index = arrIndex[1];
                var fieldname = arrIndex[2];
                var spanId   = '#field_' + index + '_' + fieldname ;
                edlistEndEdit( clickedId , usroption['data']['value'] );
                $( '#' + responseId ).html( '<span> Gelöscht ' + index + '</span>' );
                $( spanId ).removeClass( 'edit' );
                $( spanId ).removeClass( 'pointer' );
                $( spanId ).attr( 'id' , 'deleted_' +  $( spanId ).attr('id')  );
                $( '#row_' + index ).fadeOut(2000);
                
            } else if ( obj.status == 'inserted' ) {
                $( '#' + responseId ).html( 'Erstellt '  + obj.idx );
                $( '#editData' ).val('');
                
//                 if( window.confirm( 'neu laden?' ) == 0 ){ return false; }
                // reload form
                URL = $( '#' + clickedId ).attr('data-url');
                condition = $( '#' + clickedId ).attr('data-cond');
                updateResponseId = $( '#' + clickedId ).attr('data-updateResponse');
                var uri = URL.split('cHash');
                var realUri = uri[0] + condition ;
                ajaxFillForm( realUri , updateResponseId );
                
            }else{
                $( '#' + responseId ).html( '<span> Nicht gespeichert (' + obj.status + ')</span>' );
            }
            return true;
        },
        error : function(request,error)
        {
            if( request['status'] > 0 ){
                alert('error: ' + URL + ' Request ' + error + ': '+JSON.stringify(request));
                return false;
            }
            return true;
        }
    });
}
