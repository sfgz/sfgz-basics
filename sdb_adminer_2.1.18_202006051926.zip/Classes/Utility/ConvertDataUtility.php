<?php
namespace Sfgz\SdbAdminer\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class ConvertDataUtility
 * 
 */

class ConvertDataUtility {

	/**
	 * translateDate
	 * convert 
	 * - from form to store in db
	 * - or from DB to output in forms and lists
	 *
	 * @param string $datevalue
	 * @param string $inFormat optional, default is from german: d.m.Y
	 * @param string $outFormat optional, default is to english: Y-m-d
	 * @return mixed
	 */
	Public function translateDate( $datevalue , $inFormat = 'd.m.Y' , $outFormat = 'Y-m-d' ) {
		
		// to clear the date field we have to return the literal 'NULL', not the Boolean NULL
		if( empty($datevalue) && strtolower($outFormat) == 'y-m-d' ) return 'NULL';
		// if Value NULL and outformat is german return empty;
		if( $datevalue == 'NULL' && strtolower($outFormat) == 'd.m.y' ) return '';
		
		$separer = substr( $inFormat , 1 , 1 );
		// no dot given ergo this date value is not formatted as defined in $inFormat
		if( !strpos( $datevalue , $separer ) ) return $datevalue;
		
		$aDatetime = explode( ' ' , trim( str_replace( 'T' , ' ' , $datevalue ) ) );
		$sDate = $aDatetime[0];
		$time = count($aDatetime) >1 ? ' ' .$aDatetime[1] : '';
		
		$aDt = explode( $separer , $sDate );
		$aFt = explode( $separer , strtolower($inFormat) );
		$iFt = array_flip($aFt);
		
		$uxDate = mktime( 0 , 0 , 0 , $aDt[ $iFt['m'] ] , $aDt[ $iFt['d'] ] , $aDt[ $iFt['y'] ] );
		
		$content = date( $outFormat , $uxDate );
		
		return  $content . $time;
	}

    /**
     * integer2arrBinarys
     *
     * @param int $i eg 19
     * @return array eg [ 1=>1 , 2=>2 , 16=>16 ]
     */
    Public function integer2arrBinarys( $i )
    {
        $hasAct = [];
        // detect maximal binary eg. 4 or 8 or 16...
        for( $maxBin = 1 ; $maxBin < $i ; $maxBin *= 2 ){ /* empty body */ }
        
        // look up if incoming value matches a binary ( 1,2,4,8,16,...)
        for ( $s = $i ; $maxBin > 0 ; $maxBin /= 2 ){
                if( $s >= $maxBin ) { $hasAct[$maxBin] = $maxBin; $s -= $maxBin; }
        }
        return $hasAct;
    }

}
