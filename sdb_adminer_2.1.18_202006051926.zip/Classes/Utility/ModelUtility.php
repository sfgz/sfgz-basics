<?php
namespace Sfgz\SdbAdminer\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Core\Utility\PathUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class ModelUtility
 * 
 */

class ModelUtility {

	/**
	* @var array
	*/
	Public $settings = array();

    /**
     * flexdataUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\FlexdataUtility
     */
    protected $flexdataUtility = null;

    /**
     * sqlUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\SqlUtility
     */
    Public $sqlUtility = null;

    /**
     * fileUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\FileActionsUtility
     */
    protected $fileUtility = null;

    /**
     * sessionUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\SessionUtility
     */
    protected $sessionUtility = null;

    /**
     * convertDataUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\ConvertDataUtility
     */
    protected $convertDataUtility = null;

    /**
     * restrictionsUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\RestrictionsUtility
     */
    protected $restrictionsUtility = null;


    /**
     * constructor
     *
     * @return void
     */
    Public function __construct()
    {
			$this->flexdataUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\FlexdataUtility');
			$this->sqlUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\SqlUtility');
			$this->fileUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\FileActionsUtility');
			$this->sessionUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\SessionUtility');
			$this->convertDataUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\ConvertDataUtility');
			$this->restrictionsUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\RestrictionsUtility');
    }

    /**
     * dispatchActions
     *  called from external plugin
     * boot model with config of the calling plugin and dispatch actios
     * 
     * @param array $settings
     * @param int $callingPlugin
     * @return array
     */
    Public function dispatchActions( $settings , $callingPlugin = 0 )
    {
			if( !isset( $settings['req']['save'] ) ) return true;
			
			$this->setConfig( $settings , $callingPlugin );
			
			$bSuccess = true;
			if( $this->settings['req']['save'] == 'delete' ){
				$bSuccess = $this->deleteAction();
				
			}elseif( $this->settings['req']['save'] == 'create' ) {
				$bSuccess = $this->verifyData( true );
				if( $bSuccess ) $bSuccess = $this->createAction();

			}elseif( $this->settings['req']['save'] == 'save' ){
				$bSuccess = $this->verifyData( false );
				if( $bSuccess ) $bSuccess = $this->updateAction();
				
			}
			//elseif( $this->settings['req']['save'] == 'download' ){
			//	$bSuccess = 'download';
			//}
			
			$this->settings['dispatched'] = $bSuccess;
			
			$this->sessionUtility->setData(
				[
					'modelDispatched' => [
						$callingPlugin => [
							'error' => $this->settings['error'] , 
							'dispatched' => $this->settings['dispatched'] , 
							'runnedBy' => $settings['pluginUid'] , 
							'lastCreatedUid' => $this->settings['lastCreatedUid'] 
						]
					]
				]
			);
			
			return $this->settings['dispatched'];
			
    }

    /**
     * bootModel
     *  called from own plugin AND from Json
     *  boot model with config for actual plugin
     *  
     * @param array $settings
     * @param int $callingPlugin
     * @return void
     */
    Public function bootModel( $settings , $callingPlugin = 0 )
    {
		$this->settings = $settings;

		// get configuration for specific tt_content-uid (pluginUid)
		$sess = $this->sessionUtility->getData( 'modelDispatched' );
		$sData = $sess[$settings['pluginUid']];
		$this->settings['dispatched'] = isset( $sData['dispatched'] ) ? $sData['dispatched'] : false;
		if( isset( $sData['error']) ) $this->settings['error'] =  $sData['error'] ;
		if( isset( $sData['lastCreatedUid']) ) $this->settings['lastCreatedUid'] =  $sData['lastCreatedUid'] ;
		if( isset( $sData['sqlAction']) ) $this->settings['sqlAction'] =  $sData['sqlAction'] ;
		
		// unset session modelDispatched-data for this plugin-uid
		if( isset($sess[$settings['pluginUid']]) ){
 			unset( $sess[$settings['pluginUid']] );
 			$this->sessionUtility->setData( ['modelDispatched'=>$sess] );
		}

		$this->sqlUtility->connectToDatabase( $this->settings['dbname'] );
    }

    /**
     * setConfig
     *
     * @param array $settings
     * @param int $callingPlugin
     * @return boolean
     */
    protected function setConfig( $settings , $callingPlugin = 0 )
    {
			$this->settings = $settings;
			
			$reqPi = !empty($settings['req']['callPlugin']) ?  $settings['req']['callPlugin'] : $settings['pluginUid'];
			$this->settings['pluginUid'] = !empty($callingPlugin) ? $callingPlugin :  $reqPi ;

			if( empty( $this->settings['displayDateFormat'] ) ) $this->settings['displayDateFormat'] = 'd.m.Y';
			
			$allPiSettings = $this->flexdataUtility->getFlexformData( $this->settings['pluginUid'] );

			if( count($allPiSettings) ){
				foreach( $allPiSettings as $nam => $set ) $this->settings[$nam] = $set;
			}
			$this->settings = $this->flexdataUtility->reorganizeFlexformData( $this->settings );
			
			$this->sqlUtility->connectToDatabase( $this->settings['dbname'] );
			
			return true;
    }

    /**
     * closeDatabase
     *
     * @return void
     */
    Public function closeDatabase()
    {
		$this->sqlUtility->closeDatabase();
    }

    /**
     * triggerActionsBeforeUpdate
     *
     * @return array
     */
    Protected function triggerActionsBeforeUpdate()
    {
			$replaceValues = [];
			foreach( array_keys( $this->settings['req']['text'] ) as $editField ) {
				// could this field contain a upload-path?
				$uploadPath = $this->detectUploadPathInField( $editField );
				if( !$uploadPath ) continue;
				// detect if there was a file uploaded
				$uploadedFile = $this->fileUtility->fileHandler_upload( $editField , $uploadPath );
				if( $uploadedFile ) {
					$replaceValues[$editField] = $uploadedFile;
				}
			}
			return $replaceValues;
    }

    /**
     * triggerActionsAfterUpdate
     *
     * @return void
     */
    Protected function triggerActionsAfterUpdate()
    {
			$aFields = explode( ',' , $this->settings['editfields'] );
			foreach( $aFields as $rawEditField ){
				$editField = trim($rawEditField);
				// could this field contain a upload-path?
				$uploadPath = $this->detectUploadPathInField( $editField );
				if( !$uploadPath ) continue;
				// clean the directory - delete unused files (unlink)
				$this->fileUtility->detectUnusedFilesAndDelete( $uploadPath , $this->settings['dbname'] );
			}
    }

    /**
     * verifyData
     *  1. validate against conditions defined in database. 
     *     if empty set default or if not nullable then register error and return false.
     *  2. validate against conditions defined in flexform
     *     if not successfull register error and return false.
     *
     * @param string $forNewRecord
     * @return boolean
     */
    Protected function verifyData( $forNewRecord = false )
    {
			$this->settings['error'] = [];
			
			// 'noData'
			if( !is_array( $this->settings['req']['text'] ) || !count( $this->settings['req']['text'] ) ) {
				$this->settings['error']['recordset'] = 'Leer!';
				return false;
			}
			
			// invalidate against conditions defined in database
			$aExs = explode( ',' , $this->sqlUtility->extConf['validate_exceptions'] ); // a list like tinyint,int(1)
            $aExceptionTypes = [];
			foreach( $aExs as $strExc ){ $aExceptionTypes[trim($strExc)] = trim($strExc); }
			
			foreach( $this->settings['req']['text'] as $editField => $value ) {
					$aFieldDefaults = $this->sqlUtility->getFieldProperties( $editField , $this->settings['tablename'] , $this->settings['dbname'] );
					$trimVal = trim($value);
                    // set defaults if empty and default values defined.
                    // anyway valid if NULL is selected (IS_NULLABLE == YES). In that case any value is accepted, even '' or 0 or NULL.
					
					if( // if value is empty and not set by store-engine (auto-increment)
						empty($trimVal) && $aFieldDefaults['EXTRA'] != 'auto_increment'
					){
                        // invalid if NULL is not selected (IS_NULLABLE != YES) AND value is 0 AND wether: 
                        // - handle 0 as NULL == 1 and fieldtype is NOT at all in exceptionlist OR
                        // - handle 0 as NULL == 0 but fieldtype IS somewhere in exceptionlist
                        $bInExceptionlist = ( isset($aExceptionTypes[$aFieldDefaults['COLUMN_TYPE']]) || isset($aExceptionTypes[$aFieldDefaults['DATA_TYPE']]) ) ;
                        $zeroNotAllowed = ( $this->sqlUtility->extConf['validate_zero_as_null'] && !$bInExceptionlist ) || ( !$this->sqlUtility->extConf['validate_zero_as_null'] && $bInExceptionlist );
                        
                        // value is empty: set default or register error
						if( $forNewRecord && !empty($aFieldDefaults['COLUMN_DEFAULT']) ){
							$this->settings['req']['text'][$editField] = $aFieldDefaults['COLUMN_DEFAULT'];
							
						}elseif( $aFieldDefaults['IS_NULLABLE'] != 'YES' && ( !strlen($trimVal) || $zeroNotAllowed  ) ){
                            // field is not nullable: if !strlen('') OR ( zero (0) AND zeroNotAllowed ) then register error
							$this->settings['error'][$editField] = 'Leer!';
						
						}elseif( $aFieldDefaults['IS_NULLABLE'] == 'YES' && $zeroNotAllowed ){
							$this->settings['req']['text'][$editField] = 'NULL';
							
						}
					}
			}
			
			if( count($this->settings['error']) ) return false;
			// load restrictions from flexform and add some errors if affored. 
			
			$this->settings['error'] = $this->restrictionsUtility->verifyData( $this->settings['req']['text'] , $this->settings  );
			
			return !count($this->settings['error']) ? true : false;
    }
	
	/**
	 * buildQuery
	 * @param array $req optional
	 * @return array 
	 */
	Public function getDataFromRequest( $req )
	{
			$aResults = [];
			$this->settings['sqlRequest'] = $this->buildQueryFromRequest( $req );
			if( $this->settings['sqlRequest'] ){
				$aResults = $this->sqlUtility->runQuery($this->settings['sqlRequest']);
				// format date string for output
  				$aFieldDefaults = $this->sqlUtility->getFieldProperties( '' , $this->settings['tablename'] , $this->settings['dbname'] );
				foreach( $aResults as $ix => $row){
					foreach( $row as $fld => $cnt) { 
						$aResults[$ix][$fld] = $this->renderDisplayFieldValueByType( $cnt , $aFieldDefaults[$fld] );
					}
				}
			}else{
				$this->settings['error']['request'] = 'Leer!';
			}
			return $aResults;
    }
	
	/**
	 * buildQuery
	 * @param array $req optional
	 * @return array 
	 */
	Protected function buildQueryFromRequest( $req )
	{
		// FIELDS TO SELECT
		// default: select all (*)
		$strFieldsList = '*';
		// use editfields or fieldsdisplay as FieldsList under following circumstances
		if( $this->settings['list_type'] == 'sdbadminer_edit'  ){
			// use editfields: editor-plugin anyway
			if( $this->settings['formtype'] == 1 && !empty($this->settings[ 'editfields' ]) ) {
				$aFileds = explode( ',' , $this->settings[ 'editfields' ] );
				if( !empty($this->settings['ownkey']) ) $aFileds[] = $this->settings['ownkey'];
				if( is_array($aFileds) && count($aFileds) ){
                    $aKeFld = @array_flip($aFileds);
                    $strFieldsList =  $this->buildQuery_escapeFieldnames(  implode( ',' , array_keys($aKeFld) ) );
				}
			}
			
		}elseif( $this->settings['list_type'] == 'sdbadminer_main' ){
			// use fieldsdisplay: main-plugin when NOT templating AND fieldsdisplay not empty AND NOT as select-field pagetype=2
			if( $this->settings['pagetype'] <= 1 ){
				if( empty($this->settings['templating']) && !empty($this->settings['fieldsdisplay']) ){
                    $strFieldsList = $this->buildQuery_escapeFieldnames( $this->settings[ 'fieldsdisplay' ] );
				}
			}
		}
		// verify extended where clause in flexform FIXME sanitized by flexdataUtility->reorganizeFlexform_cases() ??
        if( $this->settings['extendwhere'] && empty($this->settings['whereclauses']) ) $this->settings['extendwhere'] = false;
        if( !$this->settings['whereclauses'] ) $this->settings['extendwhere'] = false;
        if( $this->settings['extendwhere'] == false ) $this->settings['whereclauses'] = '';
		
		$stateReturnAll = false;
		// display all not filtered: Controller Filter (in listAction pagetype:list_OR_page) AND no searchform
		if( $this->settings['list_type'] == 'sdbadminer_main' && ( !$settings['extendwhere'] && $this->settings['searchform'] == 0) ) $stateReturnAll = true;
		// no foreign field set display all
		if( !$this->settings['extendwhere'] && (empty($this->settings['ownkey']) || empty($this->settings['foreignkey']) ) ) $stateReturnAll = true;
		
		// verify request 
		$isKeyIncome = $req['searchField'] == $this->settings['foreignkey'] && $this->settings['ownkey'] && !empty($req['searchValue']);
		
        // If 'ownkey' is given: Perhaps searchValue is a field from fe_users table and NOT from request
		if( !$isKeyIncome && $this->settings['ownkey'] ){
            $feUserData = $this->sessionUtility->getFeUserData( $this->settings['foreignkey'] );
            if( $feUserData ){
                    $req['searchValue'] = $feUserData;
                    $req['searchField'] = $this->settings['foreignkey'];
                    $isKeyIncome = true;
            }
		}

		// no search-chars given OR ( searchfield does not match AND Filtermask is not choosen )
        if( !$stateReturnAll && !$this->settings['extendwhere'] && !$isKeyIncome )  return;
		
		if( $stateReturnAll && !$this->settings['extendwhere']){
			$returnValue = 'SELECT ' . $strFieldsList . ' FROM ' .  $this->settings['tablename'];
		
		}else{
            // sanitize searchValue.
            // apppend $this->settings['whereclauses']
            // filter by one defined field (ownkey)
            $strAddWhere = $this->getAdditionalWhereClauseFromFlexform( $this->settings , $req['searchField'] , $req['searchValue'] );
            
            if( $isKeyIncome ){
            
                $strOwnKeyClause = ' ' . $this->settings['ownkey'];
                if( is_numeric( $req['searchValue'] ) ){
                    $strOwnKeyClause .= '=' . $req['searchValue'];
                }else{
                    $strOwnKeyClause .= ' LIKE "'. utf8_decode(html_entity_decode( $req['searchValue'])) . '"';
                }
                if( $strAddWhere ) $strOwnKeyClause .= ' AND '  . $strAddWhere;
                $strClause = ' WHERE ' . trim($strOwnKeyClause) ;
                
            }else{
                $strClause = ' WHERE ' . $this->removeTrailingWhereCondition( $strAddWhere );
            }
            
            $returnValue = 'SELECT ' . $strFieldsList . ' FROM ' .  $this->settings['tablename'] . $strClause;
        }
		
		return $returnValue  . ';';
    }
	
	/**
	 * buildQuery_escapeFieldnames
	 * @param string $fieldNamesList
	 * @return string
	 */
	Protected function buildQuery_escapeFieldnames( $fieldNamesList )
	{
			$aMaskedFields = [];
			// remove the quotes from fieldnames if already quoted 
			$unmaskedFieldnamesList = str_replace( '`' , '' , $fieldNamesList );
			$aCnFld = explode( ',' , $unmaskedFieldnamesList );
			foreach( $aCnFld as $unmaskedFieldname ) {
                    $aMaskedFields[] = strpos( trim($unmaskedFieldname) , ' ' ) ? '`' . trim($unmaskedFieldname) . '`' : trim($unmaskedFieldname) ;
			}
            return implode( ',' , $aMaskedFields );
    }

    /**
     * getAdditionalWhereClauseFromFlexform
	 * build select-fields from SQL-Query settings.selector.1-4
     *
     * @param array $settings
     * @param string $searchField
     * @param string $searchValue
     * @return string
     */
    Public function getAdditionalWhereClauseFromFlexform( $settings , $searchField , $searchValue )
    {
            if( $settings['extendwhere'] && $settings['whereclauses'] ){
                $strAndwhere = $this->sessionUtility->replaceFeUserDataInString( $settings['whereclauses'] );
//                 return $strAndwhere;
                $strCondition = $this->replaceValueInAdditionalWhereClause( trim($strAndwhere) , $searchField , $searchValue );
                return $strCondition;
            }
    }

    /**
     * replaceValueInAdditionalWhereClause
     *
     * @param string $condition
     * @param string $searchField
     * @param string $searchValue
     * @return string
     */
    Private function replaceValueInAdditionalWhereClause( $condition , $searchField , $searchValue )
    {
                if( empty($condition) ) return;
                
                // replace single to double text-embracement
                $condition = str_replace( "'" , '"' , trim($condition) );
                
                if( !empty($condition) && !empty($searchField) && !empty($searchValue) ) {
                    // add double text-embracement if not already set
                    $q = strpos( ' ' . $condition , '"' ) ? '': '"';
                    $condition = str_replace( '_' . $searchField . '_' , $q . $searchValue . $q , $condition );
                }

                // embrace empty  _fieldnames_ with commatas if no variable found for OR statement
                if( strpos( ' ' . $condition , ' _' ) ){
                    $condition = str_replace( ' _' , 'STARTER' , $condition );
                    $condition = str_replace( '_' , '_"' , $condition );
                    $condition = str_replace( 'STARTER' , ' "_' , $condition );
                }
                
                return $condition;
    }

    /**
     * removeTrailingWhereCondition
     *  removes trailing AND and OR clause from given condition
     *  returns the condition without leading WHERE, AND and OR
     *
     * @param string $condition
     * @param array $trailingCond optional
     * @return string
     */
    Public function removeTrailingWhereCondition( $condition , $trailingCond = [ 'WHERE ' , 'AND ' , 'OR ' ] )
    {
        if( $condition && count($trailingCond) ) {
            $condition = trim($condition);
            foreach( $trailingCond as $cond ){
                if( strpos( ' ' . strtoupper( $condition ) , $cond ) == 1 ) $condition = trim( substr( $condition , strlen($cond) ) );
            }
        }
        return $condition;
    }

    /**
     * getEditFields
	 * build select-fields from SQL-Query settings.selector.1-4
     *
     * @return array
     */
    Public function getEditFields()
    {
			$aOutFields = [];
			
			// get all editfields from Flexform, detect type from table-settings in db
			$aFields = explode( ',' , $this->settings['editfields'] );
			$obsoleteChars = [ 0=>')' , 1=>'"' , 2=>"'" ];
			foreach( $aFields as $editField ){
				$aFieldProperties = $this->getFieldProperties( $editField );
				$aOutFields[$editField]['datatype'] = $aFieldProperties['DATA_TYPE'];
				$aOutFields[$editField]['value'] = $this->renderEditFieldValueByType( $aFieldProperties['COLUMN_DEFAULT'] , $aFieldProperties['fieldtype'] );
				$aOutFields[$editField]['type'] = $aFieldProperties['fieldtype'];
				$aOutFields[$editField]['label'] = $aFieldProperties['COLUMN_COMMENT'] ? $aFieldProperties['COLUMN_COMMENT'] : $editField;
				$aOutFields[$editField]['nullable'] = $aFieldProperties['nullable'];
				
				// predefine fields containing lists
				// extract option-values from lists like enum( "value1" , "value2" ) OR set( 'option1' , 'option2' )
				if( $aFieldProperties['DATA_TYPE'] == 'enum' || $aFieldProperties['DATA_TYPE'] == 'set' ){
					$aOutFields[$editField]['querytype'] = 'fielddef';
					$obsoleteChars[3] = $aFieldProperties['DATA_TYPE'] . '(';
					$strOpts = str_replace( $obsoleteChars , '' , trim($aFieldProperties['COLUMN_TYPE']) );
					$aOpts = explode( ',' , $strOpts );
					if( count($aOpts) ){
						$aOutFields[$editField]['options'] = [];
						foreach( $aOpts as $opt ) $aOutFields[$editField]['options'][$opt] = $opt;
					}
				}
				
			}

			// detect selector-fieldtypes from flexform if set
			// create select-element with options, mark selected, sort by text-Option
			$hideFollowers = 0;
			if( isset($this->settings['selector']) && is_array($this->settings['selector']) ){
				foreach( $this->settings['selector'] as $selId => $selField ){
					if( !$selField ) $hideFollowers = 1;
					if( $hideFollowers ) continue;
					if( !isset($aOutFields[$selField]) ) continue;
					
					$iFieldTypeNr = $this->settings['fieldtype'][$selId];
					if( empty($iFieldTypeNr) ) continue;
					
					$strFieldType = $this->settings['selector_fieldtypes'][ $iFieldTypeNr ];
					$aOutFields[$selField]['type'] = $strFieldType['name'];
					if( $strFieldType['source'] == 'none' ) continue;
					
					$rawQueryString = trim( trim($this->settings['options'][$selId]) , ';' );
					
					if( $strFieldType['source'] == 'ajax' ) {
						// with searchfiled: display only selected entry, later ajax does the work and imports the optionslist.
						$aOptions = [];
						$aOptions[ $aOutFields[$selField]['value'] ] = $aOutFields[$selField]['value'];

					}elseif( $strFieldType['source'] == 'flexform' ){
						// without searchfiled: get optionslist 
						$aOptions =  $this->getFieldOptionListFromString($rawQueryString);
						// if no options but there is a list in db-fielddef then copy that one
						if( !is_array($aOptions) || !count($aOptions) ) {
							if( !isset($aOutFields[$selField]['options']) )	continue;
							$aOptions = $aOutFields[$selField]['options'];
						}
						
					}
					
					$queryType = $this->flexdataUtility->detectQueryType( $rawQueryString );

					$aOutFields[$selField]['selectornr'] = $selId;
					$aOutFields[$selField]['querytype'] = $queryType;
					$aOutFields[$selField]['options'] = $aOptions;
				}
			}
			
			// add empty option if affored (only query and tables. Manual defined lists are not touched)
			foreach( $aOutFields as $selField => $aField ){
				if( isset($aField['options']) && count($aField['options']) && $aField['querytype'] != 'list' ){
					$aOutFields[$selField]['options'] = $this->addNullValueToOptionList( $aField , $aField['options'] );
				}
			}
			
			// get primary index fields if not set until here
			$aIndex = $this->sqlUtility->readPrimaryKey( $this->settings['dbname'] , $this->settings['tablename'] );
			foreach( $aIndex as $editField ) {
				if( isset($aOutFields[$editField]) ) continue;
				$aFieldProperties = $this->getFieldProperties( $editField );
				if( strpos( ' ' . $aFieldProperties['EXTRA'] , 'auto_increment' ) ) {
					$sqlLastKey = 'SELECT MAX('.$editField.') AS lastKey FROM '.$this->settings['tablename'].';';
					$aLastKey = $this->sqlUtility->runQuery($sqlLastKey);
					$rowKey = current( $aLastKey );
					$newKey = $rowKey['lastKey'] ? $rowKey['lastKey'] : 0;
					$intNewKey = ( 1 + $newKey );
					$aOutFields[$editField]['value'] = $intNewKey;
 					$aOutFields[$editField]['type'] = 'hidden';
 					$aOutFields[$editField]['label'] = $aFieldProperties['COLUMN_COMMENT'] ? $aFieldProperties['COLUMN_COMMENT'] : $editField;

				}else{
					$aOutFields[$editField]['value'] = $aFieldProperties['COLUMN_DEFAULT'];
					$aOutFields[$editField]['type'] = $aFieldProperties['fieldtype'];
					$aOutFields[$editField]['nullable'] = $aFieldProperties['IS_NULLABLE'] == 'YES' ? '1' : '';
					$aOutFields[$editField]['label'] = $aFieldProperties['COLUMN_COMMENT'] ? $aFieldProperties['COLUMN_COMMENT'] : $editField;
				}
			}
			return $aOutFields;
    }

    /**
     * addNullValueToOptionList
     *
     * @param array $aFieldProperties
     * @param array $aOptions
     * @return array
     */
    Public function addNullValueToOptionList( $aFieldProperties , $aOptions )
    {
				$aSrtOptions = [];
				if( !is_array($aOptions) || !count($aOptions) ) return $aSrtOptions;
				
// 				if( substr( $aFieldProperties['type'] , -strlen('selector') ) != 'selector' ) return $aOptions;
 				if( $aFieldProperties['type'] != 'selector' && $aFieldProperties['type'] != 'radiogroup' ) return $aOptions;
				
				$aFirst = current( $aOptions );
				$optionType = is_array($aFirst) && isset($aFirst['option']) ? 'array' : 'string';
				
				if( !isset($aOptions['']) && !isset($aOptions[0]) ) {
					if( $aFieldProperties['nullable'] ) {
						$nullOption =  substr( $aFieldProperties['datatype'] , -3 ) == 'int' ? 0 : '' ;
						$aSrtOptions[$nullOption] = $optionType == 'array' ? [ 'option' => $nullOption , 'label' =>'wählen...' ] : 'wählen...';
						
					}else{
						$aSrtOptions[0] = $optionType == 'array' ? [ 'option' => 0 , 'label' =>'wählen!' ] : 'wählen!';
					}
 				}
				if( count($aOptions) ) { foreach( $aOptions as $ix => $opt ) $aSrtOptions[$ix] = $opt; }
 				return $aSrtOptions;
    }

    /**
     * getFieldOptionListFromString
     *
     * @param string $rawQueryString
     * @return array
     */
    Public function getFieldOptionListFromString( $rawQueryString )
    {
		$aOptions = $this->detectAndRunQueryFromString( $rawQueryString );
		if( !count($aOptions) ) return $aOptions;
			$aOutFields = [];
			// first field of each option should be option-index, following fields are labels
			// loop through the array and place the keys in origin array
			foreach( $aOptions as $optRow ){
				// first field is taken as unique-key
				$optIndex = count($optRow)==1 ? current($optRow) : array_shift( $optRow );
				// implode the rest of fields
				$aOutFields[ $optIndex ] = implode( ' ' , $optRow  );
			}
			return $aOutFields;
		
    }
    

    /**
     * renderEditFieldValueByType
     *
     * @param str $value
     * @param str $type
     * @return string
     */
    Protected function renderDisplayFieldValueByType( $value , $type )
    {
        $value = trim($value , "'");
            
        if( $value == 'NULL' ) return '';
            
        switch( $type['DATA_TYPE'] ){
            
                case 'decimal':
                    return empty($value) || !is_numeric($value) ? $value : number_format( $value , $type['NUMERIC_SCALE'] , '.' , "'" );
                break;
                
                case 'float':
                    return  empty($value) ? $value : sprintf("%01." . $type['NUMERIC_SCALE'] . "f", $value );
                break;
                
                default:
                return $this->renderEditFieldValueByType( $value , $type['DATA_TYPE'] );
        }
        
    }
    

    /**
     * renderEditFieldValueByType
     *
     * @param str $value
     * @param str $type
     * @return string
     */
    Public function renderEditFieldValueByType( $value , $type )
    {
		$value = trim($value , "'");
		
		if( $value == 'NULL' ) return '';
		
		switch( $type ){
		
			case 'time':
				$shortTimeValue = substr( $value , 0 , 5 );
				return $shortTimeValue == '00:00' ? '' : $shortTimeValue;
			break;
		
			case 'date':
			case 'datetime':
			case 'timestamp':
				return $this->translateDate( $value , 'Y-m-d' , $this->settings['displayDateFormat'] );
			break;
		
			case 'tinyint':
			case 'smallint':
			case 'mediumint':
			case 'int':
			case 'bigint':
				return (int)$value;
			break;
			
			case 'decimal':
			case 'float':
			case 'double':
				return (double)$value;
			break;
			
			default:
			return $value;
		}
    }

    /**
     * sanitizeStringToDB
     *
     * @param string $strSql
     * @param string $fieldProperties
     * @return boolean
     */
    Protected function sanitizeStringToDB( $strSql , $fieldProperties )
    {
			// date / time handling
			if( substr( $fieldProperties['DATA_TYPE'] , 0 , 4 ) == 'date' ) {
				return $this->sanitize_translateDateToDb( $strSql );
			}
			if( $fieldProperties['DATA_TYPE'] == 'timestamp' ) {
				return $this->sanitize_translateDateToDb( $strSql );
			}
			
			// change integers from '' to 0
			if( substr( $fieldProperties['DATA_TYPE'] , -3 ) == 'int' && !strlen($strSql) ) return 0;
			// dont transorm integers any further
			if( is_numeric($strSql) ) return $strSql;
			
			// convert string value and add "embracement" 
// 			FIXME does not work with in : iso-8859-15 db:utf8mb4!
// 			$metaCharset = $this->sanitize_detectCharset( $strSql );
// 			if( empty($metaCharset) ) $metaCharset = $this->settings['displayCharset'] ? $this->settings['displayCharset'] : 'utf-8';
// 			$dbCharset = $fieldProperties['CHARACTER_SET_NAME'] != 'NULL' ? $fieldProperties['CHARACTER_SET_NAME'] : $metaCharset;
// 			$content = $metaCharset != $dbCharset ? iconv( $metaCharset , $dbCharset , $strSql) : $strSql;
//			HACK:
			$content = iconv( 'utf-8' , 'iso-8859-15' , $strSql);
			
			// fallback if converting not successfull
			if( empty($content) ) $content = $strSql;

			return trim($content) == 'NULL' || trim($content) == '' ? 'NULL' : '"' . str_replace( '"' , '\"' , $content ) .'"';
    }

    /**
     * sanitize_detectCharset
     *
     * @param string $rawString
     * @return boolean
     */
    Protected function sanitize_detectCharset( $rawString )
    {
		$strCharsetList = 'iso-8859-15,iso-8859-14,iso-8859-1,utf-8,utf-16,ucs2,iso-10646-ucs-2,windows-1251';
		$aCharsetList = explode( ',' , $strCharsetList );
		$strCharsetValue = '';
		foreach ($aCharsetList as $charset) {
			if( strtolower(mb_detect_encoding( $rawString , $charset , true)) == strtolower($charset) ){ // first test ok, charset is same as detected encoding
				$sample = iconv($charset, $charset, $rawString);
				if (md5($sample) == md5($rawString)) { // second test ok
					$strCharsetValue =  $charset;
					break;
				}
			}
		}
		return $strCharsetValue;
    }

	/**
	 * sanitize_translateDateToDb
	 * translate Form To Db Date
	 * convert from form to store in db
	 *
	 * @param string $datevalue
	 * @return mixed
	 */
	Private function sanitize_translateDateToDb( $datevalue ) 
	{
		$fldCnt = $this->translateDate( $datevalue , $this->settings['displayDateFormat'] , 'Y-m-d' );
		return trim($fldCnt) == 'NULL' || $fldCnt == '' ? $fldCnt : '"' . $fldCnt .'"';
    }

	/**
	 * translateDate
	 * convert 
	 * - from form to store in db
	 * - or from DB to output in forms and lists
	 *
	 * @param string $datevalue
	 * @param string $inFormat optional, default is from german: d.m.Y
	 * @param string $outFormat optional, default is to english: Y-m-d
	 * @return mixed
	 */
	Private function translateDate( $datevalue , $inFormat = 'd.m.Y' , $outFormat = 'Y-m-d' )
	{
		return $this->convertDataUtility->translateDate( $datevalue , $inFormat , $outFormat );
	}
    
    /**
     * detectAndRunQueryFromString
     *
     * @param string $rawQueryString
     * @return array
     */
    Protected function detectAndRunQueryFromString( $rawQueryString )
    {
			$aOptions = [];
			
			$queryType = $this->flexdataUtility->detectQueryType( trim($rawQueryString) );
			
			switch( $queryType ){
				case 'query':
					// get options from SQL-query
					$aOptions = $this->sqlUtility->runQuery( $rawQueryString );
					return $aOptions;
				break;
				case 'table':
					$sqlQuery = 'SELECT * FROM ' . $rawQueryString . ';';
					$aOptions = $this->sqlUtility->runQuery( $sqlQuery );
				break;
				case 'list':
					// get options from list
					$aOpts = explode( ';' , $rawQueryString );
					foreach( $aOpts as $row ) {
						$aOpt = explode( ':' , trim($row) );
						$key = trim($aOpt[0]);
						$value = count($aOpt)>1 ? trim($aOpt[1]) : $key;
						$aOptions[$key] = array( 'key' => $key , 'value' => $value );
					}
				break;
				case 'path':
					// get file list from directory
					$fixedQueryString = $this->getPathPartBetweenDocumentRootAndTypo3Root() . '/' . $rawQueryString;
					$typo3DocumentRoot = GeneralUtility::getIndpEnv('TYPO3_DOCUMENT_ROOT');
					$displayDirectory = rtrim( GeneralUtility::getFileAbsFileName( $typo3DocumentRoot . $fixedQueryString ) , '/' );
					
					if( !file_exists($displayDirectory) ) break;
					
					$partlyPath = rtrim( trim($rawQueryString) , '/' ) . '/';
					foreach ( glob( $displayDirectory . '/*.*' ) as $filename ) {
						$basename = pathinfo( $filename , PATHINFO_BASENAME );
						$aOptions[$partlyPath . $basename] = array( 'key' => $partlyPath . $basename , 'value' =>  $basename );
					}
				break;
			}

			return $aOptions;
    }
    
    /**
     * detectUploadPathInField
     *  used by triggerActionsBeforeUpdate and triggerActionsAfterUpdate
     *
     * @param string $selField
     * @return string with /relativePath OR false
     */
    Protected function detectUploadPathInField( $selField )
    {
			if( empty($selField) ) return false;
 			if( !isset($this->settings['selector']) || empty($this->settings['selector']) ) return false;
			
			$selId = array_search( $selField , $this->settings['selector'] );
			
			if( !isset($this->settings['selector'][$selId]) || $this->settings['selector'][$selId] != $selField ) return false;
			$rawQueryString = trim($this->settings['options'][$selId]);
			if( 'path' != $this->flexdataUtility->detectQueryType( $rawQueryString ) ) return false;
			
			// get full filename just to test if it exists
			$fixedQueryString = $this->getPathPartBetweenDocumentRootAndTypo3Root() . '/' . $rawQueryString;
			$typo3DocumentRoot = GeneralUtility::getIndpEnv('TYPO3_DOCUMENT_ROOT');
			$displayDirectory = GeneralUtility::getFileAbsFileName( $typo3DocumentRoot . $fixedQueryString  );
			if( !file_exists( $displayDirectory ) ) return false;

			return rtrim( $rawQueryString , '/') ;
    }

    /**
     * getPathPartBetweenDocumentRootAndTypo3Root
     * fix path below documentRoot and return the trailing part
     *
     * @param string $rawQueryString
     * @return array
     */
    Protected function getPathPartBetweenDocumentRootAndTypo3Root()
    {
			$typo3DocumentRoot = rtrim( GeneralUtility::getIndpEnv('TYPO3_DOCUMENT_ROOT') , '/' );
			$realpathToDocument = rtrim( realpath('') , '/' );
			$t3dpLen = strlen( $typo3DocumentRoot );
			$realLen = strlen( $realpathToDocument );
			
			if( $t3dpLen >= $realLen ) return '';
			$diff = $realLen - $t3dpLen;
			return substr( $realpathToDocument , -$diff ); // e.g. /databases
    }

    /**
     * readPrimaryKey
     *
     * @param str $dbname
     * @param str $tablename
     * @return array
     */
    Public function readPrimaryKey( $dbname , $tablename )
    {
			$this->sqlUtility->connectToDatabase( $dbname );
			$ownkey = $this->sqlUtility->readPrimaryKey( $dbname , $tablename , true );
			$this->sqlUtility->closeDatabase();
			return $ownkey;
    }

    /**
     * getFieldProperties
     *
     * @param str $editField optional, returns all if empty
     * @return array
     */
    Public function getFieldProperties( $editField = '' )
    {
			return $this->sqlUtility->getFieldProperties( $editField , $this->settings['tablename'] , $this->settings['dbname'] );
    }

    /**
     * runQuery
     *
     * @param str $queryString
     * @param str $dbname
     * @return array
     */
    Public function runQuery( $queryString , $dbname )
    {
			$this->sqlUtility->connectToDatabase( $dbname );
			$qResult = $this->sqlUtility->runQuery( $queryString );
			$this->sqlUtility->closeDatabase();
			return $qResult;
    }

    /**
     * createAction
     *
     * @return boolean
     */
    Protected function createAction()
    {
			$bSuccess = false;
			
			// catch filenames, if submitted
			$replaceValues = $this->triggerActionsBeforeUpdate();
			
			// build sql statement, $replaceValues path for filename if affored
			$sqlAdd = $this->sqlCreate( $replaceValues );
			if( !$sqlAdd ) return $bSuccess;
			$this->settings['sqlAction'] = $sqlAdd;
			
			// try to reset uid - only neccessary if new records was deleted right after building them
			$lastUid = $this->sqlGetLastCreatedUid( $this->settings['req']['searchField'] , $this->settings['tablename'] );
			if( is_numeric($lastUid) ) { $lastUid += 1; }else{  $lastUid = 1; }
			$this->sqlUtility->execQuery( 'ALTER TABLE ' . $this->settings['tablename'] . ' AUTO_INCREMENT = ' . $lastUid );
			
			// try to execute the query
			$bSuccess = $this->sqlUtility->execQuery( $sqlAdd );
			
			if( $bSuccess ){
				$lastUid = $this->sqlGetLastCreatedUid( $this->settings['req']['searchField'] , $this->settings['tablename'] );
			}else{
				$lastUid = 0;
			}

			//  detect new uid if query was successfull executed
			$this->settings['lastCreatedUid'] = $lastUid;
			
			return $bSuccess;
    }

    /**
	 * sqlGetLastCreatedUid
     *
     * @param string  $editField
     * @param string  $tablename
     * @return array
     */
    Protected function sqlGetLastCreatedUid( $editField , $tablename )
    {
			if( trim($editField) == '' || trim($tablename) == '' ) return 0;
			$sqlLastKey = 'SELECT MAX(' . $editField . ') AS lastKey FROM ' . $tablename . ';';
			$aLastKey = $this->sqlUtility->runQuery($sqlLastKey);
			$rowKey = is_array($aLastKey) ? current( $aLastKey ) : [];
			return isset($rowKey['lastKey']) ? $rowKey['lastKey'] : 0;
    }

    /**
     * sqlCreate
     *
     * @param array $replaceValues formatted as [ fieldname => value ]
     * @return string
     */
    Protected function sqlCreate( $replaceValues = [] )
    {
			// get updatable fields
			$aInputFields = $this->settings['req']['text'];
			
			// get field properties
			$this->sqlUtility->readFieldnamesSeparePrimary( $this->settings['dbname'] , $this->settings['tablename'] );
			foreach( $this->sqlUtility->info['fields'] as $editField ) {
					
					$aFieldProperties[$editField] = $this->getFieldProperties( $editField );
					
					if( !isset($aInputFields[$editField]) && $aFieldProperties[$editField]['EXTRA'] == 'on update CURRENT_TIMESTAMP' ){
							$aInputFields[$editField] = date( 'Y-m-d H:i:s' ) ;
					}
					
			}
			
			$values = [];
			foreach( $aInputFields  as $editField => $content ){
					
					if( $aFieldProperties[$editField]['EXTRA'] == 'auto_increment' ) {
 							continue;//FIXME dont work- wanna no key if auto_increment
							$sqlLastKey = 'SELECT MAX('.$editField.') AS lastKey FROM '.$this->settings['tablename'].';';
							$aLastKey = $this->sqlUtility->runQuery($sqlLastKey);
							$rowKey = current( $aLastKey );
							$values[$editField] = ( 1 + $rowKey['lastKey'] );
					}else{
							if( isset($replaceValues[$editField]) ) $content = $replaceValues[$editField];
							$values[$editField] = $this->sanitizeStringToDB( $content , $aFieldProperties[$editField]  ); 
					}
			}
			$strKeys = implode( ', ' , array_keys( $values ) );
			$strValues = implode( ', ' ,  $values  );
			$aSqlAdd = 'INSERT INTO ' . $this->settings['tablename'] . ' (' . $strKeys . ') VALUES (' . $strValues . '); ';
			
			return $aSqlAdd;
    }

    /**
     * updateAction
     *
     * @return boolean
     */
    Protected function updateAction()
    {
			$replaceValues = $this->triggerActionsBeforeUpdate();
			
			$sqlEdit = $this->sqlUpdate($replaceValues);
			if( !$sqlEdit ) return false;
			
			$this->settings['sqlAction'] = $sqlEdit;
			$result = $this->sqlUtility->execQuery( $sqlEdit );

			if( $result ) $this->triggerActionsAfterUpdate();
			return $result;
			
    }

    /**
     * sqlUpdate
     *
     * @param array $replaceValues formatted as [ fieldname => value ]
     * @return string
     */
    Protected function sqlUpdate( $replaceValues = [] )
    {
			// get field properties
			// get input values
			$fieldRec = [];
			foreach( $this->settings['req']['text'] as $editField => $value ) {
				// replace value, if replacement is defined (eg. for new path/filenames)
				if( isset($replaceValues[$editField]) ) $value = $replaceValues[$editField];
				$aFieldProperties[$editField] = $this->getFieldProperties( $editField );
				$fieldRec[] = $editField . ' = ' . $this->sanitizeStringToDB( $value , $aFieldProperties[$editField] );
			}
			if( !count($fieldRec) ) return false;
			
	//		$searchField = $this->sqlUtility->readPrimaryKey( $this->settings['dbname'] , $this->settings['tablename'] , true );
			$searchField = $this->settings['ownkey'];
			
			// glue all together
			$sqlEdit = 'UPDATE ' . $this->settings['tablename'] . ' SET ';
			$sqlEdit .= implode( ', ' , $fieldRec );
			$sqlEdit .= ' WHERE ' . $searchField . '=' . $this->sanitizeStringToDB($this->settings['req']['searchValue'] , $aFieldProperties[$searchField]) . ';';
			return $sqlEdit;
    }

    /**
     * deleteAction
     *
     * @return boolean
     */
    Protected function deleteAction()
    {
			$sqlDel = $this->sqlDelete();
			if( !$sqlDel ) return false;
			$this->settings['sqlAction'] = $sqlDel;
			$result = $this->sqlUtility->execQuery( $sqlDel );
			if( $sqlDel ) $result = $this->sqlUtility->execQuery( $sqlDel );
			
			if( $result ) $this->triggerActionsAfterUpdate(); 
			return $result;
    }

    /**
     * sqlDelete
     *
     * @return string
     */
    Protected function sqlDelete()
    {
			return 'DELETE FROM ' . $this->settings['tablename'] . ' WHERE ' . $this->settings['req']['searchField'] . '="' . $this->settings['req']['searchValue'] . '";';
    }
    

}
