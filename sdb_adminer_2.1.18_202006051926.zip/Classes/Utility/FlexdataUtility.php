<?php
namespace Sfgz\SdbAdminer\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Core\Database\ConnectionPool;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class FlexdataUtility
 * 
 */

class FlexdataUtility {

    /**
     * sqlUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\SqlUtility
     */
    protected $sqlUtility = null;

    /**
     * extensionLcKey
     *
     * @var string
     */
    Private $extensionLcKey = 'sdbadminer';

    /**
     * constructor
     *
     * @return void
     */
    public function __construct()
    {
			$this->sqlUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\SqlUtility');
    }
    
    /**
     * readPrimaryKey
     *
     * @param str $dbname
     * @param str $tablename
     * @return array
     */
    Private function readPrimaryKey( $dbname , $tablename )
    {
			$this->sqlUtility->connectToDatabase( $dbname );
			$ownkey = $this->sqlUtility->readPrimaryKey( $dbname , $tablename , true );
			$this->sqlUtility->closeDatabase();
			return $ownkey;
    }

    /**
     * getLinkFields
     * returns fieldnames that should displayed as links
     *
     * @param str $strLinkfields
     * @return array
     */
    Public function getLinkFields( $strLinkfields )
    {
			$aLinkFields = [];
			$linkFieldList = explode( ',' , $strLinkfields );
			if( !count($linkFieldList) ) return $aLinkFields;
			
			foreach( $linkFieldList as $fld ) {
				$fieldname = trim($fld);
				if( !empty($fieldname) ) $aLinkFields[$fieldname] = $fieldname;
			}

			return $aLinkFields;
    }
    
    /**
     * detectQueryType
     *
     * @param string $rawQueryString
     * @return string
     */
    Public function detectQueryType( $rawQueryString )
    {
			// get options from SQL-query
			if( substr($rawQueryString , 0 , strlen('SELECT') ) == 'SELECT' )  return 'query';
			
			// get options from list
			if(  strpos( ' ' . $rawQueryString  , ';' ) ) return 'list';

			// get file list from directory
			if( 0 === strpos( $rawQueryString , 'fileadmin/' ) ) return 'path';
			
			// default fallback: get options from view- or tablename
			return 'table';
    }

    /**
     * getFieldsContainingSpecificFilePath
     *  used to clear directory 
     *  by fileActionsUtility->detectUnusedFilesAndDelete()
     *  
     *  searches in tables for fields with given directory
     *  if the fieldname is defined by a plugin
     *
     * @param string $filePath optional, on default returns all
     * @return array empty or formatted as $fieldsList[ table => [ fieldame1 => partlyPath1  ] ]
     */
	Public function getFieldsContainingSpecificFilePath( $filePath = '' ) {
			$fieldsList = [];
			
			// get all plugins if there are some
			$aFlexdataDb = $this->getFlexdataByPluginName( 'sdbadminer_edit' );
			if( !count($aFlexdataDb) ) return $fieldsList;
			
			// loop through all plugins
			foreach( $aFlexdataDb as $settings ){
				
				// detect if any edit-fields are defined
				$edFieldList = explode( ',' , $settings['editfields'] );
				if( !count($edFieldList) ) continue;
				
				// detect if any selector-fields defined
				if( !isset($settings['selector']) || !count($settings['selector']) ) continue;
				
				// loop through all selector-fields and look up for path-segments matching with given $filePath
				foreach( $settings['selector'] as $ix => $selField ){
						// verify the field is a edit-field AND defined as selector
						if( !$selField || NULL === array_search( $selField , $edFieldList ) ) continue;
						// verify fieldcontent is a valid path-segment
						$partlyPath = trim($settings['options'][$ix]);
						if(  $this->detectQueryType( $partlyPath ) != 'path' ) continue;
						if( !empty($filePath) && trim( $filePath , '/' ) != trim( $partlyPath , '/' ) ) continue;
						// store tablename and fieldname with path-segment 
						$fieldsList[ $settings['tablename'] ][ $selField ] = rtrim( $partlyPath , '/' );
				}
			}
			return $fieldsList;
	}

    /**
     * getFirstPluginUidOnPage
     *
     * @param int $pid
     * @return int
     */
	Public function getFirstPluginUidOnPage($pid) {
		$aFields = ['uid','colPos','sorting'];
		$aWhere = ['pid' => $pid , 'CType' => 'list' , 'list_type' => 'sdbadminer%' , 'deleted' => 0 , 'hidden' => 0 ];
	  
		$rows = $this->sqlSelectQuery( $aFields , $aWhere )->orderBy('colPos')->addOrderBy('sorting')->execute()->fetchAll();
		$firstRow = current($rows);
		return $firstRow['uid'];
  
	}
    
    /**
     * isCallerDescendant
     *
     * @param int $uidActual
     * @param int $uidCaller
     * @return boolean
     */
	Public function isCallerDescendant( $uidActual , $uidCaller )
	{ 
	  // if one of $piConf[ $uidActual ]['linkfields'] is like $piConf[ $uidCaller ]['foreignkey'] then caller is child of actual
		$getChildrenByParent = $this->getChildrenByParent( $uidActual );
		if( $getChildrenByParent ) return isset($getChildrenByParent[$uidActual][$uidCaller]) ;
		return false;
	}
    
    /**
     * getChildrenByParent
     *
     * @param int $uidActual
     * @return array
     */
	Private function getChildrenByParent( $uidActual )
	{
		$pid = $this->getPageOfPlugin( $uidActual );
		$aAllPlugins = $this->getAllPluginsFromPage( $pid , '' );

		$getChildrenByParent = []; 
		if( !count($aAllPlugins) ) return false ;
		
		$piLinkfields = [];
		foreach( $aAllPlugins as $parentPid => $piSettings ){
			$aLinkFields = $this->getLinkFields( $piSettings['linkfields'] );
			foreach( $aLinkFields as $fieldname ) $piLinkfields[ $fieldname ][ $parentPid ] = $parentPid;
		}
		foreach( $aAllPlugins as $childUid => $piSettings ){
			if( !isset($piLinkfields[ $piSettings['foreignkey'] ]) ) continue;
			foreach( $piLinkfields[ $piSettings['foreignkey'] ] as $parentPid ){
				if( $parentPid != $childUid ) $getChildrenByParent[ $parentPid ][ $childUid ] = $childUid;
			}
		}
		if( !count($getChildrenByParent) ) return false ;
		
		// set grandchildren and descendants
		foreach( $getChildrenByParent as $parentPid => $row ){
			foreach( $row as $childUid ) {
				if( isset( $getChildrenByParent[ $childUid ] ) ){
					foreach( $getChildrenByParent[ $childUid ] as $grandchildUid ){
						if( !isset($aAllPlugins[$grandchildUid]) ) continue;
						// set grandchildren
						if( $parentPid == $grandchildUid ) continue;
						$getChildrenByParent[ $parentPid ][ $grandchildUid ] = $grandchildUid;
						if( isset($getChildrenByParent[ $grandchildUid ]) ){
							foreach( $getChildrenByParent[ $grandchildUid ] as $descendantUid ){
								if( !isset($aAllPlugins[$descendantUid]) ) continue;
								// set descendants
								if( $parentPid != $descendantUid ) $getChildrenByParent[ $parentPid ][ $descendantUid ] = $descendantUid;
							}
						}
						
					}
				}
			}
		}
		return $getChildrenByParent ;
	}
    
    /**
     * getPageOfPlugin
     *
     * @param int $uidActual
     * @return int
     */
	Public function getPageOfPlugin( $uidActual ) {
	  $statement = $this->sqlSelectQuery( ['pid'] ,  ['uid'=>$uidActual]  )->execute();
		while ($row = $statement->fetch()) {
			$pid = $row['pid'];
			break;
		}	  
	  return $pid;
    }
    
    /**
     * getAllPluginsFromPage
     *  used in FilterController->clearSession()
     *
     * @param int $pid
     * @param str $pluginName
     * @return array
     */
	Public function getAllPluginsFromPage( $pid , $pluginName = '' ) {
		
		$statement = $this->sqlSelectQuery( ['uid','colPos','sorting'] , [
				'pid'=>[ 'val' => $pid ], 
				'list_type'=>[ 'val' => $this->extensionLcKey . '_' . strtolower( $pluginName ) . '%' , 'op'=>'and' ] , 
				'deleted'=>[ 'val' => 0 , 'op'=>'and' ] , 
				'hidden'=>[ 'val' => 0 , 'op'=>'and' ] 
		] )->execute();
 		
 		$aSort = [];
		while ($row = $statement->fetch()) {
			$aSort[ $row['colPos'] ][ $row['sorting'] ] = $row;
		}	  
		
	  
 	  $piConf = [];
	  
	  if( !count($aSort) ) return $piConf;
	  ksort($aSort);
	  foreach($aSort as $colNr => $colRows ){
			ksort($colRows);
			foreach($colRows as $srtNr => $row ){
				$fullconf = $this->getFlexformData( $row['uid'] );
				$piConf[ $row['uid'] ] = $fullconf;
			}
	  }

	  return $piConf;
	  
	}

    /**
     * setExtensionLcKey
     *
     * @param string $extensionLcKey
     * @return void
     */
    Public function setExtensionLcKey( $extensionLcKey )
    {
        $sthis->extensionLcKey = $extensionLcKey;
	}

    /**
     * getExtensionLcKey
     *
     * @return string
     */
    Public function getExtensionLcKey()
    {
        return $sthis->extensionLcKey;
	}

    /**
     * reorganizeFlexformData
     *  clean out not used fields
     *  used fields are defined by fields set in selector 1-5
     *
     * @param array $settings
     * @return array reorganized settings
     */
    Public function reorganizeFlexformData( $settings )
    { 
		
 		$settings = $this->reorganizeFlexform_cases( $settings );
		$settings = $this->reorganizeFlexform_editfields( $settings );
		$settings = $this->reorganizeFlexform_pageRelations( $settings );
		
		return $settings;
	}

    /**
     * reorganizeFlexform_cases
     *  clean out not used fields
     *  used fields are defined by fields set in selector 1-5
     *
     * @param array $settings
     * @return array reorganized settings
     */
    Private function reorganizeFlexform_cases( $settings )
    { 
			if(
				( $settings['list_type'] == 'sdbadminer_edit' && $settings['formtype']  < 2 ) || 
				( $settings['list_type'] == 'sdbadminer_main' && $settings['searchform']  < 2 ) || 
				!isset($settings['ownkey']) || empty($settings['ownkey'])
			){
				$this->sqlUtility->connectToDatabase( $settings['dbname'] );
				$settings['ownkey'] = $this->sqlUtility->readPrimaryKey( $settings['dbname'] , $settings['tablename'] , true );
				$this->sqlUtility->closeDatabase();
			}
			
			// sanitize extended where clause in flexform
            if( $settings['extendwhere'] && empty($settings['whereclauses']) ) $settings['extendwhere'] = false;
            if( !$settings['extendwhere'] ) $settings['whereclauses'] = '';
			
			return $settings;
	}

    /**
     * reorganizeFlexform_editfields
     *  clean out not used fields
     *  used fields are defined by fields set in selector 1-5
     *
     * @param array $settings
     * @return array reorganized settings
     */
    Private function reorganizeFlexform_editfields( $settings )
    { 
			$usedFields = [];
			$edFieldList = explode( ',' , $settings['editfields'] );
			if( !count($edFieldList) ) return $settings;
			foreach($edFieldList  as $ix=>$fld) $usedFields[$ix+1] = trim($fld);
			
			// fieldtype is used for plugin-specific (own) edit field-conf. flexform-fields 'selector' and 'options' depending on fieldtype
			// catchtofield is used for values in new records. flexform-fields 'catchfromfield' and 'catchbutton' depending on catchtofield
			$aControlFieldnames = [
				'fieldtype' => [ 'selector' , 'options' ] ,
				'catchtofield' => [ 'catchfromfield' , 'catchbutton' ],
				'restrictfield' => [ 'restriction' , 'condition' ]
			];
			
			foreach( $aControlFieldnames as $mainField => $aSubFields ){
				if( !isset($settings[$mainField]) || !count($settings[$mainField]) ) continue;
				$hideFollowers = 0;
				foreach( $settings[$mainField] as $ix => $selField ){
					if( !$selField ) $hideFollowers = 1;
					// clean eg fieldname in settings['fieldtype']['selector'][1] and settings['fieldtype']['options'][1]
					if( $hideFollowers ) foreach( $aSubFields as $subFieldName ) unset($settings[$subFieldName][$ix]);
					//FIXME on ajax call the array $usedFields[$selField] is not set! clean only if $hideFollowers is true
					//without ajax: 
					// if( $hideFollowers || !isset($usedFields[$selField]) ) unset($settings[$mainField][$ix]);
					if( $hideFollowers  ) unset($settings[$mainField][$ix]);
				}
				foreach( $aSubFields as $subFieldName ) {
					if( isset($settings[$subFieldName]) && !count($settings[$subFieldName]) ) unset($settings[$subFieldName]);
				}
				if( isset($settings[$mainField]) && !count($settings[$mainField]) ) unset($settings[$mainField]);
			}
			
			return $settings;
	}
    
    /**
     * reorganizeFlexform_pageRelations
     *   seek in target-page if field 'target' is set 
     *   if it is so, then change behavior when links are built in view
     *  
     *
     * @param array $settings
     * @return array reorganized settings
     */
    Private function reorganizeFlexform_pageRelations( $settings )
    { 
			$settings['target'] = '';
			$settings['section'] = 'c'.$settings['pluginUid'];
			
			if( empty($settings['topage']) ) {
                $settings['topage'] = $settings['pagePid'];
                
			}else{
                $toPluginUid = $settings['topage'];
                // detect target-settings of the targeting page
                $queryBuilderCnt = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable('tt_content');
                $queryBuilderCnt->getRestrictions()->removeAll();		
                $queryBuilderCnt->select(...['pid'])->from('tt_content');
                $restrictedStatement = $this->appendWhereParts( ['uid' => $toPluginUid  ] , $queryBuilderCnt );
                $rows = $restrictedStatement->execute()->fetchAll();
                if( !is_array($rows) || !count($rows) ) {
                    $settings['topage'] = $settings['pagePid'];
                }else{
                    $firstRow = current($rows);
                    $settings['section'] = 'c'.$toPluginUid;
                    $settings['topage'] = $firstRow['pid'];
                }
			}
			
			// dont set target if on same page
			if( $settings['topage'] == $settings['pagePid'] ) return $settings;
			
			// detect target-settings of the targeting page
            $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable('pages');
            $queryBuilder->getRestrictions()->removeAll();		
            $queryBuilder->select(...['target'])->from('pages');
            $restrictedStatement = $this->appendWhereParts( ['uid' => $settings['topage']  ] , $queryBuilder );
			$rows = $restrictedStatement->execute()->fetchAll();
            
            // test if there are target settings like 100x200
            if( !is_array($rows) || !count($rows) ) return $settings;
            $firstRow = current($rows);
            
            if( !is_numeric( substr( $firstRow['target'] , 0 , 1 ) ) ) return $settings;
            if( !strpos( strtolower($firstRow['target']) , 'x') ) return $settings;
            
            // if correct target-setting then open page in a new window
            $aTargetFull = explode( ' ' , strtolower($firstRow['target']) );
            $aTargetDim = explode( 'x' , $aTargetFull[0] );
            $settings['target'] = 'width=' . $aTargetDim[0] . ',height=' . $aTargetDim[1] ;
            return $settings;
	}
    
    /**
     * getFlexdataByPluginName
     *
     * @param string $pluginName
     * @return array
     */
	Private function getFlexdataByPluginName( $pluginName = 'sdbadminer_edit' ) {
		
		$statement = $this->sqlSelectQuery( ['uid'] , [
				 'list_type' => [ 'val' => $pluginName ] , 
				 'deleted'   => [ 'val' => 0 , 'op'=>'and' ]  , 
				 'hidden'    => [ 'val' => 0 , 'op'=>'and' ] 
		] )->execute();
		
		$aPiList = [];
		while ($row = $statement->fetch()) {
			$aPiList[ $row['uid'] ] = $this->getFlexformData( $row[ 'uid' ] );
		}	  
	  
	  return $aPiList;
	  
	}

    /**
     * getFlexformData
     *  used by ModelUtility->setConfig()
     *
     * @param int $uid
     * @return array
     */
    Public function getFlexformData($uid)
    {
		$row = $this->sqlSelectQuery( ['pi_flexform' , 'list_type' , 'pid' , 'header' , 'subheader' , 'colPos' ] , [ 'uid'=>['val'=>$uid] ] )->execute()->fetch();
		$flexformData = GeneralUtility::xml2array($row['pi_flexform']);

		$foreignFlexform = array();
		$abstractPlugin = new \TYPO3\CMS\Frontend\Plugin\AbstractPlugin();
		if( isset($flexformData['data']) && is_array($flexformData['data']) && count($flexformData['data']) ){
			foreach ( $flexformData['data'] as $sheet => $data ) {
				if( is_array($data) && count($data) ){
					foreach ( $data as $lang => $value ) {
						if( is_array($value) && count($value) ){
							foreach ( $value as $key => $val ) {
								$strContent = $abstractPlugin->pi_getFFvalue($flexformData, $key, $sheet);
 								$execCommand = '$foreignFlexform["' . str_replace( '.' , '"]["' , $key ) . '"]=$strContent; ';
								eval( $execCommand );
							}
						}
					}
				}
			}
		}
		$foreignFlexformSettings = $foreignFlexform['settings'];
		$foreignFlexformSettings['pagePid'] = $row['pid'];
		$foreignFlexformSettings['pluginUid'] = $uid;
		$foreignFlexformSettings['list_type'] = $row['list_type'];
		$foreignFlexformSettings['header'] = $row['header']; // FIXME affored only by Sfgz\SdbTransfer\Utility->PluginsUtility::class
		$foreignFlexformSettings['subheader'] = $row['subheader']; // FIXME affored only by Sfgz\SdbTransfer\Utility->PluginsUtility::class
		$foreignFlexformSettings['colPos'] = $row['colPos']; // FIXME affored only by Sfgz\SdbTransfer\Utility->PluginsUtility::class
// 		$foreignFlexformSettings['pi_flexform'] = $row['pi_flexform']; // FIXME affored only by Sfgz\SdbTransfer\Utility->PluginsUtility::class

	    return $foreignFlexformSettings;
    }

    /**
     * sqlSelectQuery
     *
     * @param array $aFields 1-dim
     * @param array $aWhere  optional 1-dim
     * @param array $aOrder  optional 1-dim
     * @return \TYPO3\CMS\Core\Database\ConnectionPool
     */
    Protected function sqlSelectQuery( $aFields , $aWhere = [] , $aOrder = [] )
    {
		if( !count($aFields) ) return false;
		
		$queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable('tt_content');
		$queryBuilder->getRestrictions()->removeAll();		
		// collect fields and append to $queryBuilder
		$queryBuilder->select(...$aFields)->from('tt_content');
		if( !count($aWhere) ) return $queryBuilder;

		$restrictedStatement = $this->appendWhereParts( $aWhere , $queryBuilder );
		if( !count($aOrder) ) return $restrictedStatement;
		
		return $restrictedStatement->orderBy($aOrder[0]);
		
    }

    /**
     * appendWhereParts
     *
     * @param array $aWhere  1-dim
     * @param \TYPO3\CMS\Core\Database\ConnectionPool $queryBuilder
     * @return \TYPO3\CMS\Core\Database\ConnectionPool
     */
    Private function appendWhereParts( $aWhere , $queryBuilder )
    {
		// collect where and create $restrictedStatement
		$isFirst = current(array_keys($aWhere));
		$phpExec = '$restrictedStatement = $queryBuilder';
		foreach( $aWhere as $fieldname => $aCompare ){
			$phpExec .= '->';
			if( $isFirst == $fieldname){
				$operator = 'where';
			}else{
				if( is_array($aCompare) && isset( $aCompare['op'] ) ){
					$operator = trim(strtolower($aCompare['op'])) . 'Where';
				}else{
					$operator = 'andWhere';
				}
			}
			$value = is_array($aCompare) && isset($aCompare['val']) ? $aCompare['val'] : $aCompare;
			$phpExec .= $operator.'( $this->getSingleWhere( "' . $fieldname . '" , "' . $value . '" , $queryBuilder ) )';
		}
		eval( $phpExec . ';' );
		
		return $restrictedStatement;
	}

    /**
     * getSingleWhere
     *
     * @param string $strField
     * @param string $strValue
     * @param \TYPO3\CMS\Core\Database\ConnectionPool $queryBuilder
     * @return void
     */
    Private function getSingleWhere( $strField , $strValue , $queryBuilder )
    {
			if( is_numeric($strValue) ){
				return $queryBuilder->expr()->eq($strField, $queryBuilder->createNamedParameter( $strValue , \PDO::PARAM_INT ));
			}else{
				return $queryBuilder->expr()->like($strField, $queryBuilder->createNamedParameter( $strValue ) );
			}
	}

}
