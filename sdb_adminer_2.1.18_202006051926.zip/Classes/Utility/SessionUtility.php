<?php
namespace Sfgz\SdbAdminer\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class SessionUtility
 * 
 */

class SessionUtility {

	/**
	* @var string
	*/
	Private $sessionKey = 'SdbAdminer';
	
	
    /**
     * setSessionKey
     *
     * @param string $newSessionKey 
     * @return void
     */
    public function __construct( $newSessionKey = '' )
    {
                $this->setSessionKey( $newSessionKey ) ;
    }


    /**
     * setSessionKey
     *
     * @param string $newSessionKey 
     * @return void
     */
    public function setSessionKey( $newSessionKey )
    {
			if( $newSessionKey ) $this->sessionKey = $newSessionKey;
    }

    /**
     * getData
     *
     * @param int $piUid optional default is empty
     * @return void
     */
    public function getData( $piUid = '' )
    {
		$settings_useroptions = [];
		$userObj = $GLOBALS['TSFE']->fe_user;
		if( $userObj ){
			$settings_useroptions = $userObj->getKey('ses', $this->sessionKey );
		}
		if( $piUid ){
			return isset($settings_useroptions[$piUid]) ? $settings_useroptions[$piUid] : '' ;
		}
		return $settings_useroptions ;
		
    }

    /**
     * resetData
     *
     * @param int $piUid
     * @return void
     */
    public function resetData( $piUid = 0 )
    {
		$userObj = $GLOBALS['TSFE']->fe_user;
		if( $userObj ){
				if( $piUid ){
					$settings_useroptions = $userObj->getKey('ses', $this->sessionKey);
					$settings_useroptions[$piUid] = [];
				}else{
					$settings_useroptions = [];
				}
				$userObj->setKey("ses",$this->sessionKey, $settings_useroptions );
				$userObj->sesData_change = true;
				$userObj->storeSessionData();
		}
    }

    /**
     * setData
     *
     * @param array $aData
     * @return void
     */
    public function setData( $aData )
    {
		$userObj = $GLOBALS['TSFE']->fe_user;
		if( $userObj ){
			$settings_useroptions = $userObj->getKey('ses', $this->sessionKey);
			if( is_array($aData) && count($aData) ){
				foreach( $aData as $piUid => $value ){
					if( is_array($value) ){
						foreach( $value as $field => $cnt ){
							if( is_array($cnt) ){
								foreach( $cnt as $pos => $chr ) $settings_useroptions[$piUid][$field][$pos] = $chr;
							}else{
								$settings_useroptions[$piUid][$field] = $cnt;
							}
						}
					}else{
						$settings_useroptions[$piUid] = $value;
					}
				}
				$userObj->setKey("ses",$this->sessionKey, $settings_useroptions);
				$userObj->sesData_change = true;
				$userObj->storeSessionData();
			}
		}
    }

    /**
     * getFeUserData
     *
     * @param str $patternedString
     * @return string or null
     */
    public function replaceFeUserDataInString( $patternedString = '' )
    {
        if( empty($patternedString) ) return null;
        
        // detect user fields. eg. field 'name' out of '..blabla fe_users:name blabla...' 
        // whether the : could be any sign like fe_users.field
        $fldPos = strpos( ' ' . $patternedString , 'fe_users' );
        if( $fldPos ){
            
            $aAtoms = explode( ' ' , trim($patternedString) );
            foreach( $aAtoms as $atomIx => $possibleString ){
                    $fldPos = strpos( ' ' . $possibleString , 'fe_users' );
                    if( !$fldPos ) continue; // to next atom
                    
                    $fullVariablename = substr( $possibleString , $fldPos-1 );
                    $startPosName = strlen('fe_users') + $fldPos;
                    $fieldname = substr( $possibleString , $startPosName );
                    $userData = $this->getFeUserData( $fullVariablename );
                    if( !$userData ) continue; // to next atom
                    $aAtoms[$atomIx] = str_replace( $fullVariablename , $userData , $possibleString );
            }
            $patternedString = implode( ' ' , $aAtoms );
            
        }
        
        return $patternedString;
    }

    /**
     * getFeUserData
     *   returns the value of one specific field from table fe_users
     *   from the recordset of actual logged in user.
     *
     * @param str $fieldname
     * @return void
     */
    public function getFeUserData( $fieldname = '' )
    {
        $startPosName = strlen('fe_users');
        $fieldname = substr( $fieldname , $startPosName+1 );
        if( empty($fieldname) ) return null;
        
        if( !isset($GLOBALS['TSFE']) ) die( 'Beendet durch Zeile 187 in Sfgz\SdbAdminer\Utility\SessionUtility: kein TSFE!' );
        // field is unknown in table fe_users
        if( !isset($GLOBALS['TSFE']->fe_user->user[$fieldname]) ) return null;
        // return specifyed field value
        $aFeUser = $GLOBALS['TSFE']->fe_user->user[$fieldname];
        return $aFeUser;
    }

}
