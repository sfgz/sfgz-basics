<?php
namespace Sfgz\SdbAdminer\Controller;
use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Backend\Utility\BackendUtility;

/***
 *
 * This file is part of the "DB Adminer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@sfgz.ch>
 *  
 *  listAction can be filtered once by searchValue (searchField == foreignkey) 
 *       and can have one link selected (searchField == ownkey && searchValue)
 *  
 *  editAction can be filtered once by searchValue (searchField == foreignkey)
 *  
 *  if a filter-call is done then
 *  1. store link as selected if plugin has this link-name piNr-linkfieldName-searchValue [511]
 *  2. store data-filter if plugin is filtered piNr-foreignkey-searchValue OR? piNr-ownkey-searchValue
 *
 ***/

/**
 * FilterController
 */
class FilterController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * flexdataUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\FlexdataUtility
     */
    protected $flexdataUtility = null;

    /**
     * templateUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\TemplateUtility
     */
    protected $templateUtility = null;

    /**
     * modelUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\ModelUtility
     */
    protected $modelUtility = null;

    /**
     * sessionUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\SessionUtility
     */
    protected $sessionUtility = null;

    /**
     * message
     *
     * @var array
     */
    Private $message = array();
    
    /**
	 * initializeAction
	 *
	 */
	public function initializeAction()
	{
 			// General: get db-name from plugin flexform
 			
 			$this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
			$this->flexdataUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\FlexdataUtility');
			$this->modelUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\ModelUtility');
			$this->spreadsheetUtility = GeneralUtility::makeInstance('Sfgz\\SfgzFetools\\Utility\\SpreadsheetUtility');
			
			$this->settings['pluginUid'] = $this->configurationManager->getContentObject()->data['uid'];
			$this->settings['pagePid'] = $this->configurationManager->getContentObject()->data['pid'];
			$this->settings['list_type'] = $this->configurationManager->getContentObject()->data['list_type'];
			
			if( $this->settings['searchform'] < 2 || !isset($this->settings['ownkey']) || empty($this->settings['ownkey']) ){
				$this->settings['ownkey'] = $this->modelUtility->readPrimaryKey( $this->settings['dbname'] , $this->settings['tablename'] );
			}
			$this->settings = $this->flexdataUtility->reorganizeFlexformData( $this->settings );
			
			// individual for FilterController
			$this->sessionUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\SessionUtility');

			$this->templateUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\TemplateUtility');
			$this->getInputs();
			
			// if this is the first Plugin then execute crud-action if affored, regardless the plugin-type (list or edit)
			$firstPage = $this->settings['pluginUid'] == $this->flexdataUtility->getFirstPluginUidOnPage( $this->settings['pagePid'] );
			$calingPuginUid = isset($this->settings['req']['callPlugin']) ? $this->settings['req']['callPlugin']: 0;
			if( $firstPage && $GLOBALS['TSFE']->fe_user->user['username'] ) {
				// boot model with config for calling plugin and dispatch action - add errors
				$this->modelUtility->dispatchActions( $this->settings , $calingPuginUid );
			}
			// boot model with config for actual plugin - read errors
			$this->modelUtility->bootModel( $this->settings , $calingPuginUid );
			
    }

    /**
     * downloadAct
     *
     * @return void
     */
    public function downloadAct()
    {
			if( $this->settings['req']['callPlugin'] != $this->settings['pluginUid'] || !isset($this->settings['req']['save']) || $this->settings['req']['save'] != 'download' ) return;

			$req = $this->getFilterFromSession( $this->settings['req'] );
			$aResult = $this->modelUtility->getDataFromRequest( $req );
			
			if( !count( $aResult ) ) {
				return [ 'message' => 'Keine Daten in "' . $this->settings['tablename'] . '" gefunden' , 'title' => 'Kein Download!' ];
			}
			// if filtered then append info about filtername and value
			if($this->settings['searchform'] == 2 && $this->settings['foreignkey'] && $req['searchValue']) $aResult[] = [ 'Filter:' , $this->settings['foreignkey'] , $req['searchValue']  ];

			$this->spreadsheetUtility->arrayToSpreadSheet( $aResult ,  $this->settings['tablename'] . '_' . $this->settings['dbname']. '.xlsx' , true );
			
			return;

// 				csv:
// 					$title = 'meinTescht';
// 					$outString = "a1;a2;a3;a4\nb1;b2;b3;b4\nc1;c2;c3;c4";
// 					$headers = array(
// 						'Pragma'                    => 'public', 
// 						'Expires'                   => 0, 
// 						'Cache-Control'             => 'must-revalidate, post-check=0, pre-check=0',
// 						'Cache-Control'             => 'public',
// 						'Content-Description'       => 'File Transfer',
// 						'Content-Type'              => 'application/vnd.ms-excel',
// 						'Content-Disposition'       => 'attachment; filename="'.$title.'.csv"',
// 						'Content-Transfer-Encoding' => 'binary'        
// 					);
// 					foreach($headers as $header => $data) $this->response->setHeader($header, $data); 
// 					$this->response->sendHeaders();  
// 					echo $outString;
// 					exit;
// 				
    }

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
			$this->getInputs();
			
			$isDownloadError = $this->downloadAct();
			if( is_array($isDownloadError) && isset($isDownloadError['message']) ) $this->addFlashMessage( $isDownloadError['message'] , $isDownloadError['title'] , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			
			// register if this list/page sets a filter:
			$this->settings['templateLinkFields'] = $this->flexdataUtility->getLinkFields( $this->settings['linkfields'] );
			
			// behavior on create or new action: 
			// if this list/page sets some filters then reset them now
			if( isset($this->settings['templateLinkFields'][ $this->settings['req']['searchField'] ]) ){
					if( $this->settings['req']['save'] == 'create' ){
						$this->settings['req']['searchValue'] = $this->settings['req']['text'][ $this->settings['req']['searchField'] ];
					}elseif( $this->settings['req']['save'] == 'new' ){
						// unset the link marker
						$this->settings['req']['searchValue'] = '';
					}
			}elseif( $this->settings['ownkey'] == $this->settings['req']['searchField'] && $this->settings['req']['save'] == 'create' ){
				$this->settings['req']['searchValue'] = $this->settings['req']['text'][ $this->settings['req']['searchField'] ];
			}
			
			// set link-sessions, get session variables for filter
			$req  = $this->settings['req'];
			if( !isset($this->settings['req']['searchField']) ) {
				$this->clearSession(); 
			}else{
				$this->storeLinkAndFilterInSession();
				$req = $this->getFilterFromSession( $req );
			}

			// Result: execute the SQL-Statements
			$aResult = $this->modelUtility->getDataFromRequest( $req );
			$query = $this->modelUtility->settings['sqlRequest'];

			// mark records if isLink
			$aResult = $this->registerLinks( $aResult );

			// detect index fieldname 
			$this->settings['primary'] = $this->settings['ownkey'];//current($aIndex);
			
			// Templating
			if( !isset($this->settings['rowsdisplay']) || empty($this->settings['rowsdisplay']) ) $this->settings['rowsdisplay'] = '0';
			$aPgs = explode( ',' , $this->settings['rowsdisplay'] );
			$this->settings['defaultPagerSize'] = trim($aPgs[0]);
			
			$this->settings = $this->templateUtility->setDefaultTemplates( $aResult , $this->settings );
		//	foreach( [ 'leadtext' , 'template' , 'headrow' , 'mainrow' , 'footrow' ] as $part ) $this->settings[$part] = $this->sessionUtility->replaceFeUserDataInString( $this->settings[$part] );
			
			// replace placehoders with related values in  HTML-Template-Text defined in the plugin or generated 
			if( $this->settings['searchform'] != 1 ) {
				// if list gets generated by ajax ( searchform == 1 ) then the result will be overwriten 
				$this->settings = $this->templateUtility->templateTable( $aResult , $this->settings );
			}

			$this->view->assign('conf', [ 'settings' => $this->settings ,  'Query'=>  $this->form_lang_decode( $query) , 'Result'=>$aResult  , 'message'=>$this->message ] );
			$this->view->assign('message', $this->message );

			// templating css for header
 			$this->appendUserCss( $this->settings['css'] );
 			$this->modelUtility->closeDatabase();

    }

    /**
     * appendUserCss
     * replaces placeholders _uid_ and _pid_ with values
     *
     * @param str $template
     * @return string
     */
    Protected function appendUserCss( $template )
    {
			if( trim($template) == '' ) return;

			$cObj = $this->configurationManager->getContentObject();
			
			$data = [
					'_uid_' => $cObj->data['uid'] ,
					'_pid_' => $cObj->data['pid'] 
			];

			$rawCss = "\n<!-- SdbAdminer-Plugin content #_uid_ on page #_pid_  --> \n";
			$rawCss.= $template ;
// 			$rawCss.= "\n<SCRIPT> function pluginAfterjsSetOptionsNr_uid_(pluginUid) { return true; alert( 'pluginAfterjsSetOptionsNr_uid_ klicked : ' + pluginUid + '' ); } </SCRIPT>\n" ;
			$rawCss.= "<!-- /SdbAdminer-Plugin -->" ;

			$css = str_replace( array_keys( $data ) , $data , $rawCss );

			//OLD STYLE before Typo3 v8 $GLOBALS['TSFE']->content = preg_replace( '#<\/head>#' , $css . '</head>' , $GLOBALS['TSFE']->content );
			
			$GLOBALS['TSFE']->additionalHeaderData['sdb_adminer_main_'.$cObj->data['uid']] = $css;
			return $css;
    }

    /**
     * clearSession
     *
     * @return void
     */
    Private function clearSession()
    {
			$pid = $this->flexdataUtility->getPageOfPlugin( $this->settings['pluginUid'] );
			$aAllPlugins = $this->flexdataUtility->getAllPluginsFromPage( $pid , '' );
			if( count($aAllPlugins) ) {
				foreach( array_keys( $aAllPlugins ) as $piNr ) $this->sessionUtility->resetData($piNr);
			}
    }

    /**
     * storeLinkAndFilterInSession
     *  set link-sessions if call came from actual plugin
     *
     * @return array
     */
    Private function storeLinkAndFilterInSession()
    {
			$aLinkFields = $this->flexdataUtility->getLinkFields( $this->settings['linkfields'] );
			$calledFromSelf = isset($aLinkFields[ $this->settings['req']['searchField'] ]) && $this->settings['pluginUid'] == $this->settings['req']['callPlugin'];

			// set link in session if call was possible from this plugin
			$calledFromParent = $this->settings['req']['searchField'] == $this->settings['foreignkey'] && $this->settings['foreignkey'] &&  $this->settings['ownkey'];
			if(  
				( $this->settings['req']['save'] == 'create' || $calledFromSelf  || $calledFromParent ) && isset($this->settings['req']['searchValue']) && !empty($this->settings['req']['searchValue']) && !empty($this->settings['req']['searchField']) 
			){
				// selbstaufruf: link als selected markieren
				$sess = array( $this->settings['pluginUid'] => array( $this->settings['req']['searchField'] => $this->settings['req']['searchValue'] ) );
				$this->sessionUtility->setData( $sess );
				if( $calledFromSelf ) $this->message[] = '1. set Link ' . $this->settings['req']['searchField'] . '=' . $this->settings['req']['searchValue'];
				if( $calledFromParent ) $this->message[] = '2. set Filter ' . $this->settings['req']['searchField'] . '=' . $this->settings['req']['searchValue'];
			}
    }

    /**
     * getFilterFromSession
     *  get session-variables 
     *  if call came from children or grandchildrens plugin
     *
     * @param array $req
     * @return array
     */
    Private function getFilterFromSession( $req )
    {
			$aLinkFields = $this->flexdataUtility->getLinkFields( $this->settings['linkfields'] );
			$calledFromSelf = isset($aLinkFields[ $this->settings['req']['searchField'] ]) && $this->settings['pluginUid'] == $this->settings['req']['callPlugin'];
			// Only if this list/page should be filtered and filterfield is set:
			// set or get filter in session. 
			$calledFromDescendant = $this->flexdataUtility->isCallerDescendant( $this->settings['pluginUid'] , $this->settings['req']['callPlugin'] );
			if( ( $calledFromSelf || $calledFromDescendant ) && $this->settings['foreignkey'] &&  $this->settings['ownkey'] && 
			$this->settings['req']['searchField'] != $this->settings['foreignkey'] ){
				// get searchValue from session if any link is klicked which does not fit
				$sess = $this->sessionUtility->getData( $this->settings['pluginUid'] );
				if( isset($sess[ $this->settings['foreignkey'] ]) && $sess[ $this->settings['foreignkey'] ] ){
					$req['searchValue'] = $sess[ $this->settings['foreignkey'] ];
					$req['searchField'] = $this->settings['foreignkey'] ;
					$this->message[] = '3. getFilterFromSession ' . $req['searchField'] . '=' . $req['searchValue'];
				}
			}
			return $req;
    }

    /**
     * registerLinks
     * if this list/page sets a filter: get Link from session or from request
     * 
     * @param array $aResult
     * @return array
     */
    Private function registerLinks( $aResult )
    {
			if( !isset( $this->settings['templateLinkFields'] ) ){
					$this->settings['templateLinkFields'] = $this->flexdataUtility->getLinkFields( $this->settings['linkfields'] );
			}
			// Set isLink to true (1) if they are defined as link in the plugin
			$aRegisteredResult = [];
			if( is_array($aResult) && count($aResult) ){
				foreach( $aResult as $ix => $row ) {
					foreach( $row as $fld => $cnt ) {
						if( strlen( trim($fld) ) == 0 ) continue;
						$aRegisteredResult[$ix][$fld]['value'] = $cnt;
						$aRegisteredResult[$ix][$fld]['isLink'] = isset($this->settings['templateLinkFields'][$fld]) ? 1 : 0;
					}
				}
			}

			if( count($this->settings['templateLinkFields']) && isset($this->settings['req']['searchField']) && count($aRegisteredResult)){
				$isCallerDescendant = $this->flexdataUtility->isCallerDescendant( $this->settings['pluginUid'] , $this->settings['req']['callPlugin'] );
				//FIXME DELETED in conditions: && $isCallerDescendant
				if( $this->settings['req']['save'] != 'create'  ){
					// FIXME DELETED called from descendant
					$aRegisteredResult = $this->getLinkFromSession( $aRegisteredResult );
				}elseif( $this->settings['req']['save'] == 'create' || $this->settings['pluginUid'] == $this->settings['req']['callPlugin'] ){
					// called from self or creating
					$aRegisteredResult = $this->getLinkFromRequest( $aRegisteredResult );
				}
				
			}
			return $aRegisteredResult;
    }

    /**
     * getLinkFromSession
     *
     * @param array $aResult
     * @return array
     */
    Private function getLinkFromSession( $aResult )
    {
			$sess = $this->sessionUtility->getData( $this->settings['pluginUid'] );
			foreach( $aResult as $ix => $row ) {
				foreach( $row as $fld => $cnt ) {
						if( $cnt['isLink'] && isset($sess[trim($fld)]) && $sess[trim($fld)] ==  trim($cnt['value']) ) {
							$aResult[$ix][$fld]['selected'] = $cnt['value'];
							$this->message[] = '4. get Link from session ' . $fld . '=' . $cnt['value'];
						}
				}
			}
			return $aResult;
    }

    /**
     * getLinkFromRequest
     *
     * @param array $aResult
     * @return array
     */
    Private function getLinkFromRequest( $aResult )
    {
			foreach( $aResult as $ix => $row ) {
				foreach( $row as $fld => $cnt ) {
						if( $cnt['isLink'] && $this->settings['req']['searchField'] == $fld && $this->settings['req']['searchValue'] ==  trim($cnt['value']) ) {
							$aResult[$ix][$fld]['selected'] = $cnt['value'];
							$this->message[] = '5. get Link from request ' . $fld . '=' . $cnt['value'];
						}
				}
			}
			return $aResult;
    }


    /**
     * getInputs
     *
     * @return void
     */
    Protected function getInputs( )
    {
			// on input get filter name and value from request vars
				$arg = [];
				$arg['pluginUid'] = $this->settings['pluginUid'];
				$arg['req'] = 'req';
				if( $this->request->hasArgument('callPlugin') ) $arg['callPlugin'] = $this->request->getArgument('callPlugin');
			
				if( $this->request->hasArgument('field') ) $arg['searchField'] = trim($this->request->getArgument('field'));
				if( $this->request->hasArgument('content') ) $arg['searchValue'] = html_entity_decode( trim($this->request->getArgument('content')) );
				
				if( $this->request->hasArgument('action') ) $arg['action'] =$this->request->getArgument('action');
 				if( $this->request->hasArgument('save') ) { 
					$arg['save'] = $this->request->getArgument('save'); 
 				}elseif( $this->request->hasArgument('new') ){ 
					$arg['save'] = $this->request->getArgument('new');
				}
  				if( $this->request->hasArgument('text') ) $arg['text'] =  $this->request->getArgument('text') ;
  				if( $this->request->hasArgument('error') ) $arg['error'] =$this->request->getArgument('error');
				$this->settings['req'] = $arg;
    }
	
    /**
     * form_lang_decode
     *
     * @param string $notCodedString
     * @return void
     */
    Protected function form_lang_decode( $notCodedString )
    {
		return iconv( 'iso-8859-15' , 'utf-8' , $notCodedString );
    }

}
