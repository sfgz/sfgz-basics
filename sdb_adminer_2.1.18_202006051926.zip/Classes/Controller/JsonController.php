<?php
namespace Sfgz\SdbAdminer\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/**
 * JsonController
 */
class JsonController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	* @var string
	*/
	protected $defaultViewObjectName = 'TYPO3\CMS\Extbase\Mvc\View\JsonView';

	/**
	* @var array
	*/
	protected $incData = Null;

	/**
	* @var array
	*/
	protected $piSettings = Null;

	/**
	* @var int
	*/
	protected $pluginUid = Null;

    /**
     * flexdataUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\FlexdataUtility
     */
    protected $flexdataUtility = null;

    /**
     * modelUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\ModelUtility
     */
    protected $modelUtility = null;

    /**
     * sqlUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\SqlUtility
     */
    protected $sqlUtility = null;

	/**
	  * initializeAction
	  *
	  */
	public function initializeAction() {
			$this->pluginUid = GeneralUtility::_GET('cnt');
			$this->incData =  GeneralUtility::_GET('data');
			
			$this->flexdataUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\FlexdataUtility');
			
			$this->piSettings = $this->flexdataUtility->getFlexformData( $this->pluginUid );
            
            // append ts-settings
            $this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
            $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
            $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
            $this->typoScriptService =  $this->objectManager->get('TYPO3\\CMS\\Extbase\\Service\\TypoScriptService');
            $pluginKey = 'tx_sdbadminer_main';
            $settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray( $fullsettings['plugin.'][ $pluginKey . '.' ]['settings.'] );
            
            if( is_array($settings) ) {foreach($settings  as $key => $row ) $this->piSettings[$key] = $row;}
 			
			$this->extConf = GeneralUtility::makeInstance(
				\TYPO3\CMS\Core\Configuration\ExtensionConfiguration::class
			)->get('sdb_adminer');
	}

	/**
	* Action list
	* called by page type = 1545591292
	* return values from table or view
	* Recordsets from table as defined in Plugin
	* Output format: Array [ option => indexAsDefInPlugin , label => valueAsDefInPlugin ]
	*
	* @return void
	*/
	public function listAction(){
		
		$this->modelUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\ModelUtility');
		
	    switch($this->incData['subaction']){
		
			case 'getSelectOptions':
				// used only for fieldtype filtered_selector
				$settings_useroptions = $this->getSelectOptions();
			break;
			
			case 'getListData':
				// used to display lists. The template is stored in the actual html-page
				$settings_useroptions = $this->getListData();
			break;
			
			default:
				$aListData = [ 0 => [ 'option'=>'optiontest1' , 'label'=>$this->incData['searchchars'] , 'data' => [ 'uid' => 1 , 'label'=>'data test1' ] , 'selected' => false ] , 1 => [ 'option'=>'optiontest2' , 'label'=>'test2' ] , 'data' => ['uid' => 2 , 'label'=>'data test2' ] , 'selected' => true  ];
				$settings_useroptions['responseText'] = 'Json->listAction Testwerte (subaction fehlt im Ajax Aufruf)' ;
				$settings_useroptions['resultdata'] = $aListData;
			break;
		}
		
		$this->view->assign( 'value' ,  json_encode($settings_useroptions) );
		
	}

	/**
	* getSelectOptions
	*  used only for fieldtype filtered_selector
	*  
	* @return array
	*/
	Private function getSelectOptions(){
		$this->modelUtility->bootModel( $this->piSettings , $this->pluginUid );
		
		$sql = trim( $this->piSettings[ 'options' ][ $this->incData['optionsSuffix'] ] , ';' );
		$aRows = $this->modelUtility->getFieldOptionListFromString( $sql );

		$aOptions = [ 'x.0' => [ 'option' => 0 , 'label' => 'Wählen...' ] ];
		if( count($aRows) ){
			// filter the rows by search chars if there is any searchchar
			foreach( $aRows as $ix => $fldCnt ){
				// if searchchar is empty then include all recordsets as options
				$isValid = empty($this->incData['searchchars']);
				
				// if search matches exatly with index, then exclude all other fields from search and return this single option
                if( !$isValid &&  strtolower($ix) == strtolower($this->incData['searchchars']) ){ 
                    if( $this->piSettings['selector_fieldtypes'][3]['break_if_found_in_key'] ){
                        $aOptions = [ 'x.' . $ix => [ 'option' => $ix , 'label' =>$fldCnt ] ];
                        break;
                    }else{
                        $aOptions[ 'x.' . $ix] = [ 'option' => $ix , 'label' =>$fldCnt ];
                        continue;
                    }
                }

                $needles = strtolower($this->incData['searchchars']);
                $separer = ' ';
				
				// default search in field-content
                if( !$isValid ) $isValid = $this->areAllNeedlesInHaystack( $needles , strtolower($fldCnt) , $separer );
				
				// found in index OR in field-content
				if( $isValid ) {
					// javascript INFO: The index in $aOptions has to be a asociative array, otherwise js sorts by index - instead of not sorting at all
					$aOptions[ 'x.' . $ix] = [ 'option' => $ix , 'label' =>$fldCnt ];
				}
			}
		}
		
		if( isset($aOptions['x.0']) ){
            $realRowsAmount = count($aOptions)-1;
            if( $realRowsAmount == 1 ){
                unset( $aOptions['x.0'] );
            }else{
                if( isset($aOptions['x.0']['label']) ) $aOptions['x.0']['label'] .= ' (' . $realRowsAmount . ' Einträge)';
            }
		}

		// add empty option if affored
		$aFieldProperties = $this->modelUtility->getFieldProperties( $this->piSettings[ 'selector' ][ $this->incData['optionsSuffix'] ] );
		$aFieldProperties['type'] = 'filtered_selector';
		$aSrtOptions = $this->modelUtility->addNullValueToOptionList( $aFieldProperties , $aOptions );
		// end: add empty option
		
		$settings_useroptions['responseText'] = 'Json->listAction ok: WOBEI label WIE *' . $this->incData['searchchars'] . '* sql: ' .  $sql . '* count: ' . count($aRows);
		$settings_useroptions['resultdata'] = $aSrtOptions;
		
		$this->modelUtility->closeDatabase();
		
		return $settings_useroptions;
	}

	/**
	* getListData
	*  Used to listing tables. 
	*  The template is stored in the actual html-page
	*  
	* @return array
	*/
	Private function getListData(){
		$searchField = GeneralUtility::_GET('field');
		$searchField = trim($searchField);
		$searchValue = GeneralUtility::_GET('content');
		$searchValue = trim($searchValue);
		
		// used only for translate Date and Time To Display
		$this->modelUtility->bootModel( $this->piSettings , $this->pluginUid );

		$aList['link'] = explode( ',' , $this->piSettings[ 'linkfields' ] );
		
		$aList['include'] = explode( ',' , $this->piSettings[ 'includeinsearch' ] );
		
        $ifWhere = $this->modelUtility->getAdditionalWhereClauseFromFlexform( $this->piSettings , $searchField , $searchValue );
        if( $ifWhere ) {
                $ifWhere = $this->modelUtility->removeTrailingWhereCondition( $ifWhere );
                $ifWhere = ' WHERE ' . $ifWhere;
        }
		$aAllRows = $this->modelUtility->runQuery( 'SELECT * FROM ' . $this->piSettings[ 'tablename' ]  . $ifWhere . ';' , $this->piSettings['dbname'] );

		$sqlTableSchema = 'SELECT COLUMN_NAME , ';
		$sqlTableSchema .= 'CHARACTER_SET_NAME , ';
		$sqlTableSchema .= 'IS_NULLABLE , ';
		$sqlTableSchema .= 'EXTRA , ';
		$sqlTableSchema .= 'COLUMN_DEFAULT , ';
		$sqlTableSchema .= 'DATA_TYPE , ';
		$sqlTableSchema .= 'COLUMN_TYPE, ';
		$sqlTableSchema .= 'NUMERIC_SCALE, ';
		$sqlTableSchema .= 'COLUMN_COMMENT FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = "'.$this->modelUtility->settings['dbname'].'" AND  TABLE_NAME = "'.$this->modelUtility->settings['tablename'].'"';
 		$aDefaults = $this->modelUtility->runQuery( $sqlTableSchema . ';' , $this->modelUtility->settings['dbname'] );
		$anFieldDefaults = [];
		
		foreach( $aDefaults as $aRow ){
			$anFieldDefaults[$aRow['COLUMN_NAME']] = $aRow;
			// define IS_NULLABLE
			$anFieldDefaults[$aRow['COLUMN_NAME']]['nullable'] = $aRow['IS_NULLABLE'] == 'YES' ? '1' : '';
		}
		
		// sanitize data from flexform
		$aFieldOpt = [];
		if( count($aList) ) {
			foreach( $aList as $type => $aValues ){
					if( count($aValues) ) {
						foreach( $aValues as $fld ) {
							if($fld) $aFieldOpt[ $type ][trim($fld)] = trim($fld);
						}
					}
			}
		}
		
		// filter rows
		$aRows = [];
		$counter = 1;
		foreach( $aAllRows as $ix => $row ){
			
			if( $counter >= $this->extConf['sql_limit_ajax'] ) break;
			
			$isValid = false;
			$haystack = '';
			foreach( $row as $fldNam => $fldCnt ){
				if( empty($fldCnt) ) continue;
				// search in 'include' detects whether field should be listet or not
				if( !isset($aFieldOpt['include']) || isset($aFieldOpt['include'][$fldNam]) ) {
                    $haystack .= strtolower($fldCnt) . ' ';
				}
			}
			$isValid = $this->areAllNeedlesInHaystack( strtolower($this->incData['searchchars']) , trim($haystack) , ' ' );
			if( !$isValid ) continue;
			
            $aRows[$ix] = $row;
            ++$counter;
            
		}
		
		$aListData = [];
		$pageNumber = 1;
		$aFieldDefaults = $this->modelUtility->getFieldProperties( '' );
		
		if( $this->piSettings['pagetype'] == 2){ // select-list with directly page call
		// Select-rows! render values in rows and collect them for json formatting
			$iPages = count($aRows);
			foreach( $aRows as $ix => $row ){
				$isSelected = false;
				$aListDataRow = [];
				$row['pages'] = $iPages;
				$row['page'] = $pageNumber;
				foreach( $row as $fldNam => $fldCnt ){
					// format date string for output
					$fldCnt = $this->modelUtility->renderEditFieldValueByType( $fldCnt , $anFieldDefaults[$fldNam]['DATA_TYPE'] );
					// if string matches to search-char then mark as selected
					if( $fldNam == $searchField && $fldCnt == $searchValue ) $isSelected = true;
					// special render for Links ( options ) FIXME
					$aListDataRow[$fldNam]['value'] = $fldCnt;
					$aListDataRow[$fldNam]['rendered'] = $fldCnt;
					if( isset($aFieldOpt['link'][$fldNam]) ){
						if( $fldNam == $searchField && $fldCnt == $searchValue ){
							$aListDataRow[ 'SELECTED' ]['rendered'] = ' selected="1" ';
						}else{
							$aListDataRow[ 'SELECTED' ]['rendered'] = '';
						}
					}
				}
				$aListData[] = [ 'data' => $aListDataRow , 'selected' => $isSelected ];
			}
		}else{
		// table with manual filter
		// render values in rows and collect them for json formatting
			$iPages = count($aRows);
			foreach( $aRows as $ix => $row ){
				$isSelected = false;
				$aListDataRow = [];
				$row['pages'] = $iPages;
				$row['page'] = $pageNumber;
				foreach( $row as $fldNam => $fldCnt ){
					// format date string for output
					$fldCnt = $this->modelUtility->renderEditFieldValueByType( $fldCnt , $anFieldDefaults[$fldNam]['DATA_TYPE'] );
					// if string matches to search-char then mark as selected
					if( $fldNam == $searchField && $fldCnt == $searchValue ) $isSelected = true;
					// special render for Links
					$aListDataRow[$fldNam]['value'] = $fldCnt;
					if( isset($aFieldOpt['link'][$fldNam]) ){
						$selected = $fldNam == $searchField && $fldCnt == $searchValue ? ' sel' : '';
						$aListDataRow[ $fldNam ]['rendered'] = '<span class="jslink fld_' . $fldNam . $selected . '">' . $fldCnt . '</span>';
					}else{
						$aListDataRow[$fldNam]['rendered'] = $fldCnt;
					}
				}
				$aListData[] = [ 'data' => $aListDataRow , 'selected' => $isSelected ];
			}
		
		}
		
		$settings_useroptions['responseText'] = 'Json->listAction ok: WOBEI Suche WIE *' . $this->incData['searchchars'] . '* in: ' . count($aListData);
		$settings_useroptions['resultdata'] = $aListData;
		
		$this->modelUtility->closeDatabase();
		
		return $settings_useroptions;
	}

	/**
	* areAllNeedlesInHaystack
	*  
	* @param string $needles string that will be separed in to needles by separer
	* @param string $haystack stays untouched
	* @param string $separer eg * for asterisk or ' ' for blank (default)
	* @return boolean
	*/
	Private function areAllNeedlesInHaystack( $needles , $haystack , $separer = ' ' ){
			if( empty($needles) ){ return true; } 
			if( empty($haystack) ){ return false; } 
			
            $isValid = 0;
            $aChars = explode( $separer , $needles );
            foreach( $aChars as $serchChars ){
                if( empty($serchChars) ){
                    $isValid += 1;
                }elseif(strpos( ' ' . strtolower($haystack) , $serchChars )){
                    $isValid += 1;
                }
            }
            return count($aChars) == $isValid ? true : false;
	}

	/**
	* Action update
	* called by page type = 1527806882
	* stores values in users session variable
	* returns 'ok' if successfull, otherwise a errormessage
	*
	* @return void
	*/
	public function updateAction(){
		
		$this->sqlUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\SqlUtility');
		$this->sqlUtility->connectToDatabase( $this->piSettings['dbname'] );
		
		//  pageType 2 means m:n tables
	    if( $this->piSettings['list_type'] == 'sdbadminer_edit' && $this->piSettings['formtype'] == 2 ){
				$sqlDefault = 'FROM ' . $this->piSettings['tablename'] . ' WHERE '.$this->piSettings['ownkey'].'="' . $this->incData['ownValue'] . '" AND ' . $this->piSettings['keytooppositetable'] . '="' . $this->incData['foreignValue']  . '"' ;
				$aExistingRow = $this->sqlUtility->runQuery( 'SELECT * ' . $sqlDefault . ' LIMIT 1;' );
				$workDone = '';
				if( $this->incData['selected']=='false' && count($aExistingRow) ){
					// delete
					$sqlEdit = 'DELETE ' . $sqlDefault . ';';
					$workDone = $this->sqlUtility->execQuery($sqlEdit);
				}elseif( $this->incData['selected']=='true' && !count($aExistingRow) ){
					// create
					$sqlEdit = 'INSERT INTO ' . $this->piSettings['tablename'] . ' ('.$this->piSettings['ownkey'].',' . $this->piSettings['keytooppositetable'] . ') VALUES ("' . $this->incData['ownValue'] . '","' . $this->incData['foreignValue']  . '");';
					$workDone = $this->sqlUtility->execQuery($sqlEdit);
				}
				$js = '<script>$("#response_' . $this->pluginUid . ' .typo3-messages").fadeOut(2000);</script>';
				$messSQL = $this->piSettings['debugprint'] ? $sqlEdit : '' ;
				
				$messOk = '<span class="typo3-messages" style="color:#080;">ok</span>';
				$messErr = '<span class="typo3-messages">Fehler, nicht gespeichert.</span>';
				$messageOut = $workDone ? $messOk : $messErr;
				$wrappedSqlQuery = $messSQL . $messageOut . $js;

				$sqlParentQuery = 'SELECT ' . $this->piSettings['oppositelabel'] . ' FROM ' . $this->piSettings['oppositetable'] . ' WHERE '.$this->piSettings['oppositefield'].'="' . $this->incData['foreignValue'] . '" ' ;
				$sqlParentResult = $this->sqlUtility->singleQuery( $sqlParentQuery . ';' );
				$decLabel = iconv( 'iso-8859-15' , 'utf8' , $sqlParentResult[$this->piSettings['oppositelabel']] );
				$this->view->assign( 'value' ,  [ 'sql' => $wrappedSqlQuery , 'label' =>  $decLabel , 'pluginUid' =>  $this->piSettings['pluginUid']  ] );
	    }
	    // edit one field by list editing. update , delete , insert
	    if( $this->piSettings['list_type'] == 'sdbadminer_edlist' ){
            $table = $this->incData['tablename'];
            $keyName =  $this->incData['indexfield'];
            $action =  $this->incData['action'];
            $idx = 0;
            $decryptedValue = iconv( 'utf-8' , 'iso-8859-15' , $this->incData["value"] );
            switch( $action ){
                case 'insert':
                    $action = 'inserted';
					$lastUid = $this->sqlUtility->resetAutoIncrement( $table , $keyName );
                    $sqlEdit = "INSERT INTO `" . $table . "` (`" . $this->incData["fieldname"] . "`) VALUES ('" . $decryptedValue . "');" ;
					$workDone = $this->sqlUtility->execQuery($sqlEdit);
					if( $workDone ){
                        $idx = 'idx: "' . $lastUid . '"';
					}else{
                        $action =  $sqlEdit;
					}
                break;
                case 'update':
                    $action = 'updated';
                    $sqlEdit = "UPDATE `" . $table . "` SET `" . $this->incData["fieldname"] . "` = '" . $decryptedValue . "' WHERE `" . $keyName . "`=" . $this->incData["index"] . ";" ;
					$workDone = $this->sqlUtility->execQuery($sqlEdit);
					if( $workDone ){
                        $idx = $this->incData["index"];
					}else{
                        $action =  $sqlEdit;
					}
                break;
                case 'delete':
                    $action = 'deleted';
                    $sqlEdit = "DELETE FROM `" . $table . "` WHERE `" . $keyName . "`=" . $this->incData["index"] . ";" ;
					$workDone = $this->sqlUtility->execQuery($sqlEdit);
					if( $workDone ){
                        $idx = $this->incData["index"];
					}else{
                        $action =  $sqlEdit;
					}
                break;
            }
            // $action =  'not ' .  $action;
            $this->view->assign( 'value' , json_encode(['status' => $action , 'idx'=> '#' . $idx . ' ' . $this->incData["fieldname"] . '' ]) );
	    }
		$this->sqlUtility->closeDatabase();
	    
	}

}
