<?php
defined('TYPO3_MODE') || die('Access denied.');

### import users with extension svconnector_sql
// include_once(\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY).'class.tx_sdbadminer_hooks.php');
// $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['svconnector_sql']['processResponse'][] = 'tx_sdbadminer_hooks';
###

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SdbAdminer',
            'Main',
            [
                'Filter' => 'list'
            ],
            // non-cacheable actions
            [
                'Filter' => 'list'
            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SdbAdminer',
            'Edit',
            [
                'Editor' => 'edit, new',
                'Json' => 'update,list'
            ],
            // non-cacheable actions
            [
                'Editor' => 'edit, new',
                'Json' => 'update,list'
            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SdbAdminer',
            'Edlist',
            [
                'Editlist' => 'select,edlist',
                'Json' => 'update,list'
            ],
            // non-cacheable actions
            [
                'Editlist' => 'select,edlist',
                'Json' => 'update,list'
            ]
        );

    // wizards
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
        'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {
                    main {
                        iconIdentifier = sdb_adminer-plugin-main
                        title = LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdb_adminer_main.name
                        description = LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdb_adminer_main.description
                        tt_content_defValues {
                            CType = list
                            list_type = sdbadminer_main
                        }
                    }
                    edit {
                        iconIdentifier = sdb_adminer-plugin-edit
                        title = LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdb_adminer_edit.name
                        description = LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdb_adminer_edit.description
                        tt_content_defValues {
                            CType = list
                            list_type = sdbadminer_edit
                        }
                    }
                    edlist {
                        iconIdentifier = sdb_adminer-plugin-edlist
                        title = LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdb_adminer_edlist.name
                        description = LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdb_adminer_edlist.description
                        tt_content_defValues {
                            CType = list
                            list_type = sdbadminer_edlist
                        }
                    }
                }
                show = *
            }
       }'
    );
		$iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);
		
			$iconRegistry->registerIcon(
				'sdb_adminer-plugin-main',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:sdb_adminer/Resources/Public/Icons/user_plugin_main.svg']
			);
		
			$iconRegistry->registerIcon(
				'sdb_adminer-plugin-edit',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:sdb_adminer/Resources/Public/Icons/user_plugin_edit.svg']
			);
		
			$iconRegistry->registerIcon(
				'sdb_adminer-plugin-edlist',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:sdb_adminer/Resources/Public/Icons/user_plugin_edlist.svg']
			);
		
    }
);
