<?php
namespace Sfgz\SfgzUdb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class IntranetUsersUtility
 */

class IntranetUsersUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * fachbereichRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\FachbereichRepository
	 */
	protected $fachbereichRepository = NULL;

	/**
	 * cloudquotaRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\CloudquotaRepository
	 */
	protected $cloudquotaRepository = NULL;

	/**
	 * kurzklasseRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\KurzklasseRepository
	 */
	protected $kurzklasseRepository = NULL;

	/**
	 * teacherRelationRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\TeacherRelationRepository
	 */
	protected $teacherRelationRepository = NULL;

	/**
	 * exportUsersRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\ExportUsersRepository
	 */
	protected $exportUsersRepository = NULL;

	/**
	 * ecouserRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\EcouserRepository
	 */
	protected $ecouserRepository = NULL;

	/**
	 * cloudquota
	 *
	 * @var array
	 */
	protected $cloudquota = array();

	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {
			
            $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

            $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
            $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
            $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
            $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_sfgzudb_edit.']['settings.']);
            $this->settings['storagePid'] = $fullsettings['plugin.']['tx_sfgzudb_edit.']['persistence.']['storagePid'];

            $this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $this->querySettings->setRespectStoragePage(FALSE);

            $userQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
            $userQuerySettings->setRespectStoragePage(TRUE);
            $userQuerySettings->setStoragePageIds( [ $this->settings['studentPid'] ] );

            $this->fachbereichRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\FachbereichRepository');
            $this->fachbereichRepository->setDefaultQuerySettings($this->querySettings);

            $this->teacherRelationRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\TeacherRelationRepository');
            $this->teacherRelationRepository->setDefaultQuerySettings($this->querySettings);

            $this->ecouserRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\EcouserRepository');
            $this->ecouserRepository->setDefaultQuerySettings($userQuerySettings);

            $this->kurzklasseRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\KurzklasseRepository');
            $this->kurzklasseRepository->setDefaultQuerySettings($this->querySettings);

            $this->cloudquotaRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\CloudquotaRepository');
            $this->cloudquotaRepository->setDefaultQuerySettings($this->querySettings);

            $this->exportUsersRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\ExportUsersRepository');
            $this->exportUsersRepository->setDefaultQuerySettings($this->querySettings);
            
            $this->readQuotas();
            
	}

	/**
	* downloadIntranetUsersAndCloudgroups
	* teacher quota and groups from Database
	* students groups from File
	* 
	* @param int $now timestamp or empty
	* @return array
	*/
	public function getKurzklasseList() {
        $kurzklasses = $this->kurzklasseRepository->findAll();
        $aKurzklassenStudents = [];
        $aClassIdShortclassUid = [];
        foreach($kurzklasses as $objKurzklasse ){
            $objKlassen = $objKurzklasse->getKrzKlasse();
            if( !$objKlassen ) continue;
            $objKurzklasseUid = $objKurzklasse->getUid();
            $krzCloudquota = $objKurzklasse->getKrzCloudquota();
            $speicherplatz = $krzCloudquota->getSpeicherplatz();
            if($speicherplatz) $speicherplatz = trim( str_replace( 'GB' , '' , $speicherplatz ) );
            $kurzbezeichnung = $objKurzklasse->getKurzbezeichnung();
            $aKurzklassenStudents[$objKurzklasseUid] = [ 
                'uid'=>$objKurzklasseUid ,  
                'kurzbezeichnung'=>$kurzbezeichnung , 
                'speicherplatz'=>$speicherplatz  , 
                'krzCloudquota'=>$krzCloudquota 
            ];
            foreach( $objKlassen as $objKlass ){
                    $aClassIdShortclass[ $objKlass->getClassId() ] = $objKurzklasseUid;
                    $aKurzklassenStudents[$objKurzklasseUid]['klassen'][$objKlass->getClassId()]['klasse'] = $objKlass ;
                    $aKurzklassenStudents[$objKurzklasseUid]['klassenname'] = $objKlass->getKlassenname() ;
            }
        }
        $quotaSumme = 0;
        $ecousers = $this->ecouserRepository->findAll();
        foreach($ecousers as $objUser ){
            $objKlassen = $objUser->getEcoKlasse();
            if( !$objKlassen ) continue;
            $objKurzklasseUid = $aClassIdShortclass[ $objKlassen->getClassId() ];
            $cloudQuota = $objUser->getCloudQuota();
            $minSpace = $aKurzklassenStudents[$objKurzklasseUid]['speicherplatz'];
            if( $minSpace >= $cloudQuota ) $cloudQuota = $minSpace;
            $username = $objUser->getUsername();
            $aKurzklassenStudents[$objKurzklasseUid]['klassen'][ $objKlassen->getClassId() ]['students'][] = [ 'cloudquota'=>$cloudQuota , 'username'=>$username  ];
            $aKurzklassenStudents[$objKurzklasseUid]['klassen'][ $objKlassen->getClassId() ]['quota'] += $cloudQuota;
            $aKurzklassenStudents[$objKurzklasseUid]['quota'] += $cloudQuota;
            $quotaSumme += $cloudQuota;
        }
        return ['list'=>$aKurzklassenStudents,'quota'=>$quotaSumme];
	}

	/**
	* downloadIntranetUsersAndCloudgroups
	* teacher quota and groups from Database
	* students groups from File
	* 
	* @param int $now timestamp or empty
	* @return array
	*/
	public function downloadIntranetUsersAndCloudgroups($now=0) {
            $table =  $this->readIntranetUsersAndCloudgroups( $now );
            $aFieldMatch = array(
                'username'=>'username',
                'firstname'=>'firstname',
                'lastname'=>'lastname',
                'email'=>'email',
                'quotaspace'=>'quota',
                'grp1'=>'grp_1',
                'grp2'=>'grp_2',
                'grp3'=>'grp_3',
                'grp4'=>'grp_4',
                'grp5'=>'grp_5'
            );
            array_shift( $table );
            
            $aOutTable[] = $aFieldMatch;
            // special accounts
            $objsExportusers = $this->exportUsersRepository->findAll();
            foreach($objsExportusers as $objExpUser ){
                $pid = $objExpUser->getPid();
                if( $this->settings['storagePid'] == $pid ) continue;
                $aUser = [];
                foreach( $aFieldMatch as $oldName => $newName){
                        $method = 'get' . ucFirst( $oldName );
                        if( method_exists( $objExpUser , $method ) ) $aUser[$newName] =  $objExpUser->$method();
                }
                if( count($aUser) ) $aOutTable[] = $aUser;
            }
            // automatic accounts
            foreach( $table as $ix => $row ){
                if( empty($row['grp1']) ) continue;
                $aUser = [];
                foreach( $aFieldMatch as $oldName => $newName){
                        $aUser[$newName] = $row[$oldName];
                }
                $aOutTable[] = $aUser;
            }
            
            return $aOutTable;
	}

	/**
	* readIntranetUsersAndCloudgroups
	* teacher quota and groups from Database
	* students groups from File
	* 
	* @param int $now timestamp or empty
	* @return array
	*/
	public function readIntranetUsersAndCloudgroups($now=0) {
		if($now == FALSE ) $now = time();
		$tabelleKontingente = array();
 		$fieldAmount = 0;
 		
 		// add teachers
		$teaEcouserGroups = $this->getTeacherFachbereich();

        foreach( $teaEcouserGroups as $teaRow ){
		    if( isset($tabelleKontingente[$teaRow['username']]) ){
				if($tabelleKontingente[$teaRow['username']]['quotaspace'] < $teaRow['quotaspace']) $tabelleKontingente[$teaRow['username']] = $teaRow;
		    }else{
				$tabelleKontingente[$teaRow['username']] = $teaRow;
		    }
			// count number of Fields
		    $trc = 0;
			foreach( $teaRow as $fld => $cnt ){ if(!empty($cnt)) ++$trc;}
			if( $trc > $fieldAmount ) $fieldAmount = $trc;
		}

		// merge with students from File, text-values possably embraced with "
		$aStudFromFile = $this->getStudentGroupFromFile($now);
		foreach( $aStudFromFile as $teaRow ){
		    if( isset($tabelleKontingente[$teaRow['username']]) ){
				if($tabelleKontingente[$teaRow['username']]['quotaspace'] < $teaRow['quotaspace']) $tabelleKontingente[$teaRow['username']] = $teaRow;
		    }else{
				$tabelleKontingente[$teaRow['username']] = $teaRow;
		    }
		}
		
		// sort by username
		ksort($tabelleKontingente);
		
		// prepend csv-table's head-row
		$headrow = array('pid','username','firstname','lastname','email','quotaspace');
		for( $z=1 ; $z <= 5 ; ++$z ) $headrow[] = 'grp' . $z; // CHANGE! from grp_1 to grp1...
		array_unshift( $tabelleKontingente , $headrow );
		return $tabelleKontingente;
	}

	/**
	* getStudentGroupFromFile
	* 
	* @param int $now timestamp or empty
	* @return array
	*/

	private function getStudentGroupFromFile($now=0) {
		$classKontingent = $this->getClassQuotaUid($now);
		$tabelleKontingente = [];
		$iconnFile = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->settings['uploadFilePathName']);
		if( file_exists( $iconnFile ) ){
			$iconArr = file( $iconnFile );
			$firstRow = array_shift( $iconArr );
			$aHeadrow = array_flip(explode( ';' , str_replace( '"' , '' , trim($firstRow))));
			foreach( $iconArr as $id=> $row) {
				$dsRw =$row;
// 				$dsRw = iconv( 'ISO-8859-15' , 'UTF-8//TRANSLIT' , $row);
				$aRw = explode( ';' , str_replace( '"' , '' , trim($dsRw) ) );
				$tab = array();
				$tab['pid'] = $this->settings['storagePid'];
				$tab['username'] = $aRw[ $aHeadrow['username'] ];
				$tab['firstname'] = $aRw[ $aHeadrow['first_name'] ];
				$tab['lastname'] = $aRw[ $aHeadrow['last_name'] ];
				$tab['email'] = $aRw[ $aHeadrow['email'] ];
				// quota
				$clsId = trim($aRw[ trim($aHeadrow['eco_klasse']) ]);
				$tab['quotaspace'] = $this->cloudquota[ $classKontingent[$clsId]['quotaUid'] ];
				$tab['quotaspace'] = trim(str_replace( 'GB' , '' , $tab['quotaspace']));
				if(empty($tab['quotaspace'])) $tab['quotaspace'] = $this->cloudquota[ $this->settings['quotaUidZero'] ];
				// insert scoolclass as first group
				$tab['grp1'] = $classKontingent[$clsId]['classShort'];
				// store in an array 
				$tabelleKontingente[$tab['username']] =$tab;
			}
		}
		return $tabelleKontingente;
	}

	/**
	* getTeacherFachbereich
	* 
	* @return array
	*/

	Public function getTeacherFachbereich() {
        $aDbIngr = $GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default'];
        $connection = new \mysqli( $aDbIngr['host'] , $aDbIngr['user'] , $aDbIngr['password'] , $aDbIngr['dbname'] );
        $sql = "SELECT * FROM fe_users WHERE eco_acronym > '';";
        $table = $connection->query( $sql );
        $connection->close();
		$teaEcouser = array();
        foreach($table as $row){
					$uid = $row['uid'];
					$teaEcouser[$uid]['pid'] = $this->settings['storagePid'];
					$teaEcouser[$uid]['username'] = $row['username'];
					$teaEcouser[$uid]['firstname'] = utf8_encode($row['first_name']);
					$teaEcouser[$uid]['lastname'] = utf8_encode($row['last_name']);
					$teaEcouser[$uid]['email'] = $row['email'];
					$teaEcouser[$uid]['quotaspace'] = trim(str_replace( 'GB' , '' , $row['cloud_quota']));
        }
          

		$fachbereiches = $this->fachbereichRepository->findAll();
		// $fachbereichCloudKey: GruppeBezeichnung aus Fachbereich
		foreach( $fachbereiches as $fb ){
		    $uid = $fb->getUid();
		    $cloudKey = $fb->getCloudKey();
		    if(!empty($cloudKey)) $fachbereichCloudKey[$uid] = $cloudKey;
		}
		
		// in Grupen einteilen
		// $rowCount: Anzahl Gruppen ermitteln
		$rowCount = 0;
		// $fbTeachers: Fachbereiche der Lehrpersonen
		$fbTeachers = $this->teacherRelationRepository->findAll();
		foreach( $fbTeachers as $ix=>$tea ){
		    $user = $tea->getTeaEcouser();
		    if( !empty($user) ) {
				$uid = $user->getUid();
                if( '.nn' == $teaEcouser[$uid]['username'] ) continue;
                if( empty($teaEcouser[$uid]['email']) ) continue;
				$teaFb = $tea->getFachbereich();
				if(!empty($fachbereichCloudKey[$teaFb])) $teaEcouser[$uid]['grp'][] = $fachbereichCloudKey[$teaFb];
                $gidCount = isset($teaEcouser[$uid]['grp']) ? count($teaEcouser[$uid]['grp']) : 0;
                if( $gidCount > $rowCount ) {$rowCount = $gidCount;}
		    }
		}
		// $tabelle: Output Lehrpersonen und Fachbereiche zusammenziehen
		$tabelle = array();
		foreach( $teaEcouser as $uid=>$teaRow ){
		    if( strpos( $teaRow['username'] , '.' ) == 0) continue;
		    $tabelle[$uid]['pid'] = $teaRow['pid'];
		    $tabelle[$uid]['username'] = $teaRow['username'];
		    $tabelle[$uid]['firstname'] = $teaRow['firstname'];
		    $tabelle[$uid]['lastname'] = $teaRow['lastname'];
		    $tabelle[$uid]['email'] = $teaRow['email'];
		    $tabelle[$uid]['quotaspace'] = !empty($teaRow['quotaspace']) ? trim(str_replace( 'GB' , '' , $teaRow['quotaspace'])) : $this->cloudquota[ $this->settings['quotaUidTeacher'] ];
		    if( !is_array($teaRow['grp']) ) continue;
		    sort($teaRow['grp']);
		    for( $gid = 0 ; $gid < $rowCount ; ++$gid ){
				$rNr = $gid+1;
				if(isset($teaRow['grp'][$gid])) $tabelle[$uid]['grp'.$rNr] = $teaRow['grp'][$gid];
		    }
		}
		return $tabelle;
	}
	
	/**
	* getClassQuotaUid
	* creates array $klasseKontingent with Quota per Klasse
	* 
	* @param int $now timestamp or empty
	* @return array
	*/
	private function getClassQuotaUid($now=0) {
		if($now == FALSE ) $now = time();
		$klasseKontingent = array();
		$today = floor( $now / (3600*24) ) * 3600 * 24;
		$fbKurzklassen = $this->kurzklasseRepository->findAll();
        foreach( $fbKurzklassen as $krzKlasse ){
            $quotaUid = $krzKlasse->getKrzCloudquota();
            $klassen = $krzKlasse->getKrzKlasse();
            if(empty($klassen)) continue; // FIXME error
            foreach( $klassen as $klasse ){
                $clsId =  trim($klasse->getUid());
                if(empty($clsId)) continue; // FIXME error
                $clsEnd = $klasse->getKlasseEnde()->getTimestamp();
                $klasseKontingent[$clsId]['classShort'] = trim($klasse->getClassShort());
                if($clsEnd >= $today){
                    $klasseKontingent[$clsId]['quotaUid'] = $quotaUid->getUid();
                }else{
                    $klasseKontingent[$clsId]['quotaUid'] = $this->settings['quotaUidZero'];
                }
            }
        }
		return $klasseKontingent;

	}

	/**
	* readQuotas
	* initialiize quota array
	* @return array
	*/
	private function readQuotas() {
		// $cloudQuota: Quotas.Array
		$cloudquotas = $this->cloudquotaRepository->findAll();
		foreach( $cloudquotas as $quota ) $this->cloudquota[ $quota->getUid() ] = trim(str_replace( 'GB' , '' , $quota->getSpeicherplatz() ));
	}
	
	/**
	* compareDatabaseWithClouddata (unused?)
	* 
	* @param array $dbData     array from this->readIntranetUsersAndCloudgroups()
	* @param array $cloudData  array from CloudUsersUtility-readFromFile_CloudUsersAndAttributes()
	* @return array
	*/
	public function compareDatabaseWithClouddata( $dbData , $cloudData ) {
			$classKontingent = $this->getClassQuotaUid($now);
			$responseArr = array();
			
			$src = array( $dbData , $cloudData );
			// sub-array for groups
			if(!is_array($src)) return $responseArr;
			
			foreach( $src as $tabIx => $table ){
				if(is_array($table)){foreach( $table as $username => $dbRow ){
					if(is_array($dbRow)){foreach($dbRow as $field => $content ){
						if( substr( $field , 0 , 3 ) == 'grp' && !empty($content) ){ 
							$src[$tabIx][$username]['groups'][$content] = $content; 
 							unset($src[$tabIx][$username][$field]); 
						}
					}}
				}}
			}
			
			$dbLabel = array( '' , 'cloud' );
			$attLabel = array( 'MaybeObsolete' , 'Missed' );

			foreach( $src as $tableIx => $table ){
				if(is_array($table)){foreach( $table as $username => $dbRow ){
						$otherTable = ( $tableIx-1 ) * ( $tableIx-1 ) ;
						if($dbRow['grp1'] == 'admin') continue;
						if($dbRow['grp1'] == 'fachbereich-daten') continue;
						if( !isset($src[$otherTable][$username]) ){
							$students = $this->ecouserRepository->findByUsername( $username );
							if( count($students) ) $responseArr[$dbLabel[$otherTable].'Users'.$attLabel[$otherTable]][$username] = $dbRow;
						}else{
							if(is_array($dbRow['groups'])){foreach($dbRow['groups'] as $colName => $groupname ){
									if(empty($groupname) ) continue;
									if( !isset($src[$otherTable][$username]['groups'][$groupname]) ){
										// set user missing or overdue in group
										$responseArr[$dbLabel[$otherTable].'Group'.$attLabel[$otherTable]][$groupname]['users'][$username] = $src[$otherTable][$username];
									}
							}}
						}
				}}
			}
			if(is_array($responseArr['cloudGroupMissed'])){foreach( $responseArr['cloudGroupMissed'] as $groupname => $grouprow ){
					// set quota for all users
					$responseArr['cloudGroupMissed'][$groupname]['quota'] = $this->cloudquota[ $classKontingent[$groupname] ];
			}}
			if(is_array($responseArr['GroupMaybeObsolete'])){foreach( $responseArr['GroupMaybeObsolete'] as $groupname => $grouprow ){
				foreach( $grouprow['users'] as $username => $row ){
					$responseArr['GroupMaybeObsolete'][$groupname][$username] = $row;
				}
				unset($responseArr['GroupMaybeObsolete'][$groupname]['users']);
			}}
			return $responseArr;
	}

}
