<?php
namespace Sfgz\SfgzUdb\Domain\Model;


/***
 *
 * This file is part of the "Sfgz User DB" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * TeacherRelation
 */
class TeacherRelation extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * fachbereich
     * 
     * @var int
     */
    protected $fachbereich = false;

    /**
     * leiter
     * 
     * @var bool
     */
    protected $leiter = false;

    /**
     * teaEcouser
     * 
     *  not works: \ Sfgz\ SfgzUdb\ Domain\ Model\ Ecouser
     * 
     * @var \TYPO3\CMS\Extbase\Domain\Model\FrontendUser
     */
    protected $teaEcouser = null;

    /**
     * Returns the fachbereich
     * 
     * @return bool $fachbereich
     */
    public function getFachbereich()
    {
        return $this->fachbereich;
    }

    /**
     * Sets the fachbereich
     * 
     * @param bool $fachbereich
     * @return void
     */
    public function setFachbereich($fachbereich)
    {
        $this->fachbereich = $fachbereich;
    }

    /**
     * Returns the leiter
     * 
     * @return bool $leiter
     */
    public function getLeiter()
    {
        return $this->leiter;
    }

    /**
     * Sets the leiter
     * 
     * @param bool $leiter
     * @return void
     */
    public function setLeiter($leiter)
    {
        $this->leiter = $leiter;
    }

    /**
     * Returns the boolean state of leiter
     * 
     * @return bool
     */
    public function isLeiter()
    {
        return $this->leiter;
    }

    /**
     * Returns the teaEcouser
     * 
     * @return \TYPO3\CMS\Extbase\Domain\Model\FrontendUser $teaEcouser
     */
    public function getTeaEcouser()
    {
        return $this->teaEcouser;
    }

    /**
     * Sets the teaEcouser
     * 
     * @param \TYPO3\CMS\Extbase\Domain\Model\FrontendUser $teaEcouser
     * @return void
     */
    public function setTeaEcouser(\TYPO3\CMS\Extbase\Domain\Model\FrontendUser $teaEcouser)
    {
        $this->teaEcouser = $teaEcouser;
    }
}
