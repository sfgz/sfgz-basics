<?php
namespace Sfgz\SfgzUdb\Domain\Model;


/***
 *
 * This file is part of the "SfgzUdb" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * CloudQuota
 */
class Cloudquota extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * bezeichnung
     * 
     * @var string
     */
    protected $bezeichnung = '';

    /**
     * speicherplatz
     * 
     * @var string
     */
    protected $speicherplatz = '';

    /**
     * Returns the bezeichnung
     * 
     * @return string $bezeichnung
     */
    public function getBezeichnung()
    {
        return $this->bezeichnung;
    }

    /**
     * Sets the bezeichnung
     * 
     * @param string $bezeichnung
     * @return void
     */
    public function setBezeichnung($bezeichnung)
    {
        $this->bezeichnung = $bezeichnung;
    }

    /**
     * Returns the speicherplatz
     * 
     * @return string $speicherplatz
     */
    public function getSpeicherplatz()
    {
        return $this->speicherplatz;
    }

    /**
     * Sets the speicherplatz
     * 
     * @param string $speicherplatz
     * @return void
     */
    public function setSpeicherplatz($speicherplatz)
    {
        $this->speicherplatz = $speicherplatz;
    }
}
