<?php
namespace Sfgz\SfgzUdb\Command;
/**
 * Class SqlCreateTableCommandController
 */
class SqlCreateTableCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
    
    public function execute(){
    
		$sNewTableName = 'tx_sfgzudb_domain_model_exportusers';
		
        // get Data from active cms-db
        $cloudQuotaUtility = new \Sfgz\SfgzUdb\Utility\IntranetUsersUtility();
		$aTabelleKontingente =  $cloudQuotaUtility->readIntranetUsersAndCloudgroups( 0 );
		$aHeadrow = array_shift($aTabelleKontingente);
//         foreach( $aHeadrow as $i => $fld ) $aHeadrow[$i] = str_replace( 'grp_' , 'grp' , $fld ) ;
        if( !is_array($aHeadrow) ) return 0;
		$iGrpAmount = count($aHeadrow) - 5; // env 6-5
		
		// Connect to DB. Ingredients to access cms-db separately since Typo3-9 no more constants TYPO3_db_host, TYPO3_db_username etc...
		$aIng = $GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default'];
        $this->connection = new \mysqli( $aIng['host'] , $aIng['user'] , $aIng['password'] , $aIng['dbname'] );
        
        $view = $this->getFachbereichView();
        $this->connection->query($view) ;
        
        $view = $this->getBenutzerView();
        $this->connection->query($view) ;
        
        // DELETE instead of TRUNCATE TABLE:  $this->connection->query( 'TRUNCATE '.$sNewTableName.'; ' );
        // DELETE all in same Page pid
        $apid = [];
        foreach( $aTabelleKontingente as $username => $user ){
            if( !isset($apid[$user['pid']]) ){
                $apid[$user['pid']] = $user['pid'];
                $this->connection->query('DELETE FROM `'.$sNewTableName.'` WHERE `'.$sNewTableName.'`.`pid` = ' . $user['pid']) ;
            }
        }
        // DELETE doubles managed on other Page 
        foreach( $aTabelleKontingente as $username => $user ){
                $exists = 0;
                $table = $this->connection->query('SELECT * FROM '.$sNewTableName.' WHERE '.$sNewTableName.'.username = "' . $username . '";');
                if( $table ){
                    foreach( $table as $row ){
                        $exists = $row['uid'];
                    }
                }
                if( $exists ){
                    unset( $aTabelleKontingente[$username] );
                }
        }
        
        // INSERT VALUES in to table.
        // Collect row in a string, store as array and implode afterward
        $aValues = [];
        foreach( $aTabelleKontingente as $username => $user ){
                $sSqlLine = ''. $user['pid'] .', ';
                $sSqlLine .= '"'. $username .'", ';
                $sSqlLine .= '"' . utf8_decode($user['firstname']) .'", ';
                $sSqlLine .= '"'. utf8_decode($user['lastname']) .'", ';
                $sSqlLine .= '"'. $user['email'] .'", ';
                $sSqlLine .= $user['quotaspace'] ? $user['quotaspace'] : 0;
                for( $gNr = 1 ; $gNr <= 5 ; ++$gNr){ $sSqlLine .= ', "' . $user['grp'.$gNr] . '"';}
                $aValues[]= '('.$sSqlLine.')';
        }

        $loops = ceil(count($aValues)/100);
        for( $index = 0 ; $index <= $loops*100 ; $index+=100 ){
            $sTabInsert = "INSERT INTO " . $sNewTableName . " ";
            $sTabInsert.= "(" . implode( ',' , $aHeadrow ) . ") ";
            $sTabInsert.= "VALUES ";
            $sTabInsert.= implode( "," , array_slice( $aValues , $index , 100 ) ) . ";";
            $this->connection->query( $sTabInsert );
//             echo  utf8_encode($sTabInsert) . '<br>';
        }
        
        $this->connection->close();
		
		return 1;
    }
    
    /**
        * getUsersUidByEcoKey
        * 
        * @param str $username
        * @param str $sNewTableName
        * @return int
        */
    private function doesUsernameExist( $username , $sNewTableName )
    {
        $sql = "SELECT * FROM `'.$sNewTableName.'` WHERE `'.$sNewTableName.'`.`username` = " . $username . ";";
        $table = $this->connection->query( $sql );
        if( !$table ) return 0;
        return 1;
     }

    /**
    * getFachbereichView
    *
    * @return int
    */
	public function getFachbereichView(){
        $select = 'SELECT fachbereichname,leiter,tea_ecouser FROM `tx_sfgzudb_domain_model_teacherrelation` join tx_sfgzudb_domain_model_fachbereich ON tx_sfgzudb_domain_model_teacherrelation.fachbereich = tx_sfgzudb_domain_model_fachbereich.uid  ORDER BY `fachbereich` ASC';
        $view = 'DROP VIEW IF EXISTS teacherrelationView; CREATE VIEW teacherrelationView AS ' . $select;
        return $view;
    }

    /**
    * getBenutzerView
    *
    * @return int
    */
	public function getBenutzerView(){
        $select = 'SELECT uid, name, email, cloud_quota AS quota, disable AS `dis.` FROM fe_users';
        $view = 'DROP VIEW IF EXISTS benutzerView; CREATE VIEW benutzerView AS ' . $select;
        return $view;
    }

	/**
	 * getStoragePid
	 *
	 * @return int
	 */
	public function getStoragePid(){
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		return $settings['plugin.']['tx_sfgzudb_edit.']['persistence.']['storagePid'];
	}
	
}
 
