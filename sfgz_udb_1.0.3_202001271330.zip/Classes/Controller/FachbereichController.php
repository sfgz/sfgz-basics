<?php
namespace Sfgz\SfgzUdb\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "SfgzUdb" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * FachbereichController
 */
class FachbereichController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * fachbereichRepository
     * 
     * @var \Sfgz\SfgzUdb\Domain\Repository\FachbereichRepository
     * @inject
     */
    protected $fachbereichRepository = null;

	/**
	 * ecouserRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\EcouserRepository
	 */
	protected $ecouserRepository = NULL;

	/**
	 * teacherRelationRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\TeacherRelationRepository
     * @inject
	 */
	protected $teacherRelationRepository = NULL;

	/**
	 * cloudquotaRepository
	 *
	 * @var \Sfgz\SfgzUdb\Domain\Repository\CloudquotaRepository
	 */
	protected $cloudquotaRepository = NULL;
	
	public function initializeAction() {
		/** get PIDs where users are stored from plugin tx_sfgzudb_edit **/
		/** set PIDs for ecouserRepository **/
		
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		$querySettings->setStoragePageIds( [ $this->settings['teacherPid'] , $this->settings['studentPid'] ] );
		$this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		
		$dQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$dQuerySettings->setRespectStoragePage(FALSE);
        $this->teacherRelationRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\TeacherRelationRepository');
		$this->teacherRelationRepository->setDefaultQuerySettings($dQuerySettings);
            $this->cloudquotaRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\CloudquotaRepository');
            $this->cloudquotaRepository->setDefaultQuerySettings($dQuerySettings);

        $this->feUserRepository = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Domain\\Repository\\FrontendUserRepository');
		$this->feUserRepository->setDefaultQuerySettings($dQuerySettings);
		
        $this->ecouserRepository = $this->objectManager->get('Sfgz\\SfgzUdb\\Domain\\Repository\\EcouserRepository');
		$this->ecouserRepository->setDefaultQuerySettings($querySettings);
	}

    /**
     * getUsedSpace
     * 
     * @return array
     */
    public function getUsedSpaceTeacher()
    {
        $aTea = [];
            $teacherUtility = new \Sfgz\SfgzUdb\Utility\IntranetUsersUtility();
            $teaEcouserGroups = $teacherUtility->getTeacherFachbereich();

        $defaultTeacherQuota = $this->cloudquotaRepository->findByUid( $this->settings['quotaUidTeacher'] );
        $strSpeicherplatz = trim(str_replace( 'GB' , '' , $defaultTeacherQuota->getSpeicherplatz() ));
        $speicherplatz = $strSpeicherplatz ? 0+$strSpeicherplatz : 0;
    
        $fachbereiches = $this->fachbereichRepository->findAll();
        foreach( $fachbereiches as $objFachbereich ){
            $objTeachers = $objFachbereich->getFbTeacher();
            foreach( $objTeachers as $objTeacher){
                $userObj = $objTeacher->getTeaEcouser();
                if($userObj){
                    $userUid = $userObj->getUid();
                    $persQuota = $teaEcouserGroups[$userUid]['quotaspace'];
                    if( $speicherplatz > $persQuota ) $persQuota = $speicherplatz;
                    $aTea[$userObj->getUsername()] = $persQuota;
                }
            }
        }
        $iTeacherAmount = count($aTea);
        $iTeacherQuotas = array_sum($aTea);
        ksort($aTea);
        $aQuota = [ 'einzeln'=>$aTea ,'speicherplatz' => $speicherplatz , 'users'=> $iTeacherAmount , 'standard'=> ( $speicherplatz * $iTeacherAmount ) , 'summe'=> $iTeacherQuotas ];
        return $aQuota;
	}

    /**
     * action list
     * 
     * @return void
     */
    public function listAction()
    {
        $fachbereiches = $this->fachbereichRepository->findAll();
        $this->view->assign('fachbereiches', $fachbereiches);
        
        $aQuota = $this->getUsedSpaceTeacher();
        $this->view->assign('quota', $aQuota );
    }

    /**
     * action upload
     * 
     * @return void
     */
    public function uploadAction()
    {
        $this->view->assign('settings', $this->settings);

	    $path['uploadFilePathName'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->settings['uploadFilePathName']);
	    $path['uploadPath'] = rtrim( dirname( $path['uploadFilePathName'] ) , '/' ) . '/';
	    $path['defaultFileName'] = pathinfo( $this->settings['uploadFilePathName'] , PATHINFO_BASENAME );

		if($this->request->hasArgument('ecoklasse')) {
            $studentUploadUtility = new \Sfgz\SfgzUdb\Utility\StudentUploadUtility();
            if( $this->request->hasArgument('dateiname') ){
                $uploadFilename = $studentUploadUtility->uploadFile( $path['uploadPath'] );
		    }
		    if($uploadFilename){
                // transform, delete and rewrite
                $messages = $studentUploadUtility->StudentUpload( $path['uploadPath'].$uploadFilename , $path['defaultFileName'] );
                $this->addFlashMessage('Datei '. pathinfo( $uploadFilename , PATHINFO_BASENAME ) .' hochgeladen und umbenannt zu ' . $path['defaultFileName']  , 'Hochladen', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		    }
		    
            $studClassFromFileCommand = new \Sfgz\SfgzUdb\Command\StudClassFromFileCommandController();
            $aMsgs = $studClassFromFileCommand->execute();
		    if( is_array($aMsgs) ){
                $message = 'Lernende mit Klassen verbunden am '.date('d.m.y H:i') . ' ';
                $this->addFlashMessage( $message . implode(',',$aMsgs) , 'Verbinden', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
                $this->redirect('done');
		    }else{
                $this->addFlashMessage('Misslungen Lernende mit Klassen verbinden.'  , 'Verbinden', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    }
		}
	    
	    $iconnfile = (file_exists($path['uploadFilePathName'])) ? filemtime($path['uploadFilePathName']): '' ;
		$this->view->assign('iconnfile', $iconnfile);
    }

    /**
     * action done
     * 
     * @return void
     */
    public function doneAction()
    {
        $this->view->assign('settings', $this->settings);

	    $path['uploadFilePathName'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->settings['uploadFilePathName']);
	    $path['uploadPath'] = rtrim( dirname( $path['uploadFilePathName'] ) , '/' ) . '/';
	    $path['defaultFileName'] = pathinfo( $this->settings['uploadFilePathName'] , PATHINFO_BASENAME );

		if($this->request->hasArgument('export')) {
            $sqlCreateTableCommandController = new \Sfgz\SfgzUdb\Command\SqlCreateTableCommandController();
            $aMsgs = $sqlCreateTableCommandController->execute();
            $this->addFlashMessage('Export-Tabelle beschrieben' , 'Export', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
            
		}elseif($this->request->hasArgument('exportfile')) {
            $cloudQuotaUtility = new \Sfgz\SfgzUdb\Utility\IntranetUsersUtility();
            $table =  $cloudQuotaUtility->downloadIntranetUsersAndCloudgroups( 0 );
            $this->download_asCsv( $table , 'export_users' );
            
		}elseif($this->request->hasArgument('ecoklasse')) {
            $studentUploadUtility = new \Sfgz\SfgzUdb\Utility\StudentUploadUtility();
            if( $this->request->hasArgument('dateiname') ){
                $uploadFilename = $studentUploadUtility->uploadFile( $path['uploadPath'] );
		    }
		    if($uploadFilename){
                // transform, delete and rewrite
                $messages = $studentUploadUtility->StudentUpload( $path['uploadPath'].$uploadFilename , $path['defaultFileName'] );
                $this->addFlashMessage('Datei '. pathinfo( $uploadFilename , PATHINFO_BASENAME ) .' hochgeladen und umbenannt zu ' . $path['defaultFileName']  , 'Hochladen', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		    }
		    
            $studClassFromFileCommand = new \Sfgz\SfgzUdb\Command\StudClassFromFileCommandController();
            $aMsgs = $studClassFromFileCommand->execute();
		    if( is_array($aMsgs) ){
                $this->addFlashMessage('Lernende mit Klassen verbunden am '.date('d.m.y H:i') . ' ' . implode(',',$aMsgs) , 'Verbinden', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		    }else{
                $this->addFlashMessage('Misslungen Lernende mit Klassen verbinden.'  , 'Verbinden', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    }
		}
	    
	    $iconnfile = (file_exists($path['uploadFilePathName'])) ? filemtime($path['uploadFilePathName']): '' ;
		$this->view->assign('iconnfile', $iconnfile);
        
    }
    

    /**
     * action downloads
     * 
     * @return void
     */
    public function downloadsAction()
    {
        $this->view->assign('settings', $this->settings);

	    $path['uploadFilePathName'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->settings['uploadFilePathName']);
	    $path['uploadPath'] = rtrim( dirname( $path['uploadFilePathName'] ) , '/' ) . '/';
	    $path['defaultFileName'] = pathinfo( $this->settings['uploadFilePathName'] , PATHINFO_BASENAME );

		if($this->request->hasArgument('export')) {
            $sqlCreateTableCommandController = new \Sfgz\SfgzUdb\Command\SqlCreateTableCommandController();
            $aMsgs = $sqlCreateTableCommandController->execute();
            $this->addFlashMessage('Export-Tabelle beschrieben' , 'Export', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
            
		}elseif($this->request->hasArgument('exportfile')) {
            $cloudQuotaUtility = new \Sfgz\SfgzUdb\Utility\IntranetUsersUtility();
            $table =  $cloudQuotaUtility->downloadIntranetUsersAndCloudgroups( 0 );
            $this->download_asCsv( $table , 'export_users' );
            
		}elseif($this->request->hasArgument('ecoklasse')) {
            $studentUploadUtility = new \Sfgz\SfgzUdb\Utility\StudentUploadUtility();
            if( $this->request->hasArgument('dateiname') ){
                $uploadFilename = $studentUploadUtility->uploadFile( $path['uploadPath'] );
		    }
		    if($uploadFilename){
                // transform, delete and rewrite
                $messages = $studentUploadUtility->StudentUpload( $path['uploadPath'].$uploadFilename , $path['defaultFileName'] );
                $this->addFlashMessage('Datei '. pathinfo( $uploadFilename , PATHINFO_BASENAME ) .' hochgeladen und umbenannt zu ' . $path['defaultFileName']  , 'Hochladen', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		    }
		    
            $studClassFromFileCommand = new \Sfgz\SfgzUdb\Command\StudClassFromFileCommandController();
            $aMsgs = $studClassFromFileCommand->execute();
		    if( is_array($aMsgs) ){
                $this->addFlashMessage('Lernende mit Klassen verbunden am '.date('d.m.y H:i') . ' ' . implode(',',$aMsgs) , 'Verbinden', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		    }else{
                $this->addFlashMessage('Misslungen Lernende mit Klassen verbinden.'  , 'Verbinden', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    }
		}
	    
	    $iconnfile = (file_exists($path['uploadFilePathName'])) ? filemtime($path['uploadFilePathName']): '' ;
		$this->view->assign('iconnfile', $iconnfile);

// 		$cloudQuotaUtility = new \Sfgz\SfgzUdb\Utility\IntranetUsersUtility();
//         $kurzklasseList = $cloudQuotaUtility->getKurzklasseList();
//         $this->view->assign('classes', $kurzklasseList );
    }
    
	protected function download_asCsv( $tablecontent , $title  ) {
            $delimiter = $this->settings['csv_import']['delimiter'];
            $encoding = $this->settings['csv_import']['encoding'];
            $tq = $this->settings['csv_import']['text_qualifier'];
            if(!count($tablecontent)) return;
            $z=0;
            $delimiter = empty($delimiter) ? ';' : $delimiter;
            $firstRow = array_shift( $tablecontent );
            if(is_array($firstRow) && count($firstRow)) {
                    $strOut = $tq . implode( $tq . $delimiter . $tq , $firstRow ) . $tq."\n";
            }else{
                    return false;
            }
            foreach( $tablecontent as $idx => $row ){
                $rowArr=array();
                foreach( $firstRow as $rowNr ){
                        if(!isset($row[$rowNr])){
                            $rowArr[] =  '' ;
                        }else{
                            $cell = $row[$rowNr];
                            if(is_numeric($cell)){
                                    $rowArr[] =  $cell ;
                            }else{
                                    $rowArr[] = $tq . $cell . $tq;
                            }
                        }
                }
                $strOut .= implode( $delimiter  , $rowArr) ."\n";
            }
            
            $headers = array(
                'Pragma'                    => 'public', 
                'Expires'                   => 0, 
                'Cache-Control'             => 'must-revalidate, post-check=0, pre-check=0',
                'Cache-Control'             => 'public',
                'Content-Description'       => 'File Transfer',
                'Content-Type'              => 'application/vnd.ms-excel',
                'Content-Disposition'       => 'attachment; filename="'.$title.'.csv"',
                'Content-Transfer-Encoding' => 'binary'        
            );

            foreach($headers as $header => $data) $this->response->setHeader($header, $data); 

            $this->response->sendHeaders();  
            
            echo $strOut;
            
            exit;
	}

    /**
     * action new
     * 
     * @return void
     */
    public function newAction()
    {
    }

    /**
     * action create
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $newFachbereich
     * @return void
     */
    public function createAction(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $newFachbereich)
    {
        $this->addFlashMessage('The object was created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->fachbereichRepository->add($newFachbereich);
        $this->redirect('list');
    }

    /**
     * action edit
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return void
     */
    public function editAction(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
        $this->editTeacherInFachbereich($fachbereich);

        $aFbTea = $this->getMemberObjects($fachbereich);
        $aSelectorList = $this->getTeacherSelector($fachbereich);
        
        $this->view->assign('fachbereich', $fachbereich);
        $this->view->assign('fbTeacher', $aFbTea );
        $this->view->assign('users', $aSelectorList );
        
        $fachbereiches = $this->fachbereichRepository->findAll();
        $this->view->assign('fachbereiches', $fachbereiches);
    }

    /**
     * editTeacherInFachbereich
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return array
     */
    public function editTeacherInFachbereich(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
        $tc = [];
        if( $this->request->hasArgument('submit') && $this->request->getArgument('submit')){
            $tc = $this->request->getArgument('submit');
            if( isset($tc['add_member']) ) {
                $ecouser = $this->feUserRepository->findByUid( $tc['add_member'] );
                $oRelation = GeneralUtility::makeInstance('Sfgz\SfgzUdb\Domain\Model\TeacherRelation');
                $oRelation->setFachbereich( $fachbereich->getUid() );
                $oRelation->setTeaEcouser( $ecouser );
                $fachbereich->addFbTeacher($oRelation);
                $this->fachbereichRepository->update($fachbereich);
                $this->addFlashMessage('The object was added.', 'add_member '.$tc['add_member'], \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
            
            }elseif( isset($tc['rem_member']) ) {
                $oRelation = $this->teacherRelationRepository->findByUid( $tc['rem_member'] );
                $fachbereich->removeFbTeacher($oRelation);
                $this->fachbereichRepository->update($fachbereich);
//                 $this->teacherRelationRepository->remove($oRelation);
                $this->addFlashMessage('The object was removed.', 'rem_member '.$tc['rem_member'], \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
            
            }elseif( isset($tc['change_member']) ) {
                $oRelation = $this->teacherRelationRepository->findByUid( $tc['change_member'] );
                $isLeiter = $oRelation->getLeiter();
                $oRelation->setLeiter( $isLeiter ? 0 : 1 );
                $this->teacherRelationRepository->update($oRelation);
                $this->addFlashMessage('The object was (not?) changed:'.$oRelation->getUid(), 'change_member '.$tc['change_member'], \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
            
            }
 			$this->persistenceManager->persistAll();
        }
        return $fachbereich;
    }

    /**
     * getMemberObjects
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return array
     */
    public function getMemberObjects(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
        $fbTeacher = $fachbereich->getFbTeacher();
        $aFbTea=['Leiter'=>[],'Member'=>[]];
        foreach( $fbTeacher as $member ){
            $leiter = $member->getLeiter();
            $oUSer = $member->getTeaEcouser();
            $username = $oUSer->getUsername();
            if( $leiter ){
                $aFbTea['Leiter'][$username] = $member;
            }else{
                $aFbTea['Member'][$username] = $member;
            }
        }
        ksort($aFbTea['Leiter']);
        ksort($aFbTea['Member']);
        $aFbAll = [];
        foreach($aFbTea as $typ => $row ) {
            foreach( $row as $nam => $memb ){
                $aFbAll[$nam] = $memb;
            }
        }
        return $aFbAll;
    }

    /**
     * getTeacherSelector
     * return teachers that not are members
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return array
     */
    public function getTeacherSelector(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
            // collect members to exclude them
            $aFbUsers = [];
            $objFbusers = $fachbereich->getFbTeacher();
            foreach($objFbusers as $fblink ){
                $oUSer = $fblink->getTeaEcouser();
                $aFbUsers[ $oUSer->getUid() ] = 1;
            }
            // collect teacher except members
            $aSort = [];
            $ecousers = $this->feUserRepository->findByPid($this->settings['teacherPid']);
            foreach( $ecousers as $user ){
                $uid = $user->getUid();
                $username = $user->getUsername();
                $aNameTest = explode( '.' , $username );
                if( empty($aNameTest[0]) || empty($aNameTest[1]) ) continue;
                if( empty($user->getEmail()) ) continue;
                if( isset($aFbUsers[$uid]) ) continue;
                $aSort[$username]=$user;
            }
            ksort($aSort);
            $aFbUserlist = [];
            foreach($aSort as $user) $aFbUserlist[$user->getUid()] = [ 'value'=>$user->getUid() , 'label'=>$user->getName() ];
            // return teachers that not are members
            return $aFbUserlist;
    }

    /**
     * action update
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return void
     */
    public function updateAction(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
		if( $this->request->hasArgument('abort') ){
            $this->redirect('list');
        }
        $this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->fachbereichRepository->update($fachbereich);
		if( $this->request->hasArgument('ok') ){
		    $this->forward('edit', NULL, NULL, array('fachbereich' => $fachbereich));
        }
        $this->redirect('list');
    }

    /**
     * action delete
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich
     * @return void
     */
    public function deleteAction(\Sfgz\SfgzUdb\Domain\Model\Fachbereich $fachbereich)
    {
        $this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->fachbereichRepository->remove($fachbereich);
        $this->redirect('list');
    }
}
