<?php
namespace Sfgz\SfgzUdb\Controller;


/***
 *
 * This file is part of the "Sfgz User DB" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 ***/
/**
 * KlasseController
 */
class KlasseController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * klasseRepository
     * 
     * @var \Sfgz\SfgzUdb\Domain\Repository\KlasseRepository
     * @inject
     */
    protected $klasseRepository = null;

    /**
     * action list
     * 
     * @return void
     */
    public function listAction()
    {
        $klasses = $this->klasseRepository->findAll();
        $this->view->assign('klasses', $klasses);
    }

    /**
     * action edit
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Klasse $klasse
     * @ignorevalidation $klasse
     * @return void
     */
    public function editAction(\Sfgz\SfgzUdb\Domain\Model\Klasse $klasse)
    {
        $this->view->assign('klasse', $klasse);
    }

    /**
     * action update
     * 
     * @param \Sfgz\SfgzUdb\Domain\Model\Klasse $klasse
     * @return void
     */
    public function updateAction(\Sfgz\SfgzUdb\Domain\Model\Klasse $klasse)
    {
        $this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->klasseRepository->update($klasse);
        $this->redirect('list');
    }
}
