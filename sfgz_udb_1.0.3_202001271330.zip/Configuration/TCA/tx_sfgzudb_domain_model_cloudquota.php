<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_cloudquota',
        'label' => 'bezeichnung',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'versioningWS' => true,
        'enablecolumns' => [
        ],
        'searchFields' => 'bezeichnung,speicherplatz',
        'iconfile' => 'EXT:sfgz_udb/Resources/Public/Icons/tx_sfgzudb_domain_model_cloudquota.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'bezeichnung, speicherplatz',
    ],
    'types' => [
        '1' => ['showitem' => 'bezeichnung, speicherplatz'],
    ],
    'columns' => [
        't3ver_label' => [
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.versionLabel',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'max' => 255,
            ],
        ],

        'bezeichnung' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_cloudquota.bezeichnung',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
        'speicherplatz' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_udb/Resources/Private/Language/locallang_db.xlf:tx_sfgzudb_domain_model_cloudquota.speicherplatz',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim'
            ],
        ],
    
    ],
];
